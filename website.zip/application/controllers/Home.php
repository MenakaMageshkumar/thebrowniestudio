<?php
ob_start();
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH."libraries/razorpay/Razorpay.php");
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
class Home extends CI_Controller {
public function __construct() {
    parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Common_model');
        $this->load->model('Sms_model');
        $this->load->helper('pushnotification_helper');
        $this->load->helper(array('url', 'file'));
        $this->load->library('session');
        // print_r($this->session->userdata());
        // print_r($_COOKIE);
        // die;
        
        // $_COOKIE['PHPSESSID'];
        // $_COOKIE['ci_session'];
        //keepme loggedin , cookieid == database_keepme_loggedin if session cleared add session again
        if(isset($_COOKIE['brownielogin_remember_me'])){
            $cookie_brownielogin_remember_me = $_COOKIE['brownielogin_remember_me'];
            $chk_match = $this->db->query("select user_id,fullname,phone_no from user_profile where keepme_loggedin ='$cookie_brownielogin_remember_me' ")->result();
            if($chk_match){
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
             if(empty($userdata)){
                 $this->session->set_userdata('brownie_webuser',$chk_match);
			     $this->session->set_userdata('brownieweb_userlogged_in','1');
             } 
            }
        }
}
        public function index()
        {
    //         $apiKey = 'AIzaSyCkMYx-6z7bZcwABmD1b2glrJsKw7jile8';
    //         $formattedAddrTo ='641113';
    //          $geocodeTo = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.$formattedAddrTo.'&sensor=false&key='.$apiKey);
    //          echo '<pre>';
    // $outputTo = json_decode($geocodeTo);
    // print_r($outputTo);
    // die;
            // print_r($this->session->userdata());
            // die;
            $userdata = $this->session->userdata('brownie_webuser');
            $data['userdata'] = $userdata;
            $data['cart_count'] =0;
            if(isset($userdata[0]->user_id)){
                $user_id =$userdata[0]->user_id;
                $data['cart_count'] = $this->get_cartcount($user_id);
            }
            $data['menu'] = 'The Brownie Studio Home Page';
            $data['banners'] ="";
            $store_id =1; // Brownie studio
            $get_webbanner = $this->db->query("select strweb_banners from stores where store_id = $store_id")->result();
            if($get_webbanner){
                $data['banners'] = $get_webbanner[0]->strweb_banners;
            }
            
            $data['collections'] = $this->Common_model->cat_collection($store_id);
            $data['bestsellers'] = $this->Common_model->getpro_list($store_id,1,0,''); //0 -list all products 1- list best selling products only
            $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
            // echo '<pre>';
            // print_r($data['search_products']);
            // die;
                $this->load->view('style_part',$data);
                $this->load->view('header_part');
                $this->load->view('index');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
        public function encode_param($param = ''){
		if(empty($param)){
			return;
		}
		$encode = base64_encode('{*}'.$param.'{*}');
		$encode = base64_encode('a%a'.$encode.'a%a');
		$encode = base64_encode('b'.$encode.'b');
		$encode = base64_encode('Ta7K'.$encode.'eyRq');
		return urlencode($encode);
	}

	function decode_param($param = ''){
		if(empty($param)){
			return;
		}
		$decode = urldecode(trim($param));
		$decode = trim(base64_decode(urldecode($decode)),'Ta7K');
		$decode = trim($decode,'eyRq');
		$decode = trim(base64_decode(urldecode($decode)),'b');
		$decode = trim(base64_decode(urldecode($decode)),'a%a');
		$decode = trim(base64_decode(urldecode($decode)),'{*}');
		return $decode;
	}

         public function about_us()
        {
                $data['menu'] = 'About Us - The Brownie Studio';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('about-us');
                $this->load->view('footer_part');
                $this->load->view('script_part');
                  
        }
        
         public function catering_request()
        {
                // $data['menu'] = 'Catering Request - The Brownie Studio';
                 $data['menu'] = 'Corporate Gifting - The Brownie Studio';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('catering_request');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
        
         public function store_location()
        {
                $data['menu'] = 'Store Location - The Brownie Studio';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('store_location');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
        // footer pages
          public function privacy_policy()
        {
                $data['menu'] = 'Privacy Policy - The Brownie Studio';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('privacy-policy');
                $this->load->view('footer_part');
                $this->load->view('script_part');
                  
        }
        
           public function terms_of_use()
        {
                $data['menu'] = 'Terms of Use - The Brownie Studio';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('terms-of-use');
                $this->load->view('footer_part');
                $this->load->view('script_part');
                  
        }
           public function refund_policy()
        {
                $data['menu'] = 'Refund Policy - The Brownie Studio ';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('refund-policy');
                $this->load->view('footer_part');
                $this->load->view('script_part');
                  
        }
            public function shipping_and_delivery()
        {
                $data['menu'] = ' Shipping and Delivery - The Brownie Studio';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                // echo '<pre>';
                // print_r($data['search_products']);die;
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('shipping-and-delivery');
                $this->load->view('footer_part');
                $this->load->view('script_part');
                  
        }
        // footer pages
        public function get_cartcount($user_id=0){
            $count =0;
            $result = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
            $count = count($result);
            return $count;
        }
        public function shop()
        {
            $data['menu'] = 'Order Cakes Online - The Brownie Studio ';
            $userdata = $this->session->userdata('brownie_webuser');
            $data['userdata'] = $userdata;
            $user_id =0;$data['cart_count'] =0;
            if(isset($userdata[0]->user_id)){
                $user_id =$userdata[0]->user_id;
                $data['cart_count'] = $this->get_cartcount($user_id);
            }    
            if($this->session->userdata('collectionby')==""){
                $data['collectionby'] = 'BROWNIE STUDIO CAKE';
            }else{
                $data['collectionby'] = $this->session->userdata('collectionby');
            }
            
            $store_id = 1; //brownie
            $pro = $this->Common_model->getpro_list($store_id,0,0,$data['collectionby']); //0 -list all products 1- list best selling products only
            $data['products'] = json_decode(json_encode($pro), FALSE);
            $data['categories']= $this->Common_model->pro_categories($store_id);
            $data['city']= $this->Common_model->get_city($store_id);
            $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data);
                $this->load->view('header_part');
                $this->load->view('shop');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
         public function product_detail()
        {
            $userdata = $this->session->userdata('brownie_webuser');
            $data['userdata'] = $userdata;
            $user_id =0;$data['cart_count'] =0;
            if(isset($userdata[0]->user_id)){
                $user_id =$userdata[0]->user_id;
                $data['cart_count'] = $this->get_cartcount($user_id);
            }    
            $product_id  = $this->uri->segment(2);
            $item_id = $this->decode_param($this->uri->segment(3));
            $store_id = 1;
            $data['product_detail'] = $this->Common_model->product_detail($store_id,$product_id,$item_id,'','',$user_id);
            $data['related_products'] = $this->Common_model->getpro_list($store_id,0,$product_id,'');
            $data['menu'] = 'Product detail - The Brownie Studio ';
            $data['product_id'] = $product_id;
            $data['item_id'] = $item_id;
            $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data);
                $this->load->view('header_part');
                $this->load->view('product_details');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
        
       
         public function login()
        {
            $store_id =1; // Brownie studio
            $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
               $data['menu'] = 'Login - The Brownie Studio ';
                $this->load->view('style_part', $data);
                $this->load->view('header_part');
                $this->load->view('login');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
         public function sign_up()
        {
            $store_id =1; // Brownie studio
            $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $data['menu'] = 'Sign Up - The Brownie Studio ';
                $this->load->view('style_part', $data);
                $this->load->view('header_part');
                $this->load->view('sign_up');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
         public function forgot_password()
        {
            $store_id =1; // Brownie studio
            $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $data['menu'] = 'Forgot password - The Brownie Studio ';
                $this->load->view('style_part', $data);
                $this->load->view('header_part');
                $this->load->view('forget_password');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
         public function my_account()
        {
            $userdata = $this->session->userdata('brownie_webuser');
            $data['userdata'] = $userdata;
    
            if(isset($userdata[0]->user_id)){
                $user_id =$userdata[0]->user_id;
                $data['cart_count'] = $this->get_cartcount($user_id);
            }
            $data['menu'] = 'My account - The Brownie Studio Home Page';
    
    $data['acc'] = $this->db->query("select * from user_profile where user_id = $user_id")->result();
    $data['address'] = $this->db->query("select * from address where user_id = $user_id")->result();
    $data['del_address'] = $this->db->query("SELECT address.id , address.address1 , address.address2 , address.landmark , area.area_locality , city.city_name , district.district , state.state , address.pincode , address.gps_coordinates , address.address_name , address.address_type , address.area_id , address.city_id , address.district_id , address.state_id , address.user_id FROM address INNER JOIN area ON area.id = address.area_id INNER JOIN city ON city.id = address.city_id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON state.state_id = address.state_id WHERE address.user_id = $user_id order BY address_type DESC")->result();
    $data['orders'] = $this->Common_model->order_list($user_id);
    $data['state_data']= $this->db->query("SELECT * from state where status!=2")->result(); 
    $data['district_data']= $this->db->query("SELECT * from district where status!=2")->result();
    $data['city_data']= $this->db->query("SELECT * from city")->result();
    $data['area_data']= $this->db->query("SELECT * from area")->result();
    $data['cur_city'] =  $this->db->query("select id,city_name from city")->result();
    $store_id =1; // Brownie studio
    $data['store_id'] = $store_id;
    $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data);
                $this->load->view('header_part');
                $this->load->view('my_account');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
public function checkout()
        {
            
    $data_cart['menu'] = 'Checkout Page - The Brownie Studio';
    $userdata = $this->session->userdata('brownie_webuser');
    $data_cart['userdata'] = $userdata;
    $user_id =0;$data['cart_count'] =0;
    if(isset($userdata[0]->user_id)){
        $user_id =$userdata[0]->user_id;
        $data['cart_count'] = $this->get_cartcount($user_id);
    }
    
    $cart_count=0;
    $cart_total =0; $grand_total =0;$discount =0;$sub_total=0; $items_in_cart=0;
    if(empty($userdata)){
         redirect(base_url("login"));
    }else{
        $user_id = $userdata[0]->user_id;
        $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
        $cart_count = count($cart_data);
        $curr_stk = '';$preloose_product_id='';
        $result = $this->db->query("select product.subcat_id,product.packtype_id,stores.packing_charges,pc_type,pc_perc,pc_unit_value,stores.delivery_charges,stores.min_dc,dc_freekm,dc_perkm,stores.delivery_note,preferred_del_date,preferred_del_time,cart.product_image,sale_unit,pri_attcolor,pri_att,att1,var1,att2,var2,att3,var3,add_variant,ptype.type_name type,product.cat_id,prodtl.pack_content,cart.item_id,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,prodtl.display_name,cart.cart_id ,cart.varient_id,cart.varient_name,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,cart.quantity,product.prod_name,product.description product_description,product.prod_img1,product.prod_id,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status,prodtl.item_availability from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product ON product.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON product.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid INNER JOIN packettype_master ptype ON product.packtype_id = ptype.id where user.user_id =$user_id and cart.order_id = 0 and cart.product_status in (0) order by cart.product_id,cart_id")->result();
        $store_id ='';
        if(empty($result )){ // cart is empty
            redirect(base_url("shop"));
        }
        $final_array = array();
        foreach($result as $data){
            $store_id = $data->store_id;
            $product_id = $data->prod_id;
            $varient_id = 0;
            $item_id = $data->item_id;
            $type = $data->type;
            $add_variant = $data->add_variant;
            $pack_content = $data->pack_content;
             if(strtoupper($type)=="LOOSE" || strtoupper($add_variant=="NO")){ //Loose product
                        $sale_unit = $data->sale_unit;
                         $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                            if($unit_dt){
                                $slunit_name =$unit_dt[0]->unit;
                            }
                            $variant_name = $pack_content.' '.$slunit_name;
                            $variant_cnt = 1;
                            $color_value = $data->pri_attcolor;
                            $size_value = trim($variant_name);
                         
                     }else{
                         $primary_attibuteid = $data->pri_att;
                         $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                         
                         //Attribute1 //variant2
                         $att1_id = $data->att1;
                         $variant1 = $data->var1;
                         $att2_id = $data->att2;
                         $variant2 = $data->var2;
                         $att3_id = $data->att3;
                         $variant3 = $data->var3;
                         
                         $variant_name = $variant1.';'.$variant2.';'.$variant3;
                         $variant_name = rtrim($variant_name, ";");
                         $color_value = $data->pri_attcolor;
                         $size_value = trim($variant_name);
                         if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                              $color_n = $variant2.';'.$variant3; 
                              $color_n = rtrim($color_n, ";");
                              $size_value = trim($color_n);
                         }
                     }
            if(strtoupper($data->display_stock)=="YES"){
                $tot_stk = $data->item_totstock;
            }else{
                $tot_stk = $data->item_moq;
            }
            $curr_stk = $tot_stk - ($data->quantity * $data->pack_content);
            if($curr_stk<0){
                    $tot_stk = 0;
                 }
            $stock = (int)$tot_stk;
            
            //if cart quantity less than stock quantity means update cart quantity as stock quantity //also update stock price
            $cart_id = $data->cart_id;
            $quantity = $data->quantity;
            $stock = round($stock,0);
            if($stock > 10){
                $stock = 10;
            }
            
            if($quantity > $stock){
                $current_stock = $stock;
                $this->Common_model->cart_price_calculation($cart_id,$current_stock,$item_id);
            }
            
            $updated_stock = $this->db->query("select * from cart where cart_id =$cart_id")->result();
            if($updated_stock){
                $cart_total = $cart_total + $updated_stock[0]->display_price;
                $stock_availability ='';
                if($updated_stock[0]->quantity == 0 || $data->item_availability==0 ){
                  $stock_availability = 'Out of stock';
                  $stock_status = 'Sold Out';  
                }
            else if($updated_stock[0]->quantity > $stock){
                $stock_availability = 'Out of stock';
                $stock_status = 'Sold Out';
            }else if($updated_stock[0]->quantity <= $stock){
                $stock_availability = 'Stock Available';
                $stock_status ='Available';
            }
            $quantity = $updated_stock[0]->quantity;
            }else{ //rare case
                $stock_availability = 'Out of stock';
                $stock_status = 'Sold Out';
                $quantity = 0;
            }
            
            // $chk_product_availability = $this->db->query("select availability from products where product_id =$product_id and availability=0 ")->result();
            // if($chk_product_availability){
            //     $stock_availability = 'Out of stock';
            //     $stock_status = 'Sold Out';
            //     $stock = $updated_stock[0]->quantity;//for unavailabilty product stock should not allow to increase + -
            // }
            $stock = round($stock,0);
            if($stock > 10){
                $stock = 10;
            }
            if(trim($updated_stock[0]->display_type)=='4'){ // range price
                $display_price = $updated_stock[0]->range_pricing;
                $lang_menu['total']= 'Estimated Total';
            }else{
                $display_price = $updated_stock[0]->display_price;
            }
            $varient_cnt = 0;
            $getcnt = explode(";",$data->varient_name); //masala;egg;corainder
            $varient_cnt = count($getcnt);//3
            $discount = $discount + ($updated_stock[0]->mrp_price - $display_price);
            $sub_total = $sub_total + $updated_stock[0]->mrp_price;
            $grand_total = $grand_total + $display_price;
            $items_in_cart =  $items_in_cart + $data->quantity;
            $min_delivery_charge =0;$delivery_note ="";
            if($data->delivery_charges==1){
                $min_delivery_charge = $data->min_dc;
                $delivery_note = $data->delivery_note;
                $dc_freekm = $data->dc_freekm;
                $dc_perkm = $data->dc_perkm;
            }
            $delivery_charges = $data->delivery_charges;

            $final_array[] = array(
                'product_id' => $product_id,
                'cart_id' => $data->cart_id,
                'category_id' =>$data->cat_id,
                'subcat_id' =>$data->subcat_id,
                'packtype_id' =>$data->packtype_id,
                'varient_id' => $data->varient_id,
                'item_id' => $data->item_id,
                'color_value'=>$color_value,
                'size_value'=>$size_value,
                'type' => $data->type,
                'varient_name' => $data->varient_name,
                'varient_cnt' => $varient_cnt,
                'quantity' => $quantity,
                'product_name' => $data->display_name,
                'product_nameold' => $data->prod_name,
                'product_description' => $data->product_description,
                'product_image' => $data->product_image,
                'store_id' => $data->store_id,
                'store_name' => $data->store_name,
                'store_image' => $data->store_image,
                'store_description' => $data->store_description,
                'user_name' => $data->user_name,
                'rate' => $updated_stock[0]->rate,
                'price' => $updated_stock[0]->price,
                'display_type' => $data->display_type,
                'display_rate' => $updated_stock[0]->display_rate,
                'display_price' => $display_price,
                'mrp_rate' => $updated_stock[0]->mrp_rate,
                'mrp_price' => $updated_stock[0]->mrp_price,
                'stock' => "$stock",
                'stock_status' => $stock_status,
                'stock_availability' => $stock_availability,
                'preferred_del_date'=>$data->preferred_del_date,
                'preferred_del_time'=>$data->preferred_del_time
                );
        }
        $cart_total = round($cart_total);
    }
    
    //calculate packing charge 
    $est_packing_charge=0;
    if($result){
            $packing_charges = $result[0]->packing_charges;
            if($packing_charges ==0){ //disable // packing charge = 0
                    $est_packing_charge = 0;
                } 
                else { //packing charges enabled for this store
                    $items = $items_in_cart;
                    $pc_type = $result[0]->pc_type;
                    $pc_perc = $result[0]->pc_perc;
                    $pc_unit_value = $result[0]->pc_unit_value;
                    if($pc_type==0){ //percwise
                    $est_packing_charge = round(($grand_total * ($pc_perc/100)),0);
                    }else{ //unitwise
                    $est_packing_charge =  round(($items * $pc_unit_value),0);
                    }   
                }
    }
   
    $data_cart['cart_data'] = $final_array;
    $data_cart['cart_count']= $cart_count;
    $data_cart['cart_total']= $cart_total;
    $data_cart['sub_total']= $sub_total;    
    $data_cart['discount'] =$discount;
    $data_cart['delivery_note'] = $delivery_note;
    $data_cart['delivery_charges'] = $delivery_charges;
    $data_cart['packing_charges'] = $packing_charges;
    $data_cart['personal_dtl'] = $this->db->query("SELECT usr.user_type,usr.fullname,usr.phone_no,usr.email FROM user_profile usr WHERE usr.user_id =$user_id ")->result();
    $data_cart['current_address'] = $this->db->query("SELECT address.id,address.user_id,address.address1,address.address2,address.landmark,address.area_id,area.area_locality,address.city_id,city.city_name,district.district,address.district_id,state.state,address.state_id,address.pincode,address.address_name,address.gps_coordinates FROM address INNER JOIN area ON address.area_id = area.id INNER JOIN city ON address.city_id = city.id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON address.state_id = state.state_id WHERE address.user_id =$user_id AND address.address_type =1")->result();
    if(isset($data_cart['current_address'][0])){
    if($data_cart['current_address'][0]->city_id==1){ //For Chennai km wise charge
        $delivery_charge = $min_delivery_charge;
    }else if($data_cart['current_address'][0]->state_id==1){ //Outside Chennai inside Tamil Nadu: 75 Rs
        $delivery_charge = 75;
    }else{
        $delivery_charge = 130;
    }
    }else{
        $delivery_charge = $min_delivery_charge;
    }
    $data_cart['saved_address'] = $this->db->query("SELECT address.delto_name,delto_contact,address.id,address.user_id,address.address1,address.address2,address.landmark,address.area_id,area.area_locality,address.city_id,city.city_name,district.district,address.district_id,state.state,address.state_id,address.pincode,address.address_name,address.gps_coordinates FROM address INNER JOIN area ON address.area_id = area.id INNER JOIN city ON address.city_id = city.id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON address.state_id = state.state_id WHERE address.user_id =$user_id AND address.address_type !=1 order by address.id desc")->result();
    //  echo '<pre>';            
    // print_r($grand_total);
    //  echo '<pre>';            
    // print_r($delivery_charge);
    //  echo '<pre>';            
    // print_r($est_packing_charge);
    // die;
    $data_cart['grand_total'] = $grand_total + $delivery_charge + $est_packing_charge;
    $data_cart['min_delivery_charge'] = round($delivery_charge,0);
    $data_cart['est_packing_charge'] = round($est_packing_charge,0);
    $data_cart['city_list'] = $this->db->query("SELECT * FROM city")->result(); 
    $data_cart['district_list'] = $this->db->query("SELECT * FROM district where status=1")->result(); 
    $data_cart['state_list'] = $this->db->query("SELECT * FROM state where status=1")->result();  
    $data_cart['area_list'] = $this->db->query("SELECT * FROM area")->result();  
    $data_cart['user_id']= $user_id;
    if(isset($data_cart['personal_dtl'][0])){
        $user_type = $data_cart['personal_dtl'][0]->user_type;
    }else{
        $user_type = 1;
    }
    $data_cart['user_type']= $user_type;
    if($user_type==2){//sales man
        $data_cart['current_address'] = "";
    }
    // echo '<pre>';
    // print_r($data_cart['cart_data']);
    //  die;
    $store_id =1; // Brownie studio
    $data_cart['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data_cart);
                $this->load->view('header_part');
                $this->load->view('checkout');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
           public function confirm_order()
        {
              $data['ord_id'] = $this->uri->segment(2);
               $data['menu'] = 'The Brownie Studio - Confirm Order';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('confirm_order');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
         public function contact()
        {
                $data['menu'] = 'Contact Us - The Brownie Studio ';
                $userdata = $this->session->userdata('brownie_webuser');
                $data['userdata'] = $userdata;
                $user_id =0;$data['cart_count'] =0;
                if(isset($userdata[0]->user_id)){
                    $user_id =$userdata[0]->user_id;
                    $data['cart_count'] = $this->get_cartcount($user_id);
                } 
                $store_id =1; // Brownie studio
                $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part' ,$data);
                $this->load->view('header_part');
                $this->load->view('contact');
                $this->load->view('footer_part');
                $this->load->view('script_part');
        }
        // forgot password
public function verify_phoneno_forgot(){
    $phone_no = '91'.$_POST['phone_no'];
    $phone_result = $this->db->query("select phone_no from user_profile where phone_no =$phone_no and (status=2 || status=0) ")->result();
        // if(!empty($phone_result)){
        //   echo '0';
        //   die;
        // }
    $otp = rand(1111, 9999);
    $phone_num_exists = $this->db->query("select * from user_profile where phone_no ='$phone_no' and  status=1")->result(); // active user
         if($phone_num_exists)
         { 
            $user_id = $phone_num_exists[0]->user_id;
            $this->db->where('user_id',$user_id);
            $this->db->set('otp',$otp);
            $status = $this->db->update('user_profile');
        }
        else
        { 
            echo '0';
            die;
        }
        $message = 'your OTP is :';
        $message_otp = $otp;
        $message_final = $message.$message_otp;
        $result1 = $this->Sms_model->send_sms(
                                    91,
                                    $_POST['phone_no'],
                                    $message_otp
                                );
        print_r($result1);
    echo '1';
}
// forgot password otp verificaion
public function verify_otpcode_forgot(){
    $phone_no = '91'.$_POST['phone_no'];
    $otp = $_POST['otp_code'];
    $verifyotp = $this->db->query("select phone_no from user_profile where phone_no = $phone_no and otp = $otp")->result();
    if($verifyotp){
        echo '1';
        die;
    }
    echo '0';
}
// update password
public function update_password(){
    
        $phone_no = '91'.$_POST['phone_no'];
        $pass = md5($_POST['password']);
        $data['phone_no'] = '91'.$_POST['phone_no'];
        $data['password'] = md5($_POST['password']);
        $data['otp'] = $_POST['otp'];
        $data['status'] = 1;
        $status = $this->db->update('user_profile',$data,array('phone_no'=>$phone_no));    
        // $status = $this->db->query("update user_profile set password = $pass , otp = 1111 where 'phone_no'=>$phone_no"); 
        // echo  $status;
        $result1 = $this->db->query("select email,user_id,fullname,phone_no from user_profile where phone_no ='$phone_no'")->result();
			$this->session->set_userdata('brownie_webuser',$result1);
			$this->session->set_userdata('brownieweb_userlogged_in');
			$email = $result1[0]->email;
// 			mail start
 //send welcome mail to Customer
            if(trim($email)!=''){
                $to_receiver_email = $email ;
                $cust_name = $result1[0]->fullname;;
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Password Updated";
                $dt['heading'] = "Password Updated";
             $dt['message'] = 
"Dear $cust_name, <br>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Alert! Your <strong>  The Brownie Studio </strong>   account password has been updated. <br>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Please reach out to us at <strong>  thebrowniestudio@gmail.com </strong>, if this was not done by you. <br><br>

Regards,<br>
<strong>  The Brownie Studio </strong>  
  ";
$message_html = $this->load->view('template/email_template2', $dt, TRUE);
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                 
                 if($response['status']==0)
                 {
                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                 }
            }

      
// mail end
         echo '1';
        
}
// password updation end
// register function call
public function verify_phoneno()
{
    $phone_no = '91'.$_POST['phone_no'];
     $phone_result = $this->db->query("select phone_no from user_profile where phone_no =$phone_no and status = 1")->result();
        if(!empty($phone_result)){
           echo '0';
           die;
        }
    
    $otp = rand(1111, 9999);
    $phone_num_exists = $this->db->query("select * from user_profile where phone_no ='$phone_no' and (status=0 || status=2)")->result(); //incomplete registration //agn trying to register
        if($phone_num_exists){ //partially verified user
        $user_id = $phone_num_exists[0]->user_id;
        $this->db->where('user_id',$user_id);
        $this->db->set('otp',$otp);
        $status = $this->db->update('user_profile');
        }
        else{ //new user
        $status= $this->db->insert('user_profile', array('phone_no'=>$phone_no,'otp' =>$otp,'appid'=>'H2HWeb')); //default app
        $this->db->where("phone_no = '".$phone_no."'");
        $query = $this->db->get('user_profile');
        $rs = $query->row();
        $user_id = $rs->user_id;
        }
            $message = 'your OTP is :';
            $message_otp = $otp;
            $message_final = $message.$message_otp;
            $result1 = $this->Sms_model->send_sms(
                                        91,
                                        $_POST['phone_no'],
                                        $message_otp
                                    );
            print_r($result1);
    
    echo '1';
}
// otp verification
public function verify_otpcode(){
    $phone_no = '91'.$_POST['phone_no'];
    $otp = $_POST['otp_code'];
    $verifyotp = $this->db->query("select phone_no from user_profile where phone_no = $phone_no and otp = $otp")->result();
    if($verifyotp){
        $this->db->query("update user_profile set otp_verify_status = 1 where phone_no = $phone_no");
        echo '1';
        die;
    }
    echo '0';
}
// register function
public function user_register(){
    
     if(isset($_POST['email'])){
            if($_POST['email']!=''){
        $cust_email = $_POST['email'];
        $chk_email_address = $this->db->query("Select * from user_profile where email ='$cust_email'")->result();
        if(count($chk_email_address) > 0 ){
            echo '2';
             die;
        }
            }
        }
        $phone_no = '91'.$_POST['phone_no'];
        $phone_result = $this->db->query("select phone_no from user_profile where phone_no =$phone_no and status = 1")->result();
        if(!empty($phone_result)){
           echo '3';
           die;
        }
        $chk_otp_verified = $this->db->query("Select * from user_profile where phone_no =$phone_no and otp_verify_status=0")->result();
        if(count($chk_otp_verified) > 0 ){
            echo '4';
             die;
        }
        
        $data['phone_no'] = '91'.$_POST['phone_no'];
        $data['fullname'] = $_POST['fullname'];
        $data['email'] = $_POST['email'];
        $data['password'] = md5($_POST['password']);
        $data['current_cityid'] = $_POST['city_id'];
        $data['date_registered'] = date('Y-m-d H:i:s');
        $data['status'] = 1;
        $status = $this->db->update('user_profile',$data,array('phone_no'=>$phone_no));    
        $result = $this->db->query("select user_id,fullname,phone_no from user_profile where phone_no ='$phone_no'")->result();
			$this->session->set_userdata('brownie_webuser',$result);
			$this->session->set_userdata('brownieweb_userlogged_in');
			$email = $data['email'];
// 			mail start
 //send welcome mail to Customer
            if(trim($email)!=''){
                $to_receiver_email = $email ;
                $cust_name = $data['fullname'];
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Welcome to The Brownie Studio!";
                $dt['heading'] = "Welcome to The Brownie Studio!";
             $dt['message'] = 
                "Dear $cust_name, <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  Welcome to <strong> The Brownie Studio! </strong>  <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; We wish to enrich your shopping experience with wide range of stores and products.<br>
                 
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Enjoy your shopping days! <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; For any support reach us at <strong>thebrowniestudio@gmail.com </strong><br><br>

Regards,<br>
<strong>  The Brownie Studio </strong>  ";
$message_html = $this->load->view('template/email_template', $dt, TRUE);
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                 
                 if($response['status']==0)
                 {
                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                 }
            }

      
// mail end
         echo '1';
        
}
// register function call end
public function ajax_filterproduct(){
    $cake_type = 0; $city = 0;
    //sort_by:sort_by,category:category,cake_type:cake_type,city:city
    if(isset($_POST)){
        $fil_sortby ="";$where_filter="";
        if(isset($_POST['sort_by']) && $_POST['sort_by']!=""){
            $sort_by  =$_POST['sort_by'];
            if($sort_by==4){ //Price, high to low
                $fil_sortby = "order by mrp_price DESC";
            }
            else if($sort_by==3){ //Price, low to high
                $fil_sortby = "order by mrp_price ASC";
            }else {
                $fil_sortby = "";
            }
        }
         if(isset($_POST['category']) && $_POST['category']!="" && $_POST['category']!=0){
             $this->session->set_userdata('collectionby',"");// on change category remove previously saved category name
            $filter_category  =$_POST['category'];
            //$filter_category = implode(",",$filter_category);
            if($filter_category!=""){
            $where_filter = "and pro.subcat_id in ($filter_category)";
            }
        }
        $collectionby = $this->session->userdata('collectionby');
        if(isset($collectionby) && $collectionby!="" && $_POST['category']==0){ // from home page category wise filter
            if($collectionby!=""){ // BROWNIE STUDIO CAKE means ALL
                $where_filter = "and pro.cat_name = '$collectionby'";
                }
        }
        if(isset($_POST['cake_type']) && $_POST['cake_type']!=""){
            $cake_type = $_POST['cake_type'];
            //$where_filter = $where_filter." and prodtl.display_name like '%$search_key%'";
        }
        if(isset($_POST['city']) && $_POST['city']!=""){
            $city = $_POST['city'];
            if($city=="-1"){ //for all cities list only Brownies //for jar also same category so packtype condition added packtype_id=4 = "BOX"
                $where_filter = $where_filter." and pro.subcat_id = 4 and pro.packtype_id=4";
            }

        }
        
                $store_id = 1; //Brownie
                $products = $this->Common_model->filterpro_list($store_id,$fil_sortby,$where_filter,$_POST);
                // print_r($products);
                // die;
                $pro_cnt = count($products);
                $product_filtered = json_decode(json_encode($products), FALSE);
                if($product_filtered) {
                    $i =1;
                foreach($product_filtered as $pro){ ?>
                    <input type="hidden" value="<?php echo $pro_cnt;?>" id="pro_cnt">
                <div class="mx-auto col-xl-3 col-lg-4 col-md-4 col-sm-6 col-6">
						<div class="cake_feature_item p-0">
						        <a href="<?php echo base_url('product_detail/'.$pro->prod_id.'/'.$this->encode_param($pro->prod_itemid)) ?>">
    							<div class="cake_img">
    								<img src="<?php echo base_url('../'.$pro->prod_img1) ?>" alt="" style="width:270px;height:226px">
    							</div>
    						</a>
							<div class="cake_text">
								<a  href="<?php echo base_url('product_detail/'.$pro->prod_id.'/'.$this->encode_param($pro->prod_itemid)) ?>"><h3 class="font-weight-normal"><?php echo $pro->prod_name; ?></h3></a>
								 <div class="pb-0 row card-body col-12 mx-auto pt-1 px-1 pb-0">
								     	<h5 class="font_15 font-weight-light col-xl-3 px-0 col-lg-6  h6 my-auto gold_color" id="price-<?php echo $i?>" >Rs.&nbsp;<?php echo $pro->display_price; ?></h5>
										<select class="text-center rounded-0 form-control px-0 col-xl-4 col-lg-6 font-weight-normal  my-xl-auto my-lg-auto my-2 mx-auto best_seller_dropdown" id="<?php echo $i?>" style="font-size:small" onchange="variantChange(this)" >
										    <!--<option data-display="Default" value="1">0.5kg</option>-->
										    <?php $var_ary = $pro->variant;
										    foreach ($var_ary as $var){ ?>
											<option class="text-center" value="<?php echo $var->item_id;?>"><?php echo $var->var_value;?></option>
											<?php } ?>
										</select>
								        <h5 class=" px-0 col-12 col-xl-4 col-lg-12 my-xl-auto my-lg-auto my-2 mx-auto text-center"> <a id="link-<?php echo $i?>" class="text-center pest_btn text-uppercase my-2 col" href="<?php echo base_url('product_detail/'.$pro->prod_id.'/'.$this->encode_param($pro->prod_itemid)) ?>">Add</a></h5>
								        <!--<h5 class=" px-0 col-12 col-xl-4 col-lg-12 my-xl-auto my-lg-auto my-2 mx-auto text-center"> <a class="text-center pest_btn text-uppercase my-2 col" href="<?php // echo $pro->prod_id.'|'.$this->encode_param($pro->prod_itemid); ?>" id="add_to_cart" onclick='return add_cart(1)' >Add</a></h5>-->
								        <!-- Button trigger modal -->
                                            <!--<button type="button" class=" py-3 btn btn-primary mx-auto mt-2 col-12 bg-transparent blue_color_custom border-top border-bottom-0 border-right-0 border-left-0 rounded-0 font-weight-normal chk" data-toggle="modal" data-target="#quick_view" data-id="<?= $pro->prod_itemid?>" style="font-size: 13px;">-->
                                            <button type="button" class=" py-3 btn btn-primary mx-auto mt-2 col-12 bg-transparent blue_color_custom border-top border-bottom-0 border-right-0 border-left-0 rounded-0 font-weight-normal" onclick="quickview(<?php echo $pro->prod_id?>,<?php echo $pro->prod_itemid?>)" data-toggle="modal" data-id="" style="font-size: 13px;">
                                              Quick View
                                            </button>
                                     
								</div>
							</div>
						</div>
					</div>
                <?php $i++; }} else { // count zero ?>
                    <input type="hidden" value="<?php echo $pro_cnt;?>" id="pro_cnt"> 
                    <h2 class="title_small text-center col font_15 text-danger">No products available</h2>
<?php } ?>
            <!--pagination call-->
            <!--<script>pagination_read();</script>-->
            <!--pagination call end-->
            
    <?php }else{
        echo 'Something went wrong';
    }
}
public function add_cart(){
    if($_POST['item_id']==0 || $_POST['item_id']==""){
        echo json_encode(array('status'=>0,'message'=>'Please select product variant'));
        exit;
    }
    $userdata = $this->session->userdata('brownie_webuser');
    $data['userdata'] = $userdata;
    if(empty($userdata)){
         echo json_encode(array('status'=>0,'message'=>'Please login your account'));
        exit;
    }else{
    $user_id = $userdata[0]->user_id;
    $product_id = $_POST['product_id'];
    $item_id = $_POST['item_id'];
    $quantity = $_POST['quantity'];
    $message_on_cake = trim($_POST['message_on_cake']);
    $preferred_del_date = trim($_POST['preferred_del_date']);
    $preferred_del_time = trim($_POST['preferred_del_time']);
    $notes_on_chef = trim($_POST['notes_on_chef']);
    $pro = $this->db->query("select * from product where prod_id = $product_id")->result();
    if(empty($pro)){
         echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
    }
    $store_id = $pro[0]->store_id;
    $variant_name ='';
    $get_var = $this->db->query("SELECT pro.image_type,prodtl.item_images,pri_att,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id = $store_id AND prodtl.prod_itemid=$item_id AND pro.prod_status = 1 and prodtl.item_availability = 1 order by pro.prod_id")->result();
    if($get_var){
    //get variant name 
                $type = $get_var[0]->type;
                $add_variant = $get_var[0]->add_variant;
                $sale_unit = $get_var[0]->sale_unit;
                $pack_content = $get_var[0]->pack_content;
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;

                 }else{
                     $primary_attibuteid = $get_var[0]->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     //Attribute1 //variant2
                     $att1_id = $get_var[0]->att1;
                     $variant1 = $get_var[0]->var1;
                     $att2_id = $get_var[0]->att2;
                     $variant2 = $get_var[0]->var2;
                     $att3_id = $get_var[0]->att3;
                     $variant3 = $get_var[0]->var3;                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                 }
                 //
    }
    if($get_var[0]->image_type==2){ // 1 - generic 2 - variant
        $item_images  = $get_var[0]->item_images;
        $ex_images = explode("|", $item_images); 
        $product_image =  $ex_images[0];
        if($product_image==""){
        $product_image = $pro[0]->prod_img1;
        }
    }else{
        $product_image  = $pro[0]->prod_img1;
    }
    // print_r($product_image);
    // die;
    $product_desc  = $pro[0]->description;
    //for existing item update quantity and price
        $check_cart = $this->db->query("select * from cart where user_id = $user_id and product_id = $product_id and store_id =$store_id and item_id = $item_id and order_id = 0  and product_status =0 AND preferred_del_date='$preferred_del_date' AND preferred_del_time='$preferred_del_time' AND message_on_cake='$message_on_cake'")->result();
        if($check_cart) {
            $cart_id  = $check_cart[0]->cart_id;
            $quantity =  $check_cart[0]->quantity + $quantity;
        }
    $pro_data = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id = prodtl.prod_id  inner join packettype_master packtype ON packtype.id = pro.packtype_id where pro.prod_id = $product_id and prodtl.prod_itemid=$item_id")->result();
        $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0;
        $billing_rate =0; $billing_price=0;
        $display_rate =0; $display_price=0;
        $mrp_rate = 0; $mrp_price = 0;
        $range_pricing = 0;
        if($pro_data){
            $type = $pro_data[0]->type_name;
                //Price 
               $price_to_display = $pro_data[0]->price_to_display;
               $mrp_prc = $pro_data[0]->mrp_price; 
               $mop_prc = $pro_data[0]->mop_price; 
               $offer_prc = $pro_data[0]->offer_price; 
               if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==2){ //Mop
                        $display_rate =  $mop_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==3){ //Offer price
                        $display_rate =  $offer_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==4){ //range price
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                        $range_pricing =  (str_replace(',','',$mop_prc) * $quantity) .' - ₹ '.(str_replace(',','',$mrp_prc) * $quantity);
                    }else{
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                    }
               }
                ///.....///
        
        
                 ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_prc);
        $mrp_price = str_replace(',','',$mrp_prc) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display;
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_prc;
            $billing_price = str_replace(',','',$mrp_prc) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->hsn_code;
        $CGSTperc = $pro_data[0]->cgst;
        $SGST_IGSTperc = $pro_data[0]->sgst;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        }
        $display_name = $pro_data[0]->display_name;
        //for same item different message and delivery date will come so add as seperate product
    //$check_cart = $this->db->query("select * from cart where user_id = $user_id and product_id = $product_id and store_id =$store_id and item_id = $item_id and order_id = 0  and product_status =0")->result();
    $check_cart = $this->db->query("select * from cart where user_id = $user_id and product_id = $product_id and store_id =$store_id and item_id = $item_id and order_id = 0  and product_status =0 AND preferred_del_date='$preferred_del_date' AND preferred_del_time='$preferred_del_time' AND message_on_cake='$message_on_cake'")->result();
    if($check_cart) { //update
            $status  = $this->db->query("update cart set product_name = '$display_name',quantity = $quantity,rate ='$billing_rate', price ='$billing_price',mrp_rate='$mrp_rate',mrp_price='$mrp_price',billing_type= '$billing_type',base_amt ='$base_amt',HSN_code='$HSN_code',CGST='$CGST',SGST_IGST='$SGST_IGST',display_rate='$display_rate',display_price='$display_price',display_type= '$display_type',range_pricing='$range_pricing',message_on_cake='$message_on_cake',preferred_del_date='$preferred_del_date',preferred_del_time='$preferred_del_time',notes_on_chef='$notes_on_chef' where cart_id = $cart_id");                }
    else{ //insert
       $status= $this->db->insert('cart', array('user_id'=>$user_id,'product_name'=>$display_name,'product_id'=>$product_id,'store_id'=>$store_id,'item_id'=>$item_id,'quantity'=>$quantity,'product_desc'=>$product_desc,'product_image'=>$product_image,'rate'=>$billing_rate,'price'=>$billing_price,'mrp_rate'=>$mrp_rate,'billing_type'=>$billing_type,'mrp_price'=>$mrp_price,'type'=>$type,'varient_name'=>$variant_name,'product_status'=>0,'base_amt'=>$base_amt,'HSN_code'=>$HSN_code,'CGST'=>$CGST,'SGST_IGST'=>$SGST_IGST,'display_rate'=>$display_rate,'display_price'=>$display_price,'display_type'=> $display_type,'range_pricing'=> $range_pricing,'message_on_cake'=>$message_on_cake,'preferred_del_date'=>$preferred_del_date,'preferred_del_time'=>$preferred_del_time,'notes_on_chef'=>$notes_on_chef));    
    }
     //for same order update preferred date and time same
           $this->db->query("update cart set preferred_del_date='$preferred_del_date',preferred_del_time='$preferred_del_time' where user_id = $user_id and order_id=0");   
if($status){
        $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
        $cart_count = count($cart_data);
         echo json_encode(array('status'=>1,'message'=>'Product added to cart successfully','count' => $cart_count));
        exit;
}
else {
    echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
}}
}
public function cart(){
    $data_cart['menu'] = 'Cart - The Brownie Studio';
    $userdata = $this->session->userdata('brownie_webuser');
    $data_cart['userdata'] = $userdata;
    $cart_count=0;
    $cart_total =0; $grand_total =0;$discount =0;$sub_total=0;
if(empty($userdata)){
     redirect(base_url("login"));
}else{
    $user_id = $userdata[0]->user_id;
    $data_cart['cart_count'] = $this->get_cartcount($user_id);
    $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    $cart_count = count($cart_data);
    $curr_stk = '';$preloose_product_id='';
    $result = $this->db->query("select  product.subcat_id,cart.message_on_cake,cart.preferred_del_date,preferred_del_time,cart.product_image,sale_unit,pri_attcolor,pri_att,att1,var1,att2,var2,att3,var3,add_variant,ptype.type_name type,product.cat_id,prodtl.pack_content,cart.item_id,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,prodtl.display_name,cart.cart_id ,cart.varient_id,cart.varient_name,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,cart.quantity,product.prod_name,product.description product_description,product.prod_img1,product.prod_id,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status,prodtl.item_availability from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product ON product.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON product.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid INNER JOIN packettype_master ptype ON product.packtype_id = ptype.id where user.user_id =$user_id and cart.order_id = 0 and cart.product_status in (0) order by cart.product_id,cart_id")->result();
    $store_id ='';
    $final_array = array();
    foreach($result as $data){
        $store_id = $data->store_id;
        $product_id = $data->prod_id;
        $varient_id = 0;
        $item_id = $data->item_id;
        $type = $data->type;
        $add_variant = $data->add_variant;
        $pack_content = $data->pack_content;
        
        $type_var =""; 
         if($data->att1!="" && $data->var1!="" && $data->att1==7 ){ //type
                     $type_var = $data->var1;
            }
            if($data->att2!="" && $data->var2!="" && $data->att2==7 ){//type
                     $type_var = $data->var2;
            }
            if($data->att3!="" && $data->var3!="" && $data->att3==7 ){//type
                     $type_var = $data->var3;
            }
            
                $var1 = $data->var1;
                $var2 = $data->var2;
                $var3 = $data->var3;

         if(strtoupper($type)=="LOOSE" || strtoupper($add_variant=="NO")){ //Loose product
                    $sale_unit = $data->sale_unit;
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $data->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $data->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $data->att1;
                     $variant1 = $data->var1;
                     $att2_id = $data->att2;
                     $variant2 = $data->var2;
                     $att3_id = $data->att3;
                     $variant3 = $data->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $data->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $color_n = $variant2.';'.$variant3; 
                          $color_n = rtrim($color_n, ";");
                          $size_value = trim($color_n);
                     }
                 }
        if(strtoupper($data->display_stock)=="YES"){
            $tot_stk = $data->item_totstock;
        }else{
            $tot_stk = $data->item_moq;
        }
        $curr_stk = $tot_stk - ($data->quantity * $data->pack_content);
        if($curr_stk<0){
                $tot_stk = 0;
             }
        $stock = (int)$tot_stk;
        
        //if cart quantity less than stock quantity means update cart quantity as stock quantity //also update stock price
        $cart_id = $data->cart_id;
        $quantity = $data->quantity;
        $stock = round($stock,0);
        if($stock > 10){
            $stock = 10;
        }
        
        if($quantity > $stock){
            $current_stock = $stock;
            $this->Common_model->cart_price_calculation($cart_id,$current_stock,$item_id);
        }
        
        $updated_stock = $this->db->query("select * from cart where cart_id =$cart_id")->result();
        if($updated_stock){
            $cart_total = $cart_total + $updated_stock[0]->display_price;
            $stock_availability ='';
            if($updated_stock[0]->quantity == 0 || $data->item_availability==0 ){
              $stock_availability = 'Out of stock';
              $stock_status = 'Sold Out';  
            }
        else if($updated_stock[0]->quantity > $stock){
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
        }else if($updated_stock[0]->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }
        $quantity = $updated_stock[0]->quantity;
        }else{ //rare case
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
            $quantity = 0;
        }
        
        // $chk_product_availability = $this->db->query("select availability from products where product_id =$product_id and availability=0 ")->result();
        // if($chk_product_availability){
        //     $stock_availability = 'Out of stock';
        //     $stock_status = 'Sold Out';
        //     $stock = $updated_stock[0]->quantity;//for unavailabilty product stock should not allow to increase + -
        // }
        $stock = round($stock,0);
        if($stock > 10){
            $stock = 10;
        }
        if(trim($updated_stock[0]->display_type)=='4'){ // range price
            $display_price = $updated_stock[0]->range_pricing;
            $lang_menu['total']= 'Estimated Total';
        }else{
            $display_price = $updated_stock[0]->display_price;
        }
        $varient_cnt = 0;
        $getcnt = explode(";",$data->varient_name); //masala;egg;corainder
        $varient_cnt = count($getcnt);//3
        $discount = $discount + ($updated_stock[0]->mrp_price - $display_price);
        $sub_total = $sub_total + $updated_stock[0]->mrp_price;
        $grand_total = $grand_total + $display_price;
        $final_array[] = array(
            'product_id' => $product_id,
            'cart_id' => $data->cart_id,
            'category_id' =>$data->cat_id,
            'varient_id' => $data->varient_id,
            'item_id' => $data->item_id,
            'color_value'=>$color_value,
            'size_value'=>$size_value,
            'type' => $data->type,
            'varient_name' => $data->varient_name,
            'varient_cnt' => $varient_cnt,
            'quantity' => $quantity,
            'product_name' => $data->display_name,
            'product_nameold' => $data->prod_name,
            'product_description' => $data->product_description,
            'product_image' => $data->product_image,
            'store_id' => $data->store_id,
            'store_name' => $data->store_name,
            'store_image' => $data->store_image,
            'store_description' => $data->store_description,
            'user_name' => $data->user_name,
            'rate' => $updated_stock[0]->rate,
            'price' => $updated_stock[0]->price,
            'display_type' => $data->display_type,
            'display_rate' => $updated_stock[0]->display_rate,
            'display_price' => $display_price,
            'mrp_rate' => $updated_stock[0]->mrp_rate,
            'mrp_price' => $updated_stock[0]->mrp_price,
            'stock' => "$stock",
            'stock_status' => $stock_status,
            'stock_availability' => $stock_availability,
            'type_var'=>$type_var,
            'var1'=>$var1,
            'var2'=>$var2,
            'var3'=>$var3,
            'preferred_del_date'=>$data->preferred_del_date,
            'preferred_del_time'=>$data->preferred_del_time,
            'message_on_cake'=>$data->message_on_cake,
            'subcat_id' =>$data->subcat_id
            );
    }
    $cart_total = round($cart_total);
}
//echo '<pre>';
//print_r($final_array);
//die;
    $data_cart['cart_data'] = $final_array;
    $data_cart['cart_count']= $cart_count;
    $data_cart['cart_total']= $cart_total;
    $data_cart['sub_total']= $sub_total;    
    $data_cart['discount'] =$discount;
    $data_cart['grand_total'] =$grand_total;
    $store_id =1; // Brownie studio
    $data_cart['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data_cart);
                $this->load->view('header_part');
                $this->load->view('cart');
                $this->load->view('footer_part');
                $this->load->view('script_part');
}
public function add_cartquantity(){
if(!isset($_POST['cart_id']) || empty($_POST['cart_id']) || !isset($_POST['quantity']) || empty($_POST['quantity'])){
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
    }
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];
    if($quantity==0){
        echo json_encode(array('status'=>0,'message'=>'Please check quantity'));
        exit;
    }
    $check_cart = $this->db->query("select cart.* from cart  inner join product on product.prod_id = cart.product_id where cart_id =$cart_id ")->result();
     if(empty($check_cart)){
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
    }
    $user_id = $check_cart[0]->user_id;    
    $store_id = $check_cart[0]->store_id;    
    $product_id = $check_cart[0]->product_id;
    $cur_qty = $check_cart[0]->quantity;
    // if($quantity==$cur_qty){ //minimum 1 , 
    //     echo json_encode(array('status'=>3,'message'=>'Something went wrong please try again'));
    //     exit;
        
    // }
    if($quantity<$cur_qty){
        $alert_message ='Item removed'; 
    }else{
        $alert_message ='Item added';
    }
    
    foreach($check_cart as $cc){
            $rate  = $cc->rate;
            $price =  $quantity * $rate;
            $item_id = $cc->item_id;
        $pro_data = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id = prodtl.prod_id  inner join packettype_master packtype ON packtype.id = pro.packtype_id where pro.prod_id = $product_id  and prodtl.prod_itemid=$item_id")->result();
        $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0;
        $billing_rate =0; $billing_price=0;
        $display_rate =0; $display_price=0;
        $mrp_rate = 0; $mrp_price = 0;
        $range_pricing = 0;
        if($pro_data){
            $type = $pro_data[0]->type_name;
                //Price 
               $price_to_display = $pro_data[0]->price_to_display;
               $mrp_prc = $pro_data[0]->mrp_price; 
               $mop_prc = $pro_data[0]->mop_price; 
               $offer_prc = $pro_data[0]->offer_price; 
               if(strtoupper($pro_data[0]->display_stock)=='YES'){
                    $stock = $pro_data[0]->item_totstock;
                }else{
                    $stock = $pro_data[0]->item_moq;
                }
                if($quantity>$stock){ //current stock
                    $quantity = $stock;
                }
                if($quantity>10){ //allow maximum 10
                    $quantity =10;
                }
            
               if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==2){ //Mop
                        $display_rate =  $mop_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==3){ //Offer price
                        $display_rate =  $offer_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==4){ //range price
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                        $range_pricing =  (str_replace(',','',$mop_prc) * $quantity) .' - ₹ '.(str_replace(',','',$mrp_prc) * $quantity);
                    }else{
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                    }
               }
                ///.....///
        
        
                 ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_prc);
        $mrp_price = str_replace(',','',$mrp_prc) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display;
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_prc;
            $billing_price = str_replace(',','',$mrp_prc) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->hsn_code;
        $CGSTperc = $pro_data[0]->cgst;
        $SGST_IGSTperc = $pro_data[0]->sgst;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        }
        $status  = $this->db->query("update cart set quantity = $quantity,rate ='$billing_rate', price ='$billing_price',mrp_rate='$mrp_rate',mrp_price='$mrp_price',billing_type= '$billing_type',base_amt ='$base_amt',HSN_code='$HSN_code',CGST='$CGST',SGST_IGST='$SGST_IGST',display_rate='$display_rate',display_price='$display_price',display_type= '$display_type',range_pricing='$range_pricing' where cart_id = $cart_id");            
        }
        $cart_total = 0;$discount = 0;$mrp_total = 0; $array = array();
        $cart_tot = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    if(empty($cart_tot)){
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
    }
    $display_price = 0;
        foreach($cart_tot as $ct){
        $cart_total = $cart_total + $ct->display_price;  
        $mrp_total = $mrp_total + $ct->mrp_price;  
        if($cart_id==$ct->cart_id){
            $display_price = $display_price + $ct->display_price; 
        }
        $discount = $discount + ($ct->mrp_price - $ct->display_price);  
        $pro_id = $ct->product_id;
        $varient_id = $ct->varient_id;
        $pro_data = $this->db->query("select pack_content,display_stock,item_totstock,item_moq from product pro inner join product_itemdtl prodtl on pro.prod_id= prodtl.prod_id where pro.prod_id = $pro_id")->result();
        if($pro_data){
        $data = $pro_data[0];
        if(strtoupper($data->display_stock)=="YES"){
            $tot_stk = $data->item_totstock;
        }else{
            $tot_stk = $data->item_moq;
        }
        $curr_stk = $tot_stk - ($quantity * $data->pack_content);
        if($curr_stk<0){
                $tot_stk = 0;
             }
        $stock = (int)$tot_stk;
        if($stock > 10){
            $stock = 10;
        }}
        $array = array(
            "cart_id" =>$ct->cart_id,
            "stock" => "$stock"
            );
        }
        if(!empty($array)){
        $cart_total = round($cart_total);
        $result = array('status'=>1,'message'=>$alert_message,'stock' =>$stock,'mrp_total'=>$mrp_total,'display_price'=>$display_price,'discount'=>$discount,'cart_total'=>$cart_total); 
        echo json_encode($result); 
        }else{
            echo json_encode(array('status'=>0));
            exit;
        }
    }
    public function remove_cart(){
    if(!isset($_POST['cart_id']) || empty($_POST['cart_id'])){
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
    }
    $cart_id = $_POST['cart_id'];
    $result = $this->db->query("delete from cart where cart_id = $cart_id");
    $userdata = $this->session->userdata('brownie_webuser');
    $data['userdata'] = $userdata;
    if(empty($userdata)){
         echo json_encode(array('status'=>0,'message'=>'Please login your account'));
        exit;
    }else{
         $user_id = $userdata[0]->user_id;
         $cart_total = 0;$discount = 0;$mrp_total = 0; $array = array();
        $cart_tot = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    if(empty($cart_tot)){
        echo json_encode(array('status'=>2,'message'=>'Your cart is empty'));
        exit;
    }
        foreach($cart_tot as $ct){
        $cart_total = $cart_total + $ct->display_price;  
        $mrp_total = $mrp_total + $ct->mrp_price;  
        $discount = $discount + ($ct->mrp_price - $ct->display_price);  
        $pro_id = $ct->product_id;
        $varient_id = $ct->varient_id;
        $quantity = $ct->quantity;
        $pro_data = $this->db->query("select pack_content,display_stock,item_totstock,item_moq from product pro inner join product_itemdtl prodtl on pro.prod_id= prodtl.prod_id where pro.prod_id = $pro_id")->result();
        if($pro_data){
        $data = $pro_data[0];
        if(strtoupper($data->display_stock)=="YES"){
            $tot_stk = $data->item_totstock;
        }else{
            $tot_stk = $data->item_moq;
        }
        $curr_stk = $tot_stk - ($quantity * $data->pack_content);
        if($curr_stk<0){
                $tot_stk = 0;
             }
        $stock = (int)$tot_stk;
        if($stock > 10){
            $stock = 10;
        }}
        $array = array(
            "cart_id" =>$ct->cart_id,
            "stock" => "$stock"
            );
        }
        if(!empty($array)){
        $cart_total = round($cart_total);
            $result = array('status'=>1,'message'=>'Product removed from cart successfully','stock' =>$stock,'mrp_total'=>$mrp_total,'discount'=>$discount,'cart_total'=>$cart_total); 
            echo json_encode($result); 
        }else{
            echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
            exit;
        }
    }
    
}
public function order_summary(){
    $data_cart['menu'] = 'Order summary - The brownie Studio';
    $userdata = $this->session->userdata('brownie_webuser');
    $data_cart['userdata'] = $userdata;
    $user_id =0;$data['cart_count'] =0;
    if(isset($userdata[0]->user_id)){
        $user_id =$userdata[0]->user_id;
        $data['cart_count'] = $this->get_cartcount($user_id);
    }
    
    $cart_count=0;
    $cart_total =0; $grand_total =0;$discount =0;$sub_total=0;
if(empty($userdata)){
     redirect(base_url("login"));
}else{
    $user_id = $userdata[0]->user_id;
    $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    $cart_count = count($cart_data);
    $curr_stk = '';$preloose_product_id='';
    $result = $this->db->query("select cart.product_image,sale_unit,pri_attcolor,pri_att,att1,var1,att2,var2,att3,var3,add_variant,ptype.type_name type,product.cat_id,prodtl.pack_content,cart.item_id,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,prodtl.display_name,cart.cart_id ,cart.varient_id,cart.varient_name,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,cart.quantity,product.prod_name,product.description product_description,product.prod_img1,product.prod_id,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status,prodtl.item_availability from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product ON product.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON product.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid INNER JOIN packettype_master ptype ON product.packtype_id = ptype.id where user.user_id =$user_id and cart.order_id = 0 and cart.product_status in (0) order by cart.product_id,cart_id")->result();
    $store_id ='';
    if(empty($result )){ // cart is empty
        redirect(base_url("shop"));
    }
    $final_array = array();
    foreach($result as $data){
        $store_id = $data->store_id;
        $product_id = $data->prod_id;
        $varient_id = 0;
        $item_id = $data->item_id;
        $type = $data->type;
        $add_variant = $data->add_variant;
        $pack_content = $data->pack_content;
         if(strtoupper($type)=="LOOSE" || strtoupper($add_variant=="NO")){ //Loose product
                    $sale_unit = $data->sale_unit;
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $data->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $data->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $data->att1;
                     $variant1 = $data->var1;
                     $att2_id = $data->att2;
                     $variant2 = $data->var2;
                     $att3_id = $data->att3;
                     $variant3 = $data->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $data->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $color_n = $variant2.';'.$variant3; 
                          $color_n = rtrim($color_n, ";");
                          $size_value = trim($color_n);
                     }
                 }
        if(strtoupper($data->display_stock)=="YES"){
            $tot_stk = $data->item_totstock;
        }else{
            $tot_stk = $data->item_moq;
        }
        $curr_stk = $tot_stk - ($data->quantity * $data->pack_content);
        if($curr_stk<0){
                $tot_stk = 0;
             }
        $stock = (int)$tot_stk;
        
        //if cart quantity less than stock quantity means update cart quantity as stock quantity //also update stock price
        $cart_id = $data->cart_id;
        $quantity = $data->quantity;
        $stock = round($stock,0);
        if($stock > 10){
            $stock = 10;
        }
        
        if($quantity > $stock){
            $current_stock = $stock;
            $this->Common_model->cart_price_calculation($cart_id,$current_stock,$item_id);
        }
        
        $updated_stock = $this->db->query("select * from cart where cart_id =$cart_id")->result();
        if($updated_stock){
            $cart_total = $cart_total + $updated_stock[0]->display_price;
            $stock_availability ='';
            if($updated_stock[0]->quantity == 0 || $data->item_availability==0 ){
              $stock_availability = 'Out of stock';
              $stock_status = 'Sold Out';  
            }
        else if($updated_stock[0]->quantity > $stock){
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
        }else if($updated_stock[0]->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }
        $quantity = $updated_stock[0]->quantity;
        }else{ //rare case
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
            $quantity = 0;
        }
        
        // $chk_product_availability = $this->db->query("select availability from products where product_id =$product_id and availability=0 ")->result();
        // if($chk_product_availability){
        //     $stock_availability = 'Out of stock';
        //     $stock_status = 'Sold Out';
        //     $stock = $updated_stock[0]->quantity;//for unavailabilty product stock should not allow to increase + -
        // }
        $stock = round($stock,0);
        if($stock > 10){
            $stock = 10;
        }
        if(trim($updated_stock[0]->display_type)=='4'){ // range price
            $display_price = $updated_stock[0]->range_pricing;
            $lang_menu['total']= 'Estimated Total';
        }else{
            $display_price = $updated_stock[0]->display_price;
        }
        $varient_cnt = 0;
        $getcnt = explode(";",$data->varient_name); //masala;egg;corainder
        $varient_cnt = count($getcnt);//3
        $discount = $discount + ($updated_stock[0]->mrp_price - $display_price);
        $sub_total = $sub_total + $updated_stock[0]->mrp_price;
        $grand_total = $grand_total + $display_price;
        $final_array[] = array(
            'product_id' => $product_id,
            'cart_id' => $data->cart_id,
            'category_id' =>$data->cat_id,
            'varient_id' => $data->varient_id,
            'item_id' => $data->item_id,
            'color_value'=>$color_value,
            'size_value'=>$size_value,
            'type' => $data->type,
            'varient_name' => $data->varient_name,
            'varient_cnt' => $varient_cnt,
            'quantity' => $quantity,
            'product_name' => $data->display_name,
            'product_nameold' => $data->prod_name,
            'product_description' => $data->product_description,
            'product_image' => $data->product_image,
            'store_id' => $data->store_id,
            'store_name' => $data->store_name,
            'store_image' => $data->store_image,
            'store_description' => $data->store_description,
            'user_name' => $data->user_name,
            'rate' => $updated_stock[0]->rate,
            'price' => $updated_stock[0]->price,
            'display_type' => $data->display_type,
            'display_rate' => $updated_stock[0]->display_rate,
            'display_price' => $display_price,
            'mrp_rate' => $updated_stock[0]->mrp_rate,
            'mrp_price' => $updated_stock[0]->mrp_price,
            'stock' => "$stock",
            'stock_status' => $stock_status,
            'stock_availability' => $stock_availability            
            );
    }
    $cart_total = round($cart_total);
}

    $data_cart['cart_data'] = $final_array;
    $data_cart['cart_count']= $cart_count;
    $data_cart['cart_total']= $cart_total;
    $data_cart['sub_total']= $sub_total;    
    $data_cart['discount'] =$discount;
    $data_cart['grand_total'] =$grand_total;
    $store_id =1; // Brownie studio
    $data_cart['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data_cart);
                $this->load->view('header_part');
                $this->load->view('order_summary');
                $this->load->view('footer_part');
                $this->load->view('script_part');
                
}
public function ajax_saveaddress(){
        if($_POST){
            
            $coupon_code = $_POST['coupon_code'];
            $coupon_discount = $_POST['coupon_discount'];
            $final_total = $_POST['final_total'];
            $uptodate_email = $_POST['email'];
            $keepme_uptodate = $_POST['keepme_uptodate']; // 0- unchecked 1- checked
            $this->session->set_userdata('coupon_code',$coupon_code);
            $this->session->set_userdata('coupon_discount',$coupon_discount);
            $this->session->set_userdata('final_total',$final_total);
            $this->session->set_userdata('uptodate_email',$uptodate_email);
            $this->session->set_userdata('keepme_uptodate',$keepme_uptodate);
            $orderperson_array = array();
            if(isset($_POST['deliveryto_name']) && isset($_POST['deliveryto_contact']) && isset($_POST['orderby_name']) && isset($_POST['orderby_contact']) && isset($_POST['gift'])){
                $googlemap_address ="";$distance=0;
                if(isset($_POST['googlemap_address'])){
                    $googlemap_address = $_POST['googlemap_address'];
                }
                if(isset($_POST['distance'])){
                    $distance = $_POST['distance'];
                }
            $orderperson_array = array(
                'deliveryto_name' => $_POST['deliveryto_name'],
                'deliveryto_contact' => $_POST['deliveryto_contact'],
                'orderby_name' => $_POST['orderby_name'],
                'orderby_contact' => $_POST['orderby_contact'],
                'gift' => $_POST['gift'],
                'googlemap_address' => $googlemap_address,
                'distance' => $distance
                );
            }
        $this->session->set_userdata('orderperson_dtl',$orderperson_array);
        $userdata = $this->session->userdata('brownie_webuser');
        //this code doesn't work for new area and pincode
        // $city = trim($_POST['city']);
        // $get_city = $this->db->query("select * from city where city_name= '$city'")->result();
        // if($get_city){
        //     $insert['city_id'] =$get_city[0]->id; 
        // }else{
        //     $insert_city['city_name'] = $city;
        //     $insert_city['district_id'] = $_POST['districtid'];
        //     $this->db->insert('city',$insert_city);
        //     $get_cityagn = $this->db->query("select * from city where city_name= '$city'")->result();
        //     if($get_cityagn){
        //         $insert['city_id'] =$get_cityagn[0]->id; 
        //     }else{
        //         $insert['city_id'] =$_POST['cityid'];
        //     }
        // }
        $user_id = $userdata[0]->user_id;
        $user_pincode = $_POST['pincode'];
        $insert['address1'] = $_POST['address1'];
        $insert['address2'] = $_POST['address2'];
        $insert['landmark'] = $_POST['landmark'];
        $insert['state_id'] = $_POST['stateid'];
        $district = trim($_POST['district']);
        $city =$_POST['city'];
        $area = $_POST['area'];
        $insert['pincode'] = $_POST['pincode'];
        $insert['address_name'] = $_POST['address_name'];
        $addressid = $_POST['addressid'];
        //add district
        $state_id =  $_POST['stateid'];
        $find_dis = $this->db->query("select district_id from district where district='$district' and state_id =$state_id ")->result();
        if($find_dis){
            $insert['district_id'] = $find_dis[0]->district_id;
        }else{
            $insert_dis['district'] = $district;
            $insert_dis['state_id'] = $_POST['stateid'];
            $insert_dis['status'] = 1;
            $this->db->insert('district',$insert_dis);
            $insert['district_id']  = $this->db->insert_id();
        }
        $district_id = $insert['district_id'];
        //CITY
        $find_city = $this->db->query("select id from city where city_name='$city' and district_id =$district_id")->result();
        if($find_city){
            $insert['city_id'] = $find_city[0]->id;
        }else{
            $insert_city['city_name'] = $city;
            $insert_city['district_id'] = $insert['district_id'];
            $this->db->insert('city',$insert_city);
            $insert['city_id']  = $this->db->insert_id();
        }
        $city_id  = $insert['city_id'];
        //AREA
        $find_area = $this->db->query("select id from area where area_locality='$area' and city_id=$city_id")->result();
        if($find_area){
            $insert['area_id'] = $find_area[0]->id;
        }else{
            $insert_area['area_locality'] = $area;
            $insert_area['city_id'] = $insert['city_id'];
            $insert_area['pincode'] = trim($_POST['pincode']);
            // if($city_id!=1){ //FOR chennai don't allow user area to insert ,  already deliverable area inserted in table
                $this->db->insert('area',$insert_area);
                $insert['area_id']  = $this->db->insert_id();
            // }else{
            //     $insert['area_id'] = 0;
            // }
        }
        
        
        if($addressid ==0){//insert
            $insert['address_type'] = 1;    
            $insert['gps_coordinates'] ='';
            $insert['user_id'] =$user_id;
            $current_cityid = $insert['city_id'];
            $this->db->query("update address set address_type = 0 where user_id =$user_id ");    //update other address as saved address then current address will update as 1
            $this->db->query("update user_profile set current_cityid = $current_cityid where user_id =$user_id ");    //update current city in user_profile
            $this->db->insert('address',$insert);
            $addressid = $this->db->insert_id();
            $response = array('status'=>1,'message'=>$addressid);
            echo json_encode($response);
            die;
        }else{//update
            $status = $this->db->update('address',$insert,array('id'=>$addressid));    
            $response = array('status'=>1,'message'=>$addressid);
            echo json_encode($response);
            die;
        }}else{
            $response = array('status'=>0,'message'=>'something went wrong please try again');
            echo json_encode($response);
            die;
        }
    }
public function ajax_placeorder(){
    if($_POST){
        $user_id = $_POST['user_id'];
        if($user_id==0){
            $userdata = $this->session->userdata('brownie_webuser');
            $user_id = trim($userdata[0]->user_id);
        }
        $get_usercurrent_address = $this->db->query("SELECT ad.address1,ad.address2,ad.landmark,area.area_locality,city.city_name,dis.district_id,state.state_id,dis.district,state.state,ad.pincode,ad.gps_coordinates,ad.address_name FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type = 1")->result();
    if(empty($get_usercurrent_address)){//for store pickup user current address empty
        $get_usercurrent_address = $this->db->query("SELECT '' address1,'' address2,'' landmark,'' area_locality,'' city_name,'' district,'' state,'' pincode,'' gps_coordinates,'' address_name  from user_profile WHERE user_id = $user_id")->result();
    }    
    //     ///////Check stock before go to Place Order Page
       $chk_ctk = $this->check_stock($user_id);
       if($chk_ctk['status']==3){ //3 means stock not available //1 Stock available - allow to further process
          //return $chk_ctk; 
        $message = $chk_ctk['message'];
          echo json_encode(array('status'=>0,'message'=>$message));
        exit;
       }
    $payment_method = $_POST['payment_method']; 
    $payment_type = $_POST['payment_type'];
    
    $status = 1;
    /* if(isset($_POST['payment_sts']) && $_POST['payment_sts']=="0"){// on online payment mode failed or cancelled
      echo json_encode(array('status'=>2,'message'=>'Order Cancelled/Failed'));
        exit;
    } */
    
   $dt = $this->db->query("SHOW TABLE STATUS LIKE 'orders'")->result();
    $id = $dt[0]->Auto_increment;
    $sequence_num = str_pad($id, 3, 0, STR_PAD_LEFT);
    $UTN_number = "YEL".$sequence_num;
    $result = $this->db->query("SELECT cart.product_id,cart.price,cart.mrp_price,cart.quantity,cart.varient_id,cart.item_id,prodtl.price_to_display,prodtl.item_totstock,prodtl.pack_content,prodtl.item_moq,cart_id,cart.store_id,prodtl.display_stock FROM cart INNER JOIN product pro ON cart.product_id = pro.prod_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid WHERE cart.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0,1) AND pro.prod_status = 1")->result();
    $count = count($result);
 
     $final_array =array();
     $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data){
        $product_id  = $data->product_id;
        $total = $total + $data->price;
        $total_mrp = $total_mrp + $data->mrp_price;
        $items_in_cart = $items_in_cart + $data->quantity;
        $varient_id = $data->varient_id;
        $item_id = $data->item_id;
        $total_available_stock_final = 0; $moq_final = 0;
        $price_to_display = $data->price_to_display;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES'){
            $stockavailable =  $data->item_totstock;
            $stock_minus = $data->pack_content * $data->quantity;
        }else{
            $stockavailable =  $data->item_moq;
            $stock_minus = $data->pack_content * $data->quantity;
        }
        $total_available_stock_final = $stockavailable - $stock_minus; 
        //minus stock in product table
        if(strtoupper($display_stock)=='YES'){
            if($total_available_stock_final!='' || $total_available_stock_final==0){ //allow 0 quantity  also  stock - order = 5-5 = 0
                $update_data5['item_totstock'] = $total_available_stock_final;
                $status = $this->db->update('product_itemdtl',$update_data5,array('prod_id'=>$product_id,'prod_itemid'=>$item_id));
                }
        }
          
    if($result){
    $cart_id = $data->cart_id;
    $this->db->query("update cart set product_status = 2 where cart_id = $cart_id and user_id =$user_id");    
    $this->db->query("update cart set order_id = $id where user_id = $user_id and cart_id = $cart_id and order_id = 0");
    }
    else{
        echo json_encode(array('status'=>0,'message'=>'something went wrong please try again'));
        exit;
    }
    
    }
    $payment_status = 0;
    if($result){
         $insert_data  = array(
            'UTN_number'=>$UTN_number,
            'user_id'=>$user_id,
            'store_id'=>$data->store_id,
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total,
            'items_in_cart' => $items_in_cart,
            'payment_method'=>$payment_method,
            'payment_type'=>$payment_type,
            'payment_status'=>$payment_status,
            'booking_time'=>date('Y-m-d H:i:s'),
            'status'=>0,
            'address1' =>$get_usercurrent_address[0]->address1,
            'address2' =>$get_usercurrent_address[0]->address2,
            'landmark' =>$get_usercurrent_address[0]->landmark,
            'area' =>$get_usercurrent_address[0]->area_locality,
            'city' =>$get_usercurrent_address[0]->city_name,
            'district' =>$get_usercurrent_address[0]->district,
            'state' =>$get_usercurrent_address[0]->state,
            'pincode' =>$get_usercurrent_address[0]->pincode,
            'gps_coordinates' =>$get_usercurrent_address[0]->gps_coordinates,
            'address_name' =>$get_usercurrent_address[0]->address_name,
            'order_by'=>'Website'
        
        );
        // print_r($insert_data);
        // die;
    $this->db->insert('orders',$insert_data);
        //update discount
      $ttl_discount = 0;
    $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status = 2 and order_id = $id AND user_id = $user_id")->result();
            if($total_discount){
                $ttl_discount = $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
                $this->db->query("update orders set discount_amount = $ttl_discount where user_id = $user_id and order_id = $id");
            }
    
    //update packing charge & delivery Charge
    $store_id = $result[0]->store_id;
    $str = $this->db->query("select orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and UTN_number ='$UTN_number' ")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        $delivery_charges = $str[0]->delivery_charges;
        if($delivery_type==1 || $delivery_charges==0)//store pickup 
        {
            $est_delivery_charge = 0;
        }
        else { //home delivery
            $est_delivery_charge = $str[0]->min_dc;
        }
        $packing_charges = $str[0]->packing_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $billing_price = $str[0]->total_amount;
            $items = $str[0]->items_in_cart;
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($billing_price * ($pc_perc/100)),0);
            }else{ //unitwise
            $est_packing_charge =  round(($items * $pc_unit_value),0);
            }   
        }
        $total_amount = $str[0]->total_amount +  $est_packing_charge + $est_delivery_charge;
        //update packing charge & delivery Charge
      $this->db->query("update orders set customer_ordered_amt = $total_amount, packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and UTN_number = '$UTN_number'");  
    }
    ////
    
    $order = $this->db->query("select order_id,total_amount,store_id from orders where UTN_number = '$UTN_number'")->result();
    $order_id = $order[0]->order_id;
    $order_amount = $order[0]->total_amount;
    
    if(isset($_POST['coupon_code']) && $_POST['coupon_code']!="" && isset($_POST['coupon_discount']) && $_POST['coupon_discount']!=0 && $postdata['coupon_discount']!=""){
        $store_id = $order[0]->store_id;
        $coupon_code = $postdata['coupon_code'];
        $coupon_discount = $postdata['coupon_discount'];
      $get_couponid = $this->db->query("SELECT * FROM `yms_offercoupon` WHERE store_id = $store_id AND offer_code='$coupon_code'")->result();
      if($get_couponid){
          $coupon_id = $get_couponid[0]->id;
           $current_dt = date("Y-m-d H:i");
           $cpnvalidity_from = $get_couponid[0]->validity_from;
           $cpnvalidity_to = $get_couponid[0]->validity_to;
          if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to){
               $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
               $usedcnt = count($chk_coupon_usage);
               $coupon_cnt = $get_couponid[0]->offer_usage;
             if($usedcnt<=$coupon_cnt){
                $final = $order_amount-$coupon_discount;
                if($final<0){
                    $final = 0;
                }
                 $this->db->query("update orders set coupon_id = $coupon_id ,coupon_discount =$coupon_discount,total_amount=$final,customer_ordered_amt=$final where user_id = $user_id and UTN_number = '$UTN_number'");  
             }}
          
      }
}
//for clifton order accpeted on place_order by default
$this->db->query("update orders set delivery_status = 1 where UTN_number = '$UTN_number'");    

    //send Order placed notification mail      
    $get_data = $this->db->query("SELECT seller.email seller_email,seller.shopper_name seller_name,usr.email, usr.fullname,str.store_name, ord.orderby_name ,ord.UTN_number,ord.booking_time,ord.total_amount,ord.payment_method,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN user_profile usr ON usr.user_id = ord.user_id INNER JOIN shopper seller on seller.store_id = str.store_id  WHERE ord.UTN_number ='$UTN_number'")->result();
    if($get_data){
        $seller_email = $get_data[0]->seller_email;
        $email = $get_data[0]->email;
        $cust_name = $get_data[0]->orderby_name;
        $seller_name = $get_data[0]->seller_name;
        $store_name = $get_data[0]->store_name;
        $dt_frmt=date_create($get_data[0]->booking_time);
        $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
        $total = $get_data[0]->total_amount;
        $preferred_del_date  = "";
        $preferred_del_time = "";
        $payment_method = $get_data[0]->payment_method; //1 for store pickup and 2 for home delivery
        if($payment_method==1){
            $delivery_type ="Store pickup";
            $delivery_address = "-";
        }else{
            $delivery_type ="Home Delivery";
            $delivery_address = $get_data[0]->address1.', '.$get_data[0]->address2.', '.$get_data[0]->landmark.', '.$get_data[0]->area.', '.$get_data[0]->city.', '.$get_data[0]->district.', '.$get_data[0]->state.' - '.$get_data[0]->pincode;
        }
          $dt['item_dtl'] = $this->db->query("SELECT ord.changesin_deliverycharge,cart.preferred_del_date , cart.preferred_del_time , cart.varient_name,cart.product_name,cart.product_image,cart.product_desc,cart.quantity,cart.rate,cart.price,ord.packing_charge,ord.delivery_charge,ord.total_amount,ord.discount_amount,ord.coupon_discount FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$UTN_number'")->result();
            $dt['del_address'] = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.address1,ord.address2,ord.landmark,ord.area,city,district,state,pincode,gps_coordinates,address_name FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$UTN_number'")->result();
           //send Order placed notification mail to Customer
            if(trim($email)!=''){
            $to_receiver_email = $email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Order Accepted";
            $dt['heading'] = "Order Accepted";
            $dt['message'] = 
"Dear $cust_name, <br>

                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Greetings from <strong>  The Brownie Studio! ORDER ACCEPTED! </strong>,  Thanks for shopping with us.We are working on it now. Once it is ready to ship, we will send you another email with the tracking details. Questions? Suggestions? Insightful shower thoughts? Shoot us an email. <br><br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong style='font-size:17px;margin-left:130px'>  ORDER ID : ORDER#$UTN_number </strong>   <br><br>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Store Name : </strong> $store_name <br>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Order Date : </strong> $booking_time <br>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Status : </strong>  Order Accepted  <br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Delivery Type :  </strong>   $delivery_type <br>

";
$message_html = $this->load->view('template/email_template3', $dt, TRUE);
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                 if($response['status']==0){
                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                 }
            }
            //Send Order Placed notification mail to seller
    if($seller_email!=''){
            $to_receiver_email = $seller_email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Order ID : $UTN_number";
            $message = 
"Dear $seller_name

You have received a new order from $cust_name.

Store Name : $store_name 
Order ID : $UTN_number
Order Date : $booking_time
Status : Order Placed
Total : $total

Delivery Type: $delivery_type
Customer Address :
$delivery_address

Thank You,
Team YellowMart";
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
                 if($response['status']==0){
                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                 }
            }
    }
        //send order placed push notification to seller
        $seller = $this->db->query("select id,token_key,str.store_name from shopper seller INNER JOIN stores str ON seller.store_id = str.store_id where str.store_id  =$store_id ")->result();
        if($seller){
            $token_key = $seller[0]->token_key;
            $message ="ORDER#$UTN_number   $store_name - You have received a new order.";
            $title = "Order placed by the customer";
            $notify_type = "order_received";
            $user_id = $user_id;
            $seller_id = $seller[0]->id;
            $delivery_boyid = 0;
            $notified_person = "seller";
            if($token_key!=''){
            $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
            }
        }
        //send order place thanku push notification to customer
        $customer = $this->db->query("SELECT user_id,token_key FROM user_profile WHERE user_id = $user_id ")->result();
        if($customer){
                    $token_key = $customer[0]->token_key;
                    $store_name = $seller[0]->store_name; 
                    $message ="Thank you for placing an order with $store_name! Your ORDER#$UTN_number $store_name";
                    $title = "Thank you for placing an order";
                    $notify_type = "order_placed";
                    $user_id = $user_id;
                    $seller_id = $seller[0]->id;
                    $delivery_boyid = 0;
                    $notified_person = "customer";
                    if($token_key!=''){
                    $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
                    }
                    }
                    echo json_encode(array('status'=>1,'message'=>'Order Placed','UTN_number'=>$UTN_number,'order_id'=>$order_id,'order_amount'=>$order_amount));
                    /*if($payment_type==3){ //online payment
                        $order_id = encode_param($order_id);
                        echo json_encode(array('status'=>2,'message'=>'Order Placed','UTN_number'=>$UTN_number,'order_id'=>$order_id,'order_amount'=>$order_amount)); 
                    }else{
                    echo json_encode(array('status'=>1,'message'=>'Order Placed','UTN_number'=>$UTN_number,'order_id'=>$order_id,'order_amount'=>$order_amount)); 
                    }*/
        exit;
    }
    else{
         echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again')); exit;
    }
}
}
function check_stock($user_id){
        $stock_qty = 0;
        $chk_stock_status = 1;
        $cart_data = $this->db->query("select prodtl.item_stocksts,prodtl.item_availability,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,  prod.prod_status,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,display_name,cart.cart_id,cart.varient_name,cart.quantity,prod.prod_name,prod.description product_description,prod.prod_img1,prod.prod_id,prod_itemid,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product as prod ON prod.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON prodtl.prod_id = prod.prod_id AND prodtl.prod_itemid = cart.item_id  where user.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0) AND cart.type != 'Loose'  ORDER BY product_id,prod_itemid")->result();
        if($cart_data){ //other than loose
    foreach($cart_data as $data){
        $store_id = $data->store_id;
        $product_id = $data->prod_id;
        $prod_itemid = $data->prod_itemid;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES'){
            $stock = $data->item_totstock;
        }else{
            $stock = $data->item_moq;
        }
        $final_availability = $data->item_availability;
        if($data->quantity > $stock){
            $chk_stock_status = 0;
            $stock_availability = 'Out of Stock';
            $stock_status = 'Sold Out';
        }else if($data->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }
        if($final_availability!=1){
            $chk_stock_status = 0;
        }
    }
        }
        $loosecart_data = $this->db->query("select prodtl.sale_unit,prodtl.stock_unit,prodtl.pack_content, prodtl.item_stocksts,prodtl.item_availability,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,  prod.prod_status,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,display_name,cart.cart_id,cart.varient_name,cart.quantity,prod.prod_name,prod.description product_description,prod.prod_img1,prod.prod_id,prod_itemid,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product as prod ON prod.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON prodtl.prod_id = prod.prod_id AND prodtl.prod_itemid = cart.item_id  where user.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0) AND cart.type = 'Loose'  ORDER BY product_id,prod_itemid")->result();
         if($loosecart_data){ //other than loose
     $preloose_product_id=''; $chk_loose_overallqty = 0;
    foreach($loosecart_data as $data){
         $store_id = $data->store_id;
        $product_id = $data->prod_id;
        $prod_itemid = $data->prod_itemid;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES'){
                         $stock = $data->item_totstock;
                        $sale_unit = $data->sale_unit;
                        $stock_unit = $data->stock_unit;
                        $pack_content = $data->pack_content;
                        if($preloose_product_id==''){
                            $preloose_product_id = $prod_itemid;  
                            $chk_loose_overallqty = $data->quantity * $pack_content;//5 * 250g = 1250g
                        }
                        else {
                            if($preloose_product_id == $prod_itemid){
                                    $chk_loose_overallqty = $chk_loose_overallqty +($data->quantity * $pack_content);
                                }else{
                                      $preloose_product_id = $prod_itemid;  
                                      $chk_loose_overallqty = $data->quantity * $pack_content;
                                }
                        }
                        if( $chk_loose_overallqty > $stock_qty){
                                $chk_stock_status = 0;
                                    }
        }else{
            $stock = $data->item_moq;
        }
        $final_availability = $data->item_availability;
        if($data->quantity > $stock){
            $chk_stock_status = 0;
            $stock_availability = 'Out of Stock';
            $stock_status = 'Sold Out';
        }else if($data->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }   
      //chk product availability
        // $chk_product_availability = $this->db->query("select availability from products where product_id =$product_id and availability=0 ")->result();
        // if($chk_product_availability){
        //     $chk_stock_status = 0;
        // }
        if($final_availability!=1){
            $chk_stock_status = 0;
        }
        
    }
        }
        if($chk_stock_status==0){
                // $result = array('status'=>3,'message'=>'Stock Quantity updated Please Check the Cart');
                $result = array('status'=>3,'message'=>'Please check update stock status in your basket','stock'=>$stock_qty);
            }else {
                $result = array('status'=>1,'message'=>'Stock Available','stock'=>$stock_qty);
            }
        return $result;
        
    }
 function send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person){
    if($token_key!=''){
                    $data = array(
                    "action"=>1,    
                    "message"=> "$message",
                    "title"=>"$title"
                        );
                        if($notified_person=='seller'){
                    $sendNotification = seller_send_push_notification($token_key,$data);
                        }else if($notified_person=='customer'){
                    $sendNotification = send_push_notification($token_key,$data);
                        }else if($notified_person=='deliveryboy'){
                    $sendNotification = delivery_send_push_notification($token_key,$data);
                        }
                    $insert_data  = array(
                        'notify_type'=>"$notify_type",
                        "title"=>"$title",
                        'content'=>"$message",
                        'user_id'=>$user_id,
                        'seller_id'=>$seller_id,
                        'delivery_boyid' =>$delivery_boyid,
                        'notified_person' =>"$notified_person", 
                        'notify_date' => date('Y-m-d H:i:s'),
                        'read_status' => 0
                    );
                $this->db->insert('pushnotifications',$insert_data);
                }
}
  function sendmail_notification($from_email='',$from_emailpassword='',$from_username='',$to_receiver_email='',$subject,$message=''){
            $config['protocol'] = 'ssmtp';
            $config['smtp_host'] = 'ssl://ssmtp.gmail.com';
            $config['smtp_port'] = 465;
            $config['smtp_user'] = $from_email;
            $config['smtp_pass'] = $from_emailpassword;
            
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            
           // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            $this->email->clear(); 
            // $this->email->initialize($config);
            $this->email->set_newline("\r\n");
            /*html call*/
            $this->email->set_mailtype("html");
            // Sender email address
            $this->email->from($from_email, $from_username);
            // Receiver email address
            $this->email->to($to_receiver_email);
            // Subject of email
            $this->email->subject($subject);
            // Message in email
            $this->email->message($message);
            if ($this->email->send()) {
                return $result = array('status'=>1,'message'=>'Mail sent'); 
            } else {
                return $result = array('status'=>0,'message'=>'Failed to send Mail'); 
            }
}
public function ajax_prodtl(){
    if(isset($_POST)){
        $userdata = $this->session->userdata('brownie_webuser');
        $data['userdata'] = $userdata;
        $user_id =0;
        if(isset($userdata[0]->user_id)){
            $user_id =$userdata[0]->user_id;
        }
        $pre_deldate = "";$pre_deltime = "";
        $get_datetime = $this->db->query("select preferred_del_date,preferred_del_time from cart where order_id = 0 and user_id = $user_id")->result();
        if($get_datetime){
            if($get_datetime[0]->preferred_del_date!='0000-00-00'){
                $pre_deldate = $get_datetime[0]->preferred_del_date;
            }
            if($get_datetime[0]->preferred_del_time!=''){
                $pre_deltime = $get_datetime[0]->preferred_del_time;
            }
        }
        $store_id = $_POST['store_id'];
        $product_id = $_POST['product_id'];
        $item_id = $_POST['item_id'];
    $product_detail = $this->Common_model->product_detail($store_id,$product_id,$item_id,'','',$user_id);
    $pro_cnt = count($product_detail);
               
     $pro = json_decode(json_encode($product_detail), FALSE);
     if($pre_deldate==""){
        $pre_deldate = date("Y-m-d");    
     }
     $delivery_slot = $this->get_deliveryslot($pre_deldate);
        $delivery_slotarray = $delivery_slot['data'];
    //  echo '<pre>';
    //  print_r($pro);
    //  die;
    
                if($pro) { ?>
<div class="col-lg-6" id="product_detail_carousel">
        		       	<div  class="carousel slide " data-ride="carousel" id="product_carousel_custom">
        		       	    
        		       	    <ol class="carousel-indicators">
        		       	          <?php $img_cnt = count($pro->images);
        		       	           $m=0;
        		       	          for($m=0;$m<$img_cnt;$m++){ ?>
                                  <li data-target="#product_carousel_custom" data-slide-to="<?php echo $m; ?>" class="<?php if($m == 0) echo 'active'; ?> cursor_pointer_custom"></li>
                                  <?php } ?>
                              </ol>
                              
                              
            				<div class="product_img carousel-inner pr-0">
            				    <?php foreach($pro->images as $im){ ?>
    							<img class="img-fluid carousel-item w-100 prod_img_cust height_426" src="<?php echo base_url('../'.$im->product_image);?>" alt="" >
    							<?php } ?>
    						</div>
    						<a class="carousel-control-prev" href="#product_carousel_custom" role="button" data-slide="prev">
    							<span class="carousel-control-prev-icon  p-2 rounded " aria-hidden="true"></span>
    							<span class="sr-only">Previous</span>
    						</a>
    						<a class="carousel-control-next" href="#product_carousel_custom" role="button" data-slide="next">
    							<span class="carousel-control-next-icon  p-2 rounded " aria-hidden="true"></span>
    							<span class="sr-only">Next</span>
    						</a>
        		        </div>
        		            <!------mobile view heading----->
                            <div class="d-lg-none d-md-none d-sm-block d-block">
                                  <nav class="breadcrumb bg-white pl-0" role="navigation" aria-label="breadcrumbs" style="visibility: visible;">
                                     <a href="<?php echo base_url();?>" class="blue_color_custom font_weight_600" title="Home">Home</a>
                                     <span aria-hidden="true" class="blue_color_custom px-1 font-weight-normal">›</span>
                                     <a href="<?php echo base_url();?>shop" class="blue_color_custom font_weight_600" title=""><?php echo $pro->category_name; ?></a>
                                     <span aria-hidden="true" class="blue_color_custom px-1 font-weight-normal">›</span>
                                     <span class="blue_color_custom"><?php echo $pro->product_name; ?></span>
                                  </nav>
                                <h3 class="pro_det_head mb-0"><?php echo $pro->product_name; ?></h3>
        					    <hr class="line_pro mb-3 m-0">
        					    <p class="color_brownie_black"><?php echo strip_tags($pro->product_description); ?></p>
        					   
                            </div>
                              <!-----mobile view heading------>
                              
                               <!--AddOn-->
           <!--                   	<table class="table mt-4">-->
           <!--                           <thead>-->
           <!--                             <tr>-->
           <!--                               <th colspan="3" class="border-0 "><h5 class="mb-0 blue_color_custom" style="font-weight: 500;">Add Ons</h5></th>-->
                                         
           <!--                             </tr>-->
           <!--                           </thead>-->
           <!--                           <tbody>-->
           <!--                             <tr class="bg-light rounded border ">-->
           <!--                               <td scope="row" class="pb-0">-->
           <!--                                   <input type="checkbox" class="checkbox-round " checked/>-->
           <!--                               </td>-->
           <!--                               <td style="width: 55%;" class="pb-0">-->
           <!--                                   <span class=" black_browmnie" style="font-weight: 600;font-size:14px">Birthday Candle</span><br>-->
											  <!--<span class="" style="font-size: 12px;">Rent for 4 days</span>	<br>-->
											  <!--<span class="" style="font-size: 12px;"> <strong>Rs.500</strong></span><br>-->
											
											<!--</td>-->
           <!--                               <td class="pb-1 pt-1">-->
           <!--                                  <img src="<?php echo base_url();?>img/candle.jpg" alt="" class="w-25 mx-auto d-block my-auto rounded">-->
           <!--                               </td>-->
           <!--                             </tr>-->
           <!--                             <tr class="bg-light rounded border ">-->
           <!--                               <td scope="row" class="pb-0">-->
           <!--                                   <input type="checkbox" class="checkbox-round " checked/>-->
           <!--                               </td>-->
           <!--                               <td style="width: 55%;" class="pb-0">-->
           <!--                                   <span class=" black_browmnie" style="font-weight: 600;font-size:14px"> Birthday Cap</span><br>-->
											  <!--<span class="" style="font-size: 12px;">Rent for 4 days</span>	<br>-->
											  <!--<span class="" style="font-size: 12px;"> <strong>Rs.500</strong></span><br>-->
											
											<!--</td>-->
           <!--                               <td class="pb-1 pt-1">-->
           <!--                                  <img src="<?php echo base_url();?>img/cap.jpg" alt="" class="w-25 mx-auto d-block my-auto rounded">-->
           <!--                               </td>-->
           <!--                             </tr>-->
                                       
           <!--                           </tbody>-->
           <!--                         </table>-->
                            <div class="panel-group py-4" id="accordion" role="tablist" aria-multiselectable="true">

                                <div class="panel panel-default border-top border-bottom">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                        <h4 class="panel-title mb-0 my-2">
                                            <a role="button" class="bg-white pb-0 py-3 black_browmnie" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                <i class="more-less fa fa-plus"></i>
                                                Our Quality Promise
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                        <div class="panel-body text-justify px-3">
                                            	<h6 class="font-weight-bold font_family_arial black_browmnie text-center">Pure indulgence.</h6>
							                    <h6 class="font-weight-bold font_family_arial black_browmnie text-center">And, the finest ingredients.</h6>
							                    <p class="black_browmnie font-weight-normal font_15">That’s what we are made of. No substitutes, no compromise. Each ingredient, delicately treated. Each recipe, precisely crafted. And within the perfect balance of taste and texture, lies a deep sense of gratification.</p>
                                        </div>
                                    </div>
                                </div>
                        
                                <div class="panel panel-default border-bottom ">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title mb-0 my-2">
                                            <a class="collapsed bg-white pb-0 py-3 black_browmnie"  role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                <i class="more-less fa fa-plus"></i>
                                               Shipping and Delivery
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                        <div class="panel-body text-justify px-3">
                                           	<p class="black_browmnie font-weight-normal font_15">All our celebration cakes are shipped anywhere in Chennai. We use third-party delivery partners and guide them with the handling of the product.</p>
                							<p class="black_browmnie font-weight-normal font_15 py-3">Our Brownie & Dessert boxes have been developed in such ways that it is fit to ship and has a shelf life of 5-6 days from shipping when stored in the appropriate guided conditions. Our recipes have been tested under a variety of temperature, humidity & pressure conditions.</p>
                							<p class="black_browmnie font-weight-normal font_15">
                							All our products are made and packed with extreme care in sealed packs to make sure you receive them in their best condition. In case of incorrect orders or any damages caused to your cakes, we can provide a refund only in the form of store credit. No monetary refund will be provided.
                							</p>
                                        </div>
                                    </div>
                                </div>
                        
                                <div class="panel panel-default border-bottom">
                                    <div class="panel-heading" role="tab" id="headingThree">
                                        <h4 class="panel-title mb-0 my-2">
                                            <a class="collapsed bg-white pb-0 py-3 black_browmnie" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                <i class="more-less fa fa-plus"></i>
                                               Reviews
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                        <div class="panel-body best_seller_dropdown_1 p-4">
                                            <h5 class="mb-0 pb-1 prod_review">Customer Reviews</h5>
                							<p class="pb-1 mb-0 mt-4">
                							    	<!--<i class="fa fa-star pr-1 fa-2x text-warning"></i>-->
                							    	<!--<i class="fa fa-star px-1 fa-2x text-warning"></i>-->
                							    	<!--<i class="fa fa-star px-1 fa-2x text-warning"></i>-->
                							     <!--   <i class="fa fa-star px-1 fa-2x text-warning"></i>-->
                							     <!--  <i class="fa fa-star px-1 fa-2x text-warning"></i> -->
                                                    <div class="star-rating row" title="0%">
                                                        <div class="back-stars col-lg-3 col-auto my-auto pr-0">
                                                            <i class="fa fa-star-o pr-1 " aria-hidden="true"></i>
                                                            <i class="fa fa-star-o pr-1 " aria-hidden="true"></i>
                                                            <i class="fa fa-star-o pr-1 " aria-hidden="true"></i>
                                                            <i class="fa fa-star-o pr-1 " aria-hidden="true"></i>
                                                            <i class="fa fa-star-o pr-1 " aria-hidden="true"></i>
                                                            
                                                            <div class="front-stars" style="width: <?php echo $pro->overall_reviewstar;?>%">
                                                                <i class="fa fa-star pr-1 " aria-hidden="true"></i>
                                                                <i class="fa fa-star pr-1 " aria-hidden="true"></i>
                                                                <i class="fa fa-star pr-1 " aria-hidden="true"></i>
                                                                <i class="fa fa-star pr-1 " aria-hidden="true"></i>
                                                                <i class="fa fa-star pr-1 " aria-hidden="true"></i>
                                                            </div>
                                                        </div>
                                                        <p class="font_14 mb-0 my-auto col py-2 pr-0 "> Based on <?php echo count($pro->reviews);?> reviews </p>
                                                        <?php if($pro->allow_review==1){ //this item order placed user only allow to write review ?>
                            							<a href="javascript:void(0)" class="text-dark py-2 mb-2  my-auto col-lg-3 px-0 font_15 ml-3" id="write_review" onclick="write_review()">
                            							  
                            							    <span style="border-bottom: 2px solid #c4ab3f;">  <i class="fa fa-edit mr-1"></i>Write a review</span>
                            							 </a>
                            							<?php } ?>
                                                    </div>    
                							      
                						
                							</p>
                							<!---write review start-->
                							<div class="col-lg-12 px-0 d-none" id="review_div" >
                							     <h6 class="mt-3 prod_review " style="font-size: 19px;">Write a review</h6>
                                                    <div id="half-stars-example" class="">
                                                         <h6 class="mt-3 black_browmnie font_14 font_400 ">Add a Title <span id="title_error" class="text-danger error_msg font_14"></span></h6>
                                                        <!--<input type="text" class="form-control" id="review_type" placeholder="Add a Title">-->
                                                        <select class="form-control rounded-0 prod_rev_border" id="review_type">
                                                            <!--<option value="0">Select</option>-->
                                                            <option value="Highly Recommended">Highly Recommended</option>
                                                            <option value="Just Ok">Just Ok</option>
                                                            <option value="Fair Product">Fair Product</option>
                                                            <option value="Waste of Money">Waste of Money</option>
                                                        </select>
                                                        <h6 class="mt-3 black_browmnie font_14 font_400">Rating <span id="star_error" class="text-danger error_msg font_14"></span></h6>
                                                        <div class="rating-group" style="margin-left: -15px;">
                                                            <!--In starting view not star selected-->
                                                             <input class="rating__input rating__input--none"  name="rating2" id="rating2-0" value="0" type="radio">
                                                            <label aria-label="0 stars" class="rating__label" for="rating2-0">&nbsp;</label>
                                                            <!--In starting view not star selected-->
                                                            <label aria-label="1 star" class="rating__label" for="rating2-10"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="rating2" id="rating2-10" value="1" type="radio">
                                                            <label aria-label="2 stars" class="rating__label" for="rating2-20"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="rating2" id="rating2-20" value="2" type="radio">
                                                            <label aria-label="3 stars" class="rating__label" for="rating2-30"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="rating2" id="rating2-30" value="3" type="radio">
                                                            <label aria-label="4 stars" class="rating__label" for="rating2-40"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="rating2" id="rating2-40" value="4" type="radio">
                                                            <label aria-label="5 stars" class="rating__label" for="rating2-50"><i class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="rating2" id="rating2-50" value="5" type="radio" checked>
                                                            
                                                            <br>
                                                            
                                                        </div>
                                                         
                                                       
                                                        <h6 class="mt-3 black_browmnie font_14 font_400">Body of Review (1500) <span id="comment_error" class="text-danger error_msg font_14"></span></h6>
                                                        <textarea row="10" class="form-control rounded-0 prod_rev_border" id="comment"></textarea>
                                                        
                                                        
                                                        <!--submit button-->
                                                        <br>
                                                        <button class="btn pink_more mt-4 mx-auto d-block rounded-0 bg_gold font-weight-light mb-3" id="submit_rev_cus" onclick="submit_comment()">Submit Review <i class="animated fa fa-spinner rotateIn infinite d-none" style="    font-size: 17px;" id="loading_cus_rev"></i></button>
                                                    </div>
                							</div>
                							<!--write review end-->
                                            <?php
                                            $reviews = $pro->reviews;
                                            foreach($reviews as $re){ ?>
                							<p class="pb-1 mb-0 mt-4">
                							    <?php $star = $re->star_count;
                							    for($i=1; $i<=5; $i++){
                							        if($i<=$star){?>
                							            <i class="fa fa-star pr-1 text-warning"></i>
                							        <?php }else{ ?>
                							            <i class="fa fa-star-o pr-1 text text-warning"></i>
                							        <?php }
                							    }?>
                							 </p>
                							<p class=" mb-1 text-capitalize h6 fade_black font_13 "><?php echo $re->username.' on '.$re->date_reviewed;?></p>
                							<p class="small black_browmnie"><?php echo $re->comment;?></p>
                							<?php } ?>
                                        </div>
                                    </div>
                                </div>
                        
                            </div><!-- panel-group -->
                           
						
        			</div>
					
        			<div class="col-lg-6 pr-lg-0 pr-xl-3">
        				<div class="product_details_text">
        				     <!------desktop view heading----->
                             <div class="d-lg-block d-md-block d-sm-none d-none">
                                  <nav class="breadcrumb bg-white pl-0" role="navigation" aria-label="breadcrumbs" style="visibility: visible;">
                                     <a href="<?php echo base_url();?>" class="blue_color_custom font_weight_600" title="Home">Home</a>
                                     <span aria-hidden="true" class="blue_color_custom px-1 font-weight-normal">›</span>
                                     <a href="<?php echo base_url();?>shop" class="blue_color_custom font_weight_600" title=""><?php echo $pro->category_name;?></a>
                                     <span aria-hidden="true" class="blue_color_custom px-1 font-weight-normal">›</span>
                                     <span class="blue_color_custom"><?php echo $pro->product_name;?></span>
                                  </nav>
                                  <input type="hidden" id="user_id" value="<?php echo $user_id;?>" ?>
            					<h3 class="pro_det_head mb-0"><?php echo $pro->product_name;?></h3>
            					<hr class="line_pro float-left m-0">
            					<p class="color_brownie_black"><?php echo strip_tags($pro->product_description);?></p>
            				
        					</div>
        					  <!------desktop view heading----->
        					<h5 class="mb-2 py-3 text-dark bg_brownie_blue"><span class="ml-3 text-white font-weight-normal" id="price">Rs.&nbsp;<?php echo $pro->display_price;?></span></h5>
							
							<div class="row col-12 px-0 pb-3 pr-0">
								<div class="col-lg-6 col-12 my-2">
									<div class="input-group  mx-0 px-0">
										<div class="input-group-prepend">
											<span class="input-group-text best_seller_dropdown bg-white rounded-0 font_13 px-5 font_weight_600" id="type-addon1" >
												&nbsp;Type&nbsp;&nbsp;
											</span>
										</div>
										<select class="form-control best_seller_dropdown_1 rounded-0 font_13 font_weight_600" aria-describedby="type-addon1" id="variant2" style="height: 47px;" onchange="load_item(2)">
											 <?php foreach($pro->var2 as $v2){ ?>
										        <option value="<?php echo  $v2->value; ?>"  <?php echo ($v2->selected == "1")?"selected":""?>><?php echo  $v2->value;?></option>    
										   <?php } ?>
										</select>
									</div>
								
								</div>
								<div class="col-lg-6 col-12 my-2" >
									<div class="input-group  mx-0 px-0">
									    <?php if($pro->var3){ ?>
											<div class="input-group-prepend">
												<span class="input-group-text best_seller_dropdown bg-white rounded-0 font_13 px-5 font_weight_600" id="shape-addon">
													Shape
												</span>
											</div>
											<select class="form-control best_seller_dropdown_1 rounded-0 font_13 font_weight_600" id="variant3" aria-describedby="shape-addon" style="height: 47px;" onchange="load_item(3)">
												<?php foreach($pro->var3 as $v3){ ?>
										        <option value="<?php echo  $v3->value; ?>"  <?php echo ($v3->selected == "1")?"selected":""?>><?php echo  $v3->value;?></option>
										   <?php } ?>
											</select>
											<?php } else { ?>
											<input type="hidden" value="" name="variant3" id="variant3" >
											<?php } ?>
										</div>
									</div>
								</div>
								<div class="row col-12 px-0 pb-3 ">
							      <!------mobile view ----->
								<p class=" py-0 input-group-text bg-white border-0 blue_color_custom  text-dark  d-block d-lg-none d-xl-none col-12 text-left px-3" id="quantity" style="font-weight: 600;font-size: 14px;">
												Qty 
								</p>
								 <!------mobile view ----->
								<div class="col-6 col-xl-6 col-lg-6 my-2 ">
                        
									<div class="input-group  mx-0 px-0">
										<div class="input-group-prepend">
											<p class="input-group-text bg-white blue_color_custom best_seller_dropdown rounded-0 text-dark font-weight-normal p-1 d-none d-lg-block px-3" id="quantity" style="font-weight: 600;font-size: 14px;">
											Qty 
											</p>
										</div>
										<select class="form-control best_seller_dropdown rounded-0" aria-describedby="quantity-addon1" id="variant1" style="font-size: 14px;height: 45px;"  onchange="load_item(1)">
										    <?php foreach($pro->var1 as $v1){ ?>
										        <option value="<?php echo  $v1->value; ?>"  <?php echo ($v1->selected == "1")?"selected":""?>><?php echo  $v1->value;?></option>
										   <?php } ?>
										</select>
									</div>
								
								</div>
								<div class="col-6 my-auto col-lg-6 col-xl-4">
							
									<div class="input-group" style="height: 45px;">
										<a href="javascript:void(0)" class="input-group-addon minus increment btn btn-light border border-right-0  rounded-0" id="decrement" onclick="add_qty(-1)" ><i class="fa fa-minus" aria-hidden="true"></i></a>
										<input type="text" class="form-control text-center" id="qty" size="<?php echo $pro->stock;?>" value="1" onkeypress="return isNumber(event)">
										<a href=" javascript:void(0)" class="input-group-addon plus increment btn btn-light border border-left-0  rounded-0" id="increment" onclick="add_qty(1)" ><i class="fa fa-plus" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
								
							</div>
							<div class="form-group col-md-12 pl-0">
							    <?php if($pro->subcat_id==4){ ////Brownies & Desserts
							       $message_on_ck = 'Message on Card';  
							    }else{
							        $message_on_ck = 'Message on Cake';
							    }
							    ?>
							    <label class="font_weight_600 black_browmnie font_15" style="letter-spacing: 0.5px;"><strong class="font_weight_600"><?php echo $message_on_ck;?></strong></label>
								<textarea class="form-control rounded-0 pt-4" name="message" id="message_on_cake" rows="2" placeholder="<?php echo $message_on_ck;?>"></textarea>
							</div>
							<div class="row col-12 px-0 pt-2 ">
								<div class="col-12 col-xl-12 col-lg-12  pr-0">
    								 <label class="font_weight_600 black_browmnie font_15" style="letter-spacing: 0.5px;"><strong class="font_weight_600">Select preferred date</strong></label>
    								 <input style="height: 40px;" type="date" class="text-uppercase form-control rounded-0" aria-describedby="date-addon1" id="preferred_del_date" name="phone_number" placeholder="Select preferred date" onchange="validate('date');" value="<?php echo ($pre_deldate!="")?$pre_deldate:'' ?>" min="<?php echo date("Y-m-d"); ?>">
    								 <span id="preferred_del_date_error" class="text-danger error_msg col-12 pl-0 font_14"></span>
								</div>
							
								<div class="col-12 col-xl-12 col-lg-12  pr-0">
									 <label class="font_weight_600 black_browmnie font_15" style="letter-spacing: 0.5px;">	<strong class="font_weight_600">Select preferred time between selected delivery slot</strong></label>
    								<select style="height: 40px;" class="form-control rounded-0" id="preferred_del_time" aria-describedby="Time-addon1" onchange="validate('time');">-->
    								            <option value=""<?php echo ($pre_deltime == '')?"selected":"" ?> >Select Time</option>
    								            <?php if($delivery_slotarray){ foreach($delivery_slotarray as $sl){ ?>
    										                <option value="<?php echo $sl['time_slot'];?>"<?php echo ($pre_deltime == $sl['time_slot'])?"selected":"" ?>><?php echo $sl['time_slot_view'];?></option>      
    										          <?php }}else { ?>
											    <option value="08:00am to 09:00am"<?php echo ($pre_deltime == '08:00am to 09:00am')?"selected":"" ?>>08am to 09am</option>
												<option value="09:00am to 10:00am"<?php echo ($pre_deltime == '09:00am to 10:00am')?"selected":"" ?>>09am to 10am</option>
												<option value="10:00am to 11:00am"<?php echo ($pre_deltime == '10:00am to 11:00am')?"selected":"" ?>>10am to 11am</option>
												<option value="11:00am to 12:00pm"<?php echo ($pre_deltime == '11:00am to 12:00pm')?"selected":"" ?>>11am to 12pm</option>
												<option value="12:00pm to 01:00pm"<?php echo ($pre_deltime == '12:00pm to 01:00pm')?"selected":"" ?>>12pm to 01pm</option>
												<option value="01:00pm to 02:00pm"<?php echo ($pre_deltime == '01:00pm to 02:00pm')?"selected":"" ?>>01pm to 02pm</option>
												<option value="02:00pm to 03:00pm"<?php echo ($pre_deltime == '02:00pm to 03:00pm')?"selected":"" ?>>02pm to 03pm</option>
												<option value="03:00pm to 04:00pm"<?php echo ($pre_deltime == '03:00pm to 04:00pm')?"selected":"" ?>>03pm to 04pm</option>
												<option value="04:00pm to 05:00pm"<?php echo ($pre_deltime == '04:00pm to 05:00pm')?"selected":"" ?>>04pm to 05pm</option>
												<option value="05:00pm to 06:00pm"<?php echo ($pre_deltime == '05:00pm to 06:00pm')?"selected":"" ?>>05pm to 06pm</option>
												<option value="06:00pm to 07:00pm"<?php echo ($pre_deltime == '06:00pm to 07:00pm')?"selected":"" ?>>06pm to 07pm</option>
												<option value="07:00pm to 08:00pm"<?php echo ($pre_deltime == '07:00pm to 08:00pm')?"selected":"" ?>>07pm to 08pm</option>
												<option value="08:00pm to 09:00pm"<?php echo ($pre_deltime == '08:00pm to 09:00pm')?"selected":"" ?>>08pm to 09pm</option>
												<option value="09:00pm to 10:00pm"<?php echo ($pre_deltime == '09:00pm to 10:00pm')?"selected":"" ?>>09pm to 10pm</option>
												<option value="10:00pm to 11:00pm"<?php echo ($pre_deltime == '10:00pm to 11:00pm')?"selected":"" ?>>10pm to 11pm</option>
												<option value="11:00pm to 12:00am"<?php echo ($pre_deltime == '11:00pm to 12:00am')?"selected":"" ?>>11pm to 12pm</option>
												<?php } ?>
									</select>
									<span id="preferred_del_time_error" class="text-danger error_msg col-12 pl-0 font_14"></span>
								</div>
									
							</div>
							<div class="form-group col-md-12 pl-0">
							     <label class="font_weight_600 black_browmnie font_15" style="letter-spacing: 0.5px;"><strong class="font_weight_600">	Notes to Chef</strong></label>
								<textarea class="form-control rounded-0 pt-4" name="message" id="notes_on_chef" rows="2" placeholder="Note to Chef"></textarea>
							</div>
        					<a class="pink_more text-uppercase btn-block text-center" id="add_to_cart" style="background: #06555c;" href="javascript:void(0);" onclick='return add_cart(1)'>Add to Cart</a>
        				</div>
        				      <?php } else { // count zero ?>
                    <input type="hidden" value="<?php echo $pro_cnt;?>" id="pro_cnt"> 
                    <h2 class="title_small">Something went wrong</h2>
<?php } 
} else{
        echo 'Something went wrong';
    }
}
public function ajax_getdistrict()
{
        $stateID = $_POST['stateID'];
        $district = $this->db->query("select district_id,district from district where state_id = $stateID")->result();
        ?>
                                             <option selected value="0">Select District </option>
                                         <?php foreach($district as $dt){?>
                                             <option value="<?php echo $dt->district_id;?>"><?php echo $dt->district;?></option>
                                         <?php }

}
public function chk_pincode()
{
        $pincode = trim($_POST['pincode']);
        $chk_pin = $this->db->query("select * from area where pincode = '$pincode' and city_id=1")->result();
        if($chk_pin){
            echo '1';
        }else{
            echo '0';
        }
}

public function ajax_getcity(){
        $districtid = $_POST['districtid'];
        $city = $this->db->query("select id,city_name from city where district_id = $districtid")->result();
        ?>
                                             <option selected value="0">Select  City</option>
                                         <?php foreach($city as $dt){?>
                                             <option value="<?php echo $dt->id;?>"><?php echo $dt->city_name;?></option>
                                         <?php }

    }
 public function ajax_getarea(){
        $cityid = $_POST['cityid'];
        $area = $this->db->query("select id,area_locality,pincode from area where city_id = $cityid")->result();
        ?>
                                             <option selected value="0">Select Area</option>
                                         <?php foreach($area as $dt){?>
                                             <option value="<?php echo $dt->id;?>"><?php echo $dt->area_locality;?></option>
                                         <?php }

    }
 public function ajax_getpincode(){
        $areaid = $_POST['areaid'];
        $pincode='';$str_delivery_status='';
        $getpincode = $this->db->query("select pincode from area where id = $areaid")->result();
        if($getpincode){
           $pincode = $getpincode[0]->pincode; 
        }
                  $chkstr_delivery = $this->db->query("select * from store_address where store_id = 79 and pincode =$pincode")->result(); //check store will support user current address pinocde
                  if(empty($chkstr_delivery)){
                      $str_delivery_status = "This item cannot be shipped to your selected delivery location. Please choose a different delivery location.";
                  }
       if($str_delivery_status!=''){
           $response = array('status'=>2,'message'=>"This item cannot be shipped to your selected delivery location. Please choose a different delivery location.",'pincode'=>$pincode);
            echo json_encode($response);
            die;
              }
        else{
            $response = array('status'=>1,'message'=>"delivery available",'pincode'=>$pincode);
            echo json_encode($response);
            die;
        }
        
    }
// Add address from my account
    public function ajax_up_new_address(){
        $insert['address1'] = $_POST['address1'];
        $insert['address2'] = $_POST['address2'];
        $insert['landmark'] = $_POST['landmark'];
        $insert['state_id'] = $_POST['stateid'];
        $insert['district_id'] = $_POST['districtid'];
        $insert['city_id'] = $_POST['cityid'];
        $insert['area_id'] = $_POST['areaid'];
        $insert['pincode'] = $_POST['pincode'];
        $insert['user_id'] = $_POST['user_id'];
        // $user_id = $_POST['user_id'];
        $insert['address_name'] = $_POST['add_name'];
        $insert['address_type'] = 1;
        $result = $this->db->insert('address',$insert);
        echo $result;
    }
public function ajax_upaddress(){
        $update['address1'] = $_POST['address1'];
        $update['address2'] = $_POST['address2'];
        $update['landmark'] = $_POST['landmark'];
        $update['state_id'] = $_POST['stateid'];
        $update['district_id'] = $_POST['districtid'];
        $update['city_id'] = $_POST['cityid'];
        $update['area_id'] = $_POST['areaid'];
        $update['pincode'] = $_POST['pincode'];
        $update['user_id'] = $_POST['user_id'];
        $update['address_name'] = $_POST['add_name'];
        $update['address_type'] = $_POST['add_type'];
        $id = $_POST['id'];
        if($update['address_type']==1)
        {
            $update1['address_type'] = 0;
            $user_id = $update['user_id'] ;
            $sts = $this->db->update('address',$update1 , array('user_id'=>$user_id));    
        }
        $status = $this->db->update('address',$update , array('id'=>$id));    
        echo $id;
        die;
        echo 'something went wrong please try again';
    }
    public function order_detail(){
    $data['menu'] = 'order_detail - The Brownie Studio';
    $userdata = $this->session->userdata('brownie_webuser');
    $data['userdata'] = $userdata;
    $user_id =0; $data['cart_count'] =0;
    if(empty($userdata)){
         redirect(base_url("login"));
     }
    if(isset($userdata[0]->user_id)){
        $user_id =$userdata[0]->user_id;
        $data['cart_count'] = $this->get_cartcount($user_id);
    }
    $utnum = decode_param($this->uri->segment(2));
    $data['orderdata'] = $this->Common_model->order_detail($utnum);    
    $data['utn_num'] = $utnum;
    // echo '<pre>';
    // print_r($data['orderdata']);
    // die;
    $store_id =1; // Brownie studio
    $data['search_products'] = $this->Common_model->getpro_list($store_id,0,0,''); 
                $this->load->view('style_part',$data);
                $this->load->view('header_part');
                $this->load->view('order_summary');
                $this->load->view('footer_part');
                $this->load->view('script_part');
}
function prolist_variantwise_dtl(){
    if($_POST){
        $item_id = $_POST['item_id'];
        $get = $this->db->query("select  prod_itemid,prod_id,display_name,price_to_display,mrp_price,mop_price,offer_price,display_stock,item_totstock,item_moq FROM product_itemdtl where prod_itemid = $item_id and item_stocksts =1 ")->result();
        if($get){
            $price_to_display = $get[0]->price_to_display;
            if($price_to_display==1){
                $price = $get[0]->mrp_price;
            }else if($price_to_display==2){
                $price = $get[0]->mop_price;
            } else if($price_to_display==3){
                $price = $get[0]->offer_price;
            }
            if(strtoupper($get[0]->display_stock)=="YES"){
                $stock = $get[0]->item_totstock;
            }else{
                $stock = $get[0]->item_moq;
            }
            $price = round($price,0);
            if($stock>0 && $stock!=""){
                $link =  base_url('product_detail/'.$get[0]->prod_id.'/'.$this->encode_param($get[0]->prod_itemid)); 
            $final_array = array(
                'status'=>1,
                'item_id'=>$get[0]->prod_itemid,
                'prod_id'=>$get[0]->prod_id,
                'display_name'=>$get[0]->display_name,
                'price'=>'Rs.'.$price,
                'link'=>$link,
                'message'=>""
            );
            echo json_encode($final_array);exit;
            }else{
                echo json_encode(array('status'=>0,'message'=>'Stock not available')); exit;              
            }
        }else{
            echo json_encode(array('status'=>0,'message'=>'Something went wrong pleasae try again')); exit;          
        }
        
    }else{
     echo json_encode(array('status'=>0,'message'=>'Something went wrong pleasae try again ')); exit;   
    }
    
}
function ajaxprd_stock(){
    $stock = 0;$price_final=0;
    if($_POST){
        $product_id = $_POST['product_id'];
        $item_id = $_POST['item_id'];
        $get_stk = $this->db->query("select * FROM product_itemdtl prodtl WHERE prod_id =$product_id AND prodtl.prod_itemid =$item_id and item_stocksts=1 and item_availability=1")->result();
        if($get_stk){
             //Price start here
                $price_to_display = $get_stk[0]->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $get_stk[0]->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $get_stk[0]->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $get_stk[0]->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $get_stk[0]->mop_price .' - ₹ '.$get_stk[0]->mrp_price; //
                   }
                 } //Price end here
                 
            if(strtoupper($get_stk[0]->display_stock)=='YES'){
                $stock = $get_stk[0]->item_totstock;
            }else{
                $stock = $get_stk[0]->item_moq;
            }
            $price_final = round($price_final,0);
        }
        echo json_encode(array('status'=>1,'message'=>'Stock Available','stock'=>$stock,'price'=>$price_final));exit;
    }else{
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again','stock'=>$stock,'price'=>$price_final));exit;
    }
}
public function view_order(){
    if($this->uri->segment(3) == FALSE || $this->uri->segment(4) == FALSE){
        redirect(base_url());
    }
    $str_id = $this->uri->segment(3);
    $orderutn_id = $this->uri->segment(4);
    $store_data = $this->db->query("select stores.store_logo,stores.str_type,stores.store_name,stores.store_phone,stores.store_address1,stores.store_gst,stores.pincode,dis.district,state.state,invoice_format,qrcode from stores INNER JOIN district dis ON stores.district_id = dis.district_id INNER JOIN state on state.state_id =  stores.state_id  WHERE store_id =$str_id ")->result();
    $order_data = $this->db->query("select * from orders where UTN_number ='$orderutn_id' ")->result();
    $user_id = $order_data[0]->user_id;
    $user_data = $this->db->query("SELECT fullname name,u.phone_no,u.email,ord.address1,ord.address2,ord.landmark,ord.area,ord.city city_town,ord.pincode FROM user_profile as u INNER JOIN orders ord ON u.user_id = ord.user_id WHERE u.user_id = $user_id AND ord.UTN_number ='$orderutn_id'")->result();
    $order_id = $order_data[0]->order_id;
    $ord_data['order_no'] = $order_data[0]->UTN_number;
    $item_data = $this->db->query("select cart.*,prod.prod_name product_name,proddtl.display_name from cart inner join product prod ON cart.product_id = prod.prod_id INNER JOIN product_itemdtl proddtl ON proddtl.prod_id = prod.prod_id AND proddtl.prod_itemid = cart.item_id WHERE cart.order_id =$order_id and prod.prod_status in (1,2)")->result();
    //$client_data = $this->db->query("SELECT org_logo,upi_qrcode,organization_name,phone_no,gst_no,address,address2,area.area_locality area,city.city_name,district.district,state.state,client.pincode FROM client INNER JOIN state ON client.state_id = state.state_id INNER JOIN district ON district.district_id = client.district_id INNER JOIN city ON client.city_id = city.id INNER JOIN area ON client.area_id = area.id")->result();
    //$client_data = $this->db->query("SELECT str.store_logo org_logo ,str.qrcode upi_qrcode,str.store_name as organization_name,str.store_phone phone_no,str.store_gst gst_no,'' address,'' address2,area.area_locality,city.city_name,district.district,state.state,stradd.pincode FROM stores str INNER JOIN store_address stradd ON stradd.store_id = str.store_id INNER JOIN area ON stradd.area_id = area.id inner JOIN city ON city.id = stradd.city_id INNER JOIN district ON district.district_id = stradd.district_id INNER JOIN state ON state.state_id = stradd.state_id  WHERE str.store_id = $str_id AND stradd.default_address =1")->result();
    $item_array = array();
    if($item_data){
    foreach($item_data as $dt){            
        $exp_cgst = explode(':',$dt->CGST);
        $CGSTperc = $exp_cgst[0];
        $CGST = $exp_cgst[1];
        
        $exp_si = explode(':',$dt->SGST_IGST);
        $SGST_IGSTperc = $exp_si[0];
        $SGST_IGST = $exp_si[1];
        $item_array[] = array (
        'HSN_code' => $dt->HSN_code,
        'display_name' => $dt->display_name,
        'variant_name' => $dt->varient_name,
        'quantity' => $dt->quantity,
        'base_amt' => $dt->base_amt,
        'CGST' => $CGST,
        'SGST_IGST' => $SGST_IGST,
        'rate' => $dt->rate,
        'price' => $dt->price
        );
    }
    }
    
    $item = json_decode(json_encode($item_array));
    $order_format = $store_data[0]->invoice_format;
    $ord_data['page_title'] = 'Detailed Invoice';
    $ord_data['store_data'] = $store_data;
    $ord_data['item'] = $item;
    $ord_data['order_data'] =$order_data;
    $ord_data['order_format'] =$order_format;
    $ord_data['user']= $user_data;
    $ord_data['order_id'] = $orderutn_id;
    //$ord_data['client_data']= $client_data;
    if($order_format=='invoice_57' || $order_format=='invoice_74'){
        $order_format ='order_thermal';
    }else{
        $order_format ='order_default';
    }
    $this->load->view('invoice/'.$order_format,$ord_data);

}
public function invoice(){
    if($this->uri->segment(3) == FALSE || $this->uri->segment(4) == FALSE || $this->uri->segment(5) == FALSE){
        redirect(base_url());
    }
    $str_id = $this->uri->segment(3);
    $orderutn_id = $this->uri->segment(4);
    $inv_no = $this->uri->segment(5);
    
     $store_data = $this->db->query("select stores.store_logo,stores.str_type,stores.store_name,stores.store_phone,stores.store_address1,store_address2,stores.store_gst,stores.pincode,dis.district,state.state,invoice_format,qrcode from stores INNER JOIN district dis ON stores.district_id = dis.district_id INNER JOIN state on state.state_id =  stores.state_id  WHERE store_id =$str_id ")->result();
    //$client_data = $this->db->query("SELECT org_logo,upi_qrcode,organization_name,phone_no,gst_no,address,address2,area.area_locality area,city.city_name,district.district,state.state,client.pincode FROM client INNER JOIN state ON client.state_id = state.state_id INNER JOIN district ON district.district_id = client.district_id INNER JOIN city ON client.city_id = city.id INNER JOIN area ON client.area_id = area.id")->result();
    $order_data = $this->db->query("select * from orders where UTN_number ='$orderutn_id' ")->result();
    $user_id = $order_data[0]->user_id;
    $user_data = $this->db->query("SELECT ord.orderby_name name,ord.orderby_contact phone_no,ord.deliveryto_name , ord.deliveryto_contact, ord.address1,ord.address2,ord.area,ord.landmark,ord.city city_town,ord.district,ord.state,ord.pincode FROM orders as ord WHERE ord.UTN_number ='$orderutn_id'")->result();
    $order_id = $order_data[0]->order_id;
    $dt_frmt=date_create($order_data[0]->booking_time);
    // $order_date =  date_format($dt_frmt,"d/m/Y  h:i A");
    $order_date =  date_format($dt_frmt,"d/m/Y");
    $item_data = $this->db->query("select cart.*,prod.prod_name product_name,proddtl.display_name from cart inner join product prod ON cart.product_id = prod.prod_id INNER JOIN product_itemdtl proddtl ON proddtl.prod_id = prod.prod_id AND proddtl.prod_itemid = cart.item_id WHERE cart.order_id =$order_id and cart.product_status in (1,2)")->result();
    $item_array = array();
    if($item_data){
    foreach($item_data as $dt){
               $exp_cgst = explode(':',$dt->CGST);
        $CGSTperc = $exp_cgst[0];
        $CGST = $exp_cgst[1];
        
        $exp_si = explode(':',$dt->SGST_IGST);
        $SGST_IGSTperc = $exp_si[0];
        $SGST_IGST = $exp_si[1];
        $item_array[] = array (
        'HSN_code' => $dt->HSN_code,
        'display_name' => $dt->display_name,
        'variant_name' => $dt->varient_name,
        'quantity' => $dt->quantity,
        'base_amt' => $dt->base_amt,
        'CGST' => $CGST,
        'SGST_IGST' => $SGST_IGST,
        'rate' => $dt->rate,
        'price' => $dt->price
        );
    }
    }
    $item = json_decode(json_encode($item_array));
    $invoice_format = $store_data[0]->invoice_format;
    $inv_data['page_title'] = 'Detailed Invoice';
    $inv_data['store_data'] = $store_data;
    $inv_data['item'] = $item;
    $inv_data['inv_no']= $inv_no;
    $inv_data['order_id'] = $orderutn_id;
    $inv_data['order_data'] =$order_data;
    $inv_data['order_date'] = $order_date;
    $inv_data['user']= $user_data;
    $inv_data['invoice_format'] =$invoice_format;
    //$inv_data['client_data']= $client_data;
    if($invoice_format=='invoice_57' || $invoice_format=='invoice_74'){
        $invoice_format ='invoice_thermal';
    }
    $this->load->view('invoice/'.$invoice_format,$inv_data);

}
public function online_checkout($user_id=0){
    $user_id = decode_param($user_id);
    $final_total =  $this->session->userdata('final_total');
    $amt = 0;$user_name ="";$email ="";$contact ="";   $final_amt=0; 
    $get_orderamt = $this->db->query("select cart.price,cart.display_price,user.fullname,user.email,user.phone_no from cart  INNER JOIN user_profile user ON cart.user_id = user.user_id where cart.user_id=$user_id and order_id=0 and product_status in (0)")->result();
        if($get_orderamt){
        foreach ($get_orderamt as $key => $value) {
            $amt = $amt + $value->price;
            $user_name = $value->fullname;
            $email = $value->email;
            $contact = $value->phone_no;
        }
    }else {
        redirect(base_url());
    }
    
    $amt = trim($final_total, "Rs.");
    $final_amt = trim($amt);
    if(is_numeric($final_amt)){
    }else{
        $final_amt = preg_replace("/[^0-9.]/", "", "$final_amt");
    }

    //$key_id ='rzp_test_JS4a6CMPEyan76';
    //$secret = 'xj1KLQIQK38JEuY5zoYjpxwp';
    $key_id ='rzp_test_pI15kUglDD1Aje';
    $secret = 'Dnyp6hECCiEbrh9SmVVeR8EZ';
    $api = new Api($key_id,$secret);
    $orderData = [
    'receipt'         => rand(),
    'amount'          => $final_amt*100, // 39900 rupees in paise
    'currency'        => 'INR'
];
$razorpayOrder = $api->order->create($orderData);
$user_data['name'] = $user_name;
$user_data['email'] = $email;
$user_data['contact'] = $contact;
$this->load->view('razorpay-checkout',['user_data'=>$user_data,'order'=>$razorpayOrder,'key_id'=>$key_id,'secret'=>$secret]);

}
public function paymentStatus($orderid){
    $order_id = $this->decode_param($orderid);
    $razorpay_payment_id = $this->input->post('razorpay_payment_id');
    $razorpay_order_id = $this->input->post('razorpay_order_id');
    $razorpay_signature = $this->input->post('razorpay_signature');
    $data = $razorpay_order_id . "|" . $razorpay_payment_id;
    $secret = 'Dnyp6hECCiEbrh9SmVVeR8EZ';
    $generated_signature = hash_hmac("sha256", $data, $secret); 
     if ($generated_signature == $razorpay_signature) {  //payment success
        redirect(base_url().'online_placeorder/'.$razorpay_payment_id);

    }else{//payment failed
            redirect(base_url().'home/order_summary/');
    }
}
    public function online_placeorder($razorpay_payment_id)
    {
            $userdata = $this->session->userdata('brownie_webuser');
            $coupon_code = trim($this->session->userdata('coupon_code'));
            $rs_coupon_discount = trim($this->session->userdata('coupon_discount'));
            $coupon_discount = trim($rs_coupon_discount,"Rs."); 
            $final_total = $this->session->userdata('final_total');
            $uptodate_email = $this->session->userdata('uptodate_email');
            $keepme_uptodate = $this->session->userdata('keepme_uptodate');
            $orderperson_dtl = $this->session->userdata('orderperson_dtl');
            // print_r($this->session->userdata());
            // die;
            $user_id = trim($userdata[0]->user_id);
            $get_usercurrent_address = $this->db->query("SELECT ad.id,ad.address1,ad.address2,ad.landmark,area.area_locality,city.city_name,dis.district,state.state,ad.pincode,ad.gps_coordinates,ad.address_name FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type = 1")->result();
            if(empty($get_usercurrent_address)){//for store pickup user current address empty
                $get_usercurrent_address = $this->db->query("SELECT 0 as id,'' address1,'' address2,'' landmark,'' area_locality,'' city_name,'' district,'' state,'' pincode,'' gps_coordinates,'' address_name  from user_profile WHERE user_id = $user_id")->result();
            }    
        //     ///////Check stock before go to Place Order Page
           $chk_ctk = $this->check_stock($user_id);
           if($chk_ctk['status']==3)
           { //3 means stock not available //1 Stock available - allow to further process
              //return $chk_ctk; 
            $message = $chk_ctk['message'];
              //echo json_encode(array('status'=>0,'message'=>$message));
              alert($message);
              //redirect(base_url().'website/order_summary');
            exit;
           }
            $payment_method = 2; // home delivery
            $payment_type = 3;//online
            $payment_status =1;// online payment success
            $status = 1;
    
   $dt = $this->db->query("SHOW TABLE STATUS LIKE 'orders'")->result();
    $id = $dt[0]->Auto_increment;
    $sequence_num = str_pad($id, 3, 0, STR_PAD_LEFT);
    $UTN_number = "YEL".$sequence_num;
    $result = $this->db->query("SELECT cart.product_id,cart.price,cart.mrp_price,cart.quantity,cart.varient_id,cart.item_id,prodtl.price_to_display,display_stock,prodtl.item_totstock,prodtl.pack_content,prodtl.item_moq,cart_id,cart.store_id FROM cart INNER JOIN product pro ON cart.product_id = pro.prod_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid WHERE cart.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0,1) AND pro.prod_status = 1")->result();
    $count = count($result);
     $final_array =array();
     $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data){
        $product_id  = $data->product_id;
        $total = $total + $data->price;
        $total_mrp = $total_mrp + $data->mrp_price;
        $items_in_cart = $items_in_cart + $data->quantity;
        $varient_id = $data->varient_id;
        $item_id = $data->item_id;
        $total_available_stock_final = 0; $moq_final = 0;
        $price_to_display = $data->price_to_display;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES'){
            $stockavailable =  $data->item_totstock;
            $stock_minus = $data->pack_content * $data->quantity;
        }else{
            $stockavailable =  $data->item_moq;
            $stock_minus = $data->pack_content * $data->quantity;
        }
        $total_available_stock_final = $stockavailable - $stock_minus; 
        //minus stock in product table
        if(strtoupper($display_stock)=='YES'){
            if($total_available_stock_final!='' || $total_available_stock_final==0){ //allow 0 quantity  also  stock - order = 5-5 = 0
                $update_data5['item_totstock'] = $total_available_stock_final;
                $status = $this->db->update('product_itemdtl',$update_data5,array('prod_id'=>$product_id,'prod_itemid'=>$item_id));
                }
        }
          
    if($result){
    $cart_id = $data->cart_id;
    $this->db->query("update cart set product_status = 2 where cart_id = $cart_id and user_id =$user_id");    
    $this->db->query("update cart set order_id = $id where user_id = $user_id and cart_id = $cart_id and order_id = 0");
    }
    else{
        //echo json_encode(array('status'=>0,'message'=>'something went wrong please try again'));
        redirect(base_url().'home/order_summary');
        exit;
    }
    
    }

    if($result){
         $insert_data  = array(
            'UTN_number'=>$UTN_number,
            'user_id'=>$user_id,
            'store_id'=>$data->store_id,
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total,
            'items_in_cart' => $items_in_cart,
            'payment_method'=>$payment_method,
            'payment_type'=>$payment_type,
            'payment_status'=>$payment_status,
            'booking_time'=>date('Y-m-d H:i:s'),
            'status'=>0,
            'address1' =>$get_usercurrent_address[0]->address1,
            'address2' =>$get_usercurrent_address[0]->address2,
            'landmark' =>$get_usercurrent_address[0]->landmark,
            'area' =>$get_usercurrent_address[0]->area_locality,
            'city' =>$get_usercurrent_address[0]->city_name,
            'district' =>$get_usercurrent_address[0]->district,
            'state' =>$get_usercurrent_address[0]->state,
            'pincode' =>$get_usercurrent_address[0]->pincode,
            'gps_coordinates' =>$get_usercurrent_address[0]->gps_coordinates,
            'address_name' =>$get_usercurrent_address[0]->address_name,
            'order_by'=>'Website',
            'uptodate_email'=>$uptodate_email,
            'keepme_uptodate'=>$keepme_uptodate,
            'deliveryto_name'=>$orderperson_dtl['deliveryto_name'],
            'deliveryto_contact'=>$orderperson_dtl['deliveryto_contact'],
            'orderby_name'=>$orderperson_dtl['orderby_name'],
            'orderby_contact'=>$orderperson_dtl['orderby_contact'],
            'gift'=>$orderperson_dtl['gift'],
            'googlemap_address'=>$orderperson_dtl['googlemap_address'],
            'delivery_km'=>$orderperson_dtl['distance']
        
        );
    $this->db->insert('orders',$insert_data);
            //update address table 
            $deliveryto_name = $orderperson_dtl['deliveryto_name'];
            $deliveryto_contact =$orderperson_dtl['deliveryto_contact'];
            $address_id = $get_usercurrent_address[0]->id;
            if($deliveryto_name!="" && $deliveryto_contact!=""){
                $this->db->query("update address set delto_name = '$deliveryto_name',delto_contact ='$deliveryto_contact'  where user_id = $user_id and id = $address_id");
            }
            
            
          //update discount
      $ttl_discount = 0;
    $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status = 2 and order_id = $id AND user_id = $user_id")->result();
            if($total_discount){
                $ttl_discount = $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
                $this->db->query("update orders set discount_amount = $ttl_discount where user_id = $user_id and order_id = $id");
            }
    
    //update packing charge & delivery Charge
    $store_id = $result[0]->store_id;
    $str = $this->db->query("select orders.district,orders.state,orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and UTN_number ='$UTN_number' ")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        $delivery_charges = $str[0]->delivery_charges;
        if($delivery_type==1 || $delivery_charges==0)//store pickup 
        {
            $est_delivery_charge = 0;
        }
        else { //home delivery
            $est_delivery_charge = $str[0]->min_dc;
            $district_name = $str[0]->district;
            $state_name = $str[0]->state;
                   if(strtoupper($district_name)=="CHENNAI" && strtoupper($state_name)=="TAMILNADU" ){ ////manual address change can't calculate accurate distance
                        $est_delivery_charge = round($str[0]->min_dc,0);
                    }else if(strtoupper($state_name)=="TAMILNADU"){ //Inside Tamilnadu outside chennai
                        $est_delivery_charge = 75;
                    }else{
                        $est_delivery_charge = 130;
                    }
                                        
        }
        $packing_charges = $str[0]->packing_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $billing_price = $str[0]->total_amount;
            $items = $str[0]->items_in_cart;
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($billing_price * ($pc_perc/100)),0);
            }else{ //unitwise
            $est_packing_charge =  round(($items * $pc_unit_value),0);
            }   
        }
        $total_amount = $str[0]->total_amount +  $est_packing_charge + $est_delivery_charge;
        //update packing charge & delivery Charge
      $this->db->query("update orders set customer_ordered_amt = $total_amount, packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and UTN_number = '$UTN_number'");  
    }
    ////
    
    $order = $this->db->query("select order_id,total_amount,store_id from orders where UTN_number = '$UTN_number'")->result();
    $order_id = $order[0]->order_id;
    $order_amount = $order[0]->total_amount;
    /// coupon section 
    if($coupon_code!="" && $coupon_discount>0){
        $store_id = $order[0]->store_id;
      $get_couponid = $this->db->query("SELECT * FROM `yms_offercoupon` WHERE store_id = $store_id AND offer_code='$coupon_code'")->result();
      if($get_couponid){
          $coupon_id = $get_couponid[0]->id;
           $current_dt = date("Y-m-d H:i");
           $cpnvalidity_from = $get_couponid[0]->validity_from;
           $cpnvalidity_to = $get_couponid[0]->validity_to;
          if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to){
               $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
               $usedcnt = count($chk_coupon_usage);
               $coupon_cnt = $get_couponid[0]->offer_usage;
             if($usedcnt<=$coupon_cnt){
                $final = $order_amount-$coupon_discount;
                if($final<0){
                    $final = 0;
                }
                 $this->db->query("update orders set coupon_id = $coupon_id ,coupon_discount =$coupon_discount,total_amount=$final,customer_ordered_amt=$final where user_id = $user_id and UTN_number = '$UTN_number'");  
             }}
          
      
}
    }
//for clifton order accpeted on place_order by default // commented on 25-02-2022 order will accept by Seller app
// $this->db->query("update orders set delivery_status = 1 where UTN_number = '$UTN_number'");    

   if($payment_status=="1"){// on online payment mode success
       $get_amt = $this->db->query("select total_amount from orders where UTN_number = '$UTN_number'")->result();
       if($get_amt){
           $transaction_amt = $get_amt[0]->total_amount;
         if($razorpay_payment_id){
             $transaction_id = $razorpay_payment_id;
             $this->db->query("update orders set transaction_id = '$transaction_id' where UTN_number = '$UTN_number'");    
         }
             $this->db->query("update orders set transaction_amt = $transaction_amt where UTN_number = '$UTN_number'");    
           
       }
    
    }
    
    //send Order placed notification mail      
    $get_data = $this->db->query("SELECT ord.orderby_name,ord.orderby_contact,ord.uptodate_email,seller.email seller_email,seller.shopper_name seller_name,usr.email, usr.fullname,str.store_name,ord.UTN_number,ord.booking_time,ord.total_amount,ord.payment_method,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN user_profile usr ON usr.user_id = ord.user_id INNER JOIN shopper seller on seller.store_id = str.store_id  WHERE ord.UTN_number ='$UTN_number'")->result();
    if($get_data){
        $seller_email = $get_data[0]->seller_email;
        $email = $get_data[0]->email;
        $ordemail = $get_data[0]->uptodate_email;
        if($ordemail!=""){ //take checkout page email address for customer mail
            $email = $ordemail;
        }
        $cust_name = $get_data[0]->orderby_name;
        $seller_name = $get_data[0]->seller_name;
        $store_name = $get_data[0]->store_name;
        $dt_frmt=date_create($get_data[0]->booking_time);
        $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
        $total = $get_data[0]->total_amount;
        $payment_method = $get_data[0]->payment_method; //1 for store pickup and 2 for home delivery
        if($payment_method==1){
            $delivery_type ="Store pickup";
            $delivery_address = "-";
        }else{
            $delivery_type ="Home Delivery";
            $delivery_address = $get_data[0]->address1.', '.$get_data[0]->address2.', '.$get_data[0]->landmark.', '.$get_data[0]->area.', '.$get_data[0]->city.', '.$get_data[0]->district.', '.$get_data[0]->state.' - '.$get_data[0]->pincode;
        }
           $dt['item_dtl'] = $this->db->query("SELECT cart.preferred_del_date , cart.preferred_del_time , cart.varient_name,cart.product_name,cart.product_image,cart.product_desc,cart.quantity,cart.rate,cart.price,ord.packing_charge,ord.delivery_charge,ord.total_amount,ord.discount_amount,ord.coupon_discount FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$UTN_number'")->result();
            $dt['del_address'] = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.address1,ord.address2,ord.landmark,ord.area,city,district,state,pincode,gps_coordinates,address_name FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$UTN_number'")->result();
           //send Order placed notification mail to Customer
            if(trim($email)!=''){
            $to_receiver_email = $email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Order Accepted";
            $dt['heading'] = "Order Accepted";
            $dt['message'] = 
"Dear $cust_name, <br>

 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Greetings from <strong>  The Brownie Studio! ORDER ACCEPTED! </strong>,  Thanks for shopping with us.We are working on it now. Once it is ready to ship, we will send you another email with the tracking details. Questions? Suggestions? Insightful shower thoughts? Shoot us an email. <br> <br>

 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong style='font-size:17px;margin-left:130px'> ORDER ID : ORDER#$UTN_number </strong>   <br><br>
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Store Name : </strong> $store_name <br>
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Order Date : </strong> $booking_time <br>
 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Status : </strong>  Order Accepted  <br>

 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Delivery Type :  </strong>   $delivery_type <br>

";
$message_html = $this->load->view('template/email_template3', $dt, TRUE);
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                 if($response['status']==0){
                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                 }
            }
            //send payment confirmation mail to customer
                        if(trim($email)!='')
                        {
                            $to_receiver_email = $email;
                            $cust_name = $get_data[0]->orderby_name;
                            $from_email = 'yellowmart17@gmail.com';
                            $from_emailpassword = 'yellowmart123';
                            $from_username = 'The Brownie Studio';
                            $subject="Payment Confirmation";
                            $dt['heading'] = "Payment Confirmation";
                            $dt['message'] = 
                            "Dear $cust_name, <br>
                            
                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Thanks for the payment for your  <strong> ORDER ID : ORDER#$UTN_number </strong><br>
                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Your order will be delivered shortly and you will receive the confirmation on the same.<br>
                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  For any queries, you can reachout through <strong>thebrowniestudio@gmail.com</strong><br><br>
 
                            ";
                             $message_html = $this->load->view('template/payment_template', $dt, TRUE);
                             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                             if($response['status']==0)
                             {
                                 echo json_encode(array('status'=>0,'message'=>'Failed to send mail1 ')); exit;
                            }
                        }
            //Send Order Placed notification mail to seller
    if(trim($seller_email)!=''){
            $to_receiver_email = $seller_email;
            $from_email = 'mailtest12327@gmail.com';
            $from_emailpassword = 'm@iltest@123';
            $from_username = 'The Brownie Studio';
            $subject="Order ID : $UTN_number";
            $message = 
"Dear $seller_name

You have received a new order from $cust_name.

Store Name : $store_name 
Order ID : $UTN_number
Order Date : $booking_time
Status : Order Placed
Total : $total

Delivery Type: $delivery_type
Customer Address :
$delivery_address

Thank You,
Team YellowMart";
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
                 if($response['status']==0){
                    //echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                    redirect(base_url().'home/order_summary');
                    exit;                     
                 }
            }
    }
    // send order placed SMS to customer
    if($get_data){
        $name = $get_data[0]->orderby_name;
        $contact = $get_data[0]->orderby_contact;
         if($name!="" && $contact!=""){
            $result5 = $this->Sms_model->send_transactionsms(91, $contact,$name, $UTN_number);
        }
    }

        //send order placed push notification to seller
        $seller = $this->db->query("select id,token_key,str.store_name from shopper seller INNER JOIN stores str ON seller.store_id = str.store_id where str.store_id  =$store_id ")->result();
        if($seller){
            $token_key = $seller[0]->token_key;
            $message ="ORDER#$UTN_number   $store_name - You have received a new order.";
            $title = "Order placed by the customer";
            $notify_type = "order_received";
            $user_id = $user_id;
            $seller_id = $seller[0]->id;
            $delivery_boyid = 0;
            $notified_person = "seller";
            if($token_key!=''){
            $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
            }
        }
        //send order place thanku push notification to customer
        $customer = $this->db->query("SELECT * FROM user_profile WHERE user_id = $user_id ")->result();
        if($customer){
                    $token_key = $customer[0]->token_key;
                    $store_name = $seller[0]->store_name; 
                    $message ="Thank you for placing an order with $store_name! Your ORDER#$UTN_number $store_name";
                    $title = "Thank you for placing an order";
                    $notify_type = "order_placed";
                    $user_id = $user_id;
                    $seller_id = $seller[0]->id;
                    $delivery_boyid = 0;
                    $notified_person = "customer";
                    if($token_key!=''){
                    $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
                    }
                    }
                       
                    
                    // redirect(base_url().'confirm_order');
                    redirect(base_url().'confirm_order/'.encode_param($UTN_number));
        exit;
    }
    else{
         redirect(base_url().'home/order_summary');
    }
}
public function get_quickview(){
     if($_POST){ 
        $prod_id = $_POST['prod_id'];
        $item_id = $_POST['item_id'];
        $fil_sortby= "";$where_filter="";
        $store_id =1;
        $_POST['cake_type'] = 0;// 0 - egg & eggless 1-egg 2 - eggless
        
        $userdata = $this->session->userdata('brownie_webuser');
        $data['userdata'] = $userdata;
        $user_id =0;
        if(isset($userdata[0]->user_id)){
            $user_id =$userdata[0]->user_id;
        }
        //load previous cart product preferred date and time default
         $pre_deldate = "";$pre_deltime = "";
        $get_datetime = $this->db->query("select preferred_del_date,preferred_del_time from cart where order_id = 0 and user_id = $user_id")->result();
        if($get_datetime){
            if($get_datetime[0]->preferred_del_date!='0000-00-00'){
                $pre_deldate = $get_datetime[0]->preferred_del_date;
            }
            if($get_datetime[0]->preferred_del_time!=''){
                $pre_deltime = $get_datetime[0]->preferred_del_time;
            }
        }
        
         $quick_viewfil = "and pro.prod_id = $prod_id and prodtl.prod_itemid = $item_id"; 
        $products = $this->Common_model->filterpro_list($store_id,$fil_sortby,$where_filter,$_POST,$quick_viewfil);
        $product_filtered = json_decode(json_encode($products), FALSE);
        if($pre_deldate==""){
            $pre_deldate = date("Y-m-d");    
        }
        $delivery_slot = $this->get_deliveryslot($pre_deldate);
        $delivery_slotarray = $delivery_slot['data'];
    if($product_filtered){
    $qui_vw = $product_filtered[0]; ?>
    <h5 class="modal-title blue_color_custom mb-3 text-capitalize text-center" id="quick_viewLabel"> <a class="blue_color_custom text-capitalize " href="<?php echo base_url('product_detail/'.$prod_id.'/'.$this->encode_param($item_id)) ?>"><?php echo $qui_vw->prod_name; ?></a></h5>
        <section class="product_details_area p_100 pb-0 pt-0">
            	<div class="container">
            		<div class="row product_d_price mb-3">
            		    <input type="hidden" value="<?php echo $prod_id; ?>" name="product_id" id="product_id" >
		                <input type="hidden" value="<?php echo $item_id; ?>" name="item_id" id="item_id" > 
		                <input type="hidden" id="user_id" value="<?php echo $user_id;?>" ?>
            		    <div class="col-lg-6 mx-auto">
            		       	<div  class="carousel slide " data-ride="carousel" id="carouselExampleControls">
            		       	    
            		       	    
                		       	    <ol class="carousel-indicators">
            		       	          <?php $img_cnt = count($qui_vw->image);
            		       	           $m=0;
            		       	          for($m=0;$m<$img_cnt;$m++){ ?>
                                      <li data-target="#carouselExampleControls" data-slide-to="<?php echo $m; ?>" class="<?php if($m == 0) echo 'active'; ?> cursor_pointer_custom" ></li>
                                      <?php } ?>
                                    </ol>
                                    
            		       	      <a href="<?php echo base_url('product_detail/'.$prod_id.'/'.$this->encode_param($item_id)) ?>">
                    				<div class="product_img carousel-inner pr-0">
                    				    <?php $imgs = $qui_vw->image;
                    				    foreach($imgs as $im){
                    				    ?>
                    				   
            							<img class="img-fluid carousel-item w-100 prod_img_cust" src="<?php echo base_url('../'.$im->product_image)?>" alt="" style="height:250px;object-fit:contain">
            						
            							<!--<img class="img-fluid carousel-item w-100 prod_img_cust" src="img/prod_2.jpg" alt="" style="height:250px;object-fit:contain">-->
            							<?php } ?>
            						</div>
        						  </a>
        						<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        							<span class="carousel-control-prev-icon  p-2 rounded " aria-hidden="true"></span>
        							<span class="sr-only">Previous</span>
        						</a>
        						<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        							<span class="carousel-control-next-icon  p-2 rounded " aria-hidden="true"></span>
        							<span class="sr-only">Next</span>
        						</a>
            		        </div>
        		        	<div class="row col-xl-12 col-lg-12 col-12 c  pb-4 mx-auto ">
        					    	<h5 class=" text-dark text-center col-12 mt-3">Price  :<span class="ml-1" id="price">Rs.&nbsp;<?php echo $qui_vw->display_price?> </span></h5>
        					</div>
            			</div>
    					
            			<div class="col-lg-6 pr-0">
            				<div class="product_details_text row ml-0 pt-1">
    							<div class="row col-xl-12 col-lg-12 col-12  pb-4 px-0">
    								<!--<span class="input-group-text bg-white border-0  text-dark  d-block d-lg-none d-xl-none col-12 text-left" id="quantity-addon1" style="font-weight: 600;">-->
    								<!--				Qty -->
    								<!--</span>-->
    								<div class="col-12 col-xl-6 col-lg-6 my-3 ">
    
    									<div class="input-group  mx-0 px-0">
    										<div class="input-group-prepend">
    											<span class="input-group-text bg-white best_seller_dropdown  rounded-0 text-dark font-weight-normal p-1 " id="quantity-addon1" style="font-weight: 600;font-size:14px">
    												Qty 
    											</span>
    										</div>
    										<select class="form-control best_seller_dropdown rounded-0" aria-describedby="quantity-addon1" id="variant1" style="font-size:13px" onchange="load_item(1)">
    										    <?php $var = $qui_vw->variant; foreach($var as $v){  ?>
    											<option value="<?php echo $v->var_value;?>"><?php echo $v->var_value?></option>
    											<?php } ?>
    										</select>
    									</div>
    								
    								</div>
    								<div class="col-12 my-auto col-lg-6 col-xl-6">
    							
    									<div class="input-group">
    										<a href="#" class="input-group-addon minus increment btn btn-light border border-right-0  rounded-0" id="decrement" onclick="add_qty(-1)"><i class="fa fa-minus" aria-hidden="true"></i></a>
    
    										<input type="text" class="form-control text-center " id="qty" size="<?php echo $qui_vw->stock;?>" value="1"  onkeypress="return isNumber(event)">
    
    										<a href="#" class="input-group-addon plus increment btn btn-light border border-left-0  rounded-0" id="increment" onclick="add_qty(1)"><i class="fa fa-plus" aria-hidden="true"></i></a>
    									</div>
    								</div>
    							</div>
    							</div>
    						
    							<div class="row col-12 px-0 pb-4  ">
    							
    								<div class="col-12 col-xl-12 col-lg-12 my-2 pr-0">
    									<div class="input-group  mx-0 px-0">
    										<div class="input-group-prepend col-12 pl-0 col-lg-6">
    											<span class="input-group-text bg-white border-0   font-weight-light  text-dark pl-0 " id="date-addon1" style="font-weight: 400;font-size: 14px;">
    											Enter preferred date :
    											</span>
    										</div>
    										<input type="date" class=" text-uppercase form-control best_seller_dropdown rounded-0" id="preferred_del_date" aria-describedby="date-addon1" name="phone_number" placeholder="Phone Number" style="font-size:13px" onchange="validate('date');" value="<?php echo ($pre_deldate!="")?$pre_deldate:'' ?>" min="<?php echo date("Y-m-d"); ?>" >
    										<span id="preferred_del_date_error" class="text-danger error_msg col-12 pl-0 font_14 "></span>
    									</div>
    								</div>
    							
    								<div class="col-12 col-xl-12 col-lg-12 my-2 pr-0">
    									<div class="input-group  mx-0 px-0">
    										<div class="input-group-prepend col-12 pl-0 col-lg-6">
    											<span class="input-group-text bg-white border-0  font-weight-light text-dark pl-0" id="Time-addon1" style="font-weight: 400;font-size: 14px;">
    											Enter preferred time :
    											</span>
    										</div>
    										<select class="form-control best_seller_dropdown rounded-0" aria-describedby="Time-addon1" id="preferred_del_time" onchange="validate('time');" style="font-size:13px">
    										          <option value=""<?php echo ($pre_deltime == '')?"selected":"" ?> >Select Time</option>
    										          <?php if($delivery_slotarray){ foreach($delivery_slotarray as $sl){ ?>
    										                <option value="<?php echo $sl['time_slot'];?>"<?php echo ($pre_deltime == $sl['time_slot'])?"selected":"" ?>><?php echo $sl['time_slot_view'];?></option>      
    										          <?php }}else { ?>
											    <option value="08:00am to 09:00am"<?php echo ($pre_deltime == '08:00am to 09:00am')?"selected":"" ?>>08am to 09am</option>
												<option value="09:00am to 10:00am"<?php echo ($pre_deltime == '09:00am to 10:00am')?"selected":"" ?>>09am to 10am</option>
												<option value="10:00am to 11:00am"<?php echo ($pre_deltime == '10:00am to 11:00am')?"selected":"" ?>>10am to 11am</option>
												<option value="11:00am to 12:00pm"<?php echo ($pre_deltime == '11:00am to 12:00pm')?"selected":"" ?>>11am to 12pm</option>
												<option value="12:00pm to 01:00pm"<?php echo ($pre_deltime == '12:00pm to 01:00pm')?"selected":"" ?>>12pm to 01pm</option>
												<option value="01:00pm to 02:00pm"<?php echo ($pre_deltime == '01:00pm to 02:00pm')?"selected":"" ?>>01pm to 02pm</option>
												<option value="02:00pm to 03:00pm"<?php echo ($pre_deltime == '02:00pm to 03:00pm')?"selected":"" ?>>02pm to 03pm</option>
												<option value="03:00pm to 04:00pm"<?php echo ($pre_deltime == '03:00pm to 04:00pm')?"selected":"" ?>>03pm to 04pm</option>
												<option value="04:00pm to 05:00pm"<?php echo ($pre_deltime == '04:00pm to 05:00pm')?"selected":"" ?>>04pm to 05pm</option>
												<option value="05:00pm to 06:00pm"<?php echo ($pre_deltime == '05:00pm to 06:00pm')?"selected":"" ?>>05pm to 06pm</option>
												<option value="06:00pm to 07:00pm"<?php echo ($pre_deltime == '06:00pm to 07:00pm')?"selected":"" ?>>06pm to 07pm</option>
												<option value="07:00pm to 08:00pm"<?php echo ($pre_deltime == '07:00pm to 08:00pm')?"selected":"" ?>>07pm to 08pm</option>
												<option value="08:00pm to 09:00pm"<?php echo ($pre_deltime == '08:00pm to 09:00pm')?"selected":"" ?>>08pm to 09pm</option>
												<option value="09:00pm to 10:00pm"<?php echo ($pre_deltime == '09:00pm to 10:00pm')?"selected":"" ?>>09pm to 10pm</option>
												<option value="10:00pm to 11:00pm"<?php echo ($pre_deltime == '10:00pm to 11:00pm')?"selected":"" ?>>10pm to 11pm</option>
												<option value="11:00pm to 12:00am"<?php echo ($pre_deltime == '11:00pm to 12:00am')?"selected":"" ?>>11pm to 12pm</option>
												<?php } ?>
    										</select>
    										<span id="preferred_del_time_error" class="text-danger error_msg col-12 pl-0 font_14"></span>
    									</div>	
    								</div>
    									
    							</div>
    							
    							<div class="form-group col-md-12 pl-0">
    							    <?php if($qui_vw->subcat_id==4){  //Brownies & Desserts
    							        $message_on_ck = 'Type Message On Card';
    							    }else{
    							        $message_on_ck = 'Type Message On Cake';
    							    }
    							    ?>
    								<textarea class="form-control best_seller_dropdown rounded-0" name="message" id="message_on_cake" rows="2" placeholder="<?php echo $message_on_ck;?>" style="font-size:14px"></textarea>
    							</div>
    						
            				
            				</div>
            			<div class="col-lg-12 row mx-auto pl-0 pr-0">
        				    <div class="col-lg-6 mx-auto my-2">
        				        	<a class="pink_more text-uppercase  text-center col-12 bg_pink" href="<?php echo base_url('product_detail/'.$prod_id.'/'.$this->encode_param($item_id)) ?>">View Now</a>
        				    </div>
        				    <div class="col-lg-6 mx-aut my-2">
        				           <!--<a class="pink_more text-uppercase  text-center col-12 bg_pink" href="<?php echo base_url();?>cart">Add to Cart</a>-->
        				           <a class="pink_more text-uppercase text-center col-12 bg_pinkr" id="add_to_cart" href="javascript:void(0);" onclick='return add_cart(1)'>Add to Cart</a>
        				    </div>
        				    
            			</div>
            			</div>
            		</div>
            </section>
            <?php }
    }else{
        echo 'somethin went wrong please try again';
    }
}
public function load_item(){
    if($_POST){
        $product_id = $_POST['product_id'];
        $variant1 = $_POST['variant1']; //weight //piece//box
        $variant2 = $_POST['variant2']; //type (egg , eggless)
        $variant3 = $_POST['variant3']; //shape
        $whr ="";
        if($_POST['cur_var_changed']==1){
            $whr = " and var1 = '$variant1'";
        }else if($_POST['cur_var_changed']==2){
            $whr = " and var2 = '$variant2'";
        }else if($_POST['cur_var_changed']==3){
            $whr = " and var3 = '$variant3'";
        }
        $where = "WHERE pro.prod_id = $product_id";
        if($variant1!=""){
            $where = $where." and var1 = '$variant1'";
        }
        if($variant2!=""){
            $where = $where." and var2 = '$variant2'";
        }
        if($variant3!=""){
            $where = $where." and var3 = '$variant3'";
        }
        $get_data = $this->db->query("SELECT * FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id $where")->result();
        if($get_data){
            if($get_data[0]->price_to_display==1){
                $price = $get_data[0]->mrp_price;
            }else if($get_data[0]->price_to_display==2){
                $price = $get_data[0]->mop_price;
            }else  if($get_data[0]->price_to_display==3){
                $price = $get_data[0]->offer_price;
            }else{
                $price = $get_data[0]->mrp_price;
            }
            $price = round($price,0);
            $response = array('prod_id'=>$product_id,
            'item_id'=>$get_data[0]->prod_itemid,
            'var1'=>$get_data[0]->var1,
            'var2'=>$get_data[0]->var2,
            'var3'=>$get_data[0]->var3,
            'price'=>'Rs.'.$price
            );
        }else{
            $get_firstitem = $this->db->query("SELECT * FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id WHERE pro.prod_id = $product_id $whr ")->result();    
            if($get_firstitem){
                        if($get_firstitem[0]->price_to_display==1){
                        $price = $get_firstitem[0]->mrp_price;
                    }else if($get_firstitem[0]->price_to_display==2){
                        $price = $get_firstitem[0]->mop_price;
                    }else  if($get_firstitem[0]->price_to_display==3){
                        $price = $get_firstitem[0]->offer_price;
                    }else{
                        $price = $get_firstitem[0]->mrp_price;
                    }
                    $price = round($price,0);
                $response = array('prod_id'=>$product_id,
                'item_id'=>$get_firstitem[0]->prod_itemid,
                'var1'=>$get_firstitem[0]->var1,
                'var2'=>$get_firstitem[0]->var2,
                'var3'=>$get_firstitem[0]->var3,
                'price'=>'Rs.'.$price
                );
            }
        }
        if(isset($response)){
            echo json_encode(array('status'=>1,'message'=>"",'response'=>$response));
        }else{
            echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));    
        }
    }else{
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again'));
        exit;
    }
}
public function apply_couponcode(){
    if($_POST){
        $user_id = $_POST['user_id'];
        $coupon_code = trim($_POST['coupon_code']);
        $district = trim($_POST['district']);
        $state_id = $_POST['stateid'];
        $total_array = array();
        $overall_discount_text = "";
        $store_id = 1;
        $total = 0;$items = 0;$mrp_total=0;$est_delivery_charge=0;$est_packing_charge=0;$display_price=0;
        $price = $this->db->query("select * from cart where user_id =$user_id and order_id = 0 and product_status = 0")->result();
        if($price){
            foreach($price as $p){
            $total = $total + $p->display_price;
            $display_price = $display_price + $p->display_price;
            $mrp_total = $mrp_total + $p->mrp_price;
            $items = $items + $p->quantity;
            }
        }
        $str = $this->db->query("select stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,store_delivery_type from stores where store_id = $store_id ")->result();
                                if($str){
                                    $packing_charges = $str[0]->packing_charges;
                                    $delivery_charges = $str[0]->delivery_charges;
                                    $store_delivery_type = $str[0]->store_delivery_type; // 1-storepickup 2 -home delivery 3- both
                                    if($packing_charges ==0){ //disable // packing charge = 0
                                        $est_packing_charge = 0;
                                    } 
                                    else { //packing charges enabled for this store
                                        $pc_type = $str[0]->pc_type;
                                        $pc_perc = $str[0]->pc_perc;
                                        $pc_unit_value = $str[0]->pc_unit_value;
                                        if($pc_type==0){ //percwise
                                        // $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
                                        $est_packing_charge = round(($display_price * ($pc_perc/100)),0);
                                        }else{ //unitwise
                                        $est_packing_charge =  round(($items * $pc_unit_value),0);
                                        }   
                                    }
                                    
                                    if($delivery_charges ==0 || $store_delivery_type==1){ //disable // packing charge = 0
                                        $est_delivery_charge = 0;
                                        $delivery_charges = 0; //$store_delivery_type ==1 means store pickup so don't show delivery_charge
                                    }else{
                                        $est_delivery_charge = $str[0]->min_dc;
                                        if(strtoupper($district)=="CHENNAI" && $state_id==1 ){ ////manual address change can't calculate accurate distance
                                            $est_delivery_charge = round($str[0]->min_dc,0);
                                        }else if($state_id==1){ //Inside Tamilnadu outside chennai
                                            $est_delivery_charge = 75;
                                        }else{
                                            $est_delivery_charge = 130;
                                        }
                                    }
                                }
                       $tot = $total + $est_packing_charge + $est_delivery_charge;
                       $tot = round($tot,0);
                       $overall_dis = $mrp_total -  $total;
                       $overall_dis = round($overall_dis,0);
                       if($overall_dis>0){
                            $overall_discount_text = 'You have saved Rs.'.$overall_dis.' on this order.';
                       }
        $total_array = array(
            'coupon_code' =>$coupon_code,
            'coupon_discount' => "0",
            'total' =>"$tot",
            'discount_text'=>$overall_discount_text,
            'delivery_charge'=>$est_delivery_charge,
            'packing_charge'=>$est_packing_charge
            
            );
        $chk_coupon_availability =$this->db->query("select id,offer_code,offer_usage from yms_offercoupon where store_id =$store_id and offer_code = '$coupon_code'")->result();
        if(empty($chk_coupon_availability)){
            echo json_encode(array('status'=>2,'message'=>'Please enter valid coupon','data'=>$total_array));
           exit;
        }
        else{
            $coupon_id= $chk_coupon_availability[0]->id;
            $offer_usage = $chk_coupon_availability[0]->offer_usage;
            $ord = $this->db->query("select * from orders where user_id =$user_id and coupon_id = $coupon_id")->result();
            $couponused_cnt = count($ord);
            if($couponused_cnt >= $offer_usage){
                echo json_encode(array('status'=>2,'message'=>'Coupon used more than assigned','data'=>$total_array));
               exit;
            }else{
                   //offer || coupon code discount
                if(isset($_POST['coupon_code'])){
                $coupon_code = trim($_POST['coupon_code']);
                $get_cpndtl = $this->db->query("select * from yms_offercoupon where offer_code = '$coupon_code' ")->result();
                if($get_cpndtl){
                    $current_dt = date("Y-m-d H:i");
                    $cpnvalidity_from = $get_cpndtl[0]->validity_from;
                    $cpnvalidity_to = $get_cpndtl[0]->validity_to;
                    $coupon_id = $get_cpndtl[0]->id;
                    if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to){ //coupon validation date & time
                        $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
                        $usedcnt = count($chk_coupon_usage);
                        $coupon_cnt = $get_cpndtl[0]->offer_usage;
                        if($usedcnt<=$coupon_cnt){
                            $rule_type = $get_cpndtl[0]->rule_type; // 1- prec% 2- flat
                            $rule_value = $get_cpndtl[0]->rule_value; // how much percentage or flat price //5% or 50FLAT
                            $condition_chkvalue = $get_cpndtl[0]->condition_chkvalue; //thershold value
                            if($total >= $condition_chkvalue){ // order amount should greater than $condition_chkvalue
                            $coupon_discount =0;
                            if($rule_type==1 ){ //%
                                $coupon_discount = ($rule_value / 100) * $total;
                            }else if($rule_type==2 ){ //Flat
                                $coupon_discount = $rule_value;
                            }
                            $coupon_discount = round($coupon_discount,0);
                            // $total_amt = round(($total + $est_packing_charge + $est_delivery_charge - $rule_value),2);
                            $total_amt = $total - $coupon_discount + $est_delivery_charge + $est_packing_charge;
                            if($total_amt<0){
                                $total_amt =0;
                            }
                            $overdis = $mrp_total -  $total + $coupon_discount;
                            $overall_dis = round($overdis,0);
                            // $overall_discount_text = 'You have saved Rs.'.$coupon_discount.' on this order.';
                            $overall_discount_text = 'You have saved Rs.'.$overall_dis.' on this order.';
                            

                            $total_amt = round($total_amt,0);
                            $total_array = array(
                                    'coupon_code' =>$coupon_code,
                                    'coupon_discount' => "$coupon_discount",
                                    'total' =>"$total_amt",
                                    'discount_text'=>$overall_discount_text,
                                    'delivery_charge'=>$est_delivery_charge,
                                    'packing_charge'=>$est_packing_charge
                                    );
                             echo json_encode(array('status'=>1,'message'=>'Coupon available','data'=>$total_array));
                               exit;
                            }
                        }else{
                             echo json_encode(array('status'=>2,'message'=>'Coupon used more than assigned','data'=>$total_array));
                               exit;
                        }
            
        }
                    else{
                        echo json_encode(array('status'=>2,'message'=>'Coupon expired','data'=>$total_array));
                       exit;
                    }
    }
                }
                      echo json_encode(array('status'=>2,'message'=>'Invalid coupon','data'=>$total_array));
                       exit;
                
            }
            
        }
    }else{
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again!'));
        exit;
    }
}
public function ajaxwrite_review(){
    if($_POST){
        $insert_data['user_id'] = $_POST['user_id'];
        $insert_data['store_id'] = 1;
        $insert_data['product_id'] = $_POST['product_id'];
        $insert_data['item_id'] = $_POST['item_id'];
        $insert_data['star_count'] = $_POST['star_count'];
        $insert_data['review_type'] = $_POST['review_type'];
        if(isset($_POST['comment'])){
        $insert_data['comment'] = $_POST['comment'];
        }
    $insert_data['date_reviewed'] = date('Y-m-d H:i:s');
    $status = $this->db->insert('user_reviews',$insert_data);
     echo 'Product review updated successfully ';
    }else{
     echo 'Something went wrong please try again!';
    }
}
// catering add
   public function ajax_add_catering(){
        $insert['name'] = $_POST['name'];
        $insert['phonenumber'] = $_POST['phonenumber'];
        $insert['email'] = $_POST['email'];
        $insert['message'] = $_POST['message'];
        $insert['created_at'] = $_POST['created_at'];
        $result = $this->db->insert('catering ',$insert);
        	$email = "officetbs33@gmail.com";
        // 	$email = "yellowmart17@gmail.com";
        	$name = $_POST['name'];
        	$mail = $_POST['email'];
        	$phone =$_POST['phonenumber'];
        	$message = $_POST['message'];
// 			mail start
 //send welcome mail to Customer
            if(trim($email)!=''){
                $to_receiver_email = $email ;
                $cust_name = "The Brownie Studio";
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Corporate Gifting";
                $dt['heading'] = "Corporate Gifting";
                $dt['message'] = 
                "Dear $cust_name, <br>

                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $message<br><br>
                
                Regards,<br>
                <strong>$name</strong> <br>
                <strong>$phone</strong> <br>
                <strong>$mail</strong> <br> ";
                $message_html = $this->load->view('template/client_mail', $dt, TRUE);
                                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                                 
                                 if($response['status']==0)
                                 {
                                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                                 }
                            }
            // mail end
                echo '1';
    }
// contact add
   public function ajax_add_contact(){
        $insert['name'] = $_POST['name'];
        $insert['phonenumber'] = $_POST['phonenumber'];
        $insert['email'] = $_POST['email'];
        $insert['message'] = $_POST['message'];
        $insert['created_at'] = $_POST['created_at'];
        $result = $this->db->insert('yms_custenquiry',$insert);
        	$email = "officetbs33@gmail.com";
        	$name = $_POST['name'];
        	$mail = $_POST['email'];
        	$phone =$_POST['phonenumber'];
        	$message = $_POST['message'];
// 			mail start
 //send welcome mail to Customer
            if(trim($email)!=''){
                $to_receiver_email = $email ;
                $cust_name = "The Brownie Studio";
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Customer Mail";
                $dt['heading'] = "Customer Mail";
                $dt['message'] = 
                "Dear $cust_name, <br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $message<br><br>
                
                Regards,<br>
                <strong>$name</strong> <br>
                <strong>$phone</strong> <br>
                <strong>$mail</strong> <br> ";
                $message_html = $this->load->view('template/client_mail', $dt, TRUE);
                                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                                 
                                 if($response['status']==0)
                                 {
                                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                                 }
                            }
            // mail end
                echo '1';
    }
    
    
public function getLocation(){
    //if latitude and longitude are submitted
if(!empty($_POST['latitude']) && !empty($_POST['longitude'])){
    //send request and receive json data by latitude and longitude
    //$url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($_POST['latitude']).','.trim($_POST['longitude']).'&sensor=false';
    // $url = 'https://www.googleapis.com/geolocation/v1/geolocate/json?latlng='.trim($_POST['latitude']).','.trim($_POST['longitude']).'&key=AIzaSyCd6AEjgjd8og9Czs5FasZgHrm_OGBDirc';
    $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($_POST['latitude']).','.trim($_POST['longitude']).'&sensor=false'.'&key=AIzaSyCkMYx-6z7bZcwABmD1b2glrJsKw7jile8';
    $json = @file_get_contents($url);
    $data = json_decode($json);
    $status = $data->status;
    $user_id = $_POST['user_id'];
    
    //if request status is successful
    if($status == "OK"){
        //get address from json data
        $formatted_address = $data->results[0]->formatted_address;
            // $addressFrom = "7WR+WQW, Mettupalayam, Tamil Nadu 641301";//tharani address
            $addressFrom = "The Brownie Studio, 77, Pillaiyar Koil St, Apparao Garden, Aminjikarai, Chennai, Tamil Nadu 600030";
            $addressTo = $formatted_address;
            $distancekm = $this->getDistance($addressFrom, $addressTo, "K");
            $distance = str_replace(" km","",$distancekm);
        // echo '<pre>';
        // print_r($data->results[0]);
        $street_address = ""; $landmark =""; $area = ""; $city = ""; $postal_code = ""; $district = ""; $state = "";
        $location = $data->results[0]->address_components;
        $location_array = array();
        foreach($location as $add){
            $type ="";
            if(isset($add->types[0])){
                $type = $add->types[0];
            }
            if($type=="landmark"){
                $landmark = $add->long_name;
            }
            if($type=="postal_code"){
                $postal_code = $add->long_name;
            }
            if($type=="locality"){
                $city = $add->long_name;
            }
            if($type=="administrative_area_level_2"){
                $district = $add->long_name;
            }
            if($type=="administrative_area_level_1"){
                $state = $add->long_name;
            }
            if($type=="street_address"){
                $street_address = $add->long_name;
            }
            $delivery_charge =0;
            $store_id = 1;
            if(strtoupper($district)=="CHENNAI"){ //For Chennai km wise charge
                $calc_delc = $this->db->query("select delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm from stores where store_id = $store_id and delivery_charges=1")->result();
                if($calc_delc){
                    $min_dc = $calc_delc[0]->min_dc;
                    $dc_freekm = $calc_delc[0]->dc_freekm;
                    $dc_perkm = $calc_delc[0]->dc_perkm;
                    if($distance >$dc_freekm){
                        $ex_km = $distance - $dc_freekm;
                        $delivery_charge = round($min_dc + ($ex_km * $dc_perkm),0);
                    }else{
                        $delivery_charge = round($min_dc,0);
                    }
                }
            }else if(strtoupper($state)=="TAMIL NADU" || strtoupper($state)=="TAMILNADU"){ //Outside Chennai inside Tamil Nadu: 75 Rs
                $delivery_charge = '75';
            }else{
                $delivery_charge = '130';
            }
            
        $userdata = $this->session->userdata('brownie_webuser');
        if(isset($userdata[0]->user_id)){
            $user_id =$userdata[0]->user_id;
        }
        $store_id =1;
        $str = $this->db->query("select stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,'3' as payment_method from stores where stores.store_id = $store_id")->result();
        $tot = 0;$items =0;
        $get_cartamt = $this->db->query("select display_price,quantity from cart where order_id=0 and user_id=$user_id")->result(); 
        foreach($get_cartamt as $cart){
            $tot = $tot + $cart->display_price;
            $items = $items + $cart->quantity;
        }
        $packing_charges = $str[0]->packing_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($tot * ($pc_perc/100)),0);
            }else{ //unitwise
            $est_packing_charge =  round(($items * $pc_unit_value),0);
            }   
        }
        
        $final_tot = $tot;
        $stateid = 0;
        if(strtoupper($state)=="TAMIL NADU"){ //remove space only for tamilnadu
            $chk_state = 'Tamilnadu';
        }else{
            $chk_state = $state;
        }
            $get_stateid = $this->db->query("select * from state where state='$chk_state'")->result();
            if($get_stateid){
                $stateid =$get_stateid[0]->state_id;
            }
            $location_array = array(
                'street_address'=>$street_address,
                'area' => $area,
                'city'=> $city,
                'postal_code' => $postal_code,
                'district' => $district,
                'state' => $state,
                'stateid' => $stateid,
                'googlemap_address'=>$formatted_address,
                'delivery_charge' =>$delivery_charge,
                'packing_charge' =>$est_packing_charge,
                'final_total' =>$final_tot+$delivery_charge+$est_packing_charge,
                'distance' =>$distance
                );
        }
        // die;
        echo json_encode(array('status'=>1,'message'=>'Address details','location_data' => $location_array));
        exit;
    }else{
        $location =  '';
        echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again!'));
        exit;
    }
}else{
    echo json_encode(array('status'=>0,'message'=>'Something went wrong please try again!'));
        exit;
}
}
function getDistance($addressFrom, $addressTo, $unit = ''){
    // Google API key
    $apiKey = 'AIzaSyCkMYx-6z7bZcwABmD1b2glrJsKw7jile8';
    
    // Change address format
    $formattedAddrFrom    = str_replace(' ', '+', $addressFrom);
    $formattedAddrTo     = str_replace(' ', '+', $addressTo);
    
    // Geocoding API request with start address
    $geocodeFrom = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.$formattedAddrFrom.'&sensor=false&key='.$apiKey);
    $outputFrom = json_decode($geocodeFrom);
    if(!empty($outputFrom->error_message)){
        return $outputFrom->error_message;
    }
    
    // Geocoding API request with end address
    $geocodeTo = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address='.$formattedAddrTo.'&sensor=false&key='.$apiKey);
    $outputTo = json_decode($geocodeTo);
    if(!empty($outputTo->error_message)){
        return $outputTo->error_message;
    }
    
    // Get latitude and longitude from the geodata
    $latitudeFrom    = $outputFrom->results[0]->geometry->location->lat;
    $longitudeFrom    = $outputFrom->results[0]->geometry->location->lng;
    $latitudeTo        = $outputTo->results[0]->geometry->location->lat;
    $longitudeTo    = $outputTo->results[0]->geometry->location->lng;
    
    // Calculate distance between latitude and longitude
    $theta    = $longitudeFrom - $longitudeTo;
    $dist    = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) +  cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
    $dist    = acos($dist);
    $dist    = rad2deg($dist);
    $miles    = $dist * 60 * 1.1515;
    
    // Convert unit and return distance
    $unit = strtoupper($unit);
    if($unit == "K"){
        return round($miles * 1.609344, 2).' km';
    }elseif($unit == "M"){
        return round($miles * 1609.344, 2).' meters';
    }else{
        return round($miles, 2).' miles';
    }
}
//from home page -> on click colection load selected category product list
public function loadproduct(){
    if($_POST){
        $cat = $_POST['cat'];
        $this->session->set_userdata('collectionby',$cat);
        echo 1;
    }else{
        echo 0;    
    }
    
}
public function get_deliveryslot($preferred_del_date=""){
    $list = $this->db->query("select * from delivery_slot where enable =1")->result();
    $del_array = array();
    if($list){
        foreach($list as $dt){
            $del_date = explode("to",$dt->time_slot);
            $deldate_from =  date("H", strtotime($del_date[0]));
            $deldate_to =  date("H", strtotime($del_date[1]));
            $cur_time = date("H");
            $today = date("Y-m-d");
            $allow = 0;
            if($preferred_del_date==$today){ // for today show only available delivery timing
                if($deldate_from >= $cur_time + 1){
                    $allow = 1;
                }   
            }else{ //other days show all delivery timing
                $allow = 1;
            }
            if($allow==1){
                $del_array[] = array(
                    'id' => $dt->id,
                    'time_slot'=>$dt->time_slot,
                    'time_slot_view'=>$dt->time_slot_view
                    );
            }
        }
    }
    return $result = array('status'=>1,'data'=>$del_array); 
}
public function ajaxload_deliveryslot(){
    if($_POST){
        $preferred_del_date = $_POST['preferred_del_date'];
        $user_id = $_POST['user_id'];
        //load previous cart product preferred date and time default
         $pre_deldate = "";$pre_deltime = "";
        $get_datetime = $this->db->query("select preferred_del_date,preferred_del_time from cart where order_id = 0 and user_id = $user_id")->result();
        if($get_datetime){
            if($get_datetime[0]->preferred_del_date!='0000-00-00'){
                $pre_deldate = $get_datetime[0]->preferred_del_date;
            }
            if($get_datetime[0]->preferred_del_time!=''){
                $pre_deltime = $get_datetime[0]->preferred_del_time;
            }
        }
        $delivery_slot = $this->get_deliveryslot($preferred_del_date);
        $delivery_slotarray = $delivery_slot['data'];?>
                    <option value=""<?php echo ($pre_deltime == '')?"selected":"" ?> >Select Time</option>
		            <?php if($delivery_slotarray){ foreach($delivery_slotarray as $sl){ ?>
				                <option value="<?php echo $sl['time_slot'];?>"<?php echo ($pre_deltime == $sl['time_slot'])?"selected":"" ?>><?php echo $sl['time_slot_view'];?></option>      
				          <?php } } 
    }else{
        echo 'Something went wrong please try again!';
    }
}
public function update_deladdress()
{
    if($_POST){
        $id = $_POST['address_id'];
        $user_id = $_POST['user_id'];
        $data1['address_type']  = 0; //update all address as normal saved address
        $status = $this->db->update('address',$data1,array('user_id'=>$user_id)); 
        $data2['address_type']  = 1; //update this address as default address
        $status = $this->db->update('address',$data2,array('id'=>$id)); 
        // $store_id =1;
        // $get_calc = $this->get_delpack_charge($store_id,$user_id);
        // if($get_calc['status']==1){
        //     $datas = $get_calc['data'];
        //     $packing_charge = $datas['packing_charge'];
        //     $delivery_charge = $datas['delivery_charge'];
        //     $tot = $datas['total_amount'];
        // }else{
        //     echo json_encode(array('status'=>0,'message'=>'Something went wrong'));
        //     exit;
        // }
        $current_address = $this->db->query("SELECT delto_name,delto_contact,address.id,address.user_id,address.address1,address.address2,address.landmark,address.area_id,area.area_locality,address.city_id,city.city_name,district.district,address.district_id,
        state.state,address.state_id,address.pincode,address.address_name,address.gps_coordinates FROM address INNER JOIN area ON address.area_id = area.id INNER JOIN city ON address.city_id = city.id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON address.state_id = state.state_id WHERE address.user_id =$user_id AND address.address_type =1")->result();
        if($status){
            if($current_address){
                $cur_address = $current_address[0];
            $address_array = array(
                'user_id' =>$cur_address->user_id,
                'address_id' =>$cur_address->id,
                'address1' =>$cur_address->address1,
                'address2' =>$cur_address->address2,
                'landmark' =>$cur_address->landmark,
                'area' =>$cur_address->area_locality,
                'city' =>$cur_address->city_name,
                'district' =>$cur_address->district,
                'stateid' =>$cur_address->state_id,
                'pincode' =>$cur_address->pincode,
                'address_name' =>$cur_address->address_name,
                'delto_name' =>$cur_address->delto_name,
                'delto_contact' =>$cur_address->delto_contact,
                // 'packing_charge' => $packing_charge,
                // 'delivery_charge' => $delivery_charge,
                // 'tot' => $tot
                );
            }
            echo json_encode(array('status'=>1,'message'=>'Delivery address updated','address_data' =>$address_array));
            exit;
        }
    }else{
        echo json_encode(array('status'=>0,'message'=>'Something went wrong'));
        exit;
    }
}

// checkout page address

public function ajax_filteraddress(){ 

     $phone_no = $_POST['search_phonenumber'];
     $userdata = $this->session->userdata('brownie_webuser');
     $data_cart['userdata'] = $userdata;
     $user_id =0;
     if(isset($userdata[0]->user_id))
     {
            $user_id =$userdata[0]->user_id;
     }
    if($phone_no!=""){
        $filter = " AND address.delto_contact like '%$phone_no%'";
    }else{
        $filter ="";
    }
    // $saved_address = $this->db->query("SELECT address.delto_name,delto_contact,address.id,address.user_id,address.address1,address.address2,address.landmark,address.area_id,area.area_locality,address.city_id,city.city_name,district.district,address.district_id,state.state,address.state_id,address.pincode,address.address_name,address.gps_coordinates FROM address INNER JOIN area ON address.area_id = area.id INNER JOIN city ON address.city_id = city.id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON address.state_id = state.state_id WHERE address.user_id = $user_id AND address.address_type !=1 $filter order by address.id desc")->result();
    $saved_address = $this->db->query("SELECT address.delto_name,delto_contact,address.id,address.user_id,address.address1,address.address2,address.landmark,address.area_id,area.area_locality,address.city_id,city.city_name,district.district,address.district_id,state.state,address.state_id,address.pincode,address.address_name,address.gps_coordinates FROM address INNER JOIN area ON address.area_id = area.id INNER JOIN city ON address.city_id = city.id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON address.state_id = state.state_id WHERE address.user_id = $user_id $filter order by address.id desc")->result();
       if($saved_address == null)
       {?>
            <a class="rounded-0  font-weight-light btn text-white font_15 mt-4" style="background-color: #cdb34b;"  onclick="add_newaddress()">Add New Address</a>
       <?php }else
       {
          if($saved_address){ ?>
        <h5 class="text-dark font-weight-normal mt-3 col-12 pl-2" style="font-size:18.5px">Most recently used</h5>
        <!--Address---------------------------------------->
        <?php foreach($saved_address as $add){ ?>
         <div class="col-lg-6 px-lg-2 py-3 del_add" >
             <address class="mb-1">
                <h5 class="text-dark font-weight-normal " style="font-size:17px"><?php echo $add->delto_name;?></h5>
                <p class="text-dark font-weight-normal mb-2" style="font-size:15px"><?php echo $add->delto_contact;?></p>
                <p class="mb-1 add_font_col_cus " style="color:#333333;font-size: 14px;">
                    <?php $address = $add->address1.' , '.$add->address2.' , '.$add->landmark.' , '.$add->area_locality.' , '.$add->city_name.' , '.$add->district.' , '.$add->state.' - '.$add->pincode; ?></p>
                <p class="mb-1  add_font_col_cus" style="color:#333333;font-size: 14px;"><?php echo $address; ?></p>
            </address>
            <div class="form-group col-md-12 mb-3 pl-0">
    		    <div class="row">
    		        <div class="col-lg-8 col-9 py-2 col-sm-8">
    		            <button class="rounded-0  font-weight-light btn text-white font_13_5" onclick="update_deladdress(<?php echo $add->id;?>,'delivery')"  style="background-color: #cdb34b;" >Delivery to this address</button>
    		        </div>
    		         <div class="col-lg-3 col-3 py-2 col-sm-3">
    		            <button class="rounded-0  font-weight-light btn font_13_5" onclick="update_deladdress(<?php echo $add->id;?>,'edit')" ><i class="fa fa-edit mr-2 font_13" ></i>Edit</button>
    	
    		        </div>
    		    </div>
    		</div>
         </div> 
           
           
         <?php } } }?>
   <!--Address---------------------------------------->
   
<?php }
function get_delpack_charge($store_id=0,$user_id=0){ //calculate delivery charge and packing charge
$est_delivery_charge = 0; $est_packing_charge =0;
    //update packing charge & delivery Charge
    $str = $this->db->query("select stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,'3' as payment_method from stores where stores.store_id = $store_id")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        $delivery_charges = $str[0]->delivery_charges;
        if($delivery_type==1 || $delivery_charges==0)//store pickup 
        {
            $est_delivery_charge = 0;
        }
        else { //home delivery
        $current_address = $this->db->query("SELECT district.district,state.state FROM address INNER JOIN area ON address.area_id = area.id INNER JOIN city ON address.city_id = city.id INNER JOIN district ON district.district_id = address.district_id INNER JOIN state ON address.state_id = state.state_id WHERE address.user_id =$user_id AND address.address_type =1")->result();
            $est_delivery_charge = $str[0]->min_dc;
            $district_name = $current_address[0]->district;
            $state_name = $current_address[0]->state;
                   if(strtoupper($district_name)=="CHENNAI" && strtoupper($state_name)=="TAMILNADU" ){ ////manual address change can't calculate accurate distance
                        $est_delivery_charge = round($str[0]->min_dc,0);
                    }else if(strtoupper($state_name)=="TAMILNADU"){ //Inside Tamilnadu outside chennai
                        $est_delivery_charge = 75;
                    }else{
                        $est_delivery_charge = 130;
                    }
                                        
        }
        $tot = 0;$items =0;
            $get_cartamt = $this->db->query("select display_price,quantity from cart where order_id=0 and user_id=$user_id")->result(); 
            foreach($get_cartamt as $cart){
                $tot = $tot + $cart->display_price;
                $items = $items + $cart->quantity;
            }
        $packing_charges = $str[0]->packing_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($tot * ($pc_perc/100)),0);
            }else{ //unitwise
            $est_packing_charge =  round(($items * $pc_unit_value),0);
            }   
        }
        $total_amount = $tot + $est_delivery_charge + $est_packing_charge;
        $data = array(
            'delivery_charge' => round($est_delivery_charge,0),
            'packing_charge' => round($est_packing_charge,0),
            'total_amount' => round($total_amount,0)
            );
        return array('status'=>1,'message'=>'Packing Charge & delivery charge calculated','data'=>$data);
    }
    return array('status'=>0,'message'=>'');
    ////
}
}
?>