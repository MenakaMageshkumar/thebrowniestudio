<?php
ob_start();
// if (!isset($_SESSION)) {
// // each client should remember their session id for EXACTLY 24 hour
// // session_set_cookie_params(60 * 60 * 24);
//   $lifetime=600;
//   session_set_cookie_params($lifetime);
//   session_start();
// }
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
public function __construct() {
parent::__construct();

// Load form validation library
$this->load->library('form_validation');
$this->load->helper('url');
$this->load->helper(array('form'));
$this->load->model('Common_model');
$this->load->library('session');
date_default_timezone_set('Asia/Kolkata');

}
public function index(){
   }
public function checkUsrLogin() {
     $username = $_POST['username'];
    $password = $_POST['password'];
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    if($username!=''){
        $result = $this->Common_model->login($username, $password); 
        if($result && !empty($result)) {
            $this->load->library('session');
			$this->session->set_userdata('brownie_webuser',$result);
			$this->session->set_userdata('brownieweb_userlogged_in','1');
			$user_id = $result[0]->user_id;
// 			$_COOKIE['brownielogin_remember_me'] = encode_param($user_id);
            $cookie_name = "brownielogin_remember_me";
			$cookie_value = encode_param($user_id);
            //86400 * 30 //1day
			setcookie($cookie_name, $cookie_value, time() + (10 * 365 * 24 * 60 * 60), "/");//1yr
			$keepme_loggedin = encode_param($user_id);
			$this->db->query("update user_profile set keepme_loggedin = '$keepme_loggedin' where user_id =$user_id");
			echo '1';
        }else{
            // echo '0';
            echo $result;
        }
    }       
   }
   public function logout(){
       $this->session->unset_userdata('brownieweb_userlogged_in');
    //   session_destroy();
       $this->session->unset_userdata('brownie_webuser');
       $this->session->unset_userdata('collectionby');
       $this->session->unset_userdata('coupon_code');
       $this->session->unset_userdata('coupon_discount');
       $this->session->unset_userdata('final_total');
       $this->session->unset_userdata('uptodate_email');
       $this->session->unset_userdata('keepme_uptodate');
       $this->session->unset_userdata('orderperson_dtl');
        unset($_COOKIE['brownielogin_remember_me']); 
        setcookie('brownielogin_remember_me', null, -1, '/'); 
        redirect(base_url());
   }
}
?>