<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>App | Content</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Content List</h3></div>
          <div class="col-md-6" align="right">
           
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
      <div class="box-body table-responsive">
        <table id="driverTable" class="table table-bordered table-striped datatable ">
          <thead>
              <th width="25%;">Menu</th>
              <th width="30%;">Content</th>
              <th width="15%;">Action</th>
            </tr>
          </thead> 
          <tbody>
            <?php
            $i = 0;
            if(!empty($content)){
              for($i=0;$i<2;$i++) {
               ?>
               <?php if($i==0){ ?>
               <tr>
                 <td class="center">Terms and Conditions</td>
                 <td class="center"><?= $content[0]->app_terms_conditions; ?></td> 
                 <td class="center">	 
                    <a class="btn btn-sm btn-danger" 
                      href="<?= base_url('Content/editContent/'.encode_param($content[0]->store_id))."/1" ?>">
                      <i class="fa fa-fw fa-edit"></i>Edit
                    </a> 
                  </td>
                </tr>
                <?php } ?>
                <?php if($i==0){ ?>
               <tr>
                 <td class="center">Contact Us</td>
                 <td class="center"><?= $content[0]->app_contact_us; ?></td> 
                 <td class="center">	 
                    <a class="btn btn-sm btn-danger" 
                      href="<?= base_url('Content/editContent/'.encode_param($content[0]->store_id))."/2" ?>">
                      <i class="fa fa-fw fa-edit"></i>Edit
                    </a> 
                  </td>
                </tr>
                <?php } ?>
            <?php 
              } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
    <script>

 $(document).ready(function() {
    active("content_side_menu"); 
 });

</script>
</div>