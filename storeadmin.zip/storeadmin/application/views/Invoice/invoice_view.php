<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Invoice | View</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
     <style>
  .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
  </style>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Invoice Detail</h3></div>
          <div class="col-md-6" align="right">
            
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
          </div>
          </div>
           <div class="box-body table-responsive">
        <table id="driverTable" class="table table-bordered table-striped datatable ">
          <thead>
            <tr>
              <th class="hidden">Invoice No</th>
               <th width="2%" class="text-center p_3_font_13">S.NO</th>
              <th width="15%;" class="text-center p_3_font_13">INVOICE NUMBER</th>
              <th width="15%;" class="text-center p_3_font_13">ORDER ID</th/>
              <th width="7%;" class="text-center p_3_font_13">ITEM</th/>
              <th width="7%;" class="text-center p_3_font_13">TOTAL BILL</th>
              <th width="17%;" class="text-center p_3_font_13">ACTION</th>
            </tr>
          </thead> 
          <tbody>
            <?php
            if(!empty($InvoiceData)){
                 $i =1;
              foreach($InvoiceData as $dt) {
               ?>
               <tr>
                   <th class="center text-center p_3_font_13"><?= $i++ ?></th>
                 <th class="hidden"><?= $dt->inv_no ?></th>
                 <td class="center text-center p_3_font_13"><?= $dt->inv_no ?></td> 
                 <td class="center text-center p_3_font_13"><?= $dt->UTN_number; ?></td> 
                 <td class="center text-center p_3_font_13">
                      <a href="#myModal" id="link" data-toggle="modal" data-id="<?= $dt->order_id?>" class="btn btn-sm btn-primary chk"><i class="fa fa-fw fa-eye"></i>View Items</a>
                  </td> 
                 <td class="center text-center p_3_font_13"><?= round($dt->total_final_bill_amt,0); ?></td> 
                   <td class="center text-center p_3_font_13">	
                      <a class="btn btn-sm btn-pri" target="_blank" style="width:100px;margin-top:5px;margin-bottom:5px" href="<?= base_url("../home/invoice/".$dt->store_id)."/".$dt->UTN_number."/".$dt->inv_no ?>">View Invoice</a>
                      <a class="btn btn-sm btn-sec" style="width:100px;margin-top:5px;margin-bottom:5px" href="<?= base_url("../home/invoice/".$dt->store_id)."/".$dt->UTN_number."/".$dt->inv_no ?>" download="invoice-<?php echo $dt->inv_no.".html" ?>">Download</a>
                  </td>
                  
                </tr>
            <?php 
              } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Item Details</h4>
            </div>
            <div class="modal-body table-responsive">

            <strong>loading.</strong>        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div> 
</div>
<script>
function showResult(str) {
    var id = str.getAttribute('id');
    var splitdata=id.split('-');
    var str=str.value;
    //alert(id);
   if (str.length==0) {
    document.getElementById("livesearch"+splitdata[1]).innerHTML="";
    document.getElementById("livesearch"+splitdata[1]).style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch"+splitdata[1]).innerHTML=this.responseText;
      document.getElementById("livesearch"+splitdata[1]).style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","<?php echo base_url() ?>Invoice/livesearch/"+str+"/"+splitdata[1],true);
  xmlhttp.send();
}
</script>

<script>
 $('.chk').on('click',function(){
            var order_id=$(this).data('id');
    $('.modal-body').html('loading');
       $.ajax({
    	url:'<?php echo base_url() ?>Invoice/get_itemdata',
		type:'POST',
		data:'order_id='+order_id,
        success: function(data) {
          $('.modal-body').html(data);
        },
        error:function(err){
          alert("error"+JSON.stringify(err));
        }
    });
 });
 </script>
 <script>

 $(document).ready(function() {
    active("invoice_side_menu"); 
 });

</script>
 <script>
     $(document).ready(function() 
     { 
          jQuery(function () {
                    jQuery('#driverTable').DataTable({
                        // "ordering" : jQuery(this).data("ordering"),
                        // "order": [[ 1, "desc" ]]
                    });
                });
     });
</script>
