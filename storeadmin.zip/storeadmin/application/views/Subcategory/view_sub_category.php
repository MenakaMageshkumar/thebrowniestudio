<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>subcategory | subcat_list</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
     <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .error_msg{
        color: red;
        font-weight: 700;
    }
     .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
    }
    .p_3_font_13
    {
        padding-left: 3px!important;
        padding-right:3px!important;
        padding-top:10px!important;
        padding-bottom:10px!important;
        font-size: 12.5px!important;
    }
    </style>
  </head>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Subcategory List</h3></div>
          <div class="col-md-6" align="right">
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
      <div class="box-body table-responsive">
        <table id="driverTable" class="table table-bordered table-striped datatable_sub ">
          <thead>
            <tr>
                 <th width="2%" class="text-center p_3_font_13 text-uppercase">S.NO</th>
              <th class="hidden" class="text-center p_3_font_13 text-uppercase">SubCategory ID</th>
              <th width="13%;" class="text-center p_3_font_13 text-uppercase">SubCategory Name</th>
               <th class="hidden">Main Category</th>
              <th class="hidden">Category Name</th> 
              <th width="13%;" class="text-center p_3_font_13 text-uppercase">Image </th>
               <th width="5%;" class="text-center p_3_font_13 text-uppercase">Status</th>
               <th width="5%;" class="text-center p_3_font_13 text-uppercase">Popular</th>
              <th width="7%;" class="text-center p_3_font_13 text-uppercase">Action</th>
            </tr>
          </thead> 
          <tbody>
            <?php
            if(!empty($scatData)){
                  $i =1;
              foreach($scatData as $subcat) {
               ?>
               <tr>
                    <td class="center text-center p_3_font_13"><?= $i++ ?></td>
                 <td class="hidden"><?= $subcat->subcat_id ?></td>
                 <td class="center text-center p_3_font_13"><?= $subcat->subcategory_name ?></td> 
                 <td class="hidden"><?= $subcat->maincategory_id ?></td> 
                 <td class="hidden"><?= $subcat->category_id ?></td> 
                 <td class="center text-center p_3_font_13">
                     <img src="<?= base_url('../../'.$subcat->image) ?>" class="cpoint" onclick="viewImageModal('Profile Image','<?= base_url('../../'.$subcat->image) ?>');"
                  onerror="this.src='<?=base_url("../../assets/images/user_avatar.jpg")?>';" height="100" width="100" />
                 </td>
                 
                 <td class="center text-center p_3_font_13"><?= ($subcat->status == '1')?'Active':'Inactive'?></td>
                 
                 <td class="center text-center p_3_font_13">
                     <?= ($subcat->addto_popular == '1')?'Popular':''?>
                </td>
                 <td class="center text-center p_3_font_13">	 
                    <!--<a class="btn btn-sm btn-primary" id="viewSubCategory" subcat_id="<?= encode_param($subcat->subcat_id) ?>">-->
                    <!--  <i class="fa fa-fw fa-eye"></i>View-->
                    <!--</a>-->
                    <a class="btn btn-sm btn-danger" 
                      href="<?= base_url('Subcategory/editsub_cat/'.encode_param($subcat->subcat_id)) ?>">
                      <i class="fa fa-fw fa-edit"></i>Edit
                    </a> 
                    <!--<a class="btn btn-sm btn-danger" -->
                    <!--  href="<?= base_url("Sub_category/changeStatus/".encode_param($subcat->subcat_id))."/2" ?>" -->
                    <!--  onClick="return doconfirm()">-->
                    <!--  <i class="fa fa-fw fa-trash"></i>Delete-->
                    <!--</a>    -->
                    <!--<?php if($subcat->status == 1){ ?>-->
                    <!--  <a class="btn btn-sm btn-success" style="background-color:#ac2925" href="<?= base_url("Store/changeStatus/".encode_param($subcat->subcat_id))."/0" ?>">-->
                    <!--    <i class="fa fa-cog"></i> De-activate-->
                    <!--  </a>-->
                    <!--<?php } else { ?>-->
                    <!--  <a class="btn btn-sm btn-success" href="<?= base_url("Sub_category/changeStatus/".encode_param($subcat->subcat_id))."/1" ?>">-->
                    <!--    <i class="fa fa-cog"></i> Activate-->
                    <!--  </a>-->
                    <!--<?php } ?>-->
                  </td>
                </tr>
            <?php 
              } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>

 <script>
    //  $(document).ready(function() 
    //  { 
    //      active("3_id");
    //      active_main("3_id");
    //      active_sub("view_all_sub_cat");
    //  });
     jQuery(function () {
                    jQuery('.datatable_sub').DataTable({
                        "ordering" : jQuery(this).data("ordering"),
                        "order": [[ 1, "asc" ]]
                    });
                });
</script>
<script>
    $(".main-sidebar ul .sub_cat_side_menu").addClass("active");
</script>
