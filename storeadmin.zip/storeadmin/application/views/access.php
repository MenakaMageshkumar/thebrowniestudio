<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Store</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
  </head>
<div class="content-wrapper">
    <section class="content-header">
    <h1> <?= $page_title ?>
        <small><?= $page_desc ?></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="javascript:void(0);" ><i class="fa fa-dashboard"></i> Home</a></li>
        <!--<li class="active">Dashboard</li>-->
    </ol>
    </section>
    <?php if($access_denied!='') { ?>
    <section class="content">
        <div class="row">
            <div class="alert alert-danger">
           <button class="close" data-dismiss="alert" type="button">×</button>
           <?= $access_denied ?>
        </div>
        </div> 
    </section>
    <?php } ?>
</div>
