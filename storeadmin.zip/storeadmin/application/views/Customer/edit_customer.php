<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Customer | Profile </title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
  <div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?><small><?= $pDescription ?></small></h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
        $url = (!isset($user_id) || empty($user_id))?'':'Customer/updateCustomer/'.encode_param($user_id);
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>  
      </div>
      <?php if(isset($customer_data)){
          $customer_data = $customer_data[0];
      }
      ?>
      <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-body">
            <form role="form" action="<?= base_url($url) ?>" method="post" 
              class="validate" data-parsley-validate="" enctype="multipart/form-data">
              <div class="col-md-6">
                <div class="form-group">
                  <label>NAME OF THE PERSON</label>
                  <input type="text" class="form-control required" data-parsley-trigger="change"
                  data-parsley-minlength="2"
                  name="fullname" required="" placeholder="Enter Name" value="<?= $customer_data->fullname; ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="form-group">
                  <label>MOBILE NUMBER</label>
                  <input type="text" class="form-control required" data-parsley-trigger="change"
                  data-parsley-minlength="2"
                  name="phone_no" required="" placeholder="Enter Contact" value="<?= $customer_data->phone_no ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="form-group">
                  <label>MAIL ID</label>
                  <input type="text" class="form-control required" data-parsley-trigger="change"
                  data-parsley-minlength="2"
                  name="email" required="" placeholder="Enter MailID" value="<?= $customer_data->email ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="form-group ">
                                        <input type="checkbox" id="user_type"  class="form-check-input" name="user_type" 
                                          <?php 
                                          if(isset($customer_data->user_type)){
                                              if($customer_data->user_type==2){
                                               echo 'checked="checked"';
                                              }else{
                                                   echo '';
                                              }
                                          }
                                          ?> >
                                         <label class="form-check-label" for="user_type" style="font-weight:400"> Add to Sales Person</label><br>
                </div>
                <div class="form-group">

              <div class="col-md-12">      
                <div class="box-footer textCenterAlign">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>        
              </div>        
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script>

 $(document).ready(function() {
    active("customer_side_menu"); 
 });

</script>
</div>