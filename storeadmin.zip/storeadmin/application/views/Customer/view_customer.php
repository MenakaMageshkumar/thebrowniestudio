<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Customer</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
     <style>
       .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
    .p_3_font_13
    {
        padding-left: 3px!important;
        padding-right:3px!important;
        padding-top:10px!important;
        padding-bottom:10px!important;
        font-size: 12.5px!important;
    }
    @media (max-width: 768px)
    {
        .form-inline .checkbox, .form-inline .radio {
    display: inline-flex;
    margin-top: 0;
    margin-bottom: 0;
    
}
.pt_2px
{
    padding-top:3px;
}
}
@media (max-width: 768px)
{
    .form-inline .checkbox input[type=checkbox], .form-inline .radio input[type=radio] {
    position: relative;
    margin-left: 0;
}
}

    

  </style>

  </head>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Customer List</h3></div>
          <div class="col-md-6" align="right">
           
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
      <div class="box-body table-responsive">
        <table id="driverTable" class="table table-bordered table-striped datatable1 ">
             <thead>
              <th width="5%;" class="text-center p_3_font_13">S.NO</th>
              <th width="15%;" class="text-center p_3_font_13">CUSTOMER NAME</th>
              <th width="10%;" class="text-center p_3_font_13">PHONE NUMBER</th>
              <th width="20%;" class="text-center p_3_font_13">EMAIL ID</th>
              <th width="25%;" class="text-center p_3_font_13">ADDRESS</th>
              <th width="10%;" class="text-center p_3_font_13">USER STATUS</th>
              <th width="45%;" class="text-center p_3_font_13" style="width: 200px;">&nbsp; SALES&nbsp;PERSON&nbsp;STATUS&nbsp;</th>
            </tr>
          </thead> 
          <tbody>
            <?php
            if(!empty($customer)){
                $i =1;
              foreach($customer as $c) {
               ?>
               <tr>
                   <td class="text-center p_3_font_13"><?= $i; ?></td> 
                 <td  class="text-center p_3_font_13"><?= $c->fullname ?></td> 
                 <td  class="text-center p_3_font_13">+<?= $c->phone_no ?></td> 
                 <td  class="text-center p_3_font_13"><?= $c->email ?></td> 
                 <td >
                     <?php 
                     $user_id = $c->user_id;
                     $get_user = $this->db->query("SELECT addr.address1,addr.address2,addr.landmark,area.area_locality AS area,city_name as city,state,district.district,addr.pincode FROM user_profile AS usr INNER JOIN address addr ON usr.user_id = addr.user_id INNER JOIN area ON area.id = addr.area_id INNER JOIN city ON city.id=addr.city_id LEFT JOIN district ON district.district_id = addr.district_id INNER JOIN state ON state.state_id = addr.state_id WHERE addr.address_type =1 and usr.user_id = $user_id")->result();
                     $address ="";
                     if($get_user){
                     if($get_user[0]->address2 == "")
                            {
                               
                                $address_2_commo = "";
                                
                            }
                            else
                            {
                                $address_2_commo = ",";
                            }
                     
                     
                            $address = $get_user[0]->address1.' , '.$get_user[0]->address2.' '.$address_2_commo.' '.$get_user[0]->landmark.' , '.$get_user[0]->area.' , '.$get_user[0]->city.' , '.$get_user[0]->state.' , '.$get_user[0]->district.' - '.$get_user[0]->pincode;
                     }
                    echo $address; 
                     ?>
                     </td>
                 <td class="text-center p_3_font_13" >
                     	 <?php if($c->status ==0){ 
                     	     $status = 'Inactive';
                     	 }else  if($c->status ==1){ 
                     	     $status = 'Active';
                     	 }else  if($c->status ==2){ 
                     	     $status = 'Partially registered';
                     	 }
                     echo $status ?>
                     </td>
                     <td class=" p_3_font_13" style='    padding-left: 5px!important;'>
                         <div class="checkbox">
 
                         <input type="checkbox" class="chk_user_type" id="user_type-<?php echo $c->user_id;?>" name="user_type" <?php if($c->user_type==2) echo "checked"; else echo ""; ?> value="<?php echo $c->user_id;?>" >
                         <label for="vehicle1"  class="pt_2px" style="font-size: 12px;font-weight: 400;border: 0px;padding-left: 2px;background-color: #fff0;" class="form-control">
                         <?php  if( $c->user_type==2){ ?> Disable <?php } else { ?> Enable Sales Person <?php } ?>
                        </label>
                    </div>
                    <!--<a class="btn btn-sm btn-danger" -->
                    <!--  href="<?= base_url('Customer/editCustomer/'.encode_param($c->user_id)) ?>">-->
                    <!--  <i class="fa fa-fw fa-edit"></i>Edit-->
                    <!--</a>-->
                    <!--<a class="btn btn-sm btn-danger" -->
                    <!--  href="<?= base_url('Customer/editCustomer/'.encode_param($c->user_id)) ?>">-->
                    <!--  <i class="fa fa-fw fa-edit"></i>Delete-->
                    <!--</a>-->
                  </td>
                </tr>
            <?php 
             $i++; } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>
<script>
 $(document).ready(function() {
        $('#driverTable').DataTable( {
        // "order": [[ 0, "asc" ]]
    } );

});
</script>
  <script>

 $(document).ready(function() {
    active("customer_side_menu"); 
 });

</script>
<script>
$('.chk_user_type').on('change', function(e) {
e.preventDefault();

// Determine ID
 var id = $(this).attr('id');
 var user_id = $(this).attr('value');
var isChecked =$('#' + id).is(":checked")?1:0;
if(isChecked==1){
    user_type =2;//update as sales person
}else{
    user_type = 1; // normal user
}
if(user_type!=""){
    if(confirm('Do you want to submit?')){
          $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>customer/updateUsertype",
           data: {user_id:user_id,user_type:user_type}, 
           success: function(data){
               alert(data);
               location.reload();
           }
});        
}else{
        location.reload();
    }
    }
});
</script>