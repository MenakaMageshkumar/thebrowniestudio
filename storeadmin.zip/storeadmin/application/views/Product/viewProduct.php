  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Product |view Product</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
  </head>
 <style>
      .datatable tbody th { font-weight: inherit; }
        table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
        position: absolute;
        top: 8px;
        right: 8px;
        display: block;
        font-family: 'Glyphicons Halflings';
        opacity: -0.5!important;
        cursor: default;
    }
    .p_3_font_13
    {
        padding-left: 3px!important;
        padding-right:3px!important;
        padding-top:10px!important;
        padding-bottom:10px!important;
        font-size: 12.5px!important;
    }
  </style>
<div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
      <li><?= $menu ?></li>
      <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
             <button class="close" data-dismiss="alert" type="button">×</button>
             <?= $flashdata['message'] ?>
          </div>
        <?php } ?>
      </div>
      <div class="col-xs-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <div class="col-md-6"><h3 class="box-title">Product List</h3></div>
            <div class="col-md-6" align="right">
              
              <a class="btn btn-sm btn-primary" style="background-color:#441075;" href="<?= base_url('Product/addProduct')?>">Add New Product</a>
              <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
           </div>
          </div>
          <div class="box-body table-responsive">
            <table class="table table-bordered table-striped datatable  " id="example">
              <thead>
                <tr>
                  <th class="hidden">ID</th>
                  <th width="2%" class="text-center p_3_font_13">S.NO</th>
                  <th  width="23%;" class="text-center p_3_font_13">PRODUCT&nbsp;NAME</th>
                  <th  width="15%;" class="text-center p_3_font_13">IMAGE</th>
                  <th  width="7%;" class="text-center p_3_font_13">CATEGORY</th>
                  <th  width="7%;" class="text-center p_3_font_13">STATUS</th>
                  <th  width="15%;" class="text-center p_3_font_13">ACTION</th>
               </tr>
              </thead> 
              <tbody>
                <?php
                if(!empty($product_data)){
                     $i =1;
                  foreach($product_data as $product) {  ?>
                    <tr>
                      <th class="center text-center p_3_font_13"><?= $i++ ?></th>
                      <th class="hidden"><?= $product->prod_id ?></th>
                      <th class="center   text-center  p_3_font_13"><?= $product->prod_name ?></th>
                      <th class="cente text-center p_3_font_13r"><img src="<?= base_url('../../'.$product->prod_img1) ?>" class="cpoint" onclick="viewImageModal('Profile Image','<?= base_url('../../'.$product->prod_img1) ?>');"
                  onerror="this.src='<?=base_url("../../assets/images/user_avatar.jpg")?>';" height="100" width="100" /></th>
                       <th class="center text-center p_3_font_13"><?= $product->cat_name ?></th>
                      <th class="center text-center p_3_font_13"><?= ($product->prod_status == 1)?'Active':'De-activate' ?></th>
                      <td class="center text-center p_3_font_13">   
                        <!--<a class="btn btn-sm btn-info" id="viewProductDetails" product_id="<?= encode_param($product->prod_id) ?>">-->
                        <!--  <i class="fa fa-fw fa-eye"></i>View-->
                        <!--</a> -->
                        <?php if(trim($GLOBALS['role_name']) != 'Supervisor (System Default)'){ ?>
                        <a class="btn btn-sm btn-primary" style="margin-top:10px;margin-bottom:10px" href="<?= base_url('Product/editproduct/'.encode_param($product->prod_id)) ?>">
                          <i class="fa fa-fw fa-edit"></i>Edit
                        </a> 
                        <?php } ?>
                        <?php if($product->prod_status==1){ ?>
                        <a class="btn btn-sm btn-success" href="<?= base_url('Product/changeproduct_availstatus/'.encode_param($product->prod_id))."/0" ?>">
                          <i class="fa fa-fw fa-edit"></i>Available
                        </a>
                        <?php } else { ?>
                        <a class="btn btn-sm btn-danger" href="<?= base_url('Product/changeproduct_availstatus/'.encode_param($product->prod_id))."/1" ?>">
                          <i class="fa fa-fw fa-edit"></i>Not Available
                        </a>
                        <?php } ?>
                        <!--<a class="btn btn-sm btn-danger" href="<?= base_url("Product/changeStatus/".encode_param($product->prod_id))."/2" ?>" onClick="return doconfirm()">-->
                        <!--  <i class="fa fa-fw fa-trash"></i>Delete-->
                        <!--</a>    -->
                      </td>
                    </tr>
                <?php } } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<script>
     jQuery(function () {
                    jQuery('.datatable_product').DataTable({
                        "ordering" : jQuery(this).data("ordering"),
                        "order": [[ 1, "asc" ]]
                    });
                });
</script>
   <script>

 $(document).ready(function() {
    active("product_side_menu"); 
 });

</script>