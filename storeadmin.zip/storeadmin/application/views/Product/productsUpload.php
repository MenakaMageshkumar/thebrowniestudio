 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Product |Upload Product</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
  </head>

<div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
      <li><?= $menu ?></li>
      <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-danger">
             <button class="close" data-dismiss="alert" type="button">×</button>
             <?= $flashdata ?>
          </div>
        <?php } ?>
      </div>
      <div class="col-md-12">
        <?php if($this->session->flashdata('success')) { 
          $flashdata = $this->session->flashdata('success'); ?>
          <div class="alert alert-success">
             <button class="close" data-dismiss="alert" type="button">×</button>
             <?= $flashdata ?>
          </div>
        <?php } ?>
      </div>
      <div class="col-xs-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <div class="col-md-6"><h3 class="box-title">Product Upload</h3></div>
            <div class="col-md-6" align="right">
              <!--
              <a class="btn btn-sm btn-primary" href="<?= base_url('Product/addProduct')?>">Add New Product</a>
              <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>-->
           </div>
          </div>
          
          <div class="box-body table-responsive">
              <form role="form" method="post" enctype="multipart/form-data" action="<?php echo base_url().'Product/csv_upload';?>">
                  <div class="form-group">
                  <label>SELECT TYPE</label>
                  <select name="type" class="form-control" required >
                  <option value = "1">Product Update</option>
                  <option value = "2">Stock Update</option>
                  </select>
                  </div>
                
              <div class="form-group">
            <label for="fname">ATTACH FILE (CSV FORMAT)<span style="color:red">*</span> :</label>
            <!-- <input type="file" id="excel_file" class="form-control" name="userfile[]" onchange="ValidateExcelFile(this);" required accept=".xls, .xlsx"> -->
            <input type="file" id="excel_file" class="form-control" name="userfile" required accept=".csv" >
            </div>
            <div class="form-group">
            <button type="submit" class="btn btn-primary" >Upload</button>
            </div>
            </form>
            
            <form role="form" method="post" enctype="multipart/form-data" action="<?php echo base_url().'Product/Process_product';?>">
                <!--<div class="form-group">-->
                    <!--<label>Choose a store</label>-->
                    <!--<select name="store_id" class="form-control" required >-->
                    <!--    <option value="">Select store</option>-->
                      <?php 
                        // if(!empty($storedata)){
                        //   foreach ($storedata as $shopp) { 
                          ?>
                            <!--<option value="<?php echo $shopp->store_id;?>">-->
                            <!--      <?php echo $shopp->store_name;?>-->
                            <!--    </option>;-->
                         <?php
                        //  } 
                        // }
                      ?>
                  <!--  </select>-->
                  <!--</div>-->
             <div class="form-group">
            <button type="submit" name="process"  value ="process_data" class="btn btn-primary" >Process Data</button>
            <button type="submit" name="process" value="export_data" class="btn btn-primary" >Export Unprocess Data</button>
            </div>
            </form>
            <table id="mechanicUsers" class="table table-bordered table-striped datatable ">
              <thead>
                <tr>
                  <!--<th width="150px;">Store name</th>-->
                  <th width="150px;" class="text-center">PRODUCT NAME</th>
                  <th width="150px;" class="text-center">BRAND</th>
                  <th width="150px;" class="text-center">DESCRIPTION</th>
                  <th width="150px;" class="text-center">CATEGORY NAME</th>
                  <th width="100px;" class="text-center">TYPE</th>
                  <th width="100px;" class="text-center">STATUS</th>
                 </tr>
              </thead> 
              <tbody>
                <?php
                if(!empty($unpro_data)){
                  foreach($unpro_data as $data) {  ?>
                    <tr>
                      <!--<th class="center"><?= $data->store_name ?></th>-->
                      <th class="center"><?= $data->prod_name ?></th>
                      <th class="center"><?= $data->brand_name ?></th>
                       <th class="center"><?= $data->description ?></th>
                       <th class="center"><?= $data->cat_name ?></th>
                       <th class="center"><?= $data->type_name ?></th>
                       <? if($data->process_status == 0){ //unprocessed
                           $status ='Process Pending';
                       }else{ //processed
                           $status ='Export UnProcessed';
                       }
                        ?>
                       <th class="center"><?= $status; ?></th> 
                    </tr>
                <?php } } ?>
              </tbody>
            </table>
          
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
 <script>
     $(document).ready(function() 
     { 
        //  active("4_id");
        //  active_main("4_id");
        //  active_sub("upload_bulk_prod");
   
     });
</script>
   <script>

 $(document).ready(function() {
    active("product_side_menu"); 
 });

</script>
<script>
     jQuery(function () {
                    jQuery('.datatable').DataTable({
                        "ordering" : jQuery(this).data("ordering"),
                        "order": [[ 1, "asc" ]]
                    });
                });
</script>