    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Product | Add Product</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>


        
        
    <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .error_msg{
        color: red;
        
        font-size: 0.9em;
    }
     .pad_left_mobile
    {
        padding-left:0px;
    }
    @media (max-width:575px)
    {
         .pad_left_mobile
        {
            padding-left:0px;
        }
        .pt_custom_1
        {
            padding-top: 25px!important;
        }
        .pt_custom
        {
            padding-top: 25px!important;
        }
       

}
    }
   .bootstrap-select .dropdown-menu 
   {
        min-width: auto!important%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    
    
    /*28/2/2022*/
     .multiselect-container {
        width: 100% !important;
        height: 250px;
        overflow-y: scroll;
    }
    .pt_custom_1
    {
        padding-top: 51px;
    }
    .pt_custom
    {
         padding-top: 50px;
    }
   
    </style>
  </head>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?= $pTitle ?><small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
          $redirectUrl = (isset($product_id) && !empty($product_id))
                            ?'Product/updateProduct/'.$product_id
                            :'Product/createProduct';
        
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>
      </div>

        <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <h3 class="box-title">Product Details</h3>
          </div>
            
<!--<form id="createProductForm" role="form" action="<?= base_url($redirectUrl) ?>" method="post" class="validate" data-parsley-validate="" enctype="multipart/form-data">-->
<form id="createProductForm" role="form" action="<?= base_url($redirectUrl) ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
    <!--<form id="add_product_form" method="post" enctype="multipart/form-data" novalidate="novalidate">-->
    
              <div class="box-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">PRODUCT NAME</label>                            
                            <input type="text" class="form-control" name="product_name" id = "product_name" required="">
                            <span id="product_name_error" class="error_msg"></span>
                        </div>
                        <div class="form-group">
                            <label>BRAND</label>                            
                            <input type="text" class="form-control" name="brand" required="" id="brand"  value="">
                            <span id="brand_error" class="error_msg"></span>
                        </div>
                        <div class="form-group">
                            <label>PRODUCT DESCRIPTION</label>                            
                            <span id="description_error" class="error_msg"></span>
                            <textarea id="rich_editor" type="text" class="ip_reg_form_input form-control reset-form-custom" placeholder="Product Description" name="description" 
            style="height:108px;" data-parsley-trigger="change" data-parsley-minlength="2"></textarea>
            
                        </div>
                         <div class="form-group">
                            <label>CATEGORY</label>                            
                            <input type="text" class="form-control" name="category_name" required="" id="category_name"  value="">
                            <span id="category_name_error" class="error_msg"></span>
                        </div>
                        <div class="form-group">
                            <label for="serve_for">PACK TYPE</label>                            
                            <select name="type" class="form-control" id ="select_type" required="">
                                <option value="">Select Type</option>
                                <?php foreach($packettype as $p)  { ?>
                                               <option value="<?php echo $p->type_name;?>"><?php echo $p->type_name;?></option>
                                               <?php } ?> 
                            </select>
                            <span id="type_error" class="error_msg"></span>
                        </div>
                        <input type ="hidden" name="store_id" id="store_id" value="<?= $store_id; ?>">
                        <div class="form-group">
                            <label for="serve_for">PRODUCT IMAGES BY</label>                            
                            <select name="image_type" class="form-control" id ="image_type" required="">
                                <option value="1">GENERIC</option>
                                <option value="2">VARIANT</option>
                            </select>
                        </div>
                        <hr>
                        <strong id ="packet_message" style="color:blue;"></strong>
						<div id="packet_div" style="">
						    <div class="form-group packet_div">
                            <label for="serve_for">IS VARIANT APPLICABLE FOR THIS PRODUCT?</label>                            
                            <select name="add_varient" class="form-control" id ="add_varient" required="">
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                         <strong><label for="unit">PACK UNIT</label></strong>
							    <div class="row">
							     <div class="col-md-2 tbl" style="padding-left:10px">
							        <div class="form-group packet_div col-xs-12">
	                                    <label for="unit">Pack Quantity</label><input type="text" class="form-control" name="pack_content[]" id = "pack_content" required="">
	                                </div>
	                            </div>
	                            <div class="col-md-2 tbl" style="padding-left:10px">
                            	    <div class="form-group packet_div col-xs-12">
                                        <label for="unit">Sale Unit</label>
                                        <select class="form-control" name="sale_unit[]" id="sale_unit" onchange="change_stock_unit(this);">
                                            <option value="">Select</option>
                                            <?php foreach($units as $t)  { ?>
                                               <option value="<?php echo $t->id;?>"><?php echo $t->unit;?></option>
                                               <?php } ?>  

                                            </select>
                            		</div>
                            	</div>
							    </div>
						    <strong><label for="unit">PRODUCT ATTRIBUTE</label></strong>
							<div class="row">
							   
	                            <div class="col-md-2 tbl" style="padding-left:10px">
	                                <div class="form-group packet_div col-xs-12">
	                                    <label for="price">Attribute1</label>
	                                    <select class="form-control" name="attribute1[]" id="attribute-1" onchange="change_packet_primaryatt(this);">
                                            <option value="">Select</option>
                                            <?php foreach($attribute_list as $t)  { ?>
                                               <option value="<?php echo $t->id;?>"><?php echo $t->attribute_name;?></option>
                                               <?php } ?>  
                                            </select>
                            	    </div>
                            	</div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
                            	    
							        <div class="form-group packet_div col-xs-12">
							            
	                                    <label for="unit">Variant1</label>
	                                    <input type="text" class="form-control" name="varient1[]" id="vart-1" required="" >
	                                </div>
	                            </div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
	                                <div class="form-group packet_div col-xs-12">
	                                    <label for="price">Attribute2</label><select class="form-control" name="attribute2[]" id="attribute-2" >
                                            <option value="">Select</option>
                                            <?php foreach($attribute_list as $t)  { ?>
                                               <option value="<?php echo $t->id;?>"><?php echo $t->attribute_name;?></option>
                                               <?php } ?>
                                            </select>
                            	    </div>
                            	</div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
							        <div class="form-group packet_div col-xs-12">
	                                    <label for="unit">Variant2</label>
	                                    <input type="text" class="form-control" name="varient2[]" id="vart-2" required="" >
	                                </div>
	                            </div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
	                                <div class="form-group packet_div col-xs-12">
	                                    <label for="price">Attribute3</label><select class="form-control" name="attribute3[]" id="attribute-3" >
                                            <option value="">Select</option>
                                            <?php foreach($attribute_list as $t)  { ?>
                                               <option value="<?php echo $t->id;?>"><?php echo $t->attribute_name;?></option>
                                               <?php } ?>
                                            </select>
                            	    </div>
                            	</div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
							        <div class="form-group packet_div col-xs-12">
	                                    <label for="unit">Variant3</label>
	                                    <input type="text" class="form-control" name="varient3[]" id="vart-3" required="" >
	                                </div>
	                            </div>
	                            </div>
	                            <strong><label for="unit">PRODUCT PRICING & DISPLAY</label></strong>
	                            <div class="row">
	                                <div class="col-md-2 tbl" style="padding-left:10px">
							        <div class="form-group packet_div col-xs-12">
	                                    <label for="unit">Product Display Name</label><input type="text" class="form-control" name="display_name[]" id="display_name" required="">
	                                </div>
	                            </div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group packet_div col-xs-12">
                            		    <label for="price">MRP(incl. GST)</label>
                            		    <input type="text" class="form-control" name="mrp_price[]" id="mrp_price" required="" >
                        		    </div>
                        		</div>
                        		<div class="col-md-2 tbl" style="padding-left:10px">
                        		        <div class="form-group packet_div  col-xs-12">
                            		    <label for="price">MOP(incl. GST)</label>
                            		    <input type="text" class="form-control" name="mop_price[]" id="mop_price" required="" >
                        		    </div>
                        		</div>
                        		<div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group packet_div  col-xs-12">
                            		    <label for="price">Offer Price(incl. GST)</label>
                            		    <input type="text" class="form-control" name="offer_price[]" id="offer_price" required="" >
                        		    </div>
                        		</div>
                        		<div class="col-md-2 tbl" style="padding-right:10px">
                        		    <div class="form-group packet_div  col-xs-12">
                            		    <label for="price">App Display Price</label>
                            		    <select class="form-control" name="price_to_display[]" id="price_to_display" >
                                            <!--<option value="1">MRP</option><option value="2">MOP</option><option value="3">Offer Price</option>-->
                                              <?php foreach($pricingtype as $p)  { ?>
                                               <option value="<?php echo $p->id;?>"><?php echo $p->price_type;?></option>
                                               <?php } ?>
                                            </select>
                        		    </div>
                        		</div>
                        		</div>
                        		<strong><label for="unit">PRODUCT STOCK</label></strong>
                        		<div class="row">
                        		<div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group packet_div  col-xs-12">
                                		<label for="quantity">Is Stock Applicable?</label>                            
                                    <select class="form-control" name="display_stock[]" id="display_stock" onchange="stock_changes(this);">
                                    <option value="Yes">Yes</option><option value="No">No
                                    </select>
                                     </div>
                        		</div>
                            <div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group packet_div  col-xs-12">
                                    <label for="stock_unit">Stock Unit</label>                            
                                    <span id="stock_unit_id"></span>
                                         </div>
                        		</div>
                               <div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group packet_div  col-xs-12">
                            <label for="price">Total Available Stock</label>
                            <input type="text" class="form-control" name="total_available_stock[]" id="total_available_stock" required="" >
                             </div>
                        		</div>
                            <div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group packet_div  col-xs-12">
                            <label for="price">MSU</label>
                            <input type="text" class="form-control" name="moq[]" id="moq" required="" disabled="disabled" >
                             </div>
                        		</div>
                            	<div class="col-md-2 tbl" style="padding-left:10px">
                            	    <div class="form-group packet_div  col-xs-12">
                                        <label for="qty">Stock Status</label>
                                        <select name="stock_status[]" class="form-control" required="">
                                            <option value="1">Available</option>
                                            <!--<option value="Last Few Left">Last Few Left</option>-->
                                            <option value="2">Sold Out</option>
                                        </select>
                            		</div>
                            	</div>
                            </div>
                            <!--<form method='post' action='' enctype="multipart/form-data" id="packet_form">-->
                            <strong><label for="unit">IMAGE</label></strong>
                                    <div class="row">
                                    <div class="col-md-2 tbl" style="padding-left:10px">
    							        <div class="form-group packet_div  col-xs-12">
    	                                    <label for="unit">Select Color</label><input type="color" class="form-control" name="pri_attcolor[]" id="pri_attcolor" value="" required="">
    	                                </div>
    	                            </div>
    	                            <div class="col-md-5 tbl" style="padding-left:10px">
    	                                <div class="form-group col-xs-12 pad_left_mobile">
                                     <label for="unit" class="col-lg-12 col-xs-12">Variantwise Picture1</label>
                                      <div class="col-md-2">
                                         
                                        <img src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                      </div>
                                      <div class="col-lg-7 pt_custom_1" >
                                          
                                        <input name="files[]"  type="file" accept="image/*" id="item_image1" required/>
                                      </div>
                                    </div></div>
                                     <div class="col-md-5 tbl" style="padding-left:10px">
    	                                <div class="form-group col-xs-12 pad_left_mobile">
                                              <label for="unit" class="col-lg-12 col-xs-12">Variantwise Picture2</label>
                                      <div class="col-md-2">
                                        <img src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                      </div>
                                      <div class="col-lg-7 pt_custom_1" style="padding-left: 16px;">
                                          
                                        <input name="files[]"  type="file" accept="image/*" id="item_image2" required/>
                                      </div>
                                    </div></div>
                                </div>
                            <div class="">
                                <div class="col text-center">
                                    <button id="packet_submit" style="width: 100px;" type="button" class="btn btn-primary">Add</button>
                            	</div>
                            </div>
                        <!--</form>-->
                            <hr>
                            <?php 
            	if(!empty($attributes)){ 
            	if(!empty($attributes['product_type_ref']=='packet')){ ?>
            	    <div class="table-responsive">
            	         <table class="table datatable">
            	        <thead>
            <tr>
              <th width="15%;">DisplayName</th>
              <th width="5%;">PackContent</th>
              <th width="10%;">SaleUnit</th>
              <th width="10%;">Varient1</th>
              <th width="10%;">Varient2</th>
              <th width="10%;">Varient3</th>
              <th width="5%;">MRP</th> 
              <th width="5%;">MOP</th>
              <th width="5%;">OfferPrice</th>
              <th width="5%;">StockUnit</th>
              <th width="5%;">Stock</th>
              <th width="5%;">MSU</th>
              <th width="10%;">Status</th>
            </tr>
          </thead> 
          <tbody>
              <?php $cnt = count(explode("|",$attributes['sale_unit']));  
              $sale_unit = explode("|",$attributes['sale_unit']);  
            //   print_r($sale_unit);
              for($i=0; $i<$cnt;$i++){ ?>
               <tr>
                   
                 <td class="center"><?php $display_name = explode("|",$attributes['display_name']);  echo $display_name[$i];?></td>
                 <td class="center"><?php $pack_content = explode("|",$attributes['pack_content']);  echo $pack_content[$i];?></td>
                 <td class="center"><?php $val = $sale_unit[$i]; 
                 foreach($units as $t){
                         if($val == $t->id){
                             echo $t->unit_name;
                         }
                     }
                 ?></td>
                 <td class="center"><?php
                  $chk_attribute1 =str_replace("|","",$attributes['attribute1']);
                 if($chk_attribute1!=''){
                 $attribute1 = explode("|",$attributes['attribute1']);
                 $varient1 ='';
                 if($attributes['varient1']!=''){
                 $varient1 = explode("|",$attributes['varient1']);
                 }
                 $varient1 = $varient1[$i];
                 $att_id = $attribute1[$i];
                 $atts = $this->db->query("select * from attributes  where id = $att_id")->result();
                 $attribute_name ='';
                 if($atts){
                     $attribute_name = $atts[0]->attribute_name;
                 }
                echo $attribute_name.' : '.$varient1;
              }
                 ?></td>
                 <td class="center"><?php
                 $chk_attribute2 =str_replace("|","",$attributes['attribute2']);
                 if($chk_attribute2!=''){
                 $attribute2 = explode("|",$attributes['attribute2']);
                 $varient2 ='';
                 if($attributes['varient2']!=''){
                 $varient2 = explode("|",$attributes['varient2']);
                 }
                 $varient2 = $varient2[$i];
                $att2_id = $attribute2[$i];
                $attribute2_name ='';
                if(!empty($att2_id)){
                 $atts2 = $this->db->query("select * from attributes  where id = $att2_id")->result();
                 if($atts2){
                     $attribute2_name = $atts2[0]->attribute_name;
                 }
                }
                 echo $attribute2_name.' : '.$varient2;
              }
                 ?></td>
                  <td class="center"><?php
                 $chk_attribute3 =str_replace("|","",$attributes['attribute3']);
                 if($chk_attribute3!=''){
                 $attribute3 = explode("|",$attributes['attribute3']);
                 $varient3 ='';
                 if($attributes['varient3']!=''){
                 $varient3 = explode("|",$attributes['varient3']);
                 }
                 $varient3 = $varient3[$i];
                $att3_id = $attribute3[$i];
                $attribute3_name ='';
                if(!empty($att3_id)){
                 $atts3 = $this->db->query("select * from attributes  where id = $att3_id")->result();
                  if($atts3){
                     $attribute3_name = $atts3[0]->attribute_name;
                 }
                }
                
                 echo $attribute3_name.' : '.$varient3;
              }
                 ?></td>
                 <td class="center"><?php $mrp_price = explode("|",$attributes['mrp_price']);  echo round($mrp_price[$i],0);?></td>
                 <td class="center"><?php $mop_price = explode("|",$attributes['mop_price']);  echo round($mop_price[$i],0);?></td>
                 <td class="center"><?php $offer_price = explode("|",$attributes['offer_price']);  echo round($offer_price[$i],0);?></td>
                 <td class="center"><?php $stock_unit = explode("|",$attributes['stock_unit']);  $val = $stock_unit[$i];
              if($val == 1){echo "ml";}
                 else if($val == 2){ echo "ltr";}
                 else if($val == 3){ echo "gram";}
                 else if($val == 4){ echo "box";}
                 else if($val == 5){ echo "kg";}
                 else if($val == 6){ echo "Pieces";}
                 else if($val == 7){ echo "nos";}
                 else if($val == 8){ echo "Packet";}
                 else if($val == 9){ echo "Plate";}
                 ?></td>
                 <td class="center"><?php $total_available_stock = explode("|",$attributes['total_available_stock']);  echo round($total_available_stock[$i],0);?></td>
                 <td class="center"><?php $moq = explode("|",$attributes['moq']);  echo round($moq[$i],0);?></td>
                 <td class="center"><?php $stock_status = explode("|",$attributes['stock_status']);  
                 if($stock_status[$i]==0){
                     echo 'Not Available';
                 }else if($stock_status[$i]==1){
                     echo 'Available';
                 }else if($stock_status[$i]==2){
                     echo 'Sold Out';
                 }else {
                     echo 'Not Available';
                 } ?></td>
                  </tr>
             <?php }
              ?>
          
                 
                 </tbody>
                 </table>
            	    </div>
            	    <!--</div>-->
                 <?php } } ?>
                        </div>
                        <strong id ="loose_message" style="color:blue;"></strong>
                        <div id="loose_div" >
                            <div class="row">
                                <div class="col-md-2 tbl " style="padding-left:10px">
                        		    <div class="form-group loose_div col-xs-12">
                            		    <label for="price">Product Display Name</label>
                            		    <input type="text" class="form-control" name="loose_display_name[]" id="loose_display_name" required="" >
                        		    </div>
                        		</div>
                                <div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group loose_div col-xs-12">
                            		    <label for="price">Pack Quantity</label>
                            		    <input type="text" class="form-control" name="loose_pack_content[]" id="loose_pack_content" required="" >
                        		    </div>
                        		</div>
                                <div class="col-md-2 tbl" style="padding-left:10px">
                                    <div class="form-group loose_div col-xs-12">
                        		        <label for="exampleInputEmail1">Sale Unit</label>
                        		        <select class="form-control" name="loose_sale_unit[]" id="loose_sale_unit" onchange="change_loosestock_unit(this);">
                        		            <option value="">Select</option>
                                            <?php foreach($units as $t)  { ?>
                                               <option value="<?php echo $t->id;?>"><?php echo $t->unit;?></option>
                                               <?php } ?> 
                                            </select>
                        		    </div>
                        		</div>
                        		<div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group loose_div col-xs-12">
                            		    <label for="price">MRP(incl. GST)</label>
                            		    <input type="text" class="form-control" name="loose_mrp_price[]" id="loose_mrp_price" required="" >
                        		    </div>
                        		</div>
                        		<div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group loose_div col-xs-12">
                            		    <label for="price">MOP(incl. GST)</label>
                            		    <input type="text" class="form-control" name="loose_mop_price[]" id="loose_mop_price" required="" >
                        		    </div>
                        		</div>
                        		<div class="col-md-2 tbl" style="padding-right:5px">
                        		    <div class="form-group loose_div col-xs-12">
                            		    <label for="price">Offer Price(incl. GST)</label>
                            		    <input type="text" class="form-control" name="loose_offer_price[]" id="loose_offer_price" required="" >
                        		    </div>
                        		</div>
                        		
                        	</div>
                        	<div class="row">
                        	    <div class="col-md-2 tbl" style="padding-left:10px">
                        		    <div class="form-group loose_div col-xs-12">
                            		    <label for="price">App Display Price</label>
                            		    <select class="form-control" name="loose_price_to_display[]" id="loose_price_to_display" >
                                            <!--<option value="1">MRP</option><option value="2">MOP</option><option value="3">Offer Price</option>-->
                                               <?php foreach($pricingtype as $p)  { ?>
                                               <option value="<?php echo $p->id;?>"><?php echo $p->price_type;?></option>
                                               <?php } ?>
                                            </select>
                        		    </div>
                        		</div>
                        	    </div>
                         <div class="row">
                             <div class="col text-center">
                        	        <button id="loose_submit"  style="width: 100px;" type="button" class="btn btn-primary">Add</button>
                        		</div>
                             </div>
                             <hr>
                             <?php 
            	if(!empty($attributes)){ 
            	if(!empty($attributes['product_type_ref']=='loose')){ ?>
            	    <div class="table-responsive">
            	         <table class="table datatable">
            	        <thead>
            <tr>
              <th width="20%;">DISPLAY NAME</th>
              <th width="20%;">SALE UNIT</th>
              <th width="10%;">PACK CONTENT</th>
              <th width="10%;">MRP</th> 
              <th width="10%;">MOP</th>
              <th width="10%;">OFFER PRICE</th>
            </tr>
          </thead> 
          <tbody>
              <?php 
              $cnt = count(explode("|",$attributes['sale_unit']));  
              $sale_unit = explode("|",$attributes['sale_unit']);  
            //   print_r($sale_unit);
              for($i=0; $i<$cnt;$i++){ ?>
               <tr>
             <td class="center">
             <?php $display_name = explode("|",$attributes['display_name']);  echo $display_name[$i];?></td>
             <td class="center"><?php $val = $sale_unit[$i]; 
              if($val == 1){echo "ml";}
                 else if($val == 2){ echo "ltr";}
                 else if($val == 3){ echo "gram";}
                 else if($val == 4){ echo "box";}
                 else if($val == 5){ echo "kg";}
                 else if($val == 6){ echo "Pieces";}
                 else if($val == 7){ echo "nos";}
                 else if($val == 8){ echo "Packet";}
                 else if($val == 9){ echo "Plate";}?></td>
                 <td class="center"><?php $pack_content = explode("|",$attributes['pack_content']);  echo $pack_content[$i];?></td>
                 <td class="center"><?php $mrp_price = explode("|",$attributes['mrp_price']);  echo round($mrp_price[$i],0);?></td>
                 <td class="center"><?php $mop_price = explode("|",$attributes['mop_price']);  echo round($mop_price[$i],0);?></td>
                 <td class="center"><?php $offer_price = explode("|",$attributes['offer_price']);  echo round($offer_price[$i],0);?></td>
          </tr>
             <?php }
              ?>
          
                 
                 </tbody>
                 </table>
            	    </div>
            	    <!--</div>-->
                 <?php } } ?>
                        	</div>
					    <div id="variations">
						</div>
						<hr>
						 <div class="form-group packet_div col-xs-12">
                            <!--<label for="serve_for">Choose the Product Primary Attribute</label>                            -->
                            <span id="packet_primaryatt_id"></span>
                        </div>
                        <div class="form-group col-xs-12" id="loose_stock_div" style="display:none;">
                            <label for="quantity">Is Stock Applicable?</label>                            
                            <select class="form-control" name="loose_display_stock[]" id="loose_display_stock" onchange="loose_stock_changes(this);" disabled="">
                            <option value="Yes">Yes</option><option value="No">No
                            </select>
                            <label for="stock_unit">Stock Unit</label>                            
                            <span id="loose_stock_unit_id"></span>
                            
                            <label for="price">Total Available Stock</label>
                            <input type="text" class="form-control" name="loose_total_available_stock[]" id="loose_total_available_stock" required="" disabled="">
                            
                            <label for="price">MSU</label>
                            <input type="text" class="form-control" name="loose_moq[]" id="loose_moq" required="" disabled="disabled">
                             <label for="serve_for">Stock Status</label>                            
                            <select name="loose_stock_status[]" class="form-control" id="loose_stock_status" required="">
                                <option value="1">Available</option>
                                <!--<option value="Last Few Left">Last Few Left</option>-->
                                <option value="2">Sold Out</option>
                            </select>
                                
                        </div>
                        <strong><label for="unit">ENTER THE PRODUCT GST DETAILS</label></strong>
                        <div class="row">
                        <div class="col-md-4">
                        <div class="form-group col-xs-12">
                            <label for="exampleInputEmail1">HSN Code</label>                            
                            <input type="text" class="form-control" name="HSN_code" required="">
                        </div>
                        </div>
                        <div class="col-md-4">
                        <div class="form-group col-xs-12">
                            <label for="exampleInputEmail1">CGST %</label>                            
                            <input type="number" class="form-control" name="CGST" id ="CGST" required="">
                            <span id="CGST_error" class="error_msg"></span>
                        </div>
                        </div>
                        <div class="col-md-4">
                        <div class="form-group col-xs-12">
                            <label for="exampleInputEmail1">SGST/IGST %</label>                            
                            <input type="number" class="form-control" name="SGST_IGST"  id="SGST_IGST" required="">
                            <span id="SGST_IGST_error" class="error_msg"></span>
                        </div>
                        </div></div>
                    <div class="form-group col-xs-12" id="generic_image">
                        <div class="row">
                            <div class="col-md-8 marginTop30">
                                  <strong ><label for="unit">PRODUCT IMAGES (UPLOAD ATLEAST 1 IMAGES)</label></strong>
                                    <div class="form-group col-xs-12 pad_left_mobile">
                                    <label>Product Picture1</label>
                                    <div class="col-md-12 pad_left_mobile">
                                      <div class="col-md-3 pad_left_mobile">
                                        <img id="profile_image" src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                      </div>
                                      <div class="col-md-9 pad_left_mobile pt_custom" >
                                        <input name="product_image" id="product_image" type="file" accept="image/*" required/>
                                      </div>
                                     <!--<div class="col-md-5">-->
                                     <!--    <div class="form-group ">-->
                                     <!--       <p class="text-uppercase"><strong>Select Related Products</strong></p> -->
                                     <!--       <select class="selectpicker" multiple data-live-search="true" id="related_pro" name="related_pro[]" placeholder="Select Products" >-->
                                     <!--         <?php foreach($related_products as $pro){?>-->
                                     <!--         <option value="<?php echo $pro->prod_id;?>"><?php echo $pro->prod_name;?></option>-->
                                     <!--         <?php } ?>-->
                                     <!--       </select>-->
                                     <!--   </div>-->
                                     <!--</div>-->
                                     </div> 
                                    </div>
                                    <div class="form-group col-xs-12 pad_left_mobile">
                                <label>Product Picture2</label>
                                <div class="col-md-12 pad_left_mobile">
                                  <div class="col-md-3 pad_left_mobile">
                                    <img id="product_image_1" src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                  </div>
                                  <div class="col-md-9 pad_left_mobile pt_custom" >
                                    <input name="product_image_1" type="file" accept="image/*"/>
                                  </div>
            
                                  
                                 </div> 
                        </div>
                                    <div class="form-group col-xs-12 pad_left_mobile">
                                    <label>Product Picture3</label>
                                    <div class="col-md-12 pad_left_mobile">
                                      <div class="col-md-3 pad_left_mobile">
                                        <img id="product_image_2" src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                      </div>
                                      <div class="col-md-9 pad_left_mobile pt_custom" >
                                        <input name="product_image_2" type="file" accept="image/*"/>
                                      </div>
                
                                      
                                     </div> 
                            </div>
                                    <div class="form-group col-xs-12 pad_left_mobile">
                                    <label>Product Picture4</label>
                                    <div class="col-md-12 pad_left_mobile">
                                      <div class="col-md-3 pad_left_mobile">
                                        <img id="product_image_3" src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                      </div>
                                      <div class="col-md-9 pad_left_mobile pt_custom" >
                                        <input name="product_image_3" type="file" accept="image/*"/>
                                      </div>
                
                                      
                                     </div> 
                            </div>
                                    <div class="form-group col-xs-12 pad_left_mobile">
                                    <label>Product Picture5</label>
                                    <div class="col-md-12 pad_left_mobile">
                                      <div class="col-md-3 pad_left_mobile">
                                        <img id="product_image_4" src="" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                      </div>
                                      <div class="col-md-9 pad_left_mobile pt_custom" >
                                        <input name="product_image_4" type="file" accept="image/*"/>
                                      </div>
                
                                      
                                     </div> 
                            </div>
                                    <div class="form-group col-xs-12 pad_left_mobile">
                                    <p class="text-uppercase"><strong>Best Sellers</strong></p> 
                                    <input type="checkbox" id="best_selling"  class="form-check-input" name="best_selling">
                                <label class="form-check-label" for="best_selling" style="font-weight:400"> Add to Best Sellers</label><br>
                        </div>
                            </div>
                           
                            <div class="col-md-4 marginTop30">
                                 <div class="form-group col-xs-12 pad_left_mobile text-capitalize">
                                    <p class="text-uppercase"><strong>Select Related Products</strong></p> 
                                    <!--<select class="selectpicker form-control text-capitalize" multiple data-live-search="true" id="related_pro" name="related_pro[]" placeholder="Select Products" >-->
                                    <!--  <?php foreach($related_products as $pro){?>-->
                                    <!--  <option class="text-capitalize" value="<?php echo $pro->prod_id;?>"><?php echo $pro->prod_name;?></option>-->
                                    <!--  <?php } ?>-->
                                    <!--</select>-->
                                    
                                   <select id="related_pro" name="related_pro[]" multiple class="form-control" >
                                           <?php foreach($related_products as $pro){?>
                                      <option class="text-capitalize" value="<?php echo $pro->prod_id;?>"><?php echo $pro->prod_name;?></option>
                                      <?php } ?>
                                     </select>
                                </div>
                               

                            </div>
                        </div>
                       
                       
                  </div>
              
                 <div class="box-footer">
                     <div class="col text-center">       
              
                  <button id="createProductSubmit" style="width: 100px;" type="submit" class="btn btn-success">Submit</button>
                       </div>
                 </div>
       </form></div> </form></div>
       
       </div>
         </section></div>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>        
         
         <script>
 $(document).ready(function() {
     <?php //$this->session->set_userdata('product',''); ?>
      $('#variations').html("");
    $('#packet_div').show();
    $('#packet_server_hide').hide();
    $('.packet_div').children(":input").prop('disabled',false);
    $('#loose_div').hide();
    $('.loose_div').children(":input").prop('disabled',true);
    $('#loose_stock_div').hide();
    $('#loose_stock_div').children(":input").prop('disabled',true);
$("#select_type").change(function(){
  var value = $(this).val();
  
  if(value=='Loose'){
      <?php //$this->session->set_userdata('product',''); ?>
      $('#variations').html("");
    $('#loose_div').show();
    $('.loose_div').children(":input").prop('disabled',false);
    $('#loose_stock_div').show();
    $('#loose_stock_div').children(":input").prop('disabled',false);
    $('#packet_server_hide').show();
    $('#packet_div').hide();
    $('.packet_div').children(":input").prop('disabled',true);
    $('.packet_div').hide();
  }
  else{
      <?php //$this->session->set_userdata('product',''); ?>
      $('#variations').html("");
    $('#packet_div').show();
    $('.packet_div').show();
    $('#packet_server_hide').hide();
    $('.packet_div').children(":input").prop('disabled',false);
    $('#loose_div').hide();
    $('.loose_div').children(":input").prop('disabled',true);
    $('#loose_stock_div').hide();
    $('#loose_stock_div').children(":input").prop('disabled',true);
  }
//   alert(value);
         });
 });
         </script>
         <script>

//  if($('#packet').prop('checked')){
//      $('#packet_div').show();
//     $('#packet_server_hide').hide();
//      $('.loose_div').children(":input").prop('disabled',true);
//     $('#loose_stock_div').children(":input").prop('disabled',true);
//  }
 
$.validator.addMethod('lessThanEqual', function(value, element, param) {
    return this.optional(element) || parseInt(value) < parseInt($(param).val());
}, "Discounted price should be lesser than price");
</script>
<script>
// $('#createProductForm').validate({
// 	rules:{
// 		product_name:"required",
// 		measurement:"required",
// 		price:"required",
// 		quantity:"required",
// 		image:"required",
// 	}
// });
$('#createProductForm').submit(function () {
    var related_pro = $.trim($('#related_pro').val());
    var product_name = $.trim($('#product_name').val());
    var brand = $.trim($('#brand').val());
    // var description = $('#rich_editor').val();
    var category_name = $.trim($('#category_name').val());
    var pack_type = $.trim($('#select_type').val());
    var store_id = $.trim($('#store_id').val());
    var product_image = $.trim($('#product_image').val());
    if(related_pro==""){
        alert('Please select related products');
            return false;
    }
    if(pack_type=='Loose'){
    var loose_display_stock = $.trim($('#loose_display_stock').val());
    if(loose_display_stock=='Yes'){
    var loose_total_available_stock = $.trim($('#loose_total_available_stock').val());
        if(loose_total_available_stock ==''){
            alert('Please enter stock');
            return false;
        }
    }else{
    var loose_moq = $.trim($('#loose_moq').val());
        if(loose_moq ==''){
            alert('Please enter MSU');
            return false;
        }
    }
    var loose_stock_unit = $.trim($('#loose_stock_unit').val());
    if(loose_stock_unit==''){
         alert('Please select stock Unit');
            return false;
    }
    }
// alert($this->session->userdata['product']);
    if (product_name == '') {
        alert('Please enter product name');
        return false;
    }
    if (brand == '') {
        alert('Please enter brand name');
        return false;
    }
    //  if (description == '') {
    //     alert('Please enter Description');
    //     return false;
    // }
     if (category_name == '') {
        alert('Please enter category');
        return false;
    }
    if (pack_type == '') {
        alert('Please select type');
        return false;
    }
    if (store_id == '') {
        alert('Please select store');
        return false;
    }
    if (product_image == '') {
        alert('Please Select product image');
        return false;
    }
    
   
});
</script>
<script>
var num = 2;
$('#add_packet_variation').on('click',function(){     
	html = '<div class="row"><div class="col-md-3"><div class="form-group"><label for="measurement">Measurement</label>'
		+'<input type="text" class="form-control" name="packet_measurement[]" required=""></div></div>'
	    +'<div class="col-md-1"><div class="form-group">'
	    +'<label for="measurement_unit">Unit</label><select class="form-control" name="packet_measurement_unit_id[]">'
        +'<option value=1>kg</option><option value=2>gm</option><option value=3>ltr</option><option value=4>ml</option><option value=5>pack</option>'
        +'</select></div></div>'
		+'<div class="col-md-2"><div class="form-group"><label for="price">Price(₹):</label>'
		+'<input type="text" class="form-control" name="packet_price[]" required=""></div></div>'
		+'<div class="col-md-2"><div class="form-group"><label for="stock">Stock:</label>'
		+'<input type="text" class="form-control" name="packet_stock[]" /></div></div>'
		+'<div class="col-md-1"><div class="form-group"><label for="unit">Unit:</label>'
        +'<select class="form-control" name="packet_stock_unit_id[]">'
        +'<option value=1>kg</option><option value=2>gm</option><option value=3>ltr</option><option value=4>ml</option><option value=5>pack</option>'
        +'</select>'
        +'</div></div>'
        +'<div class="col-md-2"><div class="form-group packet_div"><label for="qty">Status:</label><select name="packet_status[]" class="form-control" required><option value="Available">Available</option><option value="Sold Out">Sold Out</option></select></div></div>'
		+'<div class="col-md-1" style="display: grid;"><label>Remove</label><a class="remove_variation text-danger" title="Remove variation of product" style="cursor: pointer;"><i class="fa fa-times fa-2x"></i></a></div>'
		+'</div>';
		
	$('#variations').append(html);
	$('#createProductForm').validate();
});

$('#add_loose_variation').on('click',function(){
	html = '<div class="row"><div class="col-md-4"><div class="form-group"><label for="measurement">Measurement</label>'
		+'<input type="text" class="form-control" name="loose_measurement[]" required=""></div></div>'
		+'<div class="col-md-2"><div class="form-group loose_div">'
        +'<label for="unit">Unit:</label><select class="form-control" name="loose_measurement_unit_id[]">'
        +'<option value=1>kg</option><option value=2>gm</option><option value=3>ltr</option><option value=4>ml</option><option value=5>pack</option>'
        +'</select></div></div>'
		+'<div class="col-md-3"><div class="form-group"><label for="price">Price  (₹):</label>'
		+'<input type="text" class="form-control" name="loose_price[]" required=""></div></div>'
		+'<div class="col-md-1" style="display: grid;"><label>Remove</label><a class="remove_variation text-danger" title="Remove variation of product" style="cursor: pointer;"><i class="fa fa-times fa-2x"></i></a></div>'
		+'</div>';
	$('#variations').append(html);
});
</script>
<script>
$(document).on('click','.remove_variation',function(){
	$(this).closest('.row').remove();
});



// $(document).on('change','#packet',function(){
//     $('#variations').html("");
//     $('#packet_div').show();
//     $('#packet_server_hide').hide();
//     $('.packet_div').children(":input").prop('disabled',false);
//     $('#loose_div').hide();
//     $('.loose_div').children(":input").prop('disabled',true);
//     $('#loose_stock_div').hide();
//     $('#loose_stock_div').children(":input").prop('disabled',true);
    
// });
// $(document).on('change','#loose',function(){
//     $('#variations').html("");
//     $('#loose_div').show();
//     $('.loose_div').children(":input").prop('disabled',false);
//     $('#loose_stock_div').show();
//     $('#loose_stock_div').children(":input").prop('disabled',false);
//       $('#packet_server_hide').show();
//     $('#packet_div').hide();
//     $('.packet_div').children(":input").prop('disabled',true);
    
// });
</script>
<script>
$(document).on('click','#packet_submit',function(){

    var formData = new FormData();
    var image1 = document.getElementById('item_image1').files;
        var img1 = image1[0];
     if(image1[0]){        
        if(img1.name!=""){
        //formData.append('item_images[]', img1, img1.name);
        formData.append('item_image1', img1, img1.name);
        }
    }
    var image2 = document.getElementById('item_image2').files;
    var img2 = image2[0];
    if(image2[0]){        
        if(img2.name!=""){
        formData.append('item_image2', img2, img2.name);
        }
    }
    //var files = fileSelect.files;
    // Loop through each of the selected files.
    //for (var i = 0; i < files.length; i++) {
        //var file = files[i];
        // Check the file type.
        //if (!file.type.match('image.*')) {
          //  continue;
        //}
        // Add the file to the request.
      //  formData.append('photos[]', file, file.name);
    //}
    // $('#sale_unit').val("");
var sale_unit=[];
		var someArray=$("select[name='sale_unit[]'] option:selected").each(function(){
		    sale_unit.push($(this).val());
		});
var pack_content=[];
		var someArray=$("input[name='pack_content[]']").each(function(){
			    pack_content.push($(this).val());
				});	
var display_name=[];
		var someArray=$("input[name='display_name[]']").each(function(){
			    display_name.push($(this).val());
				});					
var mrp_price=[];
		var someArray=$("input[name='mrp_price[]']").each(function(){
			    mrp_price.push($(this).val());
				});	
var mop_price=[];
		var someArray=$("input[name='mop_price[]']").each(function(){
			    mop_price.push($(this).val());
				});	
var offer_price=[];
		var someArray=$("input[name='offer_price[]']").each(function(){
			    offer_price.push($(this).val());
				});	
var price_to_display=[];
		var someArray=$("select[name='price_to_display[]'] option:selected").each(function(){
		    price_to_display.push($(this).val());
		});
var display_stock=[];
		var someArray=$("select[name='display_stock[]'] option:selected").each(function(){
		    display_stock.push($(this).val());
		});
var stock_unit=[];
		var someArray=$("select[name='stock_unit[]'] option:selected").each(function(){
		    stock_unit.push($(this).val());
		});	
var total_available_stock=[];
		var someArray=$("input[name='total_available_stock[]']").each(function(){
			    total_available_stock.push($(this).val());
				});			
var moq=[];
		var someArray=$("input[name='moq[]']").each(function(){
			    moq.push($(this).val());
				});					
var stock_status=[];
		var someArray=$("select[name='stock_status[]'] option:selected").each(function(){
		    stock_status.push($(this).val());
		});
var attribute1=[];
		var someArray=$("select[name='attribute1[]'] option:selected").each(function(){
		    attribute1.push($(this).val());
		});
var attribute2=[];
		var someArray=$("select[name='attribute2[]'] option:selected").each(function(){
		    attribute2.push($(this).val());
		});
var attribute3=[];
		var someArray=$("select[name='attribute3[]'] option:selected").each(function(){
		    attribute3.push($(this).val());
		});	
var varient1=[];
		var someArray=$("input[name='varient1[]']").each(function(){
			    varient1.push($(this).val());
				});
var varient2=[];
		var someArray=$("input[name='varient2[]']").each(function(){
			    varient2.push($(this).val());
				});
var varient3=[];
		var someArray=$("input[name='varient3[]']").each(function(){
			    varient3.push($(this).val());
				});			
var add_varient = document.getElementById('add_varient').value;

chk_packet_validation = 1;
if(add_varient=='Yes'){
    document.getElementById('attribute-1').style.borderColor = "#d2d6de";
    document.getElementById('vart-1').style.borderColor = "#d2d6de";
    var trimmed_attribute1 = $.trim($("#attribute-1").val());
    var trimmed_varient1 = $.trim($("#vart-1").val());
    if(trimmed_attribute1=='' || trimmed_varient1=='' ){
        if(trimmed_attribute1=='')document.getElementById('attribute-1').style.borderColor = "red";
        if(trimmed_varient1=='')document.getElementById('vart-1').style.borderColor = "red";
        chk_packet_validation = 0;
    }
}
if(display_name==''){
    document.getElementById('display_name').style.borderColor = "red";
    chk_packet_validation = 0;
}else{
    document.getElementById('display_name').style.borderColor = "#d2d6de";
}
if(sale_unit==''){
    document.getElementById('sale_unit').style.borderColor = "red";
    chk_packet_validation = 0;
}else{
    document.getElementById('sale_unit').style.borderColor = "#d2d6de";
}
if(pack_content=='' || pack_content==0){
    document.getElementById('pack_content').style.borderColor = "red";
    chk_packet_validation = 0;
}else{
    document.getElementById('pack_content').style.borderColor = "#d2d6de";
}
if(mrp_price=='' || mrp_price==0){
    document.getElementById('mrp_price').style.borderColor = "red";
    chk_packet_validation = 0;
}else{
    document.getElementById('mrp_price').style.borderColor = "#d2d6de";
}
if(price_to_display==''){
    document.getElementById('price_to_display').style.borderColor = "red";
    chk_packet_validation = 0;
}else{
    document.getElementById('price_to_display').style.borderColor = "#d2d6de";
}

document.getElementById('mop_price').style.borderColor = "#d2d6de";
if(price_to_display==2 || price_to_display==4 || price_to_display==5 ){ //MOP//price range //request of price
if(mop_price=='' || mop_price==0){
    document.getElementById('mop_price').style.borderColor = "red";
    chk_packet_validation = 0;
}}

document.getElementById('offer_price').style.borderColor = "#d2d6de";
if(price_to_display==3){ //offer price
if(offer_price=='' || offer_price==0){
    document.getElementById('offer_price').style.borderColor = "red";
    chk_packet_validation = 0;
}}

if(display_stock=='Yes'){
    if(total_available_stock=='' || total_available_stock==0){
        document.getElementById('total_available_stock').style.borderColor = "red";
        chk_packet_validation = 0;
    }else{
        document.getElementById('total_available_stock').style.borderColor = "#d2d6de";
    }
}
if(display_stock=='No'){
    if(display_stock=='' || display_stock==0){
        document.getElementById('display_stock').style.borderColor = "red";
        chk_packet_validation = 0;
    }else{
        document.getElementById('display_stock').style.borderColor = "#d2d6de";
    }
}
var pri_attcolor=[];
		var someArray=$("input[name='pri_attcolor[]']").each(function(){
			    pri_attcolor.push($(this).val());
				});	
formData.append('display_name', display_name);
formData.append('sale_unit', sale_unit);
formData.append('pack_content', pack_content);
formData.append('mrp_price', mrp_price);
formData.append('mop_price', mop_price);
formData.append('offer_price', offer_price);
formData.append('price_to_display', price_to_display);
formData.append('display_stock', display_stock);
formData.append('stock_unit', stock_unit);
formData.append('total_available_stock', total_available_stock);
formData.append('moq', moq);
formData.append('stock_status', stock_status);
formData.append('attribute1', attribute1);
formData.append('attribute2', attribute2);
formData.append('attribute3', attribute3);
formData.append('varient1', varient1);
formData.append('varient2', varient2);
formData.append('varient3', varient3);
formData.append('pri_attcolor', pri_attcolor);
if(chk_packet_validation==1){
            	$.ajax({
				url:'<?php echo base_url() ?>product/add_session_packet',
				type:'POST',
				//data: {display_name: display_name, sale_unit: sale_unit, pack_content: pack_content,mrp_price: mrp_price,mop_price: mop_price,offer_price: offer_price,price_to_display: price_to_display,display_stock: display_stock,stock_unit: stock_unit,total_available_stock: total_available_stock,moq:moq,stock_status: stock_status,attribute1: attribute1,attribute2: attribute2,attribute3: attribute3,varient1: varient1,varient2: varient2,varient3: varient3,pri_attcolor:pri_attcolor,formData:formData },
                data: formData, 
                //dataType: 'json',
                contentType: false,
                processData: false,
				success: function(data)
				{
                    //alert(data);
				    if(data){
				        $("#packet_message").html(data);
				        $("#packet_div").load(location.href + " #packet_div"); //to reload the packet_div without refresh the page
				    }
				}
				// $("#moq").prop('disabled',true);
    //             $("#total_available_stock").prop('disabled',false);
            	});
}else{
 alert("Please fill all validate field");   
}
});
</script>
<script>
$(document).on('click','#loose_submit',function(){
var loose_sale_unit=[];
		var someArray=$("select[name='loose_sale_unit[]'] option:selected").each(function(){
		    loose_sale_unit.push($(this).val());
		});
var loose_pack_content=[];
		var someArray=$("input[name='loose_pack_content[]']").each(function(){
			    loose_pack_content.push($(this).val());
				});	
var loose_display_name=[];
		var someArray=$("input[name='loose_display_name[]']").each(function(){
			    loose_display_name.push($(this).val());
				});	
var loose_mrp_price=[];
		var someArray=$("input[name='loose_mrp_price[]']").each(function(){
			    loose_mrp_price.push($(this).val());
				});	
var loose_mop_price=[];
		var someArray=$("input[name='loose_mop_price[]']").each(function(){
			    loose_mop_price.push($(this).val());
				});	
var loose_offer_price=[];
		var someArray=$("input[name='loose_offer_price[]']").each(function(){
			    loose_offer_price.push($(this).val());
				});	
var loose_price_to_display=[];
		var someArray=$("select[name='loose_price_to_display[]'] option:selected").each(function(){
		    loose_price_to_display.push($(this).val());
		});
		chk_loose_validation = 1;
if(loose_display_name==''){
    document.getElementById('loose_display_name').style.borderColor = "red";
    chk_loose_validation = 0;
}else{
    document.getElementById('loose_display_name').style.borderColor = "#d2d6de";
}
if(loose_sale_unit==''){
    document.getElementById('loose_sale_unit').style.borderColor = "red";
    chk_loose_validation = 0;
}else{
    document.getElementById('loose_sale_unit').style.borderColor = "#d2d6de";
}
if(loose_pack_content==''){
    document.getElementById('loose_pack_content').style.borderColor = "red";
    chk_loose_validation = 0;
}else{
    document.getElementById('loose_pack_content').style.borderColor = "#d2d6de";
}
if(loose_mrp_price=='' || loose_mrp_price==0 ){
    document.getElementById('loose_mrp_price').style.borderColor = "red";
    chk_loose_validation = 0;
}else{
    document.getElementById('loose_mrp_price').style.borderColor = "#d2d6de";
}
if(loose_price_to_display==''){
    document.getElementById('loose_price_to_display').style.borderColor = "red";
    chk_loose_validation = 0;
}else{
    document.getElementById('loose_price_to_display').style.borderColor = "#d2d6de";
}
document.getElementById('loose_mop_price').style.borderColor = "#d2d6de";
if(loose_price_to_display==2 || loose_price_to_display==4 || loose_price_to_display==5){ //MOP//price range //request of price
if(loose_mop_price=='' || loose_mop_price==0){
    document.getElementById('loose_mop_price').style.borderColor = "red";
    chk_loose_validation = 0;
}
}

document.getElementById('loose_offer_price').style.borderColor = "#d2d6de";
if(loose_price_to_display==3){ //Offer price
if(loose_offer_price=='' || loose_offer_price==0){
    document.getElementById('loose_offer_price').style.borderColor = "red";
    chk_loose_validation = 0;
}
}
if(chk_loose_validation ==1 ){
            $.ajax({
				url:'<?php echo base_url() ?>product/add_session_loose',
				type:'POST',
				// data:'str='+str,
				data: {loose_display_name: loose_display_name, loose_sale_unit: loose_sale_unit, loose_pack_content: loose_pack_content,loose_mrp_price: loose_mrp_price,loose_mop_price: loose_mop_price,loose_offer_price: loose_offer_price,loose_price_to_display: loose_price_to_display },
				success: function(data)
				{
				    if(data){
				        $("#loose_message").html(data);
                        $("#loose_div").load(location.href + " #loose_div"); //to reload the loose_div without refresh the page
				    }
				}
            	});
}else{
    alert("Please fill all validate field");
}
});
</script>
<script>
function get_varient(str){
		var id = str.getAttribute('id');
        var splitdata=id.split('-');
        var status=str.value; 
        var col_id =splitdata[1];
        //alert(col_id);
        var a =str.value;
        var att_1 = document.getElementById('attribute-'+ col_id).value;
        // alert(att_1);
      	$.ajax({
				url:'<?php echo base_url() ?>product/get_varient',
				type:'POST',
				// data:'data='+att_1,
				data:'data='+att_1+'&col_id='+col_id,
				success: function(data)
				
				{ 
				    //alert(data);
				    $('#vart-'+splitdata[1]).html(data);
				}
      	    
      	});
			}	
</script>
<script>
$(document).ready(function(){
         $("#moq").prop('disabled',true);
         $("#total_available_stock").prop('disabled',false);
         $("#loose_moq").prop('disabled',true);
         $("#loose_total_available_stock").prop('disabled',false);
         event.preventDefault();
         var a ='0';//default ml
      	$.ajax({
				url:'<?php echo base_url() ?>product/change_stock_unit',
				type:'POST',
				data:'data='+a,
				success: function(data)
				
				{ 
				    //alert(data);
				    $('#stock_unit_id').html(data);
				}
      	    
      	});
      	 var b ="1"; //loose default ml
      	$.ajax({
				url:'<?php echo base_url() ?>product/change_loosestock_unit',
				type:'POST',
				data:'data='+a,
				success: function(data)
				
				{ 
				    //alert(data);
				    $('#loose_stock_unit_id').html(data);
				}
      	    
      	});
});
function stock_changes(str){
     var a =str.value;
     if(a=='Yes'){
         $("#moq").prop('disabled',true);
         $("#total_available_stock").prop('disabled',false);
         $('#moq').val('');
         event.preventDefault();
     }
     else{
        $("#moq").prop('disabled',false);
         $("#total_available_stock").prop('disabled',true);
         $('#total_available_stock').val('');
         event.preventDefault();
     }
}

function loose_stock_changes(str){
     var a =str.value;
     if(a=='Yes'){
         $("#loose_moq").prop('disabled',true);
         $("#loose_total_available_stock").prop('disabled',false);
         $('#loose_moq').val('');
         event.preventDefault();
     }
     else{
        $("#loose_moq").prop('disabled',false);
         $("#loose_total_available_stock").prop('disabled',true);
         $('#loose_total_available_stock').val('');
         event.preventDefault();
     }
}
</script>
<script>
function change_stock_unit(str){
     if(str==0){
        var a =str;   
    }else {
		var id = str.getAttribute('id');
        var splitdata=id.split('-');
        var status=str.value; 
        var col_id =splitdata[1];
        //alert(col_id);
        var a =str.value;
      	$.ajax({
				url:'<?php echo base_url() ?>product/change_stock_unit',
				type:'POST',
				data:'data='+a,
				success: function(data)
				
				{ 
				    //alert(data);
				    $('#stock_unit_id').html(data);
				}
      	    
      	});
    }
			}
			
function change_loosestock_unit(str){
    if(str==0){
        var a =str;   
    }else {
		var id = str.getAttribute('id');
        var splitdata=id.split('-');
        var status=str.value; 
        var col_id =splitdata[1];
        //alert(col_id);
        var a =str.value;
      	$.ajax({
				url:'<?php echo base_url() ?>product/change_loosestock_unit',
				type:'POST',
				data:'data='+a,
				success: function(data)
				
				{ 
				    //alert(data);
				    $('#loose_stock_unit_id').html(data);
				}
      	    
      	});
    }
			}
</script>
<script>
$("#product_name").blur(function(){
    var product_name = document.getElementById("product_name").value;
    vald_product_name = 1;
    
    // $.ajax({
				// url:'<?php echo base_url() ?>product/change_loosestock_unit',
				// type:'POST',
				// data:'product_name='+product_name,
				// success: function(data)
				
				// { 
				//     //alert(data);
				//     $('#loose_stock_unit_id').html(data);
				// }
      	    
    //   	});
    if(product_name==''){
        document.getElementById('product_name').style.borderColor = "red";
        document.getElementById("product_name_error").textContent = "Please enter valid product name";
    }else{
        document.getElementById('product_name').style.borderColor = "#d2d6de";
        document.getElementById("product_name_error").textContent = "";
        
    }
});
$("#brand").blur(function(){
    var brand = document.getElementById("brand").value;
    if(brand==''){
        document.getElementById('brand').style.borderColor = "red";
        document.getElementById("brand_error").textContent = "Please enter brand";
    }else{
        document.getElementById('brand').style.borderColor = "#d2d6de";
        document.getElementById("brand_error").textContent = "";
        
    }
});
$("#rich_editor").blur(function(){
    var description = document.getElementById("rich_editor").value;
    if(description==''){
        document.getElementById('rich_editor').style.borderColor = "red";
        document.getElementById("description_error").textContent = "Please enter description";
    }else{
        document.getElementById('rich_editor').style.borderColor = "#d2d6de";
        document.getElementById("description_error").textContent = "";
        
    }
});
$("#category_name").blur(function(){
    var category_name = document.getElementById("category_name").value;
    if(category_name==''){
        document.getElementById('category_name').style.borderColor = "red";
        document.getElementById("category_name_error").textContent = "Please enter category name";
    }else{
        document.getElementById('category_name').style.borderColor = "#d2d6de";
        document.getElementById("category_name_error").textContent = "";
        
    }
});
$("#select_type").blur(function(){
    var type = document.getElementById("select_type").value;
    if(type==''){
        document.getElementById('select_type').style.borderColor = "red";
        document.getElementById("type_error").textContent = "Please select pack type";
    }else{
        document.getElementById('select_type').style.borderColor = "#d2d6de";
        document.getElementById("type_error").textContent = "";
        
    }
});
$("#CGST").blur(function(){
    var CGST = document.getElementById("CGST").value;
    if(CGST==''){
        document.getElementById('CGST').style.borderColor = "red";
        document.getElementById("CGST_error").textContent = "Please select CGST%";
    }else{
        document.getElementById('CGST').style.borderColor = "#d2d6de";
        document.getElementById("CGST_error").textContent = "";
        
    }
});
$("#SGST_IGST").blur(function(){
    var SGST_IGST = document.getElementById("SGST_IGST").value;
    if(SGST_IGST==''){
        document.getElementById('SGST_IGST').style.borderColor = "red";
        document.getElementById("SGST_IGST_error").textContent = "Please select SGST%";
    }else{
        document.getElementById('SGST_IGST').style.borderColor = "#d2d6de";
        document.getElementById("SGST_IGST_error").textContent = "";
        
    }
});


</script>
<script>
window.onload = function() {
    change_loosestock_unit(0); //default select
    change_stock_unit(0); //default select
    change_packet_primaryatt(4); //color
    refresh_table();
    refresh_table();
}
</script>
<script>
// $("#pack_content").keypress(function (e) {
// var charCode = (e.which) ? e.which : event.keyCode.
// alert(charCode);
// if (String.fromCharCode(charCode).match(/[^0-9]/g))
// return false;
// });
</script>
<script>
function change_packet_primaryatt(str){
    if(str==4){ //color
        var att_id =str;   
    }else {
		var id = str.getAttribute('id');
        var splitdata=id.split('-');
        var status=str.value; 
        var col_id =splitdata[1];
        var att_id =str.value;
        if(att_id!=""){
      	$.ajax({
				url:'<?php echo base_url() ?>product/change_packet_primaryatt',
				type:'POST',
				data:'data='+att_id,
				success: function(data)
				
				{ 
				    //alert(data);
				    // $('#stock_unit_id').html(data);
				    $('#packet_primaryatt_id').html(data);
				    
				}
      	    
      	});
			}
        else{		
        $('#primary_varient').hide();
        $('#label_PA').hide();
        }
}
}
</script>
<script>
function refresh_table(){
 a =1;
     	$.ajax({
				url:'<?php echo base_url() ?>product/test',
				type:'POST',
				data:'data='+a,
				success: function(data)
				
				{ 
				    // alert(data);

				}
      	    
      	});
}
</script>
<script type="text/javascript">
// $(document).ready(function() {
//   $('#related_pro').selectpicker();
 
// });
    </script>
    <script>

 $(document).ready(function() {
    active("product_side_menu"); 
    $(".bootstrap-select .dropdown-menu").addClass("form-control");
 });

</script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <script>
      $(document).ready(function(){
 $('#related_pro').multiselect({
  nonSelectedText: 'Nothing Selected',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'300px'
 });
 
});
  </script>
   
