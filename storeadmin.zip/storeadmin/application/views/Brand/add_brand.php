<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>brand  | brand_list</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
     <!--Croppie css Start-->
     <link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" rel="stylesheet">
     <link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" rel="stylesheet">
     <!--Croppie Css End-->
    <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .error_msg{
        color: red;
        font-weight: 700;
    }
     #upload-demo_brand
    {
    	width: auto;
    	height: 80vh;
        padding-bottom:25px;
    }
     .brand_img_prev
    {
        width: 225px;
        height: 100px;
        object-fit: contain;
    }
    .error_msg_fix_height
    {
        background-color: #fdfafa!important;
        font-size: 11px!important;
        text-align: left!important;
        font-weight: 600!important;
        width: 100%!important;
    }
    
      .pl_0_cus
        {
                padding-left: 0px;
        }
        .p_top_cus
        {
            padding-top: 52px;
        }
        @media (max-width:575px)
        {
            .p_top_cus
            {
                padding-top: 25px!important;
            }
        }
    
</style>
  </head>
  <div class="content-wrapper">
      <section class="content-header">
        <h1><?= $pTitle ?><small><?= $pDescription ?></small></h1>
        <ol class="breadcrumb">
         <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
         <li><?= $menu ?></li>
         <li class="active"><?= $smenu ?></li>
        </ol>
      </section>
      <section class="content">
           <div class="row">
               <div class="col-md-12">
              
                    <?php 
                    // print_r($brand_id);
                     $url = (!isset($brand_id) || empty($brand_id))?'Brand/createbrand':'Brand/updatebrand/'.encode_param($brand_id);
                    if(isset($brand_data[0])){
                    $brand_data = $brand_data[0];    
                    }
            
                   
                    if($this->session->flashdata('message')) { 
                        
                      $flashdata = $this->session->flashdata('message'); ?>
                      <div class="alert alert-<?= $flashdata['class'] ?>">
                        <button class="close" data-dismiss="alert" type="button">×</button>
                        <?= $flashdata['message'] ?>
                      </div>
                    <?php } ?>
                </div> 
                 <div class="col-md-12">
                     <div class="box box-warning">
                
                        <div class="box-body">
                            <form role="form" action="<?= base_url($url) ?>" method="post"  class="validate" data-parsley-validate="" enctype="multipart/form-data">
                                <div class="col-md-6">
                                    <!--brand name-->
                                    <div class="form-group">
                                      <label>BRAND NAME</label>
                                        <input type="text" class="form-control required" data-parsley-trigger="change" data-parsley-minlength="2"
                                            name="brand_name" required="" placeholder="Enter Brand Name" value="<?= (isset($brand_data->brand_name))?$brand_data->brand_name:'' ?>">
                                      <span class="glyphicon form-control-feedback"></span>
                                    </div>
                                     <!--brand description-->
                                    <div class="form-group">
                                      <label>BRAND DESCRIPTION</label>
                                        <input type="text" class="form-control required" data-parsley-trigger="change" data-parsley-minlength="2"
                                            name="brand_desc" required="" placeholder="Short Description about Brand" value="<?= (isset($brand_data->brand_desc))?$brand_data->brand_desc:'' ?>">
                                      <span class="glyphicon form-control-feedback"></span>
                                    </div>
                                    <!--popular check box-->
                                     <div class="form-group ">
                                        <p class="text-uppercase"><strong>Top Brand</strong></p> 
                                        <input type="checkbox" id="top_brand"  class="form-check-input" name="top_brand" 
                                          <?php 
                                          if(isset($brand_data->top_brand)){
                                              if($brand_data->top_brand==1){
                                               echo 'checked="checked"';
                                              }else{
                                                   echo '';
                                              }
                                          }
                                          ?> >
                                         <label class="form-check-label" for="top_brand" style="font-weight:400"> Add to Top Brand</label><br>
                                    </div>
                                    <!--images-->
                                        <div class="form-group">
                                            <label>PICTURE</label>
                                            <div class="col-md-12 pl_0_cus">
                                              <div class="col-md-2 pl_0_cus">
                                                <img id="profile_image" src="<?= (isset($brand_data) && isset($brand_data->brand_image))?base_url('../../'.$brand_data->brand_image):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                                              </div>
                                              <div class="col-md-9 pl_0_cus p_top_cus" >
                                                
                                                 <input name="brand_image" id="brand_cat_img" type="file" accept="image/*" 
                                                class="<?= (isset($brand_data->brand_image) && !empty($brand_data->brand_image))?'':'required' ?>" 
                                                onchange="setImg(this,'brand_image')" >
                                                <!--brandd base64 -->
                                                <input name="brand_image_crop_file" id="brand_image_crop_file" type="text" hidden>
                                                
                                                <!--Old updated file path-->
                                                <input name="brand_image_crop_file_1" id="brand_image_crop_file_1" type="text" value="<?= (isset($brand_data->brand_image))?'../../'.$brand_data->brand_image:'' ?>" hidden >
                                                
                                                  <!--brandd base64 -->
                                              </div>
                                              
                                              
                                            </div>
                                        </div>
                                    <!--  submit-->
                                      <div class="col-md-12">      
                                        <div class="box-footer textCenterAlign">
                                          <button type="submit" class="btn btn-primary">Submit</button>
                                          <a href="<?= base_url('brand/Viewbrand') ?>" class="btn btn-primary">Cancel</a>
                                        </div>        
                                      </div>  
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
      </section>
</div>
<!-- Modal -->
<!-- modal for 900 x 400 image -->
<div class="modal fade " id="brand_cropImagePop" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="upload-demo_brand" class="center-block"></div>
              </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" id="cropImageBtn_brand" class="btn btn-primary">Crop</button>
              </div>
        </div>
    </div>
</div>
 <script>
    //  $(document).ready(function() 
    //  {
    //     active("1_id");
    //     active_main("1_id");
  
    //  });
</script>
<!--2/10/2021 readImage start-->

 <!--Croppie JS Start-->
     <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.js"></script>
 <!--Croppie JS End-->
<!--Croppie JS for 350 x 233 image-->
    <script>
    // Start upload preview image
    var $uploadCrop, tempFilename, rawImg, imageId ;
    function readFile_brand(input) 
    {
        if (input.files && input.files[0]) 
        {
            var reader = new FileReader();
            reader.onload = function (e) 
            {
                $('.upload-demo').addClass('ready');
                $('#brand_cropImagePop').modal('show');
               
                rawImg = e.target.result;
            }
            reader.readAsDataURL(input.files[0]);
        }
        else 
        {
            swal("Sorry - you're browser doesn't support the FileReader API");
        }
    }
    $uploadCrop = $('#upload-demo_brand').croppie({
        viewport: 
        {
                width: 350,
                height: 233,
        },
        enforceBoundary: false,
        enableExif: true
        });
        $('#brand_cropImagePop').on('shown.bs.modal', function()
        {
            $uploadCrop.croppie('bind', {url: rawImg}).then(function()
                {
                    console.log('jQuery bind complete');
                });
        });
        $('#brand_cat_img').on('change', function () 
        { 
            imageId = $(this).data('id'); 
            tempFilename = $(this).val();
            $('#cancelCropBtn').data('id', imageId); 
            readFile_brand(this); 
            
            $('#cropImageBtn_brand').on('click', function (ev) 
        {
            $uploadCrop.croppie('result', 
            {
                type: 'base64',
                size: {width: 350, height: 233
            }}).then(function (resp) 
            {
                $('#brand_cropImagePop').modal('hide');
                 /*to disable outside click of crop modal*/
              
                $("#brand_image_crop_file").val(resp);
              
               $("#profile_image").attr('src',resp);
            });
        });
        });

</script>
<!--2/10/2021 readImage start-->
<script>
    $(".main-sidebar ul .brand_side_menu").addClass("active");
</script>
