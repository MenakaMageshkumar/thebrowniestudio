<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Brand | Brand_list</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
         <style>

     .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
    }
    .p_3_font_13
    {
        padding-left: 3px!important;
        padding-right:3px!important;
        padding-top:10px!important;
        padding-bottom:10px!important;
        font-size: 12.5px!important;
    }
    </style>
  </head>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Brand List</h3></div>
          <div class="col-md-6" align="right">
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
      <div class="box-body table-responsive">
        <table id="driverTable" class="table table-bordered table-striped datatable ">
             
          <thead>
            <tr>
                 <th width="2%" class="text-center p_3_font_13 text-uppercase">S.NO</th>
              <th class="hidden">Brand ID</th>
              <th width="13%;" class="text-center p_3_font_13 text-uppercase">Brand Name</th>
              <th width="25%;" class="text-center p_3_font_13 text-uppercase">Description</th>
              <th width="13%;" class="text-center p_3_font_13 text-uppercase">Image </th>
               <th width="25%;" class="text-center p_3_font_13 text-uppercase">Top Brand</th>
              <th width="33%;" class="text-center p_3_font_13 text-uppercase">Action</th>
            </tr>
          </thead> 
          <tbody>
            <?php
            if(!empty($brand_Data)){
                    $i =1;
              foreach($brand_Data as $brand) {
               ?>
               <tr>
                    <td class="center text-center p_3_font_13"><?= $i++ ?></td>
                 <td class="hidden"><?= $brand->brand_id ?></td>
                 <td class="center text-center p_3_font_13"><?= $brand->brand_name ?></td> 
                 <td class="center"><?= $brand->brand_desc ?></td> 
                 <td class="center text-center p_3_font_13">
                     <img src="<?= base_url('../../'.$brand->brand_image) ?>" class="cpoint" onclick="viewImageModal('Profile Image','<?= base_url('../../'.$brand->brand_image) ?>');"
                  onerror="this.src='<?=base_url("../../assets/images/user_avatar.jpg")?>';" height="100" width="100" />
                 </td>
                 <td class="center text-center p_3_font_13">
                     <?= ($brand->top_brand == '1')?'Top Brand':''?>
                </td>
                 <td class="center text-center p_3_font_13">	 
                  
                    <a class="btn btn-sm btn-danger" 
                      href="<?= base_url('Brand/edit_brand/'.encode_param($brand->brand_id )) ?>">
                      <i class="fa fa-fw fa-edit"></i>Edit
                    </a> 
                  </td>
                </tr>
            <?php 
              } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>

 <script>
     $(document).ready(function() 
     { 
          jQuery(function () {
                    jQuery('#driverTable').DataTable({
                        "ordering" : jQuery(this).data("ordering"),
                        "order": [[ 1, "desc" ]]
                    });
                });
     });
</script>
<script>
    $(".main-sidebar ul .brand_side_menu").addClass("active");
</script>
