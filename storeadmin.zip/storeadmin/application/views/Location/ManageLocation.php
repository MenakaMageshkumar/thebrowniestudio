 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Location |Manage Location</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
  </head>
     <style>
  .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
  </style>

<div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
      <li><?= $menu ?></li>
      <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
             <button class="close" data-dismiss="alert" type="button">×</button>
             <?= $flashdata['message'] ?>
          </div>
        <?php } ?>
      </div>
      <div class="col-xs-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <div class="col-md-6"><h3 class="box-title">Current Delivery Location</h3></div>
            <div class="col-md-6" align="right">
              
              <a class="btn btn-sm btn-pri" href="<?= base_url('Location/AddLocation')?>">ADD NEW</a>
              <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
           </div>
          </div>
          <div class="box-body">
              <div class="form-group">
              <input type="text" class="form-control required" data-parsley-trigger="change" data-parsley-minlength="2" name="search_text" id="search_text" required="" placeholder="SEARCH (By PINCODE,STATE,CITY,AREA)" >
              </div>
              <div class="table-responsive box-body">
            <table id="deliverylocation" class="table table-bordered table-striped datatable ">
              <thead>
                <tr>
                   <th width="2%" class="text-center p_3_font_13">S.NO</th>
                  <th width="150px;"  class="text-center p_3_font_13">STATE</th>
                  <th width="150px;"  class="text-center p_3_font_13">DISTRICT</th>
                  <th width="150px;"  class="text-center p_3_font_13">CITY / TOWN</th>
                  <th width="150px;"  class="text-center p_3_font_13">AREA</th>
                  <th width="100px;"  class="text-center p_3_font_13">PINCODE</th>
                  <th width="300px;"  class="text-center p_3_font_13">ACTION</th>
               </tr>
              </thead> 
              <tbody>
                <?php
                if(!empty($Location_data)){
                      $i =1;
                  foreach($Location_data as $dt) {  ?>
                    <tr>
                           <th class="center text-center p_3_font_13"><?= $i++ ?></th>
                      <th class="center text-center p_3_font_13"><?= $dt->state ?></th>
                       <th class="center text-center p_3_font_13"><?= $dt->district ?></th>
                       <th class="center text-center p_3_font_13"><?= $dt->city_name ?></th>
                       <th class="center text-center p_3_font_13"><?= $dt->area_locality ?></th>
                       <th class="center text-center p_3_font_13"><?= $dt->pincode ?></th>
                      <td class="center text-center p_3_font_13">   
                        <?php if($dt->default_address==1){ ?>
                          <a class="btn btn-sm btn-default" href="#">Default</a>
                        <?php } else { ?>
                        <a class="btn btn-sm btn-danger" href="<?= base_url('Location/deleteLocation/'.encode_param($dt->str_addressid)) ?>">
                          <i class="fa fa-fw fa-edit"></i>Delete
                        </a>
                        <?php } ?>
                      </td>
                    </tr>
                <?php } } ?>
              </tbody>
            </table>
          </div></div>
        </div>
      </div>
    </div>
  </section>
</div>
<script>
$(document).ready(function(){
  $("#search_text").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#deliverylocation tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script>

 $(document).ready(function() {
    active("location_side_menu"); 
 });

</script>
 <script>
     $(document).ready(function() 
     { 
          jQuery(function () {
                    jQuery('.datatable').DataTable({
                        "ordering" : jQuery(this).data("ordering"),
                        "order": [[ 1, "desc" ]]
                    });
                });
     });
</script>