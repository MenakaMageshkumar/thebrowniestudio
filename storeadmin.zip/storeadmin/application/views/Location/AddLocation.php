<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Location | Add Location</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
  <div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?><small><?= $pDescription ?></small></h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
         $url = (!isset($store_id) || empty($store_id))?'':'Location/updateLocation/'.$store_id;
         $Location_data = $Location_data[0];
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>
      </div>
      <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-body">
            <form role="form" action="<?= base_url($url) ?>" method="post" 
              class="validate" data-parsley-validate="" enctype="multipart/form-data">
              <div class="col-md-6">
                   <?php if(!empty($state)){ ?>
                  <div class="form-group">
                    <label>STATE</label>
                    <select name="state_id" class="form-control" id="state_id" placeholder="Select State" required>
                        <option selected value="">Select Your State</option>
                      <?php 
                        foreach ($state as $st) {
                          echo '<option value="'.$st->state_id.'">'.$st->state.'</option>';
                        }
                      ?>
                       </select> 
                  </div>
                <?php } ?>
                  <div class="form-group">
                    <label>DISTRICT</label>
                      <select name="district_id" id="district_id" class="form-control" placeholder="Select District" required>
                        <option selected value="">Select Your District</option>
                       </select> 
                  </div>
                  <div class="form-group">
                    <label>CITY</label>
                    <select name="city_id" id="city_id" class="form-control" placeholder="Select City" required>
                        <option selected value="">Select Your City</option>
                       </select> 
                  </div>
                  <div class="form-group">
                      <label>AREA</label><br>
                      <span id="load_area"></span>
                  </div>
                <div class="form-group">
                          <label>PINCODE</label>
                  <input type="text" class="form-control" data-parsley-trigger="change"  name="pincode" id="pincode" required="" placeholder="" Disabled>
                  </div>
                   <div class="col-md-12">      
                <div class="box-footer textCenterAlign">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>        
              </div> 
        </div>
        </form>
      </div>
    </div></div>
  </section>
</div>
<script>
$(document).ready(function() {
  $('#state_id').on('change', function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'<?php echo base_url() ?>Location/ajax_getdistrict',
                data: {stateID:stateID},
                success:function(html){
                    $('#district_id').html(html);
                }
            }); 
        }else{
            $('#district_id').html('<option value="">Select District</option>'); 
        }
  });
  $('#district_id').on('change', function(){
        var districtID = $(this).val();
        if(districtID){
            $.ajax({
                type:'POST',
                url:'<?php echo base_url() ?>Location/ajax_getcity',
                data: {districtID:districtID},
                success:function(html){
                    $('#city_id').html(html);
                }
            }); 
        }else{
            $('#city_id').html('<option value="">Select City</option>'); 
        }
  });
   $('#city_id').on('change', function(){
        var cityID = $(this).val();
        if(cityID){
            $.ajax({
                type:'POST',
                url:'<?php echo base_url() ?>Location/ajax_getarea',
                data: {cityID:cityID},
                success:function(html){
                    var obj = $.parseJSON(html);
                    $('#load_area').html(obj['first']);
                    $('#pincode').val(obj['second']);
                }
            }); 
        }
  });
  
 });
</script>
<script>
$(document).ready(function() {
   $(document).on('change', 'input[type="checkbox"]', function(e){
    var area_id=[];
		var someArray=$("input[name='area_id[]']:checked").each(function(){
			    area_id.push($(this).val());
				});
             $.ajax({
                type:'POST',
                url:'<?php echo base_url() ?>Location/ajax_getpincode',
                data: {area_id:area_id},
                success:function(html){
                    var obj = $.parseJSON(html);
                    $('#pincode').val(obj['first']);
                }
            }); 
});
});
</script>
<script>

 $(document).ready(function() {
    active("location_side_menu"); 
 });

</script>
