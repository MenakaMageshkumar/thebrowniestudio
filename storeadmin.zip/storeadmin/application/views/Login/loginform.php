<?php
$get_theme = "441075";
$get_font = "fff100";
// yellow #fff100 purple #441075
$store_id = $this->uri->segment(2);
if($store_id!=''){
 $chk_exclusive = $this->db->query("select theme_color,font_color from stores where store_id = '$store_id' and exclusive_app_enabled=1 ")->result();
 if($chk_exclusive){
     $theme = $chk_exclusive[0]->theme_color; // #441075
     $font = $chk_exclusive[0]->font_color;
     $get_theme  = str_replace("#","","$theme"); //441075
     $get_font  = str_replace("#","","$font");
 }
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login | Log in</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!--<meta property="og:image" content="https://yellowmart.biz/assets/300x200.png">-->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>
   
    
   .login-page {
    background-image: url(../images/about_bg.png);
    background-color: #eee;
    background-repeat: no-repeat;
    background-position: top left;
    background-attachment: fixed;
    padding: 40px 0px;
}

    </style>
    <style>
<?php
if($chk_exclusive){?>
.btn-purple{
    background: <?php echo $theme  ?> !important;
    color: <?php echo $font ?>!important;
}
<?php }?>
</style>
  </head>
  <body class="hold-transition login-page">
     
    <div class="login-box">
         <div class="login_logo"><img src="<?= (isset($store_data) && isset($store_data[0]->store_logo))?base_url('../'.$store_data[0]->store_logo):'' ?>" onerror="this.src='<?=base_url("../images/logo-purple.jpg")?>'" width="250" height="50" alt="img" class="center"></div>
         <!--<div class="login_logo"><img src="<?php echo base_url('../images/logo-purple.jpg')?>" alt="img" class="center"></div>-->
       <div class="login-box-body shadow ">
        <p class="login-box-msg">Store Admin</p>
        <?php if(validation_errors()) { ?>
          <div class="alert alert-danger">
            <?= validation_errors() ?>
          </div>
        <?php } ?>
        <form action="" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control login_text" name="username" placeholder="Phone">
            <span class="glyphicon glyphicon-earphone form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control login_text" name="password" placeholder="Password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-12 right">
              <button type="submit"  class="btn btn-block btn-flat btn-purple">Sign In</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>


