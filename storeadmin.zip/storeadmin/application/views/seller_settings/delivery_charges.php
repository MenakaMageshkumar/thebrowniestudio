<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Master Settings | Delivery </title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
  <div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?><small><?= $pDescription ?></small></h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
        $url = (!isset($seller_id) || empty($seller_id))?'':'SellerSettings/update_delivery/'.encode_param($seller_id);
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>  
      </div>
      <?php if(isset($settings_dc)){
          $settings_dc = $settings_dc[0];
      }
      ?>
      <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-body">
            <form role="form" action="<?= base_url($url) ?>" method="post" 
              class="validate" data-parsley-validate="" enctype="multipart/form-data">
              <div class="row">
                <div class="col-sm-6 mb-3">
                
                            <label>DELIVERY CHARGE</label>                          
                            <select name="delivery_charges" class="form-control" required="" >
                                <option value="1" <?php if($settings_dc->delivery_charges == "1"){?>selected<?php }?>>Enable</option>
                                <option value="0" <?php if($settings_dc->delivery_charges == "0"){?>selected<?php }?>>Disable</option>
                            </select>
              
                </div>
                <div class="col-sm-6 mb-3 enable">
                  <label>MINIMUM DELIVERY CHARGE</label>
                  <input type="number" class="form-control required" data-parsley-trigger="change" step="0.01"
                  data-parsley-minlength="1"
                  name="min_dc" required="" placeholder="Enter Minimum Delivery charge" value="<?= (isset($settings_dc->min_dc))?$settings_dc->min_dc:'' ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="col-sm-12 mb-3 enable">
                  <label>NOTE</label>
                  <textarea class="form-control required" name="delivery_note" rows="4" cols="80" placeholder="Type Delivery Note">
                      <?= (isset($settings_dc->delivery_note))?$settings_dc->delivery_note:'' ?>
                  </textarea>
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="col-sm-6 mb-3 enable">
                  <label>KILOMETER COVERAGE FOR MIN. DELIVERY CHARGE (KMs UPTO)</label>
                  <input type="number" class="form-control required" data-parsley-trigger="change"
                  data-parsley-minlength="1"
                  name="dc_freekm" required="" placeholder="Enter Percentage" value="<?= (isset($settings_dc->dc_freekm))?$settings_dc->dc_freekm:'' ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="col-sm-6 mb-3 enable">
                  <label>PER KMs CHARGE (> KMs COVERAGE)</label>
                  <input type="number" class="form-control required" data-parsley-trigger="change" step="0.01"
                  name="dc_perkm" required="" placeholder="Enter Unit" value="<?= (isset($settings_dc->dc_perkm))?$settings_dc->dc_perkm:'' ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                <div class="form-group">

              <div class="col-md-12">      
                <div class="box-footer">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>        
              </div>        
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<script>
$(document).ready(function(){
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue==1){
                $(".enable").show();
            } else{
                $(".enable").hide();
            }
        });
    }).change();
});
</script>
  <script>

 $(document).ready(function() {
    active("master_side_menu"); 
 });

</script>