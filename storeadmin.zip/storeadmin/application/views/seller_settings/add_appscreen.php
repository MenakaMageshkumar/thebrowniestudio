<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Product | Edit Product</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .pl_0
    {
        padding-left: 0px;
    }
     @media (max-width:575px)
    {
         .pad_left_mobile
        {
            padding-left:0px;
        }
         .pt_custom
        {
            padding-top:25px!important;
        }
    }
    .pt_custom
    {
        padding-top:52px;
    }
    </style>
  </head>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?= $pTitle ?><small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
        $data = $addappscreen[0];
          $redirectUrl = (isset($seller_id) && !empty($seller_id))
                            ?'SellerSettings/updateAppscreen/'.encode_param($seller_id)
                            :'';
        
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>
      </div>

        <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <h3 class="box-title">App Screen for Website (Upload atleast 3 images)</h3>
          </div>
            
        <form role="form" action="<?= base_url($redirectUrl) ?>" method="post"  enctype="multipart/form-data">
    <?php
    
     $app = $data->add_appscreen;
     if($app){
         $screens = explode('|',$app);
     }
    ?>
                    <div class="box-body">
                      
                    <div class="form-group col-lg-12">
                    <label>App Screen1</label>
                    <div class="col-md-12 pl_0">
                      <div class="col-md-3 pl_0">
                        <img  src="<?= (isset($data) && isset($screens[0]))?base_url('../'.$screens[0]):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0 pt_custom" >
                        <input name="image1" type="file" accept="image/*" class="<?= (isset($seller_id) && !empty($seller_id))?'':'' ?>" <?= (isset($screens[0]) && !empty($screens[0]))?'':'required'  ?>/>
                      </div>
                     </div> 
                    </div>
                    <div class="form-group col-lg-12">
                    <label>App Screen2</label>
                    <div class="col-md-12 pl_0">
                      <div class="col-md-3 pl_0">
                        <img  src="<?= (isset($data) && isset($screens[1]))?base_url('../'.$screens[1]):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0 pt_custom" >
                        <input name="image2" type="file" accept="image/*" class="<?= (isset($seller_id) && !empty($seller_id))?'':'' ?>" <?= (isset($screens[1]) && !empty($screens[1]))?'':'required'  ?>/>
                      </div>
                     </div> 
                    </div>
                    
                    <div class="form-group col-lg-12">
                    <label>App Screen3</label>
                    <div class="col-md-12 pl_0">
                      <div class="col-md-3 pl_0">
                        <img  src="<?= (isset($data) && isset($screens[2]))?base_url('../'.$screens[2]):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0 pt_custom" >
                        <input name="image3" type="file" accept="image/*" class="<?= (isset($seller_id) && !empty($seller_id))?'':'' ?>" <?=  (isset($screens[2]) && !empty($screens[2]))?'':'required'  ?>/>
                      </div>
                     </div> 
                    </div>
                    
                    <div class="form-group col-lg-12">
                    <label>App Screen4</label>
                    <div class="col-md-12 pl_0">
                      <div class="col-md-3 pl_0">
                        <img  src="<?= (isset($data) && isset($screens[3]))?base_url('../'.$screens[3]):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0 pt_custom" >
                        <input name="image4" type="file" accept="image/*" class="<?= (isset($seller_id) && !empty($seller_id))?'':'' ?>" />
                      </div>
                     </div> 
                    </div>
                    
                    <div class="form-group col-lg-12">
                    <label>App Screen5</label>
                    <div class="col-md-12 pl_0">
                      <div class="col-md-3 pl_0">
                        <img  src="<?= (isset($data) && isset($screens[4]))?base_url('../'.$screens[4]):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0 pt_custom" >
                        <input name="image5" type="file" accept="image/*" class="<?= (isset($seller_id) && !empty($seller_id))?'':'' ?>" />
                      </div>
                     </div> 
                    </div>
                    
                    <div class="form-group col-lg-12">
                    <label>App Screen6</label>
                    <div class="col-md-12 pl_0">
                      <div class="col-md-3 pl_0">
                        <img  src="<?= (isset($data) && isset($screens[5]))?base_url('../'.$screens[5]):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0 pt_custom" >
                        <input name="image6" type="file" accept="image/*" class="<?= (isset($seller_id) && !empty($seller_id))?'':'' ?>" />
                      </div>
                     </div> 
                    </div>
                    <div class="col-md-12"> &emsp;
                    </div>
                    <div class="form-group col-lg-12">
                            <label>DESCRIPTION</label>                            
                            <textarea  type="text" class="ip_reg_form_input form-control reset-form-custom" placeholder="App Description" name="add_appdescription" 
            style="height:108px;"  data-parsley-trigger="change" data-parsley-minlength="2"><?php echo $data->add_appdescription; ?></textarea>
                        </div>
                         <div class="col-md-12">      
                <div class="box-footer textCenterAlign">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>        
              </div>
                    
                 </div>   
                    
       </form>
       </div></div>
       
       </div>
         </section></div>
         
   <script>

 $(document).ready(function() {
    active("master_side_menu"); 
 });

</script>