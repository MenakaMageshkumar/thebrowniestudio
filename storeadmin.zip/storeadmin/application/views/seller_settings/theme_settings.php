<?php
$store_data = $store_data[0];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Settings | Theme</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
     <link rel="stylesheet" href="<?= base_url('css/theme-setting.css') ?>" type="text/css">
</head>

<body>
    <div class="content-wrapper col-12 d-flex pt-3">
        <div class="row col-12">
             <div class="col-lg-4 mx-auto" >
            <div class="form-group" style="padding-top:15px">
                <h1><?= $pTitle ?></h1>
            </div>
            <form role="form" action="<?= base_url('SellerSettings/update_theme/'.encode_param($store_id)) ?>" method="post" class="validate" data-parsley-validate="" enctype="multipart/form-data">
            <div class="" >
                <div class="form-group">
                    <label for="">APP THEME</label>
                    <input class="form-control w-75" type="color" name="theme_color" value="<?= (isset($store_data->theme_color))?$store_data->theme_color:'#441075' ?>" id="colorWell">
                </div>
                <div class="form-group">
                    <label for="">FONT THEME
                    </label>
                    <input class="form-control w-75" type="color" name="font_color" value="<?= (isset($store_data->font_color))?$store_data->font_color:'#ffffff' ?>" id="fontColorWell">
                </div>
                <div class="form-group">
                     <!--<button class="btn btn-success" type="button" onclick="editData()">Submit</button>-->
                     <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </div>
            </form>

        </div>
        <div class="col-lg-8 mx-auto">
        <div class="smartphone">
            <div class="content">
                <div class="header pl-3 pt-2" style="height:40px">
                    <i class="fa fa-search pr-3 pt-2 fa-style-icon" style="margin-right:40px;"></i>
                    <?php echo $store_data->store_name ?>
                    <i class="fa fa-shopping-cart float-right pr-3 pt-2 fa-style-icon"></i>
                </div>
                <div class="imag-div">
                    <img width="281" height="100" src="<?php echo base_url('../'.$store_data->store_banner1)?>">
                    <div class="text-block mx-auto pt-1">
                        <div class="row">
                            <div class="col-6">
                                <i class="fa fa-home float-left mr-3"></i>
                                <p style="float: left;font-size: 9px !important;">Your Store Name</p>
                            </div>
                            <div class="col-6">
                                <p style="float: right;font-size: 9px !important;">Restaurants</p> <i
                                    class="fa fa-building float-right mr-3"></i>
                            </div>
                            <div class="col-6">
                                <i class="fa fa-clock-o float-left mr-3"></i>
                                <p style="float: left;font-size: 9px !important;">10:00 AM-11:00 PM</p>
                            </div>
                            <div class="col-6" style="padding-right: 35px;">
                                <p style="float: right;font-size: 9px !important;">Pollachi</p> <i
                                    class="fa fa-map-marker float-right mr-3"></i>
                            </div>
                            <label class="w-100 ml-3" style="font-size: 10px !important;">We support both store pick up
                                and home
                                delivery</label>
                            <div class="col-12">
                                <i class="fa fa-share-alt float-right" style="font-size:25px;font-weight:lighter;"></i>

                            </div>
                        </div>


                        <!-- <p style="float: right;">content2</p> -->
                        <!-- <span><p>dsfds</p></span> -->
                    </div>
                </div>
                <div class="" style="position: absolute;
        top: 240px;
        width: 326px;">
                    <ul style="padding-inline-start: 0px;list-style: none;width: 86%;">
                        <li class="header li-class">Categories 1<label class="float-right header li-plus-class">+</label>
                        </li>
                        <li class="header li-class">Categories 2<label class="float-right header li-plus-class">+</label>
                        </li>
                        <li class="header li-class">Categories 3<label class="float-right header li-plus-class">+</label>
                        </li>
                        <li class="header li-class">Categories 4<label class="float-right header li-plus-class">+</label>
                        </li>
                        <li class="header li-class">Categories 5<label class="float-right header li-plus-class">+</label>
                        </li>
                        <li class="header li-class">Categories 6<label class="float-right header li-plus-class">+</label>
                        </li>
                    </ul>
                </div>
                <div class="row col-12 ml-0 header"
                    style="

    top: 298px;
    padding: 8px 0px;
    justify-content: space-between;
    background-color: rgb(27, 30, 121);
    color: rgb(142, 113, 113);">
                    <img class="mx-auto" height="20" width="20" src="<?php echo base_url('assets/theme-image/home.png')?>"/>
                    <img class="mx-auto" height="20" width="20" src="<?php echo base_url('assets/theme-image/whatsapp.png')?>"/>
                    <img class="mx-auto" height="20" width="20" src="<?php echo base_url('assets/theme-image/y.png')?>"/>
                    <img class="mx-auto" height="20" width="20" src="<?php echo base_url('assets/theme-image/discount.png')?>"/>
                    <img class="mx-auto" height="20" width="20" src="<?php echo base_url('assets/theme-image/user.png')?>"/>
                    <!-- <i class="fa fa-home fa-style-icon" style="font-size: 20px;"></i>
                    <i class="fa fa-whatsapp fa-style-icon" style="font-size: 20px;"></i>
                    <i class="fa fa-home fa-style-icon" style="font-size: 20px;"></i>
                    <span class="fa-stack fa-sm" style="font-size: 11px;">
                        <i class="fa fa-certificate fa-stack-2x fa-style-icon"></i>
                        <i class="fa fa-percent fa-stack-1x fa-style-icon"></i>
                    </span>
                    <i class="fa fa-user-o fa-style-icon" style="font-size: 18px;"></i> -->
                </div>
                <!-- <div class="col-3">
                   
                </div> -->
            </div>
        </div>
        </div>
        </div>
       
    </div>

</body>
<script>
    var colorWell;
    var fontColorWell;
    var defaultColor = "<?= (isset($store_data->theme_color))?$store_data->theme_color:'#441075' ?>";
    var defaultFontColor = "<?= (isset($store_data->font_color))?$store_data->font_color:'#ffffff' ?>"
    window.addEventListener("load", startup, false);

    function startup() {
        intialLoad(defaultColor,defaultFontColor)
        colorWell = document.querySelector("#colorWell");
        colorWell.value = defaultColor;
        colorWell.addEventListener("input", updateFirst, false);
        colorWell.addEventListener("input", updateAll, false);
        colorWell.select();
        console.log(colorWell.value)

        fontColorWell = document.querySelector("#fontColorWell");
        fontColorWell.value = defaultFontColor;
        fontColorWell.addEventListener("input", updateFontFirst, false);
        fontColorWell.addEventListener("input", updateFontAll, false);
        fontColorWell.select();
        console.log(fontColorWell.value)
    }

    function updateFirst(event) {
        //p.style.color = event.target.value;
        console.log(event.target.value)
        elements = document.getElementsByClassName("header");
        for (var i = 0; i < elements.length; i++) {
            elements[i].style.backgroundColor = event.target.value;
        }
    }

    function updateAll(event) {
        elements = document.getElementsByClassName("header");
        for (var i = 0; i < elements.length; i++) {
            elements[i].style.backgroundColor = event.target.value;
        }
    }

    function updateFontFirst(event) {
        //p.style.color = event.target.value;
        console.log(event.target.value)
        fontElement = document.getElementsByClassName("header");
        for (var i = 0; i < fontElement.length; i++) {
            fontElement[i].style.color = event.target.value;
        }
    }

    function updateFontAll(event) {
        fontElement = document.getElementsByClassName("header");
        for (var i = 0; i < fontElement.length; i++) {
            fontElement[i].style.color = event.target.value;
        }
    }
    function editData() {
        var colorWell = document.querySelector("#colorWell");
        var fontColorWell = document.querySelector("#fontColorWell");
        // console.log(colorWell.value, fontColorWell.value)
    }
    function intialLoad(defaultColor,defaultFontColor) {
       const elements = document.getElementsByClassName("header");
        for (var i = 0; i < elements.length; i++) {
            elements[i].style.backgroundColor = defaultColor;
        }
       const fontElement = document.getElementsByClassName("header");
        for (var i = 0; i < fontElement.length; i++) {
            fontElement[i].style.color = defaultFontColor;
        }
    }
</script>
  <script>

 $(document).ready(function() {
    active("master_side_menu"); 
 });

</script>

</html>