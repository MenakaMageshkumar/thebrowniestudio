<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Store Settings </title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
  <div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?><small><?= $pDescription ?></small></h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
        $url = (!isset($store_id) || empty($store_id))?'':'SellerSettings/update_storesettings/'.encode_param($store_id);
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>  
      </div>
      <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-body">
            <form role="form" action="<?= base_url($url) ?>" method="post" 
              class="validate" data-parsley-validate="" enctype="multipart/form-data">
              <div class="row">
                <div class="col-sm-6 mb-3">
                  <div class="form-group">
                            <label>DELIVERY VALUE</label>                          
                            <input type="number" class="form-control " data-parsley-trigger="change"
                  name="del_value" placeholder="Enter Value" value="<?= (isset($data['del_value']))?$data['del_value']:'' ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                </div>
                <div class="col-sm-6 mb-3">
                  <div class="form-group">
                            <label>DELIVERY TIMING TYPE</label>                          
                            <select name="del_type" class="form-control" >
                                <?php $del_type = trim($data['del_type']); ?>
                                <option value="1" <?php if($del_type == "1"){?>selected<?php }?>>Minutes</option>
                                <option value="2" <?php if($del_type == "2"){?>selected<?php }?>>Hours</option>
                                <option value="3" <?php if($del_type == "3"){?>selected<?php }?>>Days</option>
                            </select>
                </div>
                </div>
                 <div class="col-sm-6 mb-3">
                  <div class="form-group">
                            <label>PREPARATION VALUE</label>                          
                            <input type="number" class="form-control " data-parsley-trigger="change"
                  name="prep_value" placeholder="Enter Value" value="<?= (isset($data['prep_value']))?$data['prep_value']:'' ?>">
                  <span class="glyphicon form-control-feedback"></span>
                </div>
                </div>
                <div class="col-sm-6 mb-3">
                  <div class="form-group">
                            <label>PREPARATION TIMING TYPE</label>                          
                            <select name="prep_type" class="form-control" >
                                <?php $prep_type = trim($data['prep_type']); ?>
                                <option value="1" <?php if($prep_type == "1"){?>selected<?php }?>>Minutes</option>
                                <option value="2" <?php if($prep_type == "2"){?>selected<?php }?>>Hours</option>
                                <option value="3" <?php if($prep_type == "3"){?>selected<?php }?>>Days</option>
                            </select>
                </div>
                </div>
                <div class="form-group">

              <div class="col-md-12">      
                <div class="box-footer">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>        
              </div>        
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<script>
$(document).ready(function(){
    // var onrfsh_chkpc = document.getElementById("packing_charges").value;
    var onrfsh_chkpc = $("#packing_charges").val();
    if(onrfsh_chkpc==1){
                $(".enable").show();
            } else{
              $(".enable").hide();
            }
    $('#packing_charges').on('change', function() {
            var optionValue = this.value;
            if(optionValue==1){
                $(".enable").show();
            } else{
                $(".enable").hide();
            }
        });
});
</script>
<script>
$(document).ready(function(){       
    // var onrfsh_chk = document.getElementById("pc_type").value;
     var onrfsh_chk = $("#pc_type").val();
    if(onrfsh_chk==1){
                $(".perc").hide();
                $(".value").show();
            } else{
                $(".perc").show();
                $(".value").hide();
            }
 $('#pc_type').on('change', function() {
            var typeValue = this.value;
            if(typeValue==1){
                $(".perc").hide();
                $(".value").show();
            } else{
                $(".perc").show();
                $(".value").hide();
            }
        });        
});
</script>
  <script>

 $(document).ready(function() {
    active("master_side_menu"); 
 });

</script>