<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Comments</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>

     .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
    }
    .p_3_font_13
    {
        padding-left: 3px!important;
        padding-right:3px!important;
        padding-top:10px!important;
        padding-bottom:10px!important;
        font-size: 12.5px!important;
    }
    .font_weight_400
    {
        font-weight: 400;
    }
    </style>
  </head>
   <style>
  .datatable tbody th { font-weight: inherit; }
  </style>
<div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?>&nbsp &nbsp<small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-sm-12">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
           <button class="close" data-dismiss="alert" type="button">×</button>
           <?= $flashdata['message'] ?>
         </div>
       <?php } ?>
      </div>
        <div class="col-xs-12">
          <div class="box box-warning"> 
            <div class="box-header with-border">
              <div class="col-md-6"><h3 class="box-title">User Comments</h3></div>
              <div class="col-md-6" align="right">
                <!--<a class="btn btn-sm btn-primary" href="<?= base_url('Order/ViewOrders') ?>">Back</a>-->
              </div>
            </div> 
            <br>   
            <div class="box-body table-responsive">
              <table  class="table table-bordered table-striped datatable_comment ">
                <thead>
                  <tr>
                    <th width="2%" class="text-center p_3_font_13">S.NO</th>
                    <th width="10%;"  class="text-center p_3_font_13">CUSTOMER NAME</th>
                    <th width="20%;"  class="text-center p_3_font_13">PRODUCT NAME</th>
                    <!--<th width="15%;">DISPLAY NAME</th>-->
                    <th width="5%;"  class="text-center p_3_font_13">STAR</th>
                    <th width="15%;"  class="text-center p_3_font_13">REVIEW TYPE</th>
                    <th width="30%;"  class="text-center p_3_font_13">COMMENT</th>
                    <th width="15%;"  class="text-center p_3_font_13">REVIEW DATE</th>
                    <th width="7%;"  class="text-center p_3_font_13">ACTION</th>
                 </tr>
                </thead> 
                <tbody>
                  <?php if(!empty($comments)){
                       $i =1;
                    foreach($comments as $cmt) { ?>
                      <tr>
                            <th class="center text-center p_3_font_13 font_weight_400"><?= $i++ ?></th>
                        <th class="center text-center p_3_font_13 font_weight_400"><?= $cmt->username ?></th>
                        <th class="center  p_3_font_13 font_weight_400"><?= $cmt->product_name ?></th>
                        <th class="center text-center p_3_font_13 font_weight_400"><?= $cmt->star_count ?></th>
                        <th class="center text-center p_3_font_13 font_weight_400"><?= $cmt->review_type ?></th>
                        <th class="center  p_3_font_13 font_weight_400"><?= $cmt->comment ?></th>
                        <th class="center text-center p_3_font_13 font_weight_400"><?php
                        $dt_frmt=date_create($cmt->date_reviewed );
                        echo  date_format($dt_frmt,"d/m/Y");
                          ?><br>
                          <?php
                        $dt_frmt_1=date_create($cmt->date_reviewed );
                        echo  date_format($dt_frmt_1," h:i A");
                          ?>
                          </th>
                          <th class="center text-center p_3_font_13 font_weight_400">
                        <?php if($cmt->view_status==0){ ?>
                        <a class="btn btn-sm btn-success" href="<?= base_url('SellerSettings/changecomment_status/'.encode_param($cmt->cmt_id))."/1" ?>">Enable
                        </a>
                        <?php } else { ?>
                        <a class="btn btn-sm btn-danger" href="<?= base_url('SellerSettings/changecomment_status/'.encode_param($cmt->cmt_id))."/0" ?>">Disable
                        </a>
                        <?php } ?>
                        </th>
                      </tr>
                  <?php } }?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </section>
</div>
 <script>
    function submitPaymentStatus(str){
      var payment_status = str.value;
        var order_id = str.id;
        if(payment_status){
    if(confirm('Do you want to submit?')){
           
            $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>order/submitPaymentStatus",
           data: {payment_status:payment_status,order_id:order_id}, 
           success: function(data){
            //   alert(data);
               if(data==200){
                   alert ("Payment Status updated");
                location.reload();
               } else if(data==404){
                   alert ("Please update the order status");
                location.reload();
               } else{
                  alert ("something went wrong contact admin!!");
                location.reload();    
               }
           }
           
         });
    
    }else{
        location.reload();
    }
        }
  else{
      alert('please change status');
  }
    }
</script>
<script>
    jQuery(function () {
                    jQuery('.datatable_comment').DataTable({
                       
                    });
                });
</script>
  <script>

 $(document).ready(function() {
    active("master_side_menu"); 
 });

</script>