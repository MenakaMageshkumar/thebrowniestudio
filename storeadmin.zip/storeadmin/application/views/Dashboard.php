<?php
        foreach($summary_date as $dt){
            $dataPoints[] = array("label"=>  $dt['date_range'], "y"=>$dt['range_price']);
        }
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>
        .p_10_cus
        {
            padding: 1px 12px;
        }
        .my_auto
        {
            margin-top:auto!important;
            margin-bottom:auto!important;
        }
        .bg_white_cus
        {
            background-color:#ffffff;
        }
        .font_600
        {
                font-weight: 600;
        }
        .pr-0
        {
            padding-right:0px!important;
        }
        .pl-0
        {
            padding-left:0px!important;
        }
        .font_16
        {
                font-size: 15px;
        }
         .font_14
        {
                font-size: 14px;
        }
        .border_rad_3
        {
                border-radius: 3px;
        }
        .px-1
        {
            padding-left: 6px;
    padding-right: 6px;
        }
        .px-10
        {
                padding-left: 10px;
                padding-right: 10px;
        }
        .py_cust_card_head
        {
                padding-top: 16px;
                 font-size: 16px; 
                padding-bottom: 16px;
        }
         .p_7_cus
        {
            padding: 1px 7px;
        }
        .table_text_title
        {
                text-decoration: underline;
    color: #535353;
    font-size: 13px;
    border-color: #535353;
        }
        .py_15
        {
            padding-top:15px;
            padding-bottom:15px;
        }
        .font_13
        {
            font-size:13px;
        }
        .pl-9
        {
                padding-left: 9px;
        }
        .table>thead>tr>th {
            border-bottom: 1px solid #cccccca8!important;
        }
        .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
            border-top: 1px solid #cccccca8!important;
        }
        .table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
            padding-top: 13px!important;
              padding-bottom: 13px!important;
            line-height: 1.42857143;
            vertical-align: top;
            border-top: 1px solid #ddd;
        }
        .h_30
        {
            height: 30px;
        }
        .h_200_overflow
        {
            height: 206px;
            overflow-y: auto;
        }
        .h_300_overflow
        {
             height: 331px;
            overflow-y: auto;
        }
        .mx-auto
        {
            margin-left:auto;
            margin-right:auto;
        }
        .text-red {
            color: red!important;
        }
        .text-success {
            color: green!important;
        }
        .mb_5
        {
            margin-bottom:10px;
        }
/*        table.dataTable thead .sorting:after {*/
/*    opacity: -0.8;*/
/*    content: "\e150";*/
    
/*}*/
.px-6-cus
{
    padding-left: 6px!important;
    padding-right: 6px!important;
}
table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
#tbl_sumcal .table>thead>tr>th, #tbl_sumcal .table>tbody>tr>th, #tbl_sumcal .table>tfoot>tr>th, #tbl_sumcal .table>thead>tr>td, #tbl_sumcal .table>tbody>tr>td, #tbl_sumcal .table>tfoot>tr>td {
    border-top: 1px solid #d9d5d5!important;
}
#tbl_sumcal .table>thead>tr>th {
    border-bottom: 1px solid #d9d5d5!important;
    text-transform: uppercase;
}
#tbl_sumcal .table-bordered>thead>tr>th, #tbl_sumcal .table-bordered>tbody>tr>th, #tbl_sumcal .table-bordered>tfoot>tr>th, #tbl_sumcal .table-bordered>thead>tr>td, #tbl_sumcal .table-bordered>tbody>tr>td, #tbl_sumcal .table-bordered>tfoot>tr>td {
    border: 1px solid #d9d5d5!important;
}
.ord_lis_pad
        {
            padding: 0px;
        }
@media (max-width:575px)
{
    /*.date_1*/
    /*{*/
    /*    text-align:center;*/
    /*    padding-top: 5px!important;*/
    /*    padding-bottom: 5px!important;*/
    /*}*/
    /*.cust_date*/
    /*{*/
    /*    text-align:center;*/
    /*    padding-top: 5px!important;*/
    /*    padding-bottom: 5px!important;*/
    /*}*/
    [type="date"] {
  background:#fff url(https://cdn1.iconfinder.com/data/icons/cc_mono_icon_set/blacks/16x16/calendar_2.png)  97% 50% no-repeat ;
  padding-bottom:0px!important;
   padding-top:0px!important;
}
[type="date"]::-webkit-inner-spin-button {
  display: none;
}
[type="date"]::-webkit-calendar-picker-indicator {
  opacity: 0;
}

[type="date"] {
  border: 1px solid #c4c4c4;
  border-radius: 5px;
  background-color: #fff;
  /*padding: 3px 5px;*/
}
 .pl-0
        {
            padding-left:10px!important;
            margin-bottom: 10px;
        }
        .ord_lis_pad
        {
            padding: 0px 6px 0px 8px;
        }
}




    </style>
  </head>
<div class="content-wrapper">
  
    <section class="content-header">
    <h1> <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="javascript:void(0);" ><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
    </section>
     
    <section class="content">
        <!--first row-->
        <div class="row">
             <div class=" col-lg-3">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_16">Today No of Orders</h4>
                              <h3 class="marginTop5"><?php echo $tdy_order; ?></h3>
                              <p class="small">
                                  <?php $perc_tdy_order =  str_replace("-","",$tdy_order_perc);
                                  if(strpos($tdy_order_perc, '-') !== false ) { ?>
                                        <span class="text-success "> <i class="fa fa-caret-up margin-r-5 "> </i> <?php echo $perc_tdy_order;?>% Up than</span> yesterday
                                    <?php } else { ?>
                                    <span class="text-red "><i class="fa fa-caret-down margin-r-5 "> </i><?php echo $perc_tdy_order;?>% Down </span>than yesterday
                                  <?php } ?>
                                </p>
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
             <div class=" col-lg-3">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_16">Today Orders Value</h4>
                              <h3 class="marginTop5">&#8377;<?php echo $tdy_ordervalue; ?></h3>
                              <p class="small">
                                  <?php  $perc_tdy_ordervalue =  str_replace("-","",$tdy_ordervalue_perc); 
                                  if(strpos($tdy_ordervalue_perc, '-') !== false ) { ?>
                                        <span class="text-success "> <i class="fa fa-caret-up margin-r-5 "> </i> <?php echo $perc_tdy_ordervalue;?>% Up than</span> yesterday
                                    <?php } else { ?>
                                    <span class="text-red "><i class="fa fa-caret-down margin-r-5 "> </i><?php echo $perc_tdy_ordervalue;?>% Down </span>than yesterday
                                  <?php } ?>
                              </p>
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0">
                           <img src="<?= base_url('assets/images/money_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
             <div class="col-lg-3">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_16">This Month Orders</h4>
                              <h3 class="marginTop5"><?php echo $month_order;?></h3>
                              <p class="small">
                                  <?php $perc_month_order =  str_replace("-","",$month_order_perc); 
                                  if(strpos($month_order_perc, '-') !== false ) { ?>
                                        <span class="text-success "> <i class="fa fa-caret-up margin-r-5 "> </i> <?php echo $perc_month_order;?>% Up than</span> last month
                                    <?php } else { ?>
                                    <span class="text-red "><i class="fa fa-caret-down margin-r-5 "> </i><?php echo $perc_month_order;?>% Down </span>last month
                                  <?php } ?>
                                  </p>
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
             <div class="col-lg-3">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_16">This Month Orders Value</h4>
                              <h3 class="marginTop5">&#8377;<?php echo $month_ordervalue;?></h3>
                              <p class="small"><?php $perc_month_ordervalue =  str_replace("-","",$month_ordervalue_perc); 
                                  if(strpos($month_ordervalue_perc, '-') !== false ) { ?>
                                        <span class="text-success "> <i class="fa fa-caret-up margin-r-5 "> </i> <?php echo $perc_month_ordervalue;?>% Up than</span> last month
                                    <?php } else { ?>
                                    <span class="text-red "><i class="fa fa-caret-down margin-r-5 "> </i><?php echo $perc_month_ordervalue;?>% Down </span>last month
                                  <?php } ?>
                             </p>
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0">
                           <img src="<?= base_url('assets/images/money_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
        </div>
        <!--second row-->
          <div class="row marginTop10 px-10">
            <div class="col-lg-2 px-1">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_14 marginBottom-5 marginTop-8 h_30">Today Orders</h4>
                             <p class="small">&#8377;<?php echo $today_ordervalue; ?></p>
                              <h3 class="marginTop5 marginBottom-5"><?php echo $today_order; ?></h3>
                              
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0 ">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
            <div class="col-lg-2 px-1">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_14 marginBottom-5 marginTop-8 h_30">Tomorrow Orders</h4>
                             <p class="small">&#8377; <?php echo $tmw_ordervalue; ?></p>
                              <h3 class="marginTop5 marginBottom-5"><?php echo $tmw_order;?></h3>
                              
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0 ">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
            <div class="col-lg-2 px-1">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <h4 class="font_600 font_14 marginBottom-5 marginTop-8 h_30">Dayafter Orders</h4>
                             <p class="small">&#8377;<?php echo $dayaf_ordervalue;?></p>
                              <h3 class="marginTop5 marginBottom-5"><?php echo $dayaf_order;?></h3>
                              
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0 ">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
            <div class="col-lg-2 px-1">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <!--<h4 class="font_600 font_14 marginBottom-5 marginTop-8">Next 7<small>days</small>Orders</h4>-->
                             <h4 class="font_600 font_14 marginBottom-5 marginTop-8 h_30">Courier Orders for Today</h4>
                             <p class="small">&#8377; <?php echo $cour_tdy_ordervalue;?></p>
                              <h3 class="marginTop5 marginBottom-5"><?php echo $cour_tdy_order;?></h3>
                              
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0 ">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
            <div class="col-lg-2 px-1">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <!--<h4 class="font_600 font_14 marginBottom-5 marginTop-8">Next 15<small>days</small></h4>-->
                             <h4 class="font_600 font_14 marginBottom-5 marginTop-8 h_30">Courier Orders for Next 3&nbsp;<small>days</small></h4>
                             <p class="small">&#8377; <?php echo $cour_3dy_ordervalue;?></p>
                              <h3 class="marginTop5 marginBottom-5"><?php echo $cour_3dy_order;?></h3>
                              
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0 ">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
             <div class="col-lg-2 px-1">
                <div class="card bg_white_cus p_10_cus border_rad_3">
                    <div class="row">
                        <div class="col-xs-8 col-lg-9 pad pr-0">
                             <!--<h4 class="font_600 font_14 marginBottom-5 marginTop-8">Next 30<small>days</small></h4>-->
                             <h4 class="font_600 font_14 marginBottom-5 marginTop-8 h_30">Courier Orders for Next 7&nbsp;<small>days</small></h4>
                             <p class="small">&#8377;<?php echo $cour_7dy_ordervalue;?></p>
                              <h3 class="marginTop5 marginBottom-5"><?php echo $cour_7dy_order;?></h3>
                              
                        </div>
                        <div class="col-xs-4 col-lg-3 pad my_auto pl-0 ">
                           <img src="<?= base_url('assets/images/cart_1.png') ?>" class="img-responsive ">
                        </div>
                    </div>
                   
                   
                </div>
            </div>
            
        </div>
        <!--third row-->
         <div class="row marginTop10 ">
             <div class="col-lg-4">
                  <div class="card bg_white_cus p_7_cus border_rad_3">
                      <div class="card-header py_cust_card_head pl-9 text-uppercase font_600" >
                      <!--Today <strong>BROWNIES & DESSERTS</strong> Delivery-->
                      Order List for Today
                      </div>
                      <div class="card-body h_200_overflow">
                       <table class="table">
                          <thead>
                            <tr>
                              <th scope="col" class="font_13 py_15" style="width: 55%;">Item Name</th>
                              <th scope="col" class="font_13 py_15 pl-0 pr-0">Weight</th>
                              <th scope="col" class="font_13 py_15">Qty</th>
                            </tr>
                          </thead>
                          <tbody>
                              <?php $i =1; foreach($today_ordlist as $tdyord) {  ?>
                            <tr>
                              <td class=""><a class="table_text_title py_15"><?php echo $i.'. '.$tdyord['item_name']; ?></a></td>
                              <td class="font_13 py_15 pl-0 pr-0 text-center"><?php echo $tdyord['weight']; ?></td>
                              <td class="font_13 py_15 text-center"><?php echo $tdyord['quantity']; ?></td>
                            </tr>
                            <?php $i++; } ?> 
                          </tbody>
                        </table>
                      </div>
                    </div>
             </div>
              <div class="col-lg-4">
                  <div class="card bg_white_cus p_7_cus border_rad_3">
                      <div class="card-header py_cust_card_head pl-9 text-uppercase font_600" >
                      <!--Today <strong>cakes</strong> Delivery-->
                     ORDER LIST FOR TOMORROW 
                      </div>
                      <div class="card-body h_200_overflow">
                       <table class="table">
                          <thead>
                            <tr>
                              <th scope="col" class="font_13 py_15" style="width: 55%;">Item Name</th>
                              <th scope="col" class="font_13 py_15 pl-0 pr-0">Weight</th>
                              <th scope="col" class="font_13 py_15">Qty</th>
                            </tr>
                          </thead>
                          <tbody>
                             <?php $j =1; foreach($tmw_ordlist as $tmword) {  ?>
                            <tr>
                              <td class=""><a class="table_text_title py_15"><?php echo $j.'. '.$tmword['item_name']; ?></a></td>
                              <td class="text-center font_13 py_15 pl-0 pr-0"><?php echo $tmword['weight']; ?></td>
                              <td class="text-center font_13 py_15"><?php echo $tmword['quantity']; ?></td>
                            </tr>
                            <?php $j++; } ?> 
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
             </div>
              <div class="col-lg-4">
                  <div class="card bg_white_cus p_7_cus border_rad_3">
                      <div class="card-header py_cust_card_head pl-9 text-uppercase" >
                      Today <strong>THEME cakes</strong> Delivery
                      </div>
                      <div class="card-body h_200_overflow">
                       <table class="table">
                          <thead>
                            <tr>
                              <th scope="col" class="font_13 py_15"  style="width: 55%;">Item Name</th>
                              <th scope="col" class="font_13 py_15 pl-0 pr-0">Weight</th>
                              <th scope="col" class="font_13 py_15">Qty</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                  <span class="text-danger text-center text-red">No records found</span>
                              </td> 
                              
                            </tr>
                          
                           
                          </tbody>
                        </table>
                      </div>
                    </div>
             </div>
         </div>   
         <!--fourth row-->
         <div class="row marginTop10 ">
             <div class="col-lg-6 row">
                 <div class="col-lg-6 px-1">
                <!------------Today delivery--------->
                       <?php 
                       $del_count = 0;$del_perc = 0;
                        for($k=1;$k<=3;$k++){
                       if($k==1){
                           $del_time = '(8am to 12noon)';
                           if(isset($today_delivery['delivery1_cnt']) && isset($today_delivery['delivery1_perc'])){
                               $del_count = $today_delivery['delivery1_cnt'];
                               $del_perc = $today_delivery['delivery1_perc'];
                           }
                       }
                       if($k==2){
                           $del_time ='(12pm to 6pm)';
                           if(isset($today_delivery['delivery2_cnt']) && isset($today_delivery['delivery2_perc'])){
                           $del_count = $today_delivery['delivery2_cnt'];
                           $del_perc = $today_delivery['delivery2_perc'];
                           }
                       }
                       if($k==3){
                           $del_time ='(6pm to 12am)';
                           if(isset($today_delivery['delivery3_cnt']) && isset($today_delivery['delivery3_perc'])){
                           $del_count = $today_delivery['delivery3_cnt'];
                           $del_perc = $today_delivery['delivery3_perc'];
                           }
                       }
                       
                       ?>
                       <div class=" col-lg-12 px-1 margin-all">
                        <div class="card bg_white_cus p_10_cus border_rad_3">
                            <div class="row">
                                <div class="col-xs-8 col-lg-9 pad pr-0">
                                       <h4 class="font_600 font_14 marginBottom-5 marginTop-8 ">Today Delivery</h4>
                                       <p class="small" style="color:#747272"><?php echo $del_time;?></p>
                                       <h3 class="marginTop5 marginBottom-5"><?php echo $del_count;?></h3>
                                </div>
                                <div class="col-xs-4 col-lg-3 pad my_auto pl-0">
                                   <img src="<?= base_url('assets/images/del_1.png') ?>" class="img-responsive ">
                                </div>
                                <div class="col-lg-12 row pr-0">
                                    <div class="col-lg-7 col-xs-12 pr-0">
                                         <p class="small">
                                             <?php $today_perc =  str_replace("-","",$del_perc); 
                                  if(strpos($del_perc, '-') !== false ) { ?>
                                        <span class="text-success "> <i class="fa fa-caret-up margin-r-5 "> </i> <?php echo $today_perc;?>% Higher</span> than yesterday
                                    <?php } else { ?>
                                    <span class="text-red "><i class="fa fa-caret-down margin-r-5 "> </i><?php echo $today_perc;?>% Lower </span>than yesterday
                                  <?php } ?>
                                                </p>
                                    </div>
                                    <div class="col-lg-4 pl-0">
                                        <?php if($del_count>0){ ?>
                                        <button class="btn btn-danger text-uppercase orderlist" data-toggle="modal" data-target="#orderlist" data-id="<?= date('Y-m-d').'|'.$k?>" >Order List</button>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                           
                           
                        </div>
                       </div>
                       <?php } ?>
                </div>
                 <!------------Today delivery End--------->
                <div class="col-lg-6 px-1">
                <!------------Tomorrow  delivery--------->
                        <?php 
                        $del_count = 0; $del_perc =0;
                        for($l=1;$l<=3;$l++){
                       if($l==1){
                           $del_time ='(8am to 12noon)';
                           if(isset($tmw_delivery['delivery1_cnt']) && isset($tmw_delivery['delivery1_perc'])){
                           $del_count =$tmw_delivery['delivery1_cnt'];
                           $del_perc = $tmw_delivery['delivery1_perc'];
                           }
                       }
                       if($l==2){
                           $del_time ='(12pm to 6pm)';
                           if(isset($tmw_delivery['delivery2_cnt']) && isset($tmw_delivery['delivery2_perc'])){
                           $del_count =$tmw_delivery['delivery2_cnt'];
                           $del_perc = $tmw_delivery['delivery2_perc'];
                           }
                       }
                       if($l==3){
                           $del_time ='(6pm to 12am)';
                           if(isset($tmw_delivery['delivery3_cnt']) && isset($tmw_delivery['delivery3_perc'])){
                           $del_count =$tmw_delivery['delivery3_cnt'];
                           $del_perc = $tmw_delivery['delivery3_perc'];
                           }
                       }
                       
                       ?>
                       <div class=" col-lg-12 px-1 margin-all">
                        <div class="card bg_white_cus p_10_cus border_rad_3">
                            <div class="row">
                                <div class="col-xs-8 col-lg-9 pad pr-0">
                                       <h4 class="font_600 font_14 marginBottom-5 marginTop-8 ">Tomorrow Delivery</h4>
                                       <p class="small" style="color:#747272"><?php echo $del_time;?></p>
                                       <h3 class="marginTop5 marginBottom-5"><?php echo $del_count;?></h3>
                                </div>
                                <div class="col-xs-4 col-lg-3 pad my_auto pl-0">
                                   <img src="<?= base_url('assets/images/del_1.png') ?>" class="img-responsive ">
                                </div>
                                <div class="col-lg-12 row pr-0">
                                    <div class="col-lg-7 col-xs-12 pr-0">
                                         <p class="small"> 
                                         <?php $tmw_perc =  str_replace("-","",$del_perc); 
                                  if(strpos($del_perc, '-') !== false ) { ?>
                                        <span class="text-success "> <i class="fa fa-caret-up margin-r-5 "> </i> <?php echo $tmw_perc;?>% Higher</span> than yesterday
                                    <?php } else { ?>
                                    <span class="text-red "><i class="fa fa-caret-down margin-r-5 "> </i><?php echo $tmw_perc;?>% Lower </span>than yesterday
                                  <?php } ?>
                                  </p>
                                    </div>
                                    <div class="col-lg-4 pl-0">
                                        <?php if($del_count>0){ ?>
                                        <button class="btn btn-danger text-uppercase orderlist" data-toggle="modal" data-target="#orderlist" data-id="<?= date("Y-m-d", strtotime("+1 day")).'|'.$l; ?>" >Order List</button>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                           
                           
                        </div>
                       </div>
                       <?php } ?>
                </div>
                <!------------Tomorrow  deliveryEnd--------->
                  
            </div>
             <div class="col-lg-6 row margin ord_lis_pad">
                 <div class="card bg_white_cus p_7_cus border_rad_3">
                      <div class="card-header py_cust_card_head pl-9 text-uppercase font_600" >
                      <!--Today <strong>BROWNIES & DESSERTS</strong> Delivery-->
                    <h4 class="mb_5 " >Overall Top 10 Selling Items </h4>
                    <div class="row col-1g-12">
                        <div class="col-lg-6">
                             <div class="input-group mb-3 col-lg-12 col-xs-12 ">
                              <div class="input-group-prepend">
                                <span class="input-group-text text-capitalize" id="basic-addon1">From</span>
                              </div>
                              <input type="date" class="form-control date " id="date_from" aria-describedby="basic-addon1" value="<?php echo date('Y-m-d');?>" >
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="input-group mb-3 col-lg-12 col-xs-12">
                              <div class="input-group-prepend">
                                <span class="input-group-text text-capitalize" id="basic-addon2">To</span>
                              </div>
                              <input type="date" class="form-control date " id="date_to" aria-describedby="basic-addon2" value="<?php echo date('Y-m-d');?>" >
                            </div>
                        </div>

                    </div>
                   
                      </div>
                      <div class="card-body h_300_overflow" id="tbl_body">
                          <!--removed datatbale class -->
                       
                          <!--<p class="text-danger text-center">No records found</p>-->
                        
                      </div>
                    </div>
             </div>
         </div>
         <!--fifth row-->
          <div class="row marginTop10 ">
             <div class="col-lg-12 mx-auto row margin">
                 <div class="card bg_white_cus p_7_cus border_rad_3">
                      <div class="card-header py_cust_card_head pl-9 text-uppercase font_600" >
                      <!--Today <strong>BROWNIES & DESSERTS</strong> Delivery-->
                    <h4 class="">Summary Collection</h4>
                    <div class="row col-1g-12">
                        <div class="col-lg-6">
                             <div class="input-group mb-3 col-lg-12 col-xs-12">
                              <div class="input-group-prepend">
                                <span class="input-group-text text-capitalize" id="basic-addon1">From</span>
                              </div>
                              <input type="date" class="form-control date_1 " id="sum_date_from" aria-describedby="basic-addon1" value="<?php echo date('Y-m-d');?>" >
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="input-group mb-3 col-lg-12 col-xs-12">
                              <div class="input-group-prepend">
                                <span class="input-group-text text-capitalize" id="basic-addon2">To</span>
                              </div>
                              <input type="date" class="form-control date_1" id="sum_date_to" aria-describedby="basic-addon2" value="<?php echo date('Y-m-d');?>" >
                            </div>
                        </div>

                    </div>
                   
                      </div>
                      <div class="card-body" id="tbl_sumcal" style="margin-left: 10px;">
                       
                      </div>
                    </div>
             </div>
         </div>
         <!--sixth row-->
           <div class="row marginTop10 ">
             <div class="col-lg-12 mx-auto row margin">
                 <div class="card bg_white_cus p_7_cus border_rad_3">
                      <div class="card-header py_cust_card_head pl-9 text-uppercase font_600" >
                      <!--Today <strong>BROWNIES & DESSERTS</strong> Delivery-->
                            <h4 class="text-left">STATISTICS COLLECTION <span style="font-size: 14.5px;">LAST 30 DAY'S</span></h4>
                  
                      </div>
                      <div class="card-body">
                          <div id="chartContainer" style="height: 300px; width: 100%;"></div>
                      </div>
                    </div>
             </div>
         </div>
    </section>
</div>
<!-- Order List View modal -->
<div class="modal fade" id="orderlist" tabindex="-1" role="dialog" aria-labelledby="orderlistLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <!--<h5 class="modal-title text-center font_16 font_600 text-capitalize" id="orderlistLabel"> Delivery</h5>-->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<!--graph script start-->
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
 window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,  

	data: [{
		type: "spline",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
// 		[
// 		{ x: new Date(2022, 00,11), y: 2700},
//         { x: new Date(2022, 00,12 ), y: 1714 },
//         { x: new Date(2022, 00,13 ), y: 1614 },
//         { x: new Date(2022, 00,14 ), y: 1514 },
//         { x: new Date(2022, 00,15 ), y: 1614 },
//         { x: new Date(2022, 00,16 ), y: 1414 },
//         { x: new Date(2022, 00,17 ), y: 1914 },
//         { x: new Date(2022, 00,18 ), y: 2014 },
//         { x: new Date(2022, 00,19 ), y: 2114 }
            
// 		]
	}]
});
chart.render();

}
</script>
<!--graph script end-->
<script>
$(document).ready(function(){
if ($.fn.dataTable.isDataTable('#report_table')){
    $('#report_table').DataTable({
         pageLength : 5,
         lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']]
    });
}
if ($.fn.dataTable.isDataTable('#all_report_table')){
     $('#all_report_table').DataTable( {
          pageLength : 5,
         lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']],
         "targets": 'no-sort',
        "bSort": false,
        "order": []
        // dom: 'Bfrtip',
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ]
    } );
    }
});
    
</script>
<script>
$(document).ready(function(){
            var from = document.getElementById("date_from").value;
            var to = document.getElementById("date_to").value;
            var sumcal_from = document.getElementById("sum_date_from").value;
            var sumcal_to = document.getElementById("sum_date_to").value;
            if(from!="" && to!=""){
                   $.ajax({
                	url:'<?php echo base_url() ?>order/ajax_top10listselling',
            		type:'POST',
            		data:{from:from,to:to},
                    success: function(data) {
                    //   alert(data);   
                      $("#tbl_body").html(data);
               
                      
                    },
                    error:function(err){
                      alert("error"+JSON.stringify(err));
                    }
                });
  
            }
             if(sumcal_from!="" && sumcal_to!=""){
                   $.ajax({
                	url:'<?php echo base_url() ?>order/ajax_summarycolection',
            		type:'POST',
            		data:{from:sumcal_from,to:sumcal_to},
                    success: function(data) {
                       //alert(data);   
                      $("#tbl_sumcal").html(data);
                      
                    },
                    error:function(err){
                      alert("error"+JSON.stringify(err));
                    }
                });
            }
            });
</script>
<script>
 $( ".date" ).change(function() {
            var from = document.getElementById("date_from").value;
            var to = document.getElementById("date_to").value;
            // var sumcal_from = document.getElementById("sum_date_from").value;
            // var sumcal_to = document.getElementById("sum_date_to").value;
            if(from!="" && to!=""){
                   $.ajax({
                	url:'<?php echo base_url() ?>order/ajax_top10listselling',
            		type:'POST',
            		data:{from:from,to:to},
                    success: function(data) {
                    //   alert(data);
                      $("#tbl_body").html(data);
                         jQuery(function () {
                             var firsttimecall = false;
                                jQuery('.datatable_1').DataTable({
                                    
                                   
                                });
                                firsttimecall = true;
                        });
                    },
                    error:function(err){
                      alert("error"+JSON.stringify(err));
                    }
                });
            }
            // if(sumcal_from!="" && sumcal_to!=""){
            //       $.ajax({
            //     	url:'<?php echo base_url() ?>order/ajax_summarycolection',
            // 		type:'POST',
            // 		data:{from:sumcal_from,to:sumcal_to},
            //         success: function(data) {
            //         //   alert(data);   
            //           $("#tbl_sumcal").html(data);
            //         },
            //         error:function(err){
            //           alert("error"+JSON.stringify(err));
            //         }
            //     });
            // }
 });
 </script>
 <script>
 $( ".date_1" ).change(function() {
            var sumcal_from = document.getElementById("sum_date_from").value;
            var sumcal_to = document.getElementById("sum_date_to").value;
            if(sumcal_from!="" && sumcal_to!=""){
                   $.ajax({
                	url:'<?php echo base_url() ?>order/ajax_summarycolection',
            		type:'POST',
            		data:{from:sumcal_from,to:sumcal_to},
                    success: function(data) {
                    //   alert(data);   
                      $("#tbl_sumcal").html(data);
                    },
                    error:function(err){
                      alert("error"+JSON.stringify(err));
                    }
                });
            }
 });
 </script>
 <script>
 $('.orderlist').on('click',function(){
     var delivery_range =$(this).data('id'); //1 -> (8am -12noon) 2 -> (12pm - 6pm) 3 -> (6pm - 12am)
            //alert(datetime);
    $('.modal-body').html('loading');
       $.ajax({
    	url:'<?php echo base_url() ?>order/ajax_dashorderlist',
		type:'POST',
		data:'delivery_range='+delivery_range,
        success: function(data) {
          $('.modal-body').html(data);
        },
        error:function(err){
          alert("error"+JSON.stringify(err));
        }
    });
 });
 </script>