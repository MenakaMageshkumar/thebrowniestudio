<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Roles | Profile</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>
         .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
    </style>
  </head>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Roles List</h3></div>
          <div class="col-md-6" align="right">
           
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
      <div class="box-body table-responsive">
        <table id="driverTable" class="table table-bordered table-striped datatable ">
          <thead>
            <tr>
              <th width="1%" class="text-center p_3_font_13">S.NO</th>
              <th width="25%;"  class="text-center p_3_font_13 ">NAME OF THE ROLE</th>
              <th width="30%;"  class="text-center p_3_font_13">MODULE ASSIGNED</th>
              <th width="15%;" class="text-center p_3_font_13">STATUS</th>
            </tr>
          </thead> 
          <tbody>
            <?php
            if(!empty($roles_data)){
                  $i =1;
              foreach($roles_data as $data) {
               ?>
               <tr>
                <td class="center text-center p_3_font_13"><?= $i++ ?></td>
                 <td  class="p_3_font_13 text-center" ><?= $data->role_name ?></th> 
                 <td class="p_3_font_13">
                 <?php
                 $menu_name ='';
                 $roles_assigned = $data->roles_assigned;
                 if($roles_assigned){
                 $menu_data = $this->db->query("select * from roles_menu where id in  ($roles_assigned)")->result(); //1,3,4
                 foreach($menu_data as $dt){
                     if($menu_name==''){
                         $menu_name = $dt->menu_display_name;
                     }
                     else{
                     $menu_name = $menu_name.' , '.$dt->menu_display_name;
                     }
                 }
                 }
                 echo rtrim($menu_name);
                 ?>
                 
                 </th> 
                 <td  class="text-center p_3_font_13 ">
                     <?php if($data->role_name!='Supervisor (System Default)' && $data->role_name!='Manager (System Default)') { ?>	 
                    <a class="btn btn-sm btn-primary" 
                      href="<?= base_url('Role/update_roles/'.encode_param($data->id)) ?>">
                      <i class="fa fa-fw fa-edit"></i>Edit
                    </a> 
                    <?php } else { ?>
                    <a class="btn btn-sm btn-default" 
                      href="#">Default
                    </a>
                    <?php } ?>
              </td>
                </tr>
            <?php 
              } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>
   <script>

 $(document).ready(function() {
    active("role_side_menu"); 
 });

</script>
 <script>
     $(document).ready(function() 
     { 
          jQuery(function () {
                    jQuery('#driverTable').DataTable({
                       
                    });
                });
     });
</script>