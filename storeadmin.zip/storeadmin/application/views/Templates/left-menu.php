
<style>
.menu_icon {
    height: 20px;
    width: 20px;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
</style>
<?php
  $userData = $this->session->userdata['user'];
  $logo_url = $this->session->userdata['logo_url'];
  $store_id = $userData->store_id;
  $mastersettings_delivery_enable = 0;
  $delivery_enable= $this->db->query("select * from store_mastersettings where store_id =$store_id ")->result();
  if($delivery_enable){
  if(($delivery_enable[0]->delivery_type==2) || ($delivery_enable[0]->delivery_type==3)){ //2-home delivery 3-both
  $mastersettings_delivery_enable = 1;    //Super admin give access for delivery related menu's for this store
  }
  }
  if ( $userData->user_type ==3){
      $store_id = $userData->store_id;
      $role_id = $userData->role_id;
      $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
      if(!empty($chk_rls)){
          $roles_assigned = $chk_rls[0]->roles_assigned;
          if($roles_assigned!=''){
              $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
          }else{
              $menu_assigned ='';
          }
          
      }
      
  }
  //Store Master setting of Delivery 
  $storesettings_delivery_enable =0;
  $storesettings_enable = $this->db->query("select store_delivery_type,exclusive_app_enabled from stores where store_id =$store_id ")->result();
  $exclusive_app_enabled = 0;
  if($storesettings_enable){
      if(($storesettings_enable[0]->store_delivery_type==2) || ($storesettings_enable[0]->store_delivery_type==3)){ //2-home delivery 3-both
      $storesettings_delivery_enable =1;
      $exclusive_app_enabled = $storesettings_enable[0]->exclusive_app_enabled;
      }
  }
  ?>
<aside class="main-sidebar">
    <section class="sidebar" >
        <div class="user-panel">
            <div class="pull-left image">
                <a href="<?php echo base_url($logo_url); ?>"><img src="<?=base_url("../".$userData->store_logo)?>" onerror="this.src='<?=base_url("assets/images/brownie_logo.webp")?>'" class="user-image left-sid" alt="User Image"></a>
            </div>
            <div class="pull-left info">
                <p><?php echo $this->session->userdata['user']->username; ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <ul class="sidebar-menu">
            
            <?php if($this->session->userdata['user_type'] == 2 ){ // 2-store admin 3-store user ?>  
            <li class="treeview" id="order_side_menu">
                <a href="#">
                   <i class="fa fa-tasks"></i>
                        <span>Order Management</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Order/ViewOrders') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View Orders
                        </a>
                    </li>
                </ul>
            </li>
            <li class="treeview"  id="product_side_menu">
                <a href="#">
               <i class="fa fa-users"></i>
                        <span>Product Management</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Product/addProduct') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Add New Product
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('Product/viewProducts') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View All Product
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('Product/productsUpload') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Bulk Upload
                        </a>
                    </li>
                </ul>
            </li>
           
            <li class="treeview"  id="invoice_side_menu">
                <a href="#">
                   <i class="fa fa-rupee-sign"></i>
                        <span>Invoice</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Invoice/ViewInvoice') ?>" ><i class="fa fa-circle-o text-aqua"></i>View Invoice</a>
                    </li>
                </ul>
            </li>
            <li class="treeview"  id="download_side_menu">
                <a href="#">
                    <i class="fa fa-download"></i>
                        <span>Download</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <!--<a href="<?= base_url('Download/Productfile') ?>"><i class="fa fa-circle-o text-aqua"></i>Sample Product File</a>-->
                        <a href="<?php echo base_url();?>assets/csv/Product Bulk upload Sample - latest.csv" download="Product Bulk upload Sample - latest.csv"><i class="fa fa-circle-o text-aqua"></i>Sample Product File</a>
                    </li>
                    <li>
                        <a href="<?= base_url('Download/Inventoryfile') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Inventory File
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url('../'.$userData->qrcode)?>" download="qrcode"><i class="fa fa-circle-o text-aqua"></i>Download QR Code</a>
                    </li>
                    
                </ul>
            </li>
            <?php if($mastersettings_delivery_enable ==1){ ?>
            <li class="treeview"  id="delivery_side_menu">
                <a href="#">
                    <i class="fa fa-user"></i>
                        <span>Delivery Profile</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Delivery/ViewProfiles') ?>"><i class="fa fa-circle-o text-aqua"></i>View Delivery Profile</a>
                    </li>
                    <li>
                        <a href="<?= base_url('Delivery/AddProfile') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Add Delivery Profile
                        </a>
                    </li>
                </ul>
            </li>
            <?php } ?>
            <li class="treeview"  id="location_side_menu">
                <a href="#">
                    <i class="fa fa-map-marker"></i>
                        <span>Delivery Location</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Location/ManageLocation') ?>" ><i class="fa fa-circle-o text-aqua"></i>Manage Location</a>
                    </li>
                    <li>
                        <a href="<?= base_url('Location/AddLocation') ?>" ><i class="fa fa-circle-o text-aqua"></i>Add Location</a>
                    </li>
                </ul>
            </li>
            
            <li class="treeview"  id="role_side_menu">
                <a href="#">
                   <i class="fa fa-user"></i>
                        <span>Role Management</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Role/create_role') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Create Role
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('Role/manage_roles') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Manage Roles
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('Role/create_storeuser') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Create User
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('Role/view_storeuser') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View Store Users
                        </a>
                    </li>
                    
                </ul>
            </li>
            <!--------------------- Advertisement-------------------->
            <li class="treeview"  id="advertisement_side_menu">
                <a href="#">
                   <i class="fa fa-tasks"></i>
                        <span>Advertisement</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li id="view_banner_menu">
                        <a href="<?= base_url('Advertisement/ViewBanner') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View Banner
                        </a>
                    </li>
                    <!--  <li id="banner_add_menu">-->
                    <!--    <a href="<?= base_url('Advertisement/editBanner') ?>"><i class="fa fa-circle-o text-aqua"></i>Add Coupon</a>-->
                    <!--</li>-->
                </ul>
            </li>
             <!--------------------- Coupon-------------------->
            <li class="treeview"  id="coupon_side_menu">
                <a href="#">
                    <i class="fa fa-ticket" aria-hidden="true"></i>
                        <span>Coupon Management</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li id="coupon_add_menu">
                        <a href="<?= base_url('Coupon/addcoupon') ?>"><i class="fa fa-circle-o text-aqua"></i>Add Coupon</a>
                    </li>
                    <li id="coupon_view_menu">
                        <a href="<?= base_url('Coupon/viewcoupon') ?>"><i class="fa fa-circle-o text-aqua"></i>View Coupon</a>
                    </li>
                </ul>
            </li>
            <!--------------Sub category-------------------->
            <li class="treeview sub_cat_side_menu" id="3_id">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Subcategory</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li id="view_all_sub_cat">
                        <a href="<?= base_url('Subcategory/addsubcategory') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Add Subcategory
                        </a>
                    </li>
                    <li id="view_all_sub_cat">
                        <a href="<?= base_url('Subcategory/Viewsub_cat') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View All Subcategory
                        </a>
                    </li>
                </ul>
            </li>
            <!------------------Brand-------------------->
            <li class="treeview brand_side_menu" id="3_id">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Brand</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li id="view_all_sub_cat">
                        <a href="<?= base_url('Brand/addbrand') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Add Brand
                        </a>
                    </li>
                    <li id="view_all_sub_cat">
                        <a href="<?= base_url('Brand/Viewbrand') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View All Brand
                        </a>
                    </li>
                </ul>
            </li>
            <li class="treeview"  id="master_side_menu">
                <a href="#">
                    <i class="fa fa-cog"></i>
                        <span>Master Settings</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('SellerSettings/PackingCharges') ?>"><i class="fa fa-circle-o text-aqua"></i>Packing Charges</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/DeliveryCharges') ?>"><i class="fa fa-circle-o text-aqua"></i>Delivery Charges</a>
                    </li>
                    <?php // if($mastersettings_delivery_enable ==1 && $storesettings_delivery_enable ==1){ 
                     if($mastersettings_delivery_enable ==1){ ?>
                    <li>
                        <a href="<?= base_url('SellerSettings/DeliveryType') ?>"><i class="fa fa-circle-o text-aqua"></i>Delivery Type</a>
                    </li>
                    <?php } ?>
                    <li>
                        <a href="<?= base_url('SellerSettings/AddScreen') ?>"><i class="fa fa-circle-o text-aqua"></i>Add App Screen</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/StoreLocation') ?>"><i class="fa fa-circle-o text-aqua"></i>Update Store Location</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/ThemeSettings') ?>"><i class="fa fa-circle-o text-aqua"></i>Theme Settings</a>
                    </li>
                     <li>
                        <a href="<?= base_url('SellerSettings/InvoiceFormat') ?>"><i class="fa fa-circle-o text-aqua"></i>Invoice Format</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/Comments') ?>"><i class="fa fa-circle-o text-aqua"></i>User Comments</a>
                    </li>
                     <li>
                        <a href="<?= base_url('SellerSettings/StoreSettings') ?>"><i class="fa fa-circle-o text-aqua"></i>Store Settings</a>
                    </li>
                </ul>
            </li>
            <li class="treeview"  id="customer_side_menu">
                <a href="#">
                   <i class="fa fa-tasks"></i>
                        <span>Customer Management</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Customer/ManageCustomer') ?>"><i class="fa fa-circle-o text-aqua"></i>Manage Customer</a>
                    </li>
                </ul>
            </li>
            <?php if($exclusive_app_enabled==1){ ?>
            <li class="treeview"  id="content_side_menu">
                <a href="#">
                   <i class="fa fa-tasks"></i>
                        <span>Content Management</span>
                    <i class="fa fa-angle-right pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Content/ManageContent') ?>"><i class="fa fa-circle-o text-aqua"></i>Manage Content</a>
                    </li>
                </ul>
            </li>
            <?php } ?>
            <?php } ?>
            <?php if($this->session->userdata['user_type'] == 3 && $menu_assigned!='' ){
                
            foreach($menu_assigned as $dt){ 
               if($dt->menu_name=='order_management'){ ?>
               <li class="treeview">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Order Management</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Order/ViewOrders') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View Orders
                        </a>
                    </li>
                </ul>
            </li>
               <?php }  
                if($dt->menu_name=='product_management'){ ?>
                    <li class="treeview">
                <a href="#">
                    <img src="<?=base_url("assets/logo/Product.png")?>" class="user-image left-sid menu_icon" alt="icon">
                        <span>Product Management</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Product/addProduct') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Add New Product
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('Product/viewProducts') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            View All Product
                        </a>
                    </li>
                </ul>
            </li>
               <?php } 
               if($dt->menu_name=='invoice'){ ?>
               <li class="treeview">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Invoice</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Invoice/ViewInvoice') ?>" ><i class="fa fa-circle-o text-aqua"></i>View Invoice</a>
                    </li>
                </ul>
            </li>
               <?php }
               if($dt->menu_name=='download'){ ?>
               <li class="treeview">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Download</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <!--<a href="<?= base_url('Download/Productfile') ?>"><i class="fa fa-circle-o text-aqua"></i>Sample Product File</a>-->
                        <a href="<?php echo base_url();?>assets/csv/Product Bulk upload Sample - latest.csv" download="Product Bulk upload Sample - latest.csv"><i class="fa fa-circle-o text-aqua"></i>Sample Product File</a>
                    </li>
                    <li>
                        <a href="<?= base_url('Download/Inventoryfile') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Inventory File
                        </a>
                    </li>
                    <li>
                        <a href="<?=base_url('../'.$userData->qrcode)?>" download="qrcode"><i class="fa fa-circle-o text-aqua"></i>Download QRcode</a>
                    </li>
                    
                </ul>
            </li>
               <?php }
               if($dt->menu_name=='delivery_menu' && $mastersettings_delivery_enable ==1){ ?>
               <li class="treeview">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span> Delivery Profile</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Delivery/ViewProfiles') ?>"><i class="fa fa-circle-o text-aqua"></i>View Delivery Profile</a>
                    </li>
                    <li>
                        <a href="<?= base_url('Delivery/AddProfile') ?>">
                            <i class="fa fa-circle-o text-aqua"></i>
                            Add Delivery Profile
                        </a>
                    </li>
                </ul>
            </li>
               
               <?php }
               if($dt->menu_name=='delivery_location'){ ?>
               <li class="treeview">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Delivery Location</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('Location/ManageLocation') ?>" ><i class="fa fa-circle-o text-aqua"></i>Manage Location</a>
                    </li>
                    <li>
                        <a href="<?= base_url('Location/AddLocation') ?>" ><i class="fa fa-circle-o text-aqua"></i>Add Location</a>
                    </li>
                </ul>
            </li>
               <?php }
               if($dt->menu_name=='master_settings'){ ?>
               <li class="treeview">
                <a href="#">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                        <span>Master settings</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?= base_url('SellerSettings/PackingCharges') ?>"><i class="fa fa-circle-o text-aqua"></i>Packing Charges</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/DeliveryCharges') ?>"><i class="fa fa-circle-o text-aqua"></i>Delivery Charges</a>
                    </li>
                    <?php // if($mastersettings_delivery_enable ==1 && $storesettings_delivery_enable ==1){
                    if($mastersettings_delivery_enable ==1){ ?>?>
                    <li>
                        <a href="<?= base_url('SellerSettings/DeliveryType') ?>"><i class="fa fa-circle-o text-aqua"></i>Delivery Type</a>
                    </li>
                    <?php } ?>
                    <li>
                        <a href="<?= base_url('SellerSettings/AddScreen') ?>"><i class="fa fa-circle-o text-aqua"></i>Add App Screen</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/StoreLocation') ?>"><i class="fa fa-circle-o text-aqua"></i>Update Store Location</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/ThemeSettings') ?>"><i class="fa fa-circle-o text-aqua"></i>Theme Settings</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/InvoiceFormat') ?>"><i class="fa fa-circle-o text-aqua"></i>Invoice Format</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/Comments') ?>"><i class="fa fa-circle-o text-aqua"></i>User Comments</a>
                    </li>
                    <li>
                        <a href="<?= base_url('SellerSettings/StoreSettings') ?>"><i class="fa fa-circle-o text-aqua"></i>Store Settings</a>
                    </li>
                </ul>
            </li>
               <?php }
            }
            ?>  
            
            
            <?php } ?>
        </ul>
            
    </section>
</aside>

