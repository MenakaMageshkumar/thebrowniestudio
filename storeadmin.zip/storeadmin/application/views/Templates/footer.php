<div class="modal fade" id="popup_modal" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title" id="modal_header"></h4>
			</div>
			<div class="modal-body col-md-12" id="modal_content" style="border-bottom:1px solid #e5e5e5;"></div>
			<div class="modal-footer">
				<div>&nbsp;</div>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>  
<footer class="main-footer footer-section">
	<div class="pull-right hidden-xs">
		<b>Version</b> 1.0
	</div>
	<strong>Copyright &copy; <?= date('Y')?> - <?= date('Y')+1?> <a href="#" class="footer_logo">Yellow <span>Mart</span>"</a>.</strong> All rights reserved.
</footer>
