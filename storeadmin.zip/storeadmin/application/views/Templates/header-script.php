<?php
$get_theme = "441075";
$get_font = "fff100";
// yellow #fff100 purple #441075
$store_id = $this->session->userdata['user']->store_id;
if($store_id!=''){
 $chk_exclusive = $this->db->query("select theme_color,font_color from stores where store_id = $store_id and exclusive_app_enabled=1 ")->result();
 if($chk_exclusive){
     $theme = $chk_exclusive[0]->theme_color; // #441075
     $font = $chk_exclusive[0]->font_color;
     $get_theme  = str_replace("#","","$theme"); //441075
     $get_font  = str_replace("#","","$font");
 }
}
?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">
   <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?= base_url('assets/css/select2.min.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/dataTables.bootstrap.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/pace.css') ?>">
  <!--<link rel="stylesheet" href="<?= base_url('assets/css/'.$this->config->item("theme_color").'.css') ?>">-->
  <link rel="stylesheet" href="<?= base_url('assets/css/skin-blue.php?get_theme='.$get_theme.'&get_font='.$get_font.'') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/custom-style.css?'.time()) ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/parsley/parsley.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap-datepicker3.css') ?>">
  <link rel="stylesheet" href="<?= base_url('assets/css/clockpicker.css') ?>" type="text/css" >
  <link rel="stylesheet" href="<?= base_url('assets/css/morris.css')?>">
  <link rel="stylesheet"href="<?php echo base_url();?>assets/jquery-flexdatalist-2.2.4/jquery.flexdatalist.min.css" />
  <script src="<?= base_url('assets/js/jQuery-2.1.4.min.js') ?>"></script>
</head>
<style>
<?php
if($chk_exclusive){?>
.btn-primary {
    background-color: <?php echo $theme ?>!important;
    border-color: <?php echo $theme ?>!important;
}
.btn-success.hover {
    background-color: <?php echo $theme ?>!important;
}
.btn-purple{
    background: <?php echo $font ?>!important;
    color: <?php echo $theme ?>!important;
}
.btn-pri{
    background: <?php echo $theme ?>!important;
    color: <?php echo $font ?>!important;
}
.btn-pri a:hover {
    background: <?php echo $theme ?>!important;
    color: <?php echo $font ?>!important;
  }

.btn-sec{
    background: <?php echo $font ?>!important;
    color: <?php echo $theme ?>!important;
}
.btn-sec a:hover {
    background: <?php echo $font ?>!important;
    color: <?php echo $theme ?>!important;
}
.text-aqua {
    color: <?php echo $font ?>!important;
}

<?php }?>
.skin-blue .sidebar-menu > li > .treeview-menu {
    margin: 0 1px;
    background: #cda314!important;
}
.user_image_admin {
    
    width: 80%!important;
}
@media screen and (max-width: 600px) {
.user_image_admin {
    
    width: 50%!important;
}
.main-header .sidebar-toggle {
    float: left;
    background-color: #740606!important;
    background-image: none;
    padding: 15px 15px;
    font-family: fontAwesome;
}
.skin-blue .main-header .navbar .sidebar-toggle:hover {
    background-color: #740606!important;
}
}

</style>