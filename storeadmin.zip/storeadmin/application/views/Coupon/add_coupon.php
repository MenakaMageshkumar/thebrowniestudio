<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Coupon| Add Coupon</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>
        .pl_0_cus
        {
                padding-left: 0px;
        }
        .p_top_cus
        {
            padding-top: 52px;
        }
        @media (max-width:575px)
        {
            .p_top_cus
            {
                padding-top: 25px!important;
            }
        }
    </style>
  </head>
  <div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?><small><?= $pDescription ?></small></h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
 <?php 
  $url = (!isset($coupon_id) || empty($coupon_id))?'Coupon/save_coupon':'Coupon/save_edit_coupon/'.encode_param($coupon_id);

?>
    <div class="row">
   <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <?php 
    //   print_r($coupondata);
      ?>
      <?php
                if(isset($coupondata))
                {
                    $coupondata = $coupondata[0];
                    $validity_from  = date('d/m/Y', strtotime($coupondata ->validity_from));
                    $validity_to = date('d/m/Y', strtotime($coupondata ->validity_to));
                    $condition_check = floatval($coupondata->condition_chkvalue);
                    $rule_value = $coupondata->rule_value;
                    
                } ?>
      <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-body">
            <form role="form"  method="post" action="<?= base_url($url) ?>" class="validate" data-parsley-validate="" enctype="multipart/form-data" onsubmit="return validateForm()">
              <div class="col-md-12">
                  <!--<?php print_r($storedata);?>-->
                  <h5 class="h4 text-uppercase " style="padding: 7px;">Offer Details</h5>
                  <div class="form-group col-md-6">
                    <label>TITLE</label>
                    <input type="text" class="form-control" name="cp_title" placeholder="Enter Coupon Title" value="<?= (isset($coupondata->title))?$coupondata->title:'' ?>" required>
                  </div>
                  <div class="form-group col-md-6">
                      <label>OFFER CODE</label>
                      <input type="text" class="form-control" name="cp_offer_code" id="cp_offer_code" placeholder="Enter Offer Code" value="<?= (isset($coupondata->offer_code))?$coupondata->offer_code:'' ?>" required>
                      <span id="cp_offer_code_error" class="error_msg"></span>
                    </div>
                  <div class="form-group col-md-12">
                      <label>TERMS & CONDITIONS</label>
                      <textarea class="form-control text-left" name="cp_terms_condition"  required>
                          <?= (isset($coupondata->terms_conds))?$coupondata->terms_conds:'' ?>
                      </textarea>
                    </div>
                 <h5 class="h4 text-uppercase" style="padding: 7px;">Offer Rules</h5>
                 <div class="form-group col-md-6">
                    <label>RULE TYPE</label>
                   <select name="cp_rule_type" class="form-control required" placeholder="Select Category" required>
                      <!--<option selected value="">Choose a Rule Type</option>-->
                      <?php if(isset($coupondata)){ ?>
                      <option value=""<?php echo ($coupondata->rule_type == '')?"selected":"" ?> >Select type</option>
                      <option value="1"<?php echo ($coupondata->rule_type == '1')?"selected":"" ?> >Percentage</option>
                      <option value="2"<?php echo ($coupondata->rule_type == '2')?"selected":"" ?>>Flat</option>
                      <?php } else { ?>
                        <option selected value="">Select Type</option>
                        <option value="1">Percentage</option>
                        <option value="2">Flat</option>
                      <?php } ?>
                    </select>
                  </div>
                <div class="form-group col-md-6">
                    <label>VALUE</label>
                    <input type="number" minimum=1 class="form-control" name="rule_value" required value="<?= (isset($rule_value))?$rule_value:'' ?>">
                  </div>
                  <div class="form-group col-md-6">
                    <label>CONDITIONS</label>
                    <input type="number" minimum=1 class="form-control" name="cp_condition" required value="<?= (isset($condition_check))?$condition_check:'' ?>">
                  </div>
                  <div class="form-group col-md-6">
                    <label>VALIDATE FROM</label>
                    <!--<input type="date" class="form-control text-uppercase" name="cp_valid_from" id="cp_valid_from" value="<?= (isset($validity_from))?$validity_from:'' ?>" required >-->
                     <input type="text"  name="cp_valid_from" id="cp_valid_from" class="form-control hasDatepicker text-uppercase" placeholder="dd/mm/yyyy" value="<?= (isset($validity_from))?$validity_from:'' ?>" required>
                  </div>
                  <div class="form-group col-md-6">
                    <label>VALIDATE TO</label>
                    <!--<input type="date" class="form-control text-uppercase" name="cp_valid_to" id="cp_valid_to" onchange = "DateCheck();" value="<?= (isset($validity_to))?$validity_to:'' ?>" required >-->
                    <input type="text"  name="cp_valid_to" id="cp_valid_to" onchange = "DateCheck();" class="form-control hasDatepicker text-uppercase" placeholder="dd/mm/yyyy" value="<?= (isset($validity_to))?$validity_to:'' ?>" required>
                  </div>
                  <div class="form-group col-md-6">
                    <label>OFFER USAGE</label>
                    <input type="number" class="form-control" min="1" name="cp_offer_usage" required value="<?= (isset($coupondata->offer_usage))?$coupondata->offer_usage:'' ?>">
                  </div>
                <div class="form-group col-md-6">
                    <label>OFFER IMAGE</label>
                    <div class="col-md-12 pl_0_cus">
                      <div class="col-md-2 pl_0_cus">
                        <img id="profile_image" src="<?= (isset($coupondata) && isset($coupondata->offer_image))?base_url("../".$coupondata->offer_image):'' ?>" onerror="this.src='<?=base_url("assets/images/user_avatar.jpg")?>'" height="75" width="75" />
                      </div>
                      <div class="col-md-9 pl_0_cus p_top_cus" >
                        <input name="offer_image" type="file" accept="image/*" class="" onmouseleave="readURL(this,'profile_image');" />
                      </div>
                    </div>
                   
              <div class="col-md-12">      
                <div class="box-footer textCenterAlign">
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <a href="" class="btn btn-primary">Cancel</a>
                </div>        
              </div>        
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

//  <script>
     $(document).ready(function() 
     {
        // active("12_id");
        // active_main("12_id");
        // active_sub("coupon_add_menu");
        // date format  
var dateformat = 'dd/mm/yyyy';

$('.hasDatepicker').datepicker({
  format: dateformat,
  autoclose: true
});


// date format function end
       
     });
// </script>
<!--Date check for valide To-->
<script>
     function DateCheck()
        {
            var valide_from = formatDate($("#cp_valid_from").val());
                   var valide_to = formatDate($("#cp_valid_to").val());
                   if (valide_from != '' && valide_to !='') {
                       if (Date.parse(valide_from) > Date.parse(valide_to)) {
                           $("#cp_valid_to").val('');
                          alert("Check the Date! End Should be greater than start date");
                       }
                   }
                   return false;
            }
</script>
 <!--View Image -->
<script>
	function readURL(input, dec_id) 
	{
		if (input.files && input.files[0]) 
		{
    		var reader = new FileReader();
    		reader.onload = function(e) 
			{
        		$('#' + dec_id).attr('src', e.target.result);
    		};
    	reader.readAsDataURL(input.files[0]);
		}
    }
</script>
<!--phone number verification-->
<script>
$("#cp_offer_code").blur(function()
{
    var cp_offer_code = document.getElementById("cp_offer_code").value;
            $.ajax({
                url:'<?php echo base_url();?>Coupon/verify_coupon_offer',
                 type:'POST',
                 data:{cp_offer_code:cp_offer_code},
                 success: function(data) {
                    if(data==0)
                    {
                        document.getElementById('cp_offer_code').style.borderColor = "red";
                        document.getElementById("cp_offer_code_error").textContent = "Offer Code already exist!";
                    }
                    else
                    {
                        // alert(data);
                         document.getElementById('cp_offer_code').style.borderColor = "green";
                        document.getElementById("cp_offer_code_error").textContent = "";
                    }
                 }
                
            });
});
</script>
<script>
    function validateForm()
    {
         var cp_offer_code_error = document.getElementById("cp_offer_code_error").innerHTML;
            if(cp_offer_code_error =='Offer Code already exist!')
            {
                alert("Offer Code is already exist");
                return false;
            } 
            else
            { 
                
            }
    
    }
</script>
<script>

 $(document).ready(function() {
    active("coupon_side_menu"); 
 });

</script>
<script>
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}

</script>
