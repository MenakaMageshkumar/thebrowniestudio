<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Coupon | Coupon_list</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/dataTables.bootstrap4.min.css">
    
  </head>
     <style>
  .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
  </style>
  <div class="content-wrapper" >
  <section class="content-header">
    <h1>
       <?= $pTitle ?>
        <small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
          <?php if($this->session->flashdata('message')) { 
              $flashdata = $this->session->flashdata('message'); ?>
              <div class="alert alert-<?= $flashdata['class'] ?>">
                 <button class="close" data-dismiss="alert" type="button">×</button>
                 <?= $flashdata['message'] ?>
              </div>
          <?php } ?>
      </div>
      <div class="col-xs-12">
      <div class="box box-warning"> 
        <div class="box-header with-border">
          <div class="col-md-6"><h3 class="box-title">Coupon List</h3></div>
          <div class="col-md-6" align="right">
           
            
            <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
          </div>
        </div>
      <div class="box-body table-responsive">
        <table id="coupon_datatable" class="table table-striped table-bordered" style="width:100%">
          <thead>
            <tr>
              <th width="2%" class="text-center p_3_font_13 text-uppercase">S.NO</th>
              <th class="hidden">Coupon ID</th>
              <th class="text-center p_3_font_13 text-uppercase">Coupon Title</th>
              <th class="text-center p_3_font_13 text-uppercase">Offer Code</th>
              <th class="text-center p_3_font_13 text-uppercase">Coupon image</th> 
              <th class="text-center p_3_font_13 text-uppercase">Terms & Conditions</th>
              <th class="text-center p_3_font_13 text-uppercase">Rule Type</th>
              <th class="text-center p_3_font_13 text-uppercase">Applicable Store</th>
              <th class="text-center p_3_font_13 text-uppercase">Conditions Check Amount</th>
              <th class="text-center p_3_font_13 text-uppercase">Validate From</th>
              <th class="text-center p_3_font_13 text-uppercase">Validate To</th>
              <th class="text-center p_3_font_13 text-uppercase">Offer Usage</th>
              <th class="text-center p_3_font_13 text-uppercase">Action</th>
            </tr>
          </thead> 
          
           <tbody>
            <?php
            // print_r($coupondata);
            if(!empty($coupondata)){
                 $i =1;
              foreach($coupondata as $coupon) {
               ?>
               <tr>
                   <td class="center text-center p_3_font_13"><?= $i++ ?></td>
                 <td class="hidden"><?= $coupon->id ?></td>
                 <td class="center text-center p_3_font_13"><?= $coupon->title ?></td> 
                 <td class="center text-center p_3_font_13"><?= $coupon->offer_code ?></td> 
                 <td class="center text-center p_3_font_13"><img src="<?= base_url('../../'.$coupon->offer_image) ?>" class="cpoint" onclick="viewImageModal('Profile Image','<?= base_url('../../'.$coupon->offer_image) ?>');"
                  onerror="this.src='<?=base_url("../../assets/images/user_avatar.jpg")?>';" height="100" width="100" /></td> 
                 <td class="center  p_3_font_13"><?= $coupon->terms_conds ?></td>
                 <td class="center text-center p_3_font_13"><?= ($coupon->rule_type == '1')?'Percentage':'Flat'?></td>
                 <td class="center text-center p_3_font_13"><?= $coupon->applicable_str ?></td>
                 <td class="center text-center p_3_font_13"><?= $coupon->condition_chkvalue ?></td>
                 <td class="center text-center p_3_font_13">
                      <?php 
                        $valid_from = $coupon->validity_from;
                        $valid_from_value = date("d/m/Y", strtotime($valid_from));
                        ?>     
                        <?= $valid_from_value ?>
                    
                </td>
                 <td class="center text-center p_3_font_13">
                <?php 
                $valid_to = $coupon->validity_to;
                $valid_to_value = date("d/m/Y", strtotime($valid_to));
                ?>     
                     <?= $valid_to_value ?>
                     
                </td>
                 <td class="center text-center p_3_font_13"><?= $coupon->offer_usage ?></td>
                 <td class="center text-center p_3_font_13" width="18%">	 
                    <!--<a class="btn btn-sm btn-primary" id="viewCoupon" coupon_id="<?= encode_param($coupon->id) ?>">-->
                    <!--  <i class="fa fa-fw fa-eye"></i>View-->
                    <!--</a>-->
                    <a class="btn btn-sm btn-danger" style="margin-bottom: 10px;"  href="<?= base_url('Coupon/editcoupon/'.encode_param($coupon->id)) ?>" >
                      <i class="fa fa-fw fa-edit"></i>Edit
                    </a> 
                    <a class="btn btn-sm btn-danger" style="margin-bottom: 10px;" href="<?= base_url('Coupon/deletecoupon/'.encode_param($coupon->id)) ?>" >
                      <i class="fa fa-fw fa-trash"></i>Delete
                    </a>    
                   
                  </td>
                </tr>
            <?php 
              } 
            }?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>
<script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready( function () {
  var table = $('#coupon_datatable').DataTable( {
    pageLength : 5,
    lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']]
  } )
} );
</script>
<script>

 $(document).ready(function() {
    active("coupon_side_menu"); 
 });

</script>