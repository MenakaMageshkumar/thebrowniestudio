<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Banner | Add Banner</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <!--Croppie css Start-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" rel="stylesheet">
	<!--Croppie Css End-->
    <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .error_msg{
        color: red;
        font-weight: 700;
    }
    #upload-demo
    {
    	width: auto;
    	height: 80vh;
        padding-bottom:25px;
    }
    .ban_img_prev
    {
        width: 250px;
        height: 112.5px;
        object-fit: contain;
    }
    </style>
  </head>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?= $pTitle ?><small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
        <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <h3 class="box-title">Add Banners</h3>
          </div>
				<div class="box-body">
				    <form id="createStoreForm" role="form" action="<?= base_url('Advertisement/update_Advertisement/'.encode_param($store_id)) ?>" method="post" class="validate" enctype="multipart/form-data">
					  <div class="row">
							  <!------------------ Banner 1 ------------------->
							  <div class="form-group col-lg-8">
								  <label class="text-uppercase center-block">Banner 1 <span class="small text-lowercase font-light text-info"> (recommended 1000 x 450 image) </span></label> 
								   <input type="file" class="form-control item-img center-block" name="banner_1" id = "banner_1" onchange="readURL(this,'item-img-output_1');" >
							  </div>
							  <div class="form-group col-lg-4">
								<!--<img src="<?= base_url('assets/images/1000x450.png') ?>" class=" img-responsive  ban_img_prev" id="item-img-output_1" >-->
								<?php $banners =explode('|',$banner[0]->strweb_banners); ?>
								<img class=" img-responsive  ban_img_prev" id="item-img-output_1" src="<?= (isset($banners[0]) && isset($banners[0]))?base_url('../../'.$banners[0]):'' ?>" onerror="this.src='<?=base_url("assets/images/1000x450.png")?>'" >
							   
                        
							  </div>
							  <!-------------------Banner 2------------------->
							  <div class="form-group col-lg-8">
								<label
								class="text-uppercase center-block">Banner 2 <span class="small text-lowercase font-light text-info"> (recommended 1000 x 450 image) </span></label> 
								 <input type="file" class="form-control item-img center-block" name="banner_2" id = "banner_2"  onchange="readURL(this,'item-img-output_2');">
							  </div>
								<div class="form-group col-lg-4">
									<!--<img src="<?= base_url('assets/images/1000x450.png') ?>" class=" img-responsive ban_img_prev" id="item-img-output_2" >-->
									<img class=" img-responsive  ban_img_prev" id="item-img-output_2" src="<?= (isset($banners[1]) && isset($banners[1]))?base_url('../../'.$banners[1]):'' ?>" onerror="this.src='<?=base_url("assets/images/1000x450.png")?>'" >
								</div>
							  <!---------------------Banner 3------------------------>
							  <div class="form-group col-lg-8">
								<label class="text-uppercase center-block">Banner 3 <span class="small text-lowercase font-light text-info"> (recommended 1000 x 450 image) </span></label> 
								 <input type="file" class="form-control item-img center-block" name="banner_3" id = "banner_3" onchange="readURL(this,'item-img-output_3');" >
							  </div>
								<div class="form-group col-lg-4">
									<!--<img src="<?= base_url('assets/images/1000x450.png') ?>" class=" img-responsive  ban_img_prev" id="item-img-output_3" >-->
									<img class=" img-responsive  ban_img_prev" id="item-img-output_3" src="<?= (isset($banners[2]) && isset($banners[2]))?base_url('../../'.$banners[2]):'' ?>" onerror="this.src='<?=base_url("assets/images/1000x450.png")?>'" >
								</div>
					  </div>
					  <div class="box-footer">
					   <div class="col text-center">       
						  <button id="AddbannerSubmit" style="width: 100px;" type="submit" class="btn btn-success">Submit</button>
						</div>
					  </div>
					  </form>
				</div>
		   
       </div> 
     </div>
   </div>
   	<!-- modal -->
	<div class="modal fade " id="cropImagePop" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div id="upload-demo" class="center-block"></div>
				  </div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" id="cropImageBtn" class="btn btn-primary">Crop</button>
				  </div>
			</div>
		</div>
	</div>
	<!-- modal -->
</section>
<!--Croppie JS Start-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.js"></script>
<!--Croppie JS End-->
<script>
		// Start upload preview image
		var $uploadCrop, tempFilename, rawImg, imageId;
		function readFile(input) 
		{
			if (input.files && input.files[0]) 
			{
				var reader = new FileReader();
				reader.onload = function (e) 
				{
					$('.upload-demo').addClass('ready');
					$('#cropImagePop').modal('show');
					rawImg = e.target.result;
				}
				reader.readAsDataURL(input.files[0]);
			}
			else 
			{
				swal("Sorry - you're browser doesn't support the FileReader API");
			}
		}
		$uploadCrop = $('#upload-demo').croppie({
			viewport: 
			{
					width: 500,
					height: 225,
			},
			enforceBoundary: false,
			enableExif: true
			});
			$('#cropImagePop').on('shown.bs.modal', function()
			{
				// alert('Shown pop');
				$uploadCrop.croppie('bind', {url: rawImg}).then(function()
					{
				        console.log('jQuery bind complete');
				    });
			});
			$('.item-img').on('change', function () 
			{ 
				imageId = $(this).data('id'); 
				tempFilename = $(this).val();
				$('#cancelCropBtn').data('id', imageId); readFile(this); 
			});
			$('#cropImageBtn').on('click', function (ev) 
			{
				$uploadCrop.croppie('result', 
				{
					type: 'base64',
					format: 'jpeg',
					size: {width: 1000, height: 450
				}}).then(function (resp) 
				{
			
					$('#cropImagePop').modal('hide');
					 
				});
			});
				// End upload preview image

</script>
<!--View Image -->
<script>
	function readURL(input, dec_id) 
	{
		if (input.files && input.files[0]) 
		{
    		var reader = new FileReader();
    		reader.onload = function(e) 
			{
        		$('#' + dec_id).attr('src', e.target.result);
    		};
    	reader.readAsDataURL(input.files[0]);
		}
    }
</script>
<script>

 $(document).ready(function() {
    active("advertisement_side_menu"); 
 });

</script>
</div>
