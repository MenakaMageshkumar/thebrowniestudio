<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Banner | View Banner</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .error_msg{
        color: red;
        font-weight: 700;
    }
     .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
    }
    .p_3_font_13
    {
        padding-left: 3px!important;
        padding-right:3px!important;
        padding-top:10px!important;
        padding-bottom:10px!important;
        font-size: 12.5px!important;
    }
    </style>
  </head>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?= $pTitle ?><small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">

        <div class="col-md-12">
            <div class="box box-warning">
                <div class="box-header with-border">
                    <div class="col-md-6">
                        <h3 class="box-title">Banner List</h3>
                     </div>
                    <div class="col-md-6" align="right">
                        <a class="btn btn-sm btn-primary" href="<?= base_url() ?>">Back</a>
                    </div>
                </div>
                  <div class="box-body table-responsive">
                    <table class="table table-bordered table-striped datatable " id="example">
                        <thead>
                            <tr>
                                 <th width="2%" class="text-center p_3_font_13 text-uppercase">S.NO</th>
                                <th width="150px" class="text-center p_3_font_13 text-uppercase">Banner 1</th>
                                <th width="150px;" class="text-center p_3_font_13 text-uppercase">Banner 2</th>
                                <th width="150px;" class="text-center p_3_font_13 text-uppercase">Banner 3</th>
                                <!--<th width="150px;">STATUS</th>-->
                                <th width="300px;" class="text-center p_3_font_13 text-uppercase">Update</th>
                            </tr>
                      </thead> 
                      <tbody>
                        <!--Loop Start-->
                        <?php if(isset($banner[0]->strweb_banners)){  
                        $i =1; ?>
                        <tr>
                            <td class="center text-center p_3_font_13"><?= $i++ ?></td>
                            <td class="center text-center p_3_font_13">
                                <?php $banners =explode('|',$banner[0]->strweb_banners); ?>
                                <img src="<?= (isset($banners[0]) && isset($banners[0]))?base_url('../../'.$banners[0]):'' ?>" onerror="this.src='<?=base_url("assets/images/1000x450.png")?>'" class="cpoint" style="height:112.5px;width:225px;object-fit:contain" />
                            </td>
                            <td class="center text-center p_3_font_13">
                                <img src="<?= (isset($banners[1]) && isset($banners[1]))?base_url('../../'.$banners[1]):'' ?>" onerror="this.src='<?=base_url("assets/images/1000x450.png")?>'" class="cpoint" style="height:112.5px;width:225px;object-fit:contain" />
                            </td>
                            <td class="center text-center p_3_font_13">
                               <img src="<?= (isset($banners[2]) && isset($banners[2]))?base_url('../../'.$banners[2]):'' ?>" onerror="this.src='<?=base_url("assets/images/1000x450.png")?>'" class="cpoint" style="height:112.5px;width:225px;object-fit:contain" />
                            </td>
                            <!--<td class="center">-->
                            <!--     <a class="btn btn-sm btn-success" href="">-->
                            <!--        Active-->
                            <!--    </a>-->
                            <!--    <a class="btn btn-sm btn-danger" style="display:none;" href="">-->
                            <!--        Inactive-->
                            <!--    </a>-->
                            <!--</td>-->
                             <!--------------------Banner Updated------------->
                            <td class="center text-center p_3_font_13">   
                                <a class="btn btn-sm btn-primary" href="<?php echo base_url('Advertisement/editBanner/'.encode_param($store_id))?>" >
                                    <i class="fa fa-fw fa-edit"></i>
                                    Edit
                                </a> 
                               
                            </td>
                        </tr>
                        <?php } ?>
                        <!--Loop End -->
                        
                      </tbody>
                    </table>
                </div>
            </div> 
      </div>
    </div>
 </section>
 <script>

 $(document).ready(function() {
    active("advertisement_side_menu"); 
 });

</script>
</div>