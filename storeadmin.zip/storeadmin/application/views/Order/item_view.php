<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">-->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >

    <title>View Item Data</title>
    <style>
        .text_line_cus {
            text-decoration: underline;
        }
        .border_bottom_cus {
            border-bottom: 1px solid #000;
        }
        .font_600_cus {
            font-weight: 600;
            font-size: 14px;
        }
        .border_bottom_cus span
        {
            font-size: 13px;
        }
        table td
        {
              font-size: 13px!important;
        }
        /* Style the tab */
        .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
        }
        
        /* Style the buttons inside the tab */
        .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
        }
        
        /* Change background color of buttons on hover */
        .tab button:hover {
        background-color: #ddd;
        }
        
        /* Create an active/current tablink class */
        .tab button.active {
        background-color: #ccc;
        }
        
        /* Style the tab content */
        .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid  p-2" >
        <div class="tab">
                      <!--<button class="tablinks" onclick="openCity(event, 'print_1_tab')" id="defaultOpen">Product 1</button>-->
            <?php $i = 1; foreach($orderData as $ord){
                if($i==1){ ?>
              <button class="tablinks" onclick="openCity(event, '<?php echo 'print_'.$i.'_tab'?>')" id="defaultOpen">Product <?php echo $i; ?></button>
              <?php }else { ?>
                <button class="tablinks" onclick="openCity(event, '<?php echo 'print_'.$i.'_tab'?>')">Product <?php echo $i; ?></button>
          <?php }$i++;} ?>
        </div>
        <?php $i = 1; foreach($orderData as $ord){ ?>
        
        <div id="<?php echo 'print_'.$i.'_tab'?>" class="tabcontent">
               <h3>Product <?php echo $i; ?></h3>
           <div id="print_<?php echo $i; ?>">
                <div class="p-2" style=" border: 4px solid #ccc;">
                     
                <!--------------manufacturing kot start-------------->
                <div>
                    <h5 class="text-uppercase text_line_cus">CHEF KOT</h5>
                    <div class="row col-12 pr-0 mb-3-removed">
                        <!---------------Columen first--------------->
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus text-uppercase">DELIVERY DATE / DAY</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <?php 
                                    $var = $ord['preferred_del_date'];
                                    ?>
                                    <span>:&nbsp;<?php  
                                    echo date("d-m-Y", strtotime($var) );?>&nbsp; /&nbsp;
                                   <?php echo date('l', strtotime($var));?>  
                                    </span>
                                </div>
                            </div>
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Summary Type</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;Normal from Menu / Customized Cakes</span>
                                </div>
                            </div>
                             <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Egg / Eggless</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['cake_type'];?></span>
                                </div>
                            </div>
                             <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Product Name </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['product_name'];?></span>
                                </div>
                            </div>
                             <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Shape</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['cake_shape'];?></span>
                                </div>
                            </div>
    
                        </div>
                         <!---------------Columen first end--------------->
                        <!---------------Columen second blank --------------->
                        <div class="col-1">
    
                        </div>
                          <!---------------Columen second blank end --------------->
                        <!---------------Columen third --------------->
                        <div class="col row">
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">DELIVERY TIME </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;
                                    <?php 
                                    $real_time = $ord['preferred_del_time'];
                                    
                                    // first 4 first value
                                    $first_val = substr($real_time, 0, 7);
                                    // last 4 digit value
                                    $totime = substr($real_time, -7);

                                    //  echo $totime;
                                    $date = $totime;
                                    $final_val_last = date('h:ia', strtotime("-30 minutes", strtotime($date)));
                                    echo $first_val.'&nbsp;to&nbsp;'.$final_val_last; 
                                     
                                 
                                    ?> 
                                    </span>
                                    <!--( Delivery Time - 1 hour )-->
                                </div>
                            </div>
                             <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">ORDER ID </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['orderid']; ?></span>
                                </div>
                            </div>
                            <div class="col-12 row">
                                <div class="col row pr-0 ">
                                    <img src="<?php echo base_url('../../'.$ord['product_image']); ?>" class="img-fluid w-25 h-100 mx-auto " />
                                </div>
                            </div>
    
                        </div>
                           <!---------------Columen third end --------------->
                    </div>
                    
                     <!------------cake detail start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Cake Details</span></td>
                                <td style="width: 2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp;
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    <!--------------cake detail end-------------->
                     <!------------topper detail start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Topper</span></td>
                                <td style="width: 2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp;Customized / Happy Birthday / Happy Anniversary / Congrats / Others - mention below
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    <!--------------topper detail end-------------->
                    <!------------msg detail start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;"  class="border_bottom_cus mr-1"> <span class="font_600_cus">Msg On Cake </span></td>
                                <td style="width: 2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp;<?php  echo $ord['message_on_cake']?>
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    <!--------------msg detail end-------------->
                    <!------------note to chef  start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Notes to Chef  </span></td>
                                <td style="width: 2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp;<?php  echo $ord['notes_on_chef']?>
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    <!--------------note to chef end-------------->
    
                    <!--line start-->
                     <div class="col-12 mb-3-removed pl-0" style="padding-right: 43px;">
                          <hr style=" height: 3px; background: #ccc;" />
                         <hr  style=" height: 3px; background: #ccc;" />
                    </div>
                    <!--line end-->
                </div>
                 <!--------------manufacturing kot end-------------->
                <!--------------QUALITY CHECK LIST-------------->
                 <div>
                   
                    <div class="row col-12 pr-0 mb-3-removed">
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col pl-0 mr-1 ">
                                    <h5 class="text-uppercase text_line_cus">QUALITY CHECKLIST</h5>
                                </div>
                                <div class="col pl-0 ">
                                   
                                </div>
                            </div>
                         
                        </div>
                        <div class="col-1">
    
                        </div>
                        <div class="col row">
                            
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">ORDER DATE</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                   <?php $var_d = $ord['booking_date']; ?>
                                   
                                    <span>:&nbsp;<?php  echo date("d-m-Y H:i:s", strtotime($var_d) );   ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row col-12 pr-0 mb-3-removed">
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Product Name</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['product_name'];?></span>
                                </div>
                            </div>
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Shape</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['cake_shape'];?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-1">
    
                        </div>
                        <div class="col row">
                         
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">ORDER ID </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['orderid'];?></span>
                                </div>
                            </div>
                            
                           <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus text-uppercase">Delivery Date / Day  </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                     <?php 
                                            $var_2 = $ord['preferred_del_date'];
                                        ?>
                                        <span>:&nbsp;<?php  echo date("d-m-Y", strtotime($var_2) );?>  &nbsp;/&nbsp; <?php
 
                                            echo date('l', strtotime($var_2));
                                        ?> </span>
                                    <!--<span>:&nbsp;<?php echo $ord['preferred_del_date'];?></span>-->
                                </div>
                            </div>
                            
                        
                            
                        </div>
                    </div>
                     <!------------cake detail start-------------->
                        <div class="row col-12 pr-0 mb-3-removed">
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Cake Details </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;</span>
                                </div>
                            </div>
                         
                        </div>
                        <div class="col-1">
    
                        </div>
                        <div class="col row">
                            
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">DELIVERY TIME</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp; <?php 
                                     $real_time = $ord['preferred_del_time'];
                                    // first 4 first value
                                    $first_val = substr($real_time, 0, 7);
                                    // last 4 digit value
                                    $totime = substr($real_time, -7);
                                     //  echo $totime;
                                    $date = $totime;
                                    $final_val_last = date('h:ia', strtotime("-30 minutes", strtotime($date)));
                                    echo $first_val.'&nbsp;to&nbsp;'.$final_val_last; 
                                    ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--------------cake detail end-------------->
                     <!------------topper detail start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Topper</span></td>
                                <td style="width: 2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp;
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    <!--------------topper detail end-------------->
                    <!------------msg detail start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Msg On Cake  </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['message_on_cake'];?></span>
                                </div>
                            </div>
                         
                        </div>
                        <div class="col-1">
    
                        </div>
                        <div class="col row">
                            
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Notes to Chef </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['notes_on_chef'];?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--------------msg detail end-------------->
                   
                     <!------------Notes to Quality Team  start-------------->
                     
                    <!--------------Notes to Quality Team end-------------->
                  
                     <!------------is everything okay start-------------->
                       <div class="row col-12 pr-0 mb-3-removed">
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <table class="col-12">
                                    <tr>
                                        <td style="width: 150px;" class=" mr-1"> <span class="font_600_cus">Is everything correct  & added? </span></td>
                                        <td style="width: 2px;"></td>
                                        <td class="">
                                            :&nbsp;
                                        </td>
                                        <td style="width: 30px;"></td>
                                    </tr>
                                     <tr>
                                        <td style="width: 100%;" class=" mr-1"> 
                                        <textarea class="form-control rounded-0" row="2" style="border: 1px solid #000;"></textarea>
                                        </td>
                                      
                                    </tr>
                                    
                                </table>
                            </div>
                         
                        </div>
                        <div class="col-1">
    
                        </div>
                        <div class="col row">
                            
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Notes to Quality Team </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;</span>
                                </div>
                            </div>
                             <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus"> Notes to Delivery Team </span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                       <div class="row col-12 pr-0 mb-3-removed">
                       
    
                    </div>
                    <!--------------is everything okay  end-------------->
                    
                    
                     <div class="row col-12 pr-0 mb-3-removed">
                        <div class="col row">
                            <div class="col-12 row mb-auto pb-2 pr-0">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Is it a Gift ?</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;<?php echo $ord['gift'];?></span>
                                </div>
                            </div>
                         
                        </div>
                        <div class="col-1">
    
                        </div>
                        <div class="col row">
                            
                            <div class="col-12 row mb-auto ">
                                <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                    <span class="font_600_cus">Ribbon Pack?</span>
                                </div>
                                <div class="col pl-0 border_bottom_cus">
                                    <span>:&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <!--line start-->
                     <div class="col-12 mb-3-removed pl-0" style="padding-right: 43px;">
                          <hr style=" height: 3px; background: #ccc;" />
                         <hr  style=" height: 3px; background: #ccc;" />
                    </div>
                    <!--line start-->
                </div>
                 <!--QUALITY CHECK LIST End-->
                <!--DELIVERY KOT start-->
                 <div>
                    <h5 class="text-uppercase text_line_cus">DELIVERY CHECKLIST</h5>
                    
                      <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Product Name</span></td>
                                <td style="width:2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp; <?php echo $ord['product_name']; ?>
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    
                      <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Notes to Delivery Team</span></td>
                                <td style="width:2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp; 
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    
                      <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td style="width: 150px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Msg On Cake</span></td>
                                <td style="width: 2px;"></td>
                                <td class="border_bottom_cus">
                                    :&nbsp; <?php echo $ord['message_on_cake']; ?>
                                </td>
                                <td style="width: 30px;"></td>
                            </tr>
                        </table>
    
                    </div>
                    
                        <div class="row col-12 pr-0 mb-3-removed">
                            <div class="col row">
                                <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">DELIVERY DATE  </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                         <?php 
                                            $var_1 = $ord['preferred_del_date'];
                                        ?>
                                        <span>:&nbsp;<?php  echo date("d-m-Y", strtotime($var_1) ); ?> </span>
                                    </div>
                                </div>
                             
                            </div>
                            <div class="col-1">
        
                            </div>
                            <div class="col row">
                                
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">DELIVERY TIME</span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;
                                        <?php
                                        $real_time = $ord['preferred_del_time'];
                                    // first 4 first value
                                    $first_val = substr($real_time, 0, 7);
                                    // last 4 digit value
                                    $totime = substr($real_time, -7);
                                     //  echo $totime;
                                    $date = $totime;
                                    $final_val_last = date('h:ia', strtotime("-30 minutes", strtotime($date)));
                                    echo $first_val.'&nbsp;to&nbsp;'.$final_val_last; 
                                        
                                        ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <!--location start-->
                   
                     <h5 class="text-uppercase "> LOCATION</h5>
                     <div class="row col-12 pr-0 mb-3-removed">
                            <div class="col row">
                                <!--Door No-->
                                <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Door No </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['address1'];?></span>
                                    </div>
                                </div>
                                 <!--Door No end-->
                                  <!--Flat/ Individual-->
                                <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Flat / Individual House </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;</span>
                                    </div>
                                </div>
                                 <!--Area  end-->
                                 <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Area  </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['area'];?></span>
                                    </div>
                                </div>
                                 <!--Area  end-->
                                 <!--Land Mark end-->
                                 <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Land Mark  </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['landmark'];?></span>
                                    </div>
                                </div>
                                 <!--Land Mark  end-->
                                 <!--Mobile Number end-->
                                 <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Mobile Number </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;+91<?php echo $ord['deliveryto_contact'];?></span>
                                    </div>
                                </div>
                                 <!--Mobile Number end-->
                             
                            </div>
                            <div class="col-1">
        
                            </div>
                            <div class="col row">
                                 <!--Apartment name -->
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Apartment Name </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;</span>
                                    </div>
                                </div>
                                 <!--Apartment name end-->
                                 <!--Street Name -->
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Street Name </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['address2'];?></span>
                                    </div>
                                </div>
                                 <!--Street Name end-->
                                  <!--Pincode Name -->
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Pincode </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['pincode'];?></span>
                                    </div>
                                </div>
                                 <!--Pincode Name end-->
                                   <!--blank space -->
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 ">
                                        <span class="font_600_cus"></span>
                                    </div>
                                    <div class="col pl-0 ">
                                        <span>&nbsp;</span>
                                    </div>
                                </div>
                                 <!--blank space end-->
                                   <!--Alternate  / Emergency Name -->
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Alternate / Emergency No:</span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;+91<?php echo $ord['orderby_contact'];?></span>
                                    </div>
                                </div>
                                 <!--Alternate  / Emergency end-->
                            </div>
                        </div>
                    <!--location end-->
                      <h5 class="text-uppercase  text-danger"> EMERGENCY NUMBER</h5>
                       <div class="row col-12 pr-0 mb-3-removed">
                            <div class="col row">
                                <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Ordered By  </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['orderby_name'].'  +91'.$ord['orderby_contact'];?></span>
                                    </div>
                                </div>
                             
                            </div>
                            <div class="col-1">
        
                            </div>
                            <div class="col row">
                                
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Delivery To</span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['deliveryto_name'].'  +91'.$ord['deliveryto_contact'];?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <div class="row col-12 pr-0 mb-3-removed">
                            <div class="col row">
                                <div class="col-12 row mb-auto pb-2 pr-0">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Is it a Gift ?  </span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;<?php echo $ord['gift'];?></span>
                                    </div>
                                </div>
                             
                            </div>
                            <div class="col-1">
        
                            </div>
                            <div class="col row">
                                
                                <div class="col-12 row mb-auto ">
                                    <div class="col-4 pl-0 mr-1 border_bottom_cus">
                                        <span class="font_600_cus">Ribbon Pack?</span>
                                    </div>
                                    <div class="col pl-0 border_bottom_cus">
                                        <span>:&nbsp;</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <div class="row col-12 pr-0 mb-3-removed">
                        <table class="col-12">
                            <tr>
                                <td  class="mr-1"> <span class="font_600_cus">Call Brownie Studio @ 8939- 300-108 | @ 8939-621-467 | @866-76-20-320</span></td>
                            </tr>
                        </table>
    
                    </div>
                 
                </div>
                 <!--DELIVERY KOT End-->
                </div>
            </div>
       
          <div class="print-button mt-3">

            <span class="print-button__content btn btn-success px-3 py-2 js__action--print" onclick="printDiv('<?php echo 'print_'.$i.'_tab'?>')" title="Print this page">
                Print
            </span>

        </div>
        </div>
         <?php $i++; } ?>
         <!-----------------------------print 2---------------------------------------------->
        <!-- <div id="print_2_tab" class="tabcontent">-->
        <!--       <h3>Product 2</h3>-->
        <!--   <div id="print_2">-->
        <!--        <div class="p-2" style=" border: 4px solid #ccc;">-->
            <!--------------manufacturing kot start-------------->
        <!--    <div>-->
        <!--        <h5 class="text-uppercase text_line_cus">CHEF KOT</h5>-->
        <!--        <div class="row col-12 pr-0 mb-3-removed">-->
                    <!---------------Columen first--------------->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">DELIVERY DATE/DAY</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Summary Type</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Normal from Menu/ Customized Cakes</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                 <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Egg / Eggless</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Egg</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                 <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Product Name </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Classic Cake - Caramelized White Chocolate - 1kg</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                 <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Shape</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Round/ Heart / Square</span>-->
        <!--                    </div>-->
        <!--                </div>-->

        <!--            </div>-->
                     <!---------------Columen first end--------------->
                    <!---------------Columen second blank --------------->
        <!--            <div class="col-1">-->

        <!--            </div>-->
                      <!---------------Columen second blank end --------------->
                    <!---------------Columen third --------------->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">DELIVERY TIME </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;( Delivery Time - 1 hour )</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                 <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Order ID : </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                <div class="col-12 row">-->
        <!--                    <div class="col row pr-0 ">-->
        <!--                        <img src="https://b.zmtcdn.com/data/pictures/chains/5/18564675/009928ad4e39cc9debcf6c45bd07d856.jpg" class="img-fluid w-25 h-100 mx-auto " />-->
        <!--                    </div>-->
        <!--                </div>-->

        <!--            </div>-->
                       <!---------------Columen third end --------------->
        <!--        </div>-->
                
                 <!------------cake detail start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Cake Details</span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp;-->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                <!--------------cake detail end-------------->
                 <!------------topper detail start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Topper</span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp;Customized / Happy Birthday/ Happy Anniversary/ Congrats / Others - mention below-->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                <!--------------topper detail end-------------->
                <!------------msg detail start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;"  class="border_bottom_cus mr-1"> <span class="font_600_cus">Msg On Cake </span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp;-->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                <!--------------msg detail end-------------->
                <!------------note to chef  start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Notes to Chef  </span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp;-->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                <!--------------note to chef end-------------->

                <!--line start-->
        <!--         <div class="col-12 mb-3-removed pl-0" style="padding-right: 43px;">-->
        <!--              <hr style=" height: 3px; background: #ccc;" />-->
        <!--             <hr  style=" height: 3px; background: #ccc;" />-->
        <!--        </div>-->
                <!--line end-->
        <!--    </div>-->
             <!--------------manufacturing kot end-------------->
            <!--------------QUALITY CHECK LIST-------------->
        <!--     <div>-->
               
        <!--        <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col pl-0 mr-1 ">-->
        <!--                        <h5 class="text-uppercase text_line_cus">QUALITY CHECKLIST</h5>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 ">-->
                               
        <!--                    </div>-->
        <!--                </div>-->
                     
        <!--            </div>-->
        <!--            <div class="col-1">-->

        <!--            </div>-->
        <!--            <div class="col row">-->
                        
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">ORDER DATE</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Tue Jan 11 2022 07:55:39 pm</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--        <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Product Name</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Classic Cake - Caramelized White Chocolate  - 1kg</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Shape</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;Round/ Heart / Square</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--            <div class="col-1">-->

        <!--            </div>-->
        <!--            <div class="col row">-->
                     
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">ORDER ID </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
                        
        <!--               <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Delivery Date/ Day  </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
                        
                    
                        
        <!--            </div>-->
        <!--        </div>-->
                 <!------------cake detail start-------------->
        <!--            <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Cake Details </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
                     
        <!--            </div>-->
        <!--            <div class="col-1">-->

        <!--            </div>-->
        <!--            <div class="col row">-->
                        
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">DELIVERY TIME</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;( Delivery Time - 1 hour )</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
                <!--------------cake detail end-------------->
                 <!------------topper detail start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Topper</span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp;-->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                <!--------------topper detail end-------------->
                <!------------msg detail start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Msg On Cake  </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
                     
        <!--            </div>-->
        <!--            <div class="col-1">-->

        <!--            </div>-->
        <!--            <div class="col row">-->
                        
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Notes to Chef </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
                <!--------------msg detail end-------------->
               
                 <!------------Notes to Quality Team  start-------------->
        <!--         <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Notes to Quality Team </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
                     
        <!--            </div>-->
        <!--            <div class="col-1">-->

        <!--            </div>-->
        <!--            <div class="col row">-->
                        
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Notes to Delivery Team  </span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
                <!--------------Notes to Quality Team end-------------->
              
                 <!------------is everything okay start-------------->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Is everything correct  & added? </span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp;-->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                <!--------------is everything okay  end-------------->
                
                
        <!--         <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <div class="col row">-->
        <!--                <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Is it a Gift ?</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
                     
        <!--            </div>-->
        <!--            <div class="col-1">-->

        <!--            </div>-->
        <!--            <div class="col row">-->
                        
        <!--                <div class="col-12 row mb-auto ">-->
        <!--                    <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                        <span class="font_600_cus">Ribbon pack?</span>-->
        <!--                    </div>-->
        <!--                    <div class="col pl-0 border_bottom_cus">-->
        <!--                        <span>:&nbsp;</span>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
                
                
                <!--line start-->
        <!--         <div class="col-12 mb-3-removed pl-0" style="padding-right: 43px;">-->
        <!--              <hr style=" height: 3px; background: #ccc;" />-->
        <!--             <hr  style=" height: 3px; background: #ccc;" />-->
        <!--        </div>-->
                <!--line start-->
        <!--    </div>-->
             <!--QUALITY CHECK LIST End-->
            <!--DELIVERY KOT start-->
        <!--     <div>-->
        <!--        <h5 class="text-uppercase text_line_cus">DELIVERY CHECKLIST</h5>-->
                
        <!--          <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Product Name</span></td>-->
        <!--                    <td style="width:2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp; -->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                
        <!--          <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Notes to Delivery Team</span></td>-->
        <!--                    <td style="width:2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp; -->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                
        <!--          <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td style="width: 192px;" class="border_bottom_cus mr-1"> <span class="font_600_cus">Msg On Cake</span></td>-->
        <!--                    <td style="width: 2px;"></td>-->
        <!--                    <td class="border_bottom_cus">-->
        <!--                        :&nbsp; -->
        <!--                    </td>-->
        <!--                    <td style="width: 30px;"></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
                
        <!--            <div class="row col-12 pr-0 mb-3-removed">-->
        <!--                <div class="col row">-->
        <!--                    <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">DELIVERY DATE  </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                         
        <!--                </div>-->
        <!--                <div class="col-1">-->
    
        <!--                </div>-->
        <!--                <div class="col row">-->
                            
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">DELIVERY TIME</span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;( Delivery Time - 1 hour )</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
                <!--location start-->
               
        <!--         <h5 class="text-uppercase text_line_cus"> LOCATION</h5>-->
        <!--         <div class="row col-12 pr-0 mb-3-removed">-->
        <!--                <div class="col row">-->
                            <!--Door No-->
        <!--                    <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Door No </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Door No end-->
                              <!--Flat/ Individual-->
        <!--                    <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Flat/ Individual House </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Area  end-->
        <!--                     <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Area  </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Area  end-->
                             <!--Land Mark end-->
        <!--                     <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Land Mark  </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Land Mark  end-->
                             <!--Mobile Number end-->
        <!--                     <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Mobile Number </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Mobile Number end-->
                         
        <!--                </div>-->
        <!--                <div class="col-1">-->
    
        <!--                </div>-->
        <!--                <div class="col row">-->
                             <!--Apartment name -->
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Apartment name </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Apartment name end-->
                             <!--Street Name -->
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Street Name </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Street Name end-->
                              <!--Pincode Name -->
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Pincode </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Pincode Name end-->
                               <!--blank space -->
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 ">-->
        <!--                            <span class="font_600_cus"></span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 ">-->
        <!--                            <span>&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--blank space end-->
                               <!--Alternate  / Emergency Name -->
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Alternate  / Emergency no:</span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                             <!--Alternate  / Emergency end-->
        <!--                </div>-->
        <!--            </div>-->
                <!--location end-->
        <!--          <h5 class="text-uppercase text_line_cus text-dark"> EMERGENCY NUMBER</h5>-->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--                <div class="col row">-->
        <!--                    <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Ordered By  </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                         
        <!--                </div>-->
        <!--                <div class="col-1">-->
    
        <!--                </div>-->
        <!--                <div class="col row">-->
                            
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Delivery to</span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--                <div class="col row">-->
        <!--                    <div class="col-12 row mb-auto pb-2 pr-0">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Is it a Gift ?  </span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
                         
        <!--                </div>-->
        <!--                <div class="col-1">-->
    
        <!--                </div>-->
        <!--                <div class="col row">-->
                            
        <!--                    <div class="col-12 row mb-auto ">-->
        <!--                        <div class="col-4 pl-0 mr-1 border_bottom_cus">-->
        <!--                            <span class="font_600_cus">Ribbon pack?</span>-->
        <!--                        </div>-->
        <!--                        <div class="col pl-0 border_bottom_cus">-->
        <!--                            <span>:&nbsp;</span>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--           <div class="row col-12 pr-0 mb-3-removed">-->
        <!--            <table class="col-12">-->
        <!--                <tr>-->
        <!--                    <td  class="mr-1"> <span class="font_600_cus">Call Brownie Studio @ 8939- 300-108 | @ 8939-621-467 | @866-76-20-320</span></td>-->
        <!--                </tr>-->
        <!--            </table>-->

        <!--        </div>-->
             
        <!--    </div>-->
             <!--DELIVERY KOT End-->
        <!--</div>-->
        <!--    </div>-->
        <!--        <div class="print-button mt-3">-->

        <!--    <span class="print-button__content btn btn-success px-3 py-2 js__action--print" onclick="printDiv('print_2')" title="Print this page">-->
        <!--        Print-->
        <!--    </span>-->

        <!--</div>-->
        <!--    </div>-->
         <!-----------------------------print 2 End---------------------------------------------->
    </div>
   


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!--print-->
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
    <!--print-->
    <!--tab-->
    <script>
        function openCity(evt, cityName) {
          var i, tabcontent, tablinks;
          tabcontent = document.getElementsByClassName("tabcontent");
          for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
          }
          tablinks = document.getElementsByClassName("tablinks");
          for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
          }
          document.getElementById(cityName).style.display = "block";
          evt.currentTarget.className += " active";
        }
        
        document.getElementById("defaultOpen").click();
</script>
     <!--tab-->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>