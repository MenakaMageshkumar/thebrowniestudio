<?php
// echo '<pre>';
// print_r($orderData);
// die;
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Orders | Completed</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
   <style>
  .datatable tbody th { font-weight: inherit; }
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
  </style>
<div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?>&nbsp &nbsp<small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-sm-12">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
           <button class="close" data-dismiss="alert" type="button">×</button>
           <?= $flashdata['message'] ?>
         </div>
       <?php } ?>
      </div>
        <div class="col-xs-12">
          <div class="box box-warning"> 
            <div class="box-header with-border">
              <div class="col-md-6"><h3 class="box-title">Completed Orders - Invoice Details</h3></div>
              <div class="col-md-6" align="right">
                <?php if(!empty($orderData)){ ?>
                  
                <?php } ?>&nbsp &nbsp
                <a class="btn btn-sm btn-primary" href="<?= base_url('Order/ViewOrders') ?>">Back</a>
              </div>
            </div> 
            <br>   
            <div class="box-body table-responsive">
              <table  class="table table-bordered table-striped datatable" id="example">
                <thead>
                  <tr>
                     <th width="2%" class="text-center p_3_font_13">S.NO</th>
                    <th width="6%;" class="text-center p_3_font_13">ORDER ID</th>
                    <th width="10%;" class="text-center p_3_font_13">ORDER DATE</th>
                    <th width="10%;" class="text-center p_3_font_13">ORDER PERSON NAME</th>
                    <th width="10%;" class="text-center p_3_font_13">ORDER PHONE NUMBER</th>
                    <th width="23%;" class="text-center p_3_font_13">DELIVERY ADDRESS</th>
                    <th width="10%;" class="text-center p_3_font_13">DELIVERY PHONE NUMBER</th>
                   <th width="10%;" class="text-center p_3_font_13">DELIVERY DATE</th>
                    <th width="10%;" class="text-center p_3_font_13">ITEMS</th>
                    <th width="7%;" class="text-center p_3_font_13">₹TOTAL(INC)</th>
                    <th  class="text-center p_3_font_13">DELIVERY TYPE</th>
                    <th  class="text-center p_3_font_13">STATUS</th>
                    <th width="23%;" class="text-center p_3_font_13">ACTION</th>
                 </tr>
                </thead> 
                <tbody>
                  <?php 
               
                  if(!empty($orderData)){
                       $i =1;
                       
                    foreach($orderData as $odrData) { ?>
                      <tr>
                          
                        <th class="center text-center p_3_font_13"><?= $i++ ?></th>
                        <th class="center text-center p_3_font_13"><?= $odrData->UTN_number ?></th>
                        <th class="center text-center p_3_font_13"><?php
                        $dt_frmt=date_create($odrData->booking_time);
                        echo  date_format($dt_frmt,"d/m/Y"); ?> <br> <?php
                        echo  date_format($dt_frmt," h:i A");
                     
                          ?><br>
                         
                          </strong>
                          </th>
                        <?php if($this->session->userdata['user_type']==1){ ?>
                    <th class="center text-center p_3_font_13"><?= $odrData->store_name ?></th>
                    <?php } ?>
                    <th  class="center text-center p_3_font_13"><?= $odrData->orderby_name ?></th>
                     <th  class="center text-center p_3_font_13 ">+91<?= $odrData->orderby_contact ?></th>
                     
                     
                        <th class="center ">
                            <?php  if($odrData->address2 == "")
                            {
                               
                                $address_2_commo = "";
                                
                            }
                            else
                            {
                                $address_2_commo = ",";
                            }
                            
                            ?>
                        <?= $odrData->deliveryto_name.', 
                        '.$odrData->address1.',
                        '.$odrData->address2.' '.$address_2_commo.'
                        '.$odrData->landmark.', 
                        '.$odrData->area.', '.$odrData->city.',
                        '.$odrData->district.', 
                        '.$odrData->state.' - '.$odrData->pincode;
                         ?></th>
                        <th class="center text-center p_3_font_13">+91<?
                        // $phone_no = substr($odrData->deliveryto_contact,2); //remove country code 91
                         $phone_no = $odrData->deliveryto_contact; //remove country code 91
                        echo $phone_no; ?></th>
                        <th class="center text-center p_3_font_13">
                             <?php 
                             $order_id = $odrData->order_id;
                             $get_deltiming = $this->db->query("select preferred_del_date,preferred_del_time from cart where order_id =$order_id")->result();
                             if($get_deltiming){
                                 $dt_frmt_1 = date_create($get_deltiming[0]->preferred_del_date);
                                 $dt_frmt_2=($get_deltiming[0]->preferred_del_time);
                             }
                           ?>
                        <strong> <?php echo  date_format($dt_frmt_1,"d/m/Y"); ?> <br> 
                        <?php echo  $dt_frmt_2 ;
                          ?>
                        </th>
                        <th class="center text-center p_3_font_13">
                          <a class="btn btn-sm btn-primary chk" href="#myModal" id="link" data-toggle="modal" data-id="<?= $odrData->order_id?>"><i class="fa fa-fw fa-eye"></i>Item Details</a>
                        </th>
                        <th class="center text-center p_3_font_13">
                            <?php 
                            // if($odrData->changesin_deliverycharge>0){
                            //     $total = $odrData->total_amount - $odrData->delivery_charge + $odrData->spent_deliverycharge;
                            // }else{
                            //     $total = $odrData->total_amount;
                            // }
                            $total = $odrData->total_amount;
                            echo $total ?></th>
                        <th class="center text-center p_3_font_13"><?php if($odrData->payment_method ==1)  echo 'Store pickup'; else echo 'Home Delivery'; ?></th>
                        <th class="center text-center p_3_font_13">
                            <?php 
                            $delivery_status = $odrData->delivery_status;
                            $delivery_status_flg = $odrData->delivery_status_flg;
                            $order_method = $odrData->payment_method; //1 for store pickup and 2 for home delivery
            if($delivery_status==0){
                 $delivery_status_text = 'Awaiting Store Confirmation'; //Order Placed
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $delivery_status_text = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $delivery_status_text = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $delivery_status_text = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $delivery_status_text = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //purle
            }
            else if($delivery_status==4 && $order_method==2 ){ //home delivery
                $delivery_status_text = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            else if($delivery_status==4 && $order_method==1 ){ //store pickup
                $delivery_status_text = 'Order Packed  & ready to Pickup';
                $delivery_sts_clr = '#a52a2a'; //brown
            }else if($delivery_status==5 && $delivery_status_flg ==0){
                $delivery_status_text = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }else if($delivery_status==6){
                $delivery_status_text = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }
            else{
                $delivery_status_text = 'Order Placed';//Order Placed
                $delivery_sts_clr = '#000000'; //black
            }
  ?>
                        
                <?php $curr_delivery_status = $odrData->delivery_status;
            if(($curr_delivery_status==4 || $curr_delivery_status==5) && $delivery_status_flg == 1 ){
            $curr_delivery_status = 2;    
            } ?>
                 <?php if($curr_delivery_status==2) { ?>
                                      <!--<select  name='delivery_status' id=<?php echo $odrData->UTN_number ?> onchange='submitOrderStatus(this)' >-->
                                      <!--  <option value="<?php echo ($curr_delivery_status == '0')?"selected":"" ?>">Select</option>-->
                                      <!--  <option value="3"  <?php echo ($curr_delivery_status == "3")?"selected":""?>><?php echo 'Returned';?></option>-->
                                      <!--  </select>-->
                                        <?php } ?>
                                        
                                         <div style="color:<?php echo $delivery_sts_clr ?>"> <?php echo $delivery_status_text;?></div>
                                        <?php
                                         if($odrData->payment_status ==1){
                                          $delivery_type ='Paid'; 
                                          $delivery_type_color ='#000000';
                                        } else { 
                                          $delivery_type ='Unpaid'; 
                                          $delivery_type_color ='#FF0000';
                                        }
                                        ?>
                                        <div style="color:<?php echo $delivery_type_color ?>"> <?php echo $delivery_type;?></div>
                                        
                                        <?php //if($delivery_status!=6 || $delivery_status==3){ //don't allow payment for cancelled & returned order?> 
                                        <!--<select  name='payment_status' id=<?php echo $odrData->UTN_number ?> onchange='submitPaymentStatus(this)' >-->
                                        <!--<option value="0"  <?php echo ($odrData->payment_status == "0")?"selected":""?>><?php echo 'Unpaid';?></option>-->
                                        <!--<option value="1"  <?php echo ($odrData->payment_status == "1")?"selected":""?>><?php echo 'Paid';?></option>-->
                                        <!--</select>-->
                                        <?php //} ?>
                                        
                                        </th>
                                        <?php if($odrData->inv_no !='') {?>
                                        <th class="center text-center p_3_font_13">
                                            <a class="btn btn-sm btn-pri mb-3" style="margin-left: 15px;" target="_blank" href="<?= base_url("../home/invoice/".$odrData->store_id)."/".$odrData->UTN_number."/".$odrData->inv_no ?>">View Invoice</a> &emsp; 
                                            <a class="btn btn-sm btn-sec" href="<?= base_url("../home/invoice/".$odrData->store_id)."/".$odrData->UTN_number."/".$odrData->inv_no ?>" download="order-<?php echo $odrData->inv_no.".html" ?>">Print Invoice</a>
                                        </th>
                                        <?php } else { ?>
                                        <th class="center text-center p_3_font_13"></th>
                                        <?php } ?>
                      </tr>
                  <?php } }?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </section>
</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Item Details</h4>
            </div>
            <div class="modal-body table-responsive">

            <strong>loading.</strong>        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div> 
</div>
<script>
 $('.chk').on('click',function(){
            var order_id=$(this).data('id');
            // alert(order_id);
    $('.modal-body').html('loading');
       $.ajax({
    	url:'<?php echo base_url() ?>order/get_itemdata',
		type:'POST',
		data:'order_id='+order_id,
        success: function(data) {
          $('.modal-body').html(data);
        },
        error:function(err){
          alert("error"+JSON.stringify(err));
        }
    });
 });
 </script>
  <script>
    function submitOrderStatus(str){
      var order_status = str.value;
        var order_id = str.id;
        if(order_status){
    if(confirm('Do you want to submit?')){
           
            $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>order/submitOrderStatus",
           data: {order_status:order_status,order_id:order_id}, 
           success: function(data){
               //alert(data);
               if(data==200){
                   alert ("Order Status updated");
                location.reload();
               } else if(data==404){
                   alert ("Please update the previous status");
                location.reload();
               } else{
                  alert ("something went wrong contact admin!!");
                location.reload();    
               }
           }
           
         });
    
    }else{
        location.reload();
    }
        }
  else{
      alert('please change status');
  }
    }
</script>
 <script>
    function submitPaymentStatus(str){
      var payment_status = str.value;
        var order_id = str.id;
        if(payment_status){
    if(confirm('Do you want to submit?')){
           
            $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>order/submitPaymentStatus",
           data: {payment_status:payment_status,order_id:order_id}, 
           success: function(data){
               alert(data);
               if(data==200){
                   alert ("Payment Status updated");
                location.reload();
               } else if(data==404){
                   alert ("Please update the order status");
                location.reload();
               } else{
                  alert ("something went wrong contact admin!!");
                location.reload();    
               }
           }
           
         });
    
    }else{
        location.reload();
    }
        }
  else{
      alert('please change status');
  }
    }
</script>

<script>

 $(document).ready(function() {
    active("order_side_menu"); 
 });

</script>