<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Orders | Accepted</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    <link rel="stylesheet" type="text/css"  href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" type="text/css"  href="https://cdn.datatables.net/buttons/1.4.0/css/buttons.dataTables.min.css" />

    
  </head>
  <style>
  .datatable tbody th { font-weight: inherit; }
  table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: none!important;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
.mx_auto_custom
{
        margin-left: auto;
    margin-right: auto;
    display: block!important;
    margin-bottom: -10px;
}
.mt_3_mb_3
{
        margin-top: 5px;
    margin-bottom: 10px;
}
table.dataTable thead .sorting {
    background-image: url()!important;
}
table.dataTable thead .sorting_asc {
   background-image: url()!important;
}
table.dataTable thead .sorting_desc {
     background-image: url()!important;
}
  </style>
<div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?>&nbsp &nbsp<small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-sm-12 table-responsive">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
           <button class="close" data-dismiss="alert" type="button">×</button>
           <?= $flashdata['message'] ?>
         </div>
       <?php } ?>
      </div>
        <div class="col-xs-12">
          <div class="box box-warning"> 
            <div class="box-header with-border">
              <div class="col-md-6"><h3 class="box-title">Accepted Orders</h3></div>
              <div class="col-md-6" align="right">
                <?php if(!empty($orderData)){ ?>
                  
                <?php } ?>&nbsp &nbsp
                <a class="btn btn-sm btn-primary" href="<?= base_url('Order/ViewOrders') ?>">Back</a>
              </div>
            </div> 
            <br>  
               <div class="box-header with-border">
                     <div class="col-md-12 row">
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">ORDER DATE FROM:</label>
                            <input type="date" id="orddate_from" class="form-control text-uppercase" name="orddate_from">
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">TO:</label>
                            <input type="date" id="orddate_to" class="form-control text-uppercase" name="orddate_to">
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">DELIVERY DATE FROM:</label>
                            <input type="date" id="deldate_from" class="form-control text-uppercase" name="deldate_from">
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">TO:</label>
                            <input type="date" id="deldate_to" class="form-control text-uppercase" name="deldate_to">
                        </div>
                         <div class="col-md-3 mt_3_mb_3">
                            <label for="date">DELIVERY TIMING</label>
                            <select name="del_time" class="form-control term"  id="del_time">
                               <option value="">Select</option>
                               <?php foreach($del_time as $tim){ ?>
                               <option value="<?php echo $tim->time_slot; ?>"><?php echo $tim->time_slot_view; ?></option>
                               <?php } ?>
                            </select>
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">DELIVERY STATUS</label>
                            <select name="del_status" class="form-control term" id="del_status">
                               <option value="">Select</option>
                               <option value="1">Accepted</option>
                               <option value="4">Packed</option>
                               <option value="7">Shipped</option>
                            </select>
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">PINCODE</label>
                            <input type="text" id="pincode" class="form-control" name="pincode" maxlength="6" placeholder="Search Pincode">
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">PHONE NUMBER</label>
                            <input type="text" id="phoneno" class="form-control" name="phoneno" maxlength="10" placeholder="Search Phone Number">
                        </div>
                        <div class="col-md-3 mt_3_mb_3">
                            <label for="date">ORDER TYPE</label>
                            <select name="ord_type" class="form-control term" id="ord_type">
                               <option value="">Select</option>
                               <option value="CO">Courier Order</option>
                               <option value="DO">Delivery Order</option>
                            </select>
                        </div>
                        <div class="col-md-2 col-lg-1 mt_3_mb_3">
                            <label for="btn"></label>
                            <button class="btn btn-danger px-4 text-uppercase form-control" id="refresh_button" style="margin-top:4px">Reset &emsp;&emsp;</button>
                        </div>
				    </div>
				</div><br>
				
            <div class="box-body table-responsive">
              <table  class="table table-bordered table-striped datatable" id="ordertable">
                <thead>
                  <tr>
                    <th width="2%" class="text-center p_3_font_13">S.NO</th>
                    <th width="6%;" class="text-center p_3_font_13">ORDER ID</th>
                    <th width="10%;" class="text-center p_3_font_13">ORDER PERSON NAME</th>
                    <th width="10%;" class="text-center p_3_font_13">ORDER PHONE NUMBER</th>
                     <th width="16%;" class="text-center p_3_font_13">DELIVERY ADDRESS</th>
                    <th width="14%;" class="text-center p_3_font_13">DELIVERY PHONE NUMBER</th>
                    <th width="21%;" class="text-center p_3_font_13">PRODUCT NAME</th>
                    <!--for mobile view status-->
                    <th width="7%;" class="text-center p_3_font_13"><span style="color:#fff0">spc</span>STATUS<span style="color:#fff0">spc</span></th>
                    <th width="14%;" class="text-center p_3_font_13">ORDER DATE & DELIVERY DATE</th>
                    <th width="7%;" class="text-center p_3_font_13">ACTION</th>
                 </tr>
                </thead> 
              </table>
            </div>
            
          </div>
        </div>
    </div>
  </section>
</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Item Details</h4>
            </div>
            <div class="modal-body">

            <strong>loading.</strong>        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div> 
</div>
<script>
 $('.chk').on('click',function(){
            var order_id=$(this).data('id');
            // alert(order_id);
    $('.modal-body').html('loading');
       $.ajax({
    	url:'<?php echo base_url() ?>order/get_itemdata',
		type:'POST',
		data:'order_id='+order_id,
        success: function(data) {
          $('.modal-body').html(data);
        },
        error:function(err){
          alert("error"+JSON.stringify(err));
        }
    });
 });
 </script>
 <script>
    function submitOrderStatus(str){
      var order_status = str.value;
        var order_id = str.id;
        if(order_status){
    if(confirm('Do you want to submit?')){
            if(order_status==7){     
            $("#dialog-modal").modal();     
            }
            $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>order/submitOrderStatus",
           data: {order_status:order_status,order_id:order_id}, 
           success: function(data){
               if(data==200){
                   alert ("Order Status updated");
                location.reload();
               } else if(data==404){
                   alert ("Please update the previous status");
                location.reload();
               }else if(data==7){                     
                     $('#ordid').val(order_id);
               } else{
                   alert(data);
                //   alert ("something went wrong contact admin!!");
                location.reload();    
               }
           }
           
         });
    
    }else{
        location.reload();
    }
        }
  else{
      alert('please change status');
  }
    }
</script>
<!-- close  modal -->
<div class="modal fade" id="dialog-modal" tabindex="-1" role="dialog" aria-labelledby="close_std_label" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="close_std_label">Order Track</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form>
          <div class="form-group">
            <label for="std_remark">Enter Track ID</label>
            <input type="hidden" id="ordid" name="ordid" value="0">
            <textarea class="form-control" id="track_id" name="track_id" rows="1" required></textarea>
            <label for="std_remark" class="marginTop23">Delivery Charge</label>
            <input type="text" id="delivery_charge" class="form-control" name="delivery_charge" value="" required>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="trackid_submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<!-- Button close  modal -->
<script>
 $(document).ready(function() {
          $('#trackid_submit').on('click', function(){
              var ordid = document.getElementById("ordid").value;
              var track_id = document.getElementById("track_id").value;
              var delivery_charge = document.getElementById("delivery_charge").value;
                if(track_id){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo base_url() ?>Order/ajax_add_trackid',
                        data: {ordid:ordid,track_id:track_id,delivery_charge:delivery_charge},
                        success:function(data){
                            //response= JSON.parse(data);
                            alert(data);
                            location.reload(); 
                        }
                    }); 
                }
          });
 });
</script>
 <script>
// $(document).ready(function() {
//     // $('#example').DataTable( {
//     //     "order": [[ 1, "desc" ]]
//     // } );
// } );
 $(document).ready(function() {
    active("order_side_menu"); 
 });

</script>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.0/js/dataTables.buttons.min.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.0/js/buttons.flash.min.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.0/js/buttons.html5.min.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.0/js/buttons.print.min.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.0/css/buttons.dataTables.min.css"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script> 
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script> 
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script> 

<script type="text/javascript">
     $(document).ready(function(){
        var termid = 0;
       table = $('#ordertable').DataTable({
        "lengthChange": true,
         "lengthMenu": [[10, 20, 50, -1], [10, 20, 50, "All"]],
       dom: 'Blfrtip',
        buttons: [
            // 'copy', 'csv', 'excel', 'pdf', 'print'
            { extend: 'excel', text: 'EXPORT REPORT' }
        ],
      
          'processing': true,
          'serverSide': true,
          'serverMethod': 'post',
          'ajax': {
             'url':'<?=base_url()?>Order/load_AcceptedOrders',
              'data' : function (d) {
                d.orddate_from = $('#orddate_from').val();
                d.orddate_to = $('#orddate_to').val();
                d.deldate_from = $('#deldate_from').val();
                d.deldate_to = $('#deldate_to').val();
                d.pincode = $('#pincode').val();
                d.phoneno = $('#phoneno').val();
                d.ord_type = $('#ord_type').val();
                d.del_time = $('#del_time').val();
                d.del_status = $('#del_status').val();
                }
          },
          'columns': [
             { data: 'SNo' },
             { data: 'UTN_number' },
             { data: 'orderby_name' },
             { data: 'orderby_contact' },
             { data: 'address' },
             { data: 'deliveryto_contact' },
             { data: 'product_name' },
             { data: 'status' },
             { data: 'order_del_date' },
             { data: 'action' }
          ]
        });
         	
         	
     });
     </script>
     <script>
     $('#orddate_from').on('change', function()
			{
			     table.draw();
			});
	$('#orddate_to').on('change', function()
			{
			     table.draw();
			});
	$('#deldate_from').on('change', function()
			{
			     table.draw();
			});
    $('#deldate_to').on('change', function()
			{
			     table.draw();
			});
	$('#pincode').on('keyup',function(){
	    var pincode = $('#pincode').val().length;
	    table.draw();
	   // if(pincode==6){
	   //     table.draw();
	   // }
	});
	$('#phoneno').on('keyup',function(){
	    var phoneno = $('#phoneno').val().length;
	    table.draw();
	   // if(phoneno==10){
	   //     table.draw();
	   // }
	});
	$('#ord_type').on('change', function()
			{
			     table.draw();
			});
	$('#del_time').on('change', function()
			{
			     table.draw();
			});
	$('#del_status').on('change', function()
			{
			     table.draw();
			});
			
	$('#refresh_button').click(function () 
			 {
                location.reload();
            });
     </script>