<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Orders</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
  </head>
<div class="content-wrapper">
    <section class="content-header">
    <h1> <?= $page_title ?>
        <small><?= $page_desc ?></small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="javascript:void(0);" ><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Orders</li>
    </ol>
    </section>
    <?php 
        if($this->session->flashdata('message')) { 
        $flashdata = $this->session->flashdata('message'); ?>
        <br><div class="alert alert-<?= $flashdata['class'] ?>">
           <button class="close" data-dismiss="alert" type="button">×</button>
           <?= $flashdata['message'] ?>
        </div>
    <?php } ?>  
    <section class="content">
        <div class="row">
            <?php if(isset($accepted_order)){ ?>
                <div class="col-lg-3 ">
                    <div class="small-box bg-yellow">
                        <div class="inner">
                            <h4>Accepted Orders</h4>
                            <p><?php echo 'Total : '. $accepted_order ?></p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-android-list"></i>
                        </div>
                        <a href="<?= base_url('Order/AcceptedOrders') ?>" class="small-box-footer ">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            <?php } if(isset($completed_order)){ ?>
                <div class="col-lg-3 ">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h4>Completed Orders</h4> 
                            <p>
                                <?php echo 'Total : '.$completed_order; ?>
                            </p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="<?= base_url('Order/CompletedOrders') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            <?php } ?>
        </div> 
    </section>
</div>

<script>

 $(document).ready(function() {
    active("order_side_menu"); 
 });

</script>
