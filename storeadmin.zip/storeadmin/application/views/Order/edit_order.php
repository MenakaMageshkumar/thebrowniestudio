   <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Orders | Edit Orprodder</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>


        
        
    <style>
    .tbl{
    padding-right: 2px;
    padding-left: 2px;
    }
    .error_msg{
        color: red;
        font-weight: 700;
    }
     .pad_left_mobile
    {
        padding-left:0px;
    }
    @media (max-width:575px)
    {
         .pad_left_mobile
        {
            padding-left:0px;
        }
        .pt_custom_1
        {
            padding-top: 25px!important;
        }
        .pt_custom
        {
            padding-top: 25px!important;
        }
       

}
    }
   .bootstrap-select .dropdown-menu 
   {
        min-width: auto!important%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    
    
    /*28/2/2022*/
     .multiselect-container {
        width: 100% !important;
        height: 250px;
        overflow-y: scroll;
    }
    .pt_custom_1
    {
        padding-top: 53px;
    }
    .pt_custom
    {
         padding-top: 50px;
    }
   
    </style>
  </head>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?= $pTitle ?><small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <?php 
          $redirectUrl = (isset($ord_id) && !empty($ord_id))
                            ?'Order/updateOrder/'.$ord_id
                            :'Order/AcceptedOrders';
        
        if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
            <button class="close" data-dismiss="alert" type="button">×</button>
            <?= $flashdata['message'] ?>
          </div>
        <?php } ?>
      </div>

        <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-header with-border">
            <h3 class="box-title">Order Update</h3>
          </div>
            
<!--<form id="createProductForm" role="form" action="<?= base_url($redirectUrl) ?>" method="post" class="validate" data-parsley-validate="" enctype="multipart/form-data">-->
<form id="createProductForm" role="form" action="<?= base_url($redirectUrl) ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">

              <div class="box-body">
                        <div class="form-group row">
                            <input type="hidden" class="col-12" value="<?php echo $ord_data['order_id']; ?>" id="order_id" >
                            <input type="hidden" class="col-12" value="<?php echo $user_id; ?>" id="user_id" >
                            <label for="exampleInputEmail1" class="col-lg-5">ORDER ID : <?php echo $ord_data['UTN_number']; ?></label>  &emsp;&emsp;&emsp;
                                                    
                            <label for="exampleInputEmail1" class="col-lg-5 text-uppercase">DELIVERY DATE :
                            
                            <?php
                             $dt_frmt=date_create($ord_data['delivery_date']);
                                 echo  date_format($dt_frmt,"d/m/Y"); ?> 
                         
                            
                            </label>   
                             <label for="exampleInputEmail1" class="col-lg-5">ORDER DATE : <?php echo $ord_data['order_date']; ?></label>    &emsp;&emsp;&emsp;
                            <label for="exampleInputEmail1" class="col-lg-5">DELIVERY TIME : <?php echo $ord_data['delivery_time']; ?></label>                         
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1"> ITEM DETAILS</label>
                            <div class="table-responsive">
                	         <table class="table datatable table-bordered ">
                	            <thead>
                            <tr>
                              <th width="3%;" class="text-center">S.NO</th>
                              <th width="8%;" class="text-center">IMAGE</th>
                              <th width="15%;" class="text-center">PRODUCT NAME</th>
                              <th width="15%;" class="text-center">VARIANT </th>
                              <th width="5%;" class="text-center">QUANTITY</th>
                              <th width="10%;" class="text-center">PRICE</th>
                              <th width="10%;" class="text-center">ACTION</th>
                            </tr>
                            </thead> 
                                <tbody>
                                <?php 
                                  $i =1;
                                foreach($item_data as $itm){ ?>
                                <tr>
                                    <td class="text-center"><?= $i++ ?></td>
                                    <td class="text-center"><img src="<?php echo base_url('../../'.$itm['product_image']); ?>"  width="100px;" heigth="100px;"></img> </td>
                                    <td class="text-center"><?php echo  $itm['product_name'];?></td>
                                    <td class="text-center"><?php echo  $itm['variant'];?></td>
                                    <td class="text-center"><?php echo  $itm['quantity'];?></td>
                                    <td class="text-center"><?php echo  $itm['price'];?></td>
                                    <td class="text-center">
                                    <?php if($item_cnt>1){ //for more than one item allow remove check box ?>
                                     <div class="checkbox">
                                     <input type="checkbox" class="remove_product" id="cart_id-<?php echo $itm['cart_id'];?>" name="cart_id" value="<?php echo $itm['cart_id'];?>" >
                                     </div>
                                     <?php } else {
                                     echo '';    
                                      } ?>
                                    </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            </table>
                            </div>
                    </div>
                        <div class="form-group">
                                    <p class="text-uppercase"><strong>Select Products</strong></p> 
                                      <input class="form-control" id="searchInput" type="text" placeholder="Search..">
                                      <br>
                                      <!--<ul class="list-group" id="searchList" style="height:300px; overflow:hidden; overflow-y:scroll;" onclick="alert(this.clicked.line.id);">-->
                                          <?php //foreach($search_products as $pro) { ?>
                                        <!--<li class="list-group-item"><?php echo $pro->product_name.' - '.$pro->variant_name.' - '.$pro->stock; ?></li>-->
                                        <?php //} ?>
                                      <!--</ul>-->
                                         <select class="form-control" id="newitem_id" required>
                                          <option value="">Select Products</option>
                                          <?php foreach($search_products as $pro) { ?>
                                          <option value="<?php echo $pro->item_id; ?>" ><?php echo $pro->product_name.' - '.$pro->variant_name; ?></option>
                                        <?php } ?>  
                                          </select>
                    </div>
                        <label>QUANTITY</label>
                        <div class="input-group col-md-3">
                          <span class="input-group-btn">
                              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
                                  <span class="glyphicon glyphicon-minus"></span>
                              </button>
                          </span>
                          <input type="text" name="quant[1]" class="form-control input-number text-center" value="1" min="1" max="10" id="qty">
                          <span class="input-group-btn">
                              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[1]">
                                  <span class="glyphicon glyphicon-plus"></span>
                              </button>
                          </span>
                      </div>
                        <div class="form-group row ">
                            <div class="col-md-4 marginTop23">
                                <label>MESSAGE ON CAKE</label>
                                <input type="text" id="message_on_cake" class="form-control text-uppercase" name="message_on_cake">
                            </div>
                            <div class="col-md-4 marginTop23">
                                <label for="date">DELIVERY DATE</label>
                                <!--<input type="date" id="preferred_del_date" class="form-control text-uppercase" name="preferred_del_date" >-->
                                <input type="text"  id="preferred_del_date" min="<?php echo date("d/m/Y"); ?>"  name="preferred_del_date" class="form-control hasDatepicker text-uppercase" placeholder="dd/mm/yyyy" value="<?php echo $preferred_del_date;?>" onchange="validate('date');" >
                            </div>
                            <div class="col-md-4 marginTop23">
                                <label for="date">DELIVERY TIME</label>
                                <select class="form-control" id="preferred_del_time" required>
                                <option value="<?php echo ($preferred_del_time == '')?"selected":"" ?>">Select Delivery Time</option>
                                <?php foreach($delivery_slot as $time){ ?>
                                    <option value="<?php echo $time->time_slot; ?>"  <?php echo ($preferred_del_time == $time->time_slot)?"selected":""?>><?php echo $time->time_slot_view;?></option>
                                <?php } ?>
                                </select>
                            </div>
                    </div>
                        <div class="form-group marginTop23">
                                    <button id="update_btn" style="width: 120px;" type="button" class="btn btn-primary">Update Order</button>
                        </div>

             </div> </form></div>
       
       </div>
         </section></div>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>        

<script>
$(document).ready(function(){
  $("#searchInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
        // $("#searchList li").filter(function() {
        $("#newitem_id option").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
// date format  
var dateformat = 'dd/mm/yyyy';

$('.hasDatepicker').datepicker({
  format: dateformat,
  autoclose: true
});


// date format function end
});
</script>
<script>
$('.btn-number').click(function(e){
    e.preventDefault();
    
    fieldName = $(this).attr('data-field');
    type      = $(this).attr('data-type');
    var input = $("input[name='"+fieldName+"']");
    var currentVal = parseInt(input.val());
    if (!isNaN(currentVal)) {
        if(type == 'minus') {
            
            if(currentVal > input.attr('min')) {
                input.val(currentVal - 1).change();
            } 
            if(parseInt(input.val()) == input.attr('min')) {
                $(this).attr('disabled', true);
            }

        } else if(type == 'plus') {

            if(currentVal < input.attr('max')) {
                input.val(currentVal + 1).change();
            }
            if(parseInt(input.val()) == input.attr('max')) {
                $(this).attr('disabled', true);
            }

        }
    } else {
        input.val(0);
    }
});
$('.input-number').focusin(function(){
   $(this).data('oldValue', $(this).val());
});
$('.input-number').change(function() {
    
    minValue =  parseInt($(this).attr('min'));
    maxValue =  parseInt($(this).attr('max'));
    valueCurrent = parseInt($(this).val());
    
    name = $(this).attr('name');
    if(valueCurrent >= minValue) {
        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the minimum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    if(valueCurrent <= maxValue) {
        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the maximum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    
    
});
$(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
</script>
<script>
$(document).on('click','#update_btn',function(){
    var order_id = document.getElementById('order_id').value;
    var qty = document.getElementById('qty').value;
    var message_on_cake = document.getElementById('message_on_cake').value;
    var item_id = document.getElementById('newitem_id').value;
    var preferred_del_date = document.getElementById('preferred_del_date').value;
    // var preferred_del_date = formatDate(preferred_del_date); //not working
    var preferred_del_time = document.getElementById('preferred_del_time').value; 
    
// var specific_date = new Date(preferred_del_date);
// var current_date = new Date();
// alert(specific_date);
// alert(current_date);
// if(current_date.getTime() > specific_date.getTime())
// {
//  alert('hi');   
// }
// return false;
    if(item_id!="" && qty!=0 && qty!="" && preferred_del_date!="" && preferred_del_time!=""){
        $.ajax({
				url:'<?php echo base_url() ?>order/seller_addproduct',
				type:'POST',
				// data:'str='+str,
				data: {item_id: item_id, qty: qty, message_on_cake: message_on_cake,preferred_del_date:preferred_del_date,preferred_del_time:preferred_del_time,order_id:order_id},
				success: function(data)
				{
				    response= JSON.parse(data);
				    alert(response.message);
				   location.reload();
				}
            	});
    }else{
        alert("please select required field");
    }
   
    
});
</script>
<script>
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}

</script>
<script>
$('.remove_product').on('change', function(e) {
e.preventDefault();

// Determine ID
 var id = $(this).attr('id');
 var cart_id = $(this).attr('value');
//  alert(cart_id);
 var order_id = document.getElementById('order_id').value;
var isChecked =$('#' + id).is(":checked")?1:0;
if(isChecked==1){
    if(confirm('Do you want to remove this item?')){
          $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>Order/removeitem",
           data: {order_id:order_id,cart_id:cart_id}, 
           success: function(data){
               alert(data);
               location.reload();
           }
});        
}else{
        location.reload();
    }
    }
});
</script>
<script>
function validate(type){
    var preferred_del_date = document.getElementById("preferred_del_date").value;
    var preferred_del_time = document.getElementById("preferred_del_time").value;
        if(type=='date'){ //on change date change timing
        var user_id = document.getElementById("user_id").value;
        $.ajax({
                type:'POST',
                url:'<?php echo base_url() ?>Order/ajaxload_deliveryslot',
                data: {user_id:user_id,preferred_del_date:preferred_del_date},
                success:function(data)
                {
                    // alert(data);
     	          $('select[id="preferred_del_time"]').html(data);

                }
            });
        }
}
</script>