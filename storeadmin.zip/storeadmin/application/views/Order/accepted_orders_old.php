<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Orders | Accepted</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/AdminLTE.min.css') ?>">
    
  </head>
  <style>
  .datatable tbody th { font-weight: inherit; }
  table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after {
    position: absolute;
    top: 8px;
    right: 8px;
    display: block;
    font-family: 'Glyphicons Halflings';
    opacity: -0.5!important;
    cursor: default;
}
.p_3_font_13
{
    padding-left: 3px!important;
    padding-right:3px!important;
    padding-top:10px!important;
    padding-bottom:10px!important;
    font-size: 12.5px!important;
}
.mx_auto_custom
{
        margin-left: auto;
    margin-right: auto;
    display: block!important;
    margin-bottom: -10px;
}
  </style>
<div class="content-wrapper">
  <section class="content-header">
    <h1><?= $pTitle ?>&nbsp &nbsp<small><?= $pDescription ?></small>
    </h1>
    <ol class="breadcrumb">
     <li><a href="<?= base_url() ?>"><i class="fa fa-star-o" aria-hidden="true"></i>Home</a></li>
     <li><?= $menu ?></li>
     <li class="active"><?= $smenu ?></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-sm-12 table-responsive">
        <?php if($this->session->flashdata('message')) { 
          $flashdata = $this->session->flashdata('message'); ?>
          <div class="alert alert-<?= $flashdata['class'] ?>">
           <button class="close" data-dismiss="alert" type="button">×</button>
           <?= $flashdata['message'] ?>
         </div>
       <?php } ?>
      </div>
        <div class="col-xs-12">
          <div class="box box-warning"> 
            <div class="box-header with-border">
              <div class="col-md-6"><h3 class="box-title">Accepted Orders</h3></div>
              <div class="col-md-6" align="right">
                <?php if(!empty($orderData)){ ?>
                  
                <?php } ?>&nbsp &nbsp
                <a class="btn btn-sm btn-primary" href="<?= base_url('Order/ViewOrders') ?>">Back</a>
              </div>
            </div> 
            <br>  
          
            <div class="box-body table-responsive">
              <table  class="table table-bordered table-striped datatable" id="example">
                <thead>
                  <tr>
                    <th width="2%" class="text-center p_3_font_13">S.NO</th>
                    
                    <th width="6%;" class="text-center p_3_font_13">ORDER ID</th>
                    
                    <th width="10%;" class="text-center p_3_font_13">ORDER PERSON NAME</th>
                    
                    <th width="10%;" class="text-center p_3_font_13">ORDER PHONE NUMBER</th>
                    
                     <th width="16%;" class="text-center p_3_font_13">DELIVERY ADDRESS</th>
                     
                    <th width="14%;" class="text-center p_3_font_13">DELIVERY PHONE NUMBER</th>
                    
                    <th width="21%;" class="text-center p_3_font_13">PRODUCT NAME</th>
                    <th width="7%;" class="text-center p_3_font_13">STATUS</th>
                    <th width="14%;" class="text-center p_3_font_13">ORDER DATE & DELIVERY DATE</th>
                    <th width="7%;" class="text-center p_3_font_13">ACTION</th>
                 </tr>
                </thead> 
                <tbody>
                  
                  <?php if(!empty($orderData)){
                       $i =1;
                    foreach($orderData as $odrData) { ?>
                      <tr>
                        <th class="center text-center p_3_font_13"><?= $i ?></th>
                        
                        <th class="center text-center p_3_font_13"><?= $odrData->UTN_number ?></th>
                        
                        <th  class="center text-center p_3_font_13"><?= $odrData->orderby_name ?></th>
                        
                        <th  class="center text-center p_3_font_13 ">+91<?= $odrData->orderby_contact ?></th>
                        <th class="center ">
                            <?php  if($odrData->address2 == "")
                            {
                               
                                $address_2_commo = "";
                                
                            }
                            else
                            {
                                $address_2_commo = ",";
                            }
                            
                            ?>
                        <?= $odrData->deliveryto_name.', 
                        '.$odrData->address1.',
                        '.$odrData->address2.' '.$address_2_commo.'
                        '.$odrData->landmark.', 
                        '.$odrData->area.', '.$odrData->city.',
                        '.$odrData->district.', 
                        '.$odrData->state.' - '.$odrData->pincode;
                         ?></th>
                        <th class="center text-center p_3_font_13">+91<?
                        $phone_no = $odrData->deliveryto_contact; //remove country code 91
                        echo $phone_no; ?></th>
                        
                      
                         <th class="center">
                             <p>
                                 <!--To remove last string 1 -->
                                 <?php $product_name_cu = substr(trim($odrData->product_name), 0, -1);?>
                                   <!--To remove last string 1 -->
                                <?= print_r($product_name_cu); ?>
                             </p>
                          
                        </th>
                        <th class="center text-center p_3_font_13">
                            <?php 
                            $delivery_status = $odrData->delivery_status;
                            $delivery_status_flg = $odrData->delivery_status_flg;
                            $order_method = $odrData->payment_method; //1 for store pickup and 2 for home delivery
            if($delivery_status==0){
                 $delivery_status_text = 'Awaiting Store Confirmation'; //Order Placed
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $delivery_status_text = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $delivery_status_text = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $delivery_status_text = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $delivery_status_text = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //purle
            }
            else if($delivery_status==4 && $order_method==2 ){ //home delivery
                $delivery_status_text = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            else if($delivery_status==4 && $order_method==1 ){ //store pickup
                $delivery_status_text = 'Order Packed  & ready to Pickup';
                $delivery_sts_clr = '#a52a2a'; //brown
            }else if($delivery_status==5 && $delivery_status_flg ==0){
                $delivery_status_text = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }else if($delivery_status==6){
                $delivery_status_text = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }else if($delivery_status==7){
                $delivery_status_text = 'Order Shipped';
                $delivery_sts_clr = '#800080'; //purle
            }
            else{
                $delivery_status_text = 'Order Placed';//Order Placed
                $delivery_sts_clr = '#000000'; //black
            }
  ?>
                        
                <?php $curr_delivery_status = $odrData->delivery_status;
            if(($curr_delivery_status==4 || $curr_delivery_status==5) && $delivery_status_flg == 1 ){
            $curr_delivery_status = 2;    
            } ?>
                            
                            <select  name='delivery_status' class="form-control mx_auto_custom text-center" style="padding: 0px;" id=<?php echo $odrData->UTN_number ?> onchange='submitOrderStatus(this)' >
                                        <option value="<?php echo ($curr_delivery_status == '0')?"selected":"" ?>">Select</option>
                                        <option value="4"  <?php echo ($curr_delivery_status == "4")?"selected":""?>><?php echo 'Packed';?></option>
                                        <option value="7"  <?php echo ($curr_delivery_status == "7")?"selected":""?>><?php echo 'Shipped';?></option>
                                        <option value="2"  <?php echo ($curr_delivery_status == "2")?"selected":""?>><?php echo 'Delivered';?></option>
                                        <option value="3"  <?php echo ($curr_delivery_status == "3")?"selected":""?>><?php echo 'Returned';?></option>
                                        </select>
                                        
                                         &emsp; 
                                        <?php
                                         if($odrData->payment_status ==1){
                                           $delivery_type ='Paid'; 
                                           $delivery_type_color ='#000000';
                                        } else { 
                                           $delivery_type ='Unpaid'; 
                                           $delivery_type_color ='#FF0000';
                                        }?>
                                        <div style="color:<?php echo $delivery_type_color ?>"> <?php echo $delivery_type;?></div>
                                        </th>
                        <th class="center text-center p_3_font_13"><?php
                        $dt_frmt=date_create($odrData->booking_time);
                        echo  date_format($dt_frmt,"d/m/Y  h:i A");?><br><strong><?php
                        $del_date ="";$del_time ="";
                        if($odrData->preferred_del_date!="0000-00-00"){
                            $del_dt=date_create($odrData->preferred_del_date);
                            $del_date = date_format($del_dt,"d/m/Y");
                        }
                        if($odrData->preferred_del_time!=""){
                            $del_time = $odrData->preferred_del_time;
                        }
                        echo  $del_date.' '.$del_time;
                        
                          ?></strong></th>
                                        <th class="center text-center p_3_font_13">
                                            <!--<a class="btn btn-sm btn-pri" target="_blank" href="<?= base_url("../home/view_order/".$odrData->store_id)."/".$odrData->UTN_number ?>">View Order</a>&emsp; -->
                                            <!--<a class="btn btn-sm btn-sec" href="<?= base_url("../home/view_order/".$odrData->store_id)."/".$odrData->UTN_number ?>" download="order-<?php echo $odrData->UTN_number.".html" ?>">Print Order</a>-->
                                            <a class="btn btn-sm btn-pri" target="_blank" href="<?= base_url("Order/item_view/".encode_param($odrData->order_id)) ?>">View Order</a>&emsp; 
                                        </th>
                      </tr>
                  <?php $i++; } }?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </section>
</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Item Details</h4>
            </div>
            <div class="modal-body">

            <strong>loading.</strong>        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div> 
</div>
<script>
 $('.chk').on('click',function(){
            var order_id=$(this).data('id');
            // alert(order_id);
    $('.modal-body').html('loading');
       $.ajax({
    	url:'<?php echo base_url() ?>order/get_itemdata',
		type:'POST',
		data:'order_id='+order_id,
        success: function(data) {
          $('.modal-body').html(data);
        },
        error:function(err){
          alert("error"+JSON.stringify(err));
        }
    });
 });
 </script>
 <script>
    function submitOrderStatus(str){
      var order_status = str.value;
        var order_id = str.id;
        if(order_status){
    if(confirm('Do you want to submit?')){
            if(order_status==7){     
            $("#dialog-modal").modal();     
            }
            $.ajax({
           type: "POST",
           url: "<?php echo base_url();?>order/submitOrderStatus",
           data: {order_status:order_status,order_id:order_id}, 
           success: function(data){
               if(data==200){
                   alert ("Order Status updated");
                location.reload();
               } else if(data==404){
                   alert ("Please update the previous status");
                location.reload();
               }else if(data==7){                     
                     $('#ordid').val(order_id);
               } else{
                   alert(data);
                //   alert ("something went wrong contact admin!!");
                location.reload();    
               }
           }
           
         });
    
    }else{
        location.reload();
    }
        }
  else{
      alert('please change status');
  }
    }
</script>
<!-- close  modal -->
<div class="modal fade" id="dialog-modal" tabindex="-1" role="dialog" aria-labelledby="close_std_label" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="close_std_label">Order Track</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form>
          <div class="form-group">
            <label for="std_remark">Enter Track ID</label>
            <input type="hidden" id="ordid" name="ordid" value="0">
            <textarea class="form-control" id="track_id" name="track_id" rows="1" required></textarea>
            <label for="std_remark" class="marginTop23">Delivery Charge</label>
            <input type="text" id="delivery_charge" class="form-control" name="delivery_charge" value="" required>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="trackid_submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<!-- Button close  modal -->
<script>
 $(document).ready(function() {
          $('#trackid_submit').on('click', function(){
              var ordid = document.getElementById("ordid").value;
              var track_id = document.getElementById("track_id").value;
              var delivery_charge = document.getElementById("delivery_charge").value;
                if(track_id){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo base_url() ?>Order/ajax_add_trackid',
                        data: {ordid:ordid,track_id:track_id,delivery_charge:delivery_charge},
                        success:function(data){
                            //response= JSON.parse(data);
                            alert(data);
                            location.reload(); 
                        }
                    }); 
                }
          });
 });
</script>
 <script>
// $(document).ready(function() {
//     // $('#example').DataTable( {
//     //     "order": [[ 1, "desc" ]]
//     // } );
// } );
 $(document).ready(function() {
    active("order_side_menu"); 
 });

</script>