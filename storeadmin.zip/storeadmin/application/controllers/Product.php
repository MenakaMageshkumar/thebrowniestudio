<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Product_model');
        $this->load->library('CSVReader');
    $this->load->helper('file');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        error_reporting(0);
        $GLOBALS['role_name'] = '';
        $userData = $this->session->userdata['user'];
          if ( $userData->user_type ==3){
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  $GLOBALS['role_name'] = $chk_rls[0]->role_name;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='product_management'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }
          }
          
        
    }
    //
    public function addProduct(){
        // unset($_SESSION['product']);
        // $final_data =array();
        // $this->session->set_userdata('product' ,$final_data);
        // $this->session->set_userdata('product','');
        // echo '<pre>';print_r($_SESSION);die;
        // if($this->session->userdata['product']!=''){
        // $this->session->set_userdata('product' ,'');
        // }
         $userData = $this->session->userdata['user'];
         $store_id = $userData->store_id;
         $template['store_id']  = $userData->store_id;
        $template['page'] = 'Product/addproduct';
        $template['pTitle'] = "Add Product";
        $template['pDescription'] = "Add Product"; 
        $template['menu'] = "Product Management";
        $template['smenu'] = "View Product";
        $template['store_data'] = $this->Product_model->getStores($store_id);
        $template['attributes'] ='';
        if(isset($_SESSION['product'])){
        $template['attributes'] =$_SESSION['product'];
        }
        $template['units'] = $this->db->query("select * from product_units")->result();
        $template['attribute_list'] = $this->db->query("select * from attributes")->result();
        $template['packettype'] = $this->db->query("select * from packettype_master order by id")->result();
        $template['pricingtype'] = $this->db->query("select id,price_type from product_pricing where status = 1 order by id")->result();
        $template['related_products'] =  $this->db->query("SELECT DISTINCT pro.prod_id,pro.prod_name FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id WHERE pro.prod_status = 1 order by pro.prod_name")->result();
        $this->load->view('template',$template);
    }
    //
    public function viewProducts(){
        $template['page'] = 'Product/viewProduct';
        $template['menu'] = 'Product Management';
        $template['smenu'] = 'View Products';
        $template['pTitle'] = "View Products";
        $template['pDescription'] = "View and Manage Product";
        $store_id = $this->session->userdata['user']->store_id;
        $template['product_data'] = $this->Product_model->getProduct($store_id);
        $template['menu'] = $dt->menu_name;
        $this->load->view('template',$template);
    }
    
    function changeStatus($product_id){
        $product_id = decode_param($product_id);
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        $status = $this->Product_model->changeStatus($product_id);
        if(!$status){
            $this->session->set_flashdata('message',$flashMsg);
        }
        redirect(base_url('Product/viewProducts'));
    }
    function changeproduct_availstatus($product_id){//
        $product_id = decode_param($product_id);
        $data['availability'] = $this->uri->segment(4);
        $data['product_id'] = decode_param($this->uri->segment(3));
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        $status = $this->Product_model->changeproduct_availstatus($data);
        if(!$status){
            $this->session->set_flashdata('message',$flashMsg);
        }
        redirect(base_url('Product/viewProducts'));
    }
    
    public function createProduct(){
         $err = 0;
        $errMsg = '';
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(!isset($_POST) || empty($_POST)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/addproduct'));
        }
        else if($err == 0 && (!isset($_POST['product_name']) || empty($_POST['product_name']))){
            $err = 1;
            $errMsg = 'Provide a Product Name';
        }
        else if($err == 0 && (!isset($_POST['brand']) || empty($_POST['brand']))){
            $err = 1;
            $errMsg = 'Provide a Brand Name';
        }
        else if($err == 0 && (!isset($_POST['description']) || empty($_POST['description']))){
            $err = 1;
            $errMsg = 'Provide a Product Description';
        }
        else if($err == 0 && (!isset($_POST['category_name']) || empty($_POST['category_name']))){
            $err = 1;
            $errMsg = 'Provide a Category';
        }
        
        else if($err == 0 && (!isset($_POST['type']) || empty($_POST['type']))){
            $err = 1;
            $errMsg = 'Provide a Pack Type';
        }
        else if($err == 0 && (!isset($_FILES['product_image']) || empty($_FILES['product_image']))){
               $err = 1;
               $errMsg = 'Provide Product Picture';
        }
        else if($err == 0 && (!isset($_POST['HSN_code']) || empty($_POST['HSN_code']))){
            $err = 1;
            $errMsg = 'Provide a HSN Code';
        }
        else if($err == 0 && (!isset($_POST['CGST']) || empty($_POST['CGST']))){
            $err = 1;
            $errMsg = 'Provide a CGST Percentage';
        }else if($err == 0 && (!isset($_POST['SGST_IGST']) || empty($_POST['SGST_IGST']))){
            $err = 1;
            $errMsg = 'Provide a SGST/IGST Percentage';
        }
        $pro_name = trim($_POST['product_name']);
        $store_id = $_POST['store_id']; 
$chk_productexists = $this->db->query("select * from product where prod_name = '$pro_name' and store_id = $store_id")->result();
if(!empty($chk_productexists)){
               $err = 1;
               $errMsg = "Can't Create Duplicate Product. Plz check Product Name";
}
// if(($err == 0 && $_SESSION['product'])==''){
//          $err = 1;
//          $errMsg = 'Provide Varient Detail';
//     }
        if($_FILES['product_image'] ==''){
            $_POST['product_image']= '';
        }
        if($err == 0){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_image')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $_POST['product_image'] = $config['upload_path']."/".$upload_data['file_name'];
            }

        if($_FILES['product_image_1']['name']){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_1']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_1');
            $upload_data = $this->upload->data();
            $_POST['product_image_1'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['product_image_1'] = '';
        }
        
        if($_FILES['product_image_2']['name']){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_2']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_2');
            $upload_data = $this->upload->data();
            $_POST['product_image_2'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['product_image_2'] = '';
        }
        
        if($_FILES['product_image_3']['name']){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_3']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_3');
            $upload_data = $this->upload->data();
            $_POST['product_image_3'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['product_image_3'] = '';
        }
        
        if($_FILES['product_image_4']['name']){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_4']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_4');
            $upload_data = $this->upload->data();
            $_POST['product_image_4'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['product_image_4'] = '';
        }
        }
         if($err == 1){
            $flashMsg['message'] = $errMsg;
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/addProduct/'));
        }
        $product_id ='';
         $status = $this->Product_model->createProduct($_POST,$product_id);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'product created';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/viewProducts'));
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Product/addProduct/'));
    }
    public function add_session_packet(){
        /*if($_FILES['item_image1'] =="" && $_FILES['item_image2'] ==""){
            echo 'Please select product image';
            die;
        }*/
        /*$img_cnt = count($_FILES['item_image1']['name']);
    for ($i=0; $i < $img_cnt; $i++){
        $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['item_images']['name'][$i];
            $this->upload->initialize($config);
            $this->upload->do_upload('item_images');
            $upload_data = $this->upload->data();
            $_POST['item_images'][] = $config['upload_path']."/".$upload_data['file_name'];
    }*/
    $item_image1 =""; $item_image2="";
    if(isset($_FILES['item_image1']['name'])){
            if($_FILES['item_image1']['name']!=""){
                    $config = set_upload_service("../../assets/uploads/products");
                    $this->load->library('upload');
                    $config['file_name'] = time()."_".$_FILES['item_image1']['name'];
                    $this->upload->initialize($config);
                    $this->upload->do_upload('item_image1');
                    $upload_data = $this->upload->data();
                    $item_image1 = $config['upload_path']."/".$upload_data['file_name'];
            }
    }
    if(isset($_FILES['item_image2']['name'])){
            if($_FILES['item_image2']['name']!=""){
                    $config = set_upload_service("../../assets/uploads/products");
                    $this->load->library('upload');
                    $config['file_name'] = time()."_".$_FILES['item_image2']['name'];
                    $this->upload->initialize($config);
                    $this->upload->do_upload('item_image2');
                    $upload_data = $this->upload->data();
                    $item_image2 = $config['upload_path']."/".$upload_data['file_name'];
            }
    }
        $varient1 =''; $varient2 =''; $varient3 =''; $attribute1 =''; $attribute2 = ''; $attribute3 = '';
        //if(isset($_POST['varient1'][0])){
            //$attribute1 = $_POST['attribute1'][0];
            //$varient1= $_POST['varient1'][0];
        //}
        if(isset($_POST['varient1'])){
            $attribute1 = $_POST['attribute1'];
            $varient1= $_POST['varient1'];
        }
        if(isset($_POST['varient2'])){
            $attribute2 = $_POST['attribute2'];
            $varient2= $_POST['varient2'];
        }
        if(isset($_POST['varient3'])){
            $attribute3 = $_POST['attribute3'];
            $varient3= $_POST['varient3'];
        }
          if(isset($_POST['pri_attcolor'])){
            $pri_attcolor = $_POST['pri_attcolor'];
        }
        
        if($_POST){
        if($_POST['pack_content']!=''){
        $final_data =array();
        // if(isset($this->session->userdata['product'])){
        if(!empty($this->session->userdata['product'])){
        $final_data = array(
            //'sale_unit' =>$this->session->userdata['product']['sale_unit'].'|'.$_POST['sale_unit'][0],
            'sale_unit' =>$this->session->userdata['product']['sale_unit'].'|'.$_POST['sale_unit'],
            'pack_content' =>$this->session->userdata['product']['pack_content'].'|'.$_POST['pack_content'],
            'display_name' =>$this->session->userdata['product']['display_name'].'|'.$_POST['display_name'],
            'mrp_price' =>$this->session->userdata['product']['mrp_price'].'|'.$_POST['mrp_price'],
            'mop_price' =>$this->session->userdata['product']['mop_price'].'|'.$_POST['mop_price'],
            'offer_price' =>$this->session->userdata['product']['offer_price'].'|'.$_POST['offer_price'],
            'price_to_display' =>$this->session->userdata['product']['price_to_display'].'|'.$_POST['price_to_display'],
            'display_stock' =>$this->session->userdata['product']['display_stock'].'|'.$_POST['display_stock'],
            'stock_unit' =>$this->session->userdata['product']['stock_unit'].'|'.$_POST['stock_unit'],
            'total_available_stock' =>$this->session->userdata['product']['total_available_stock'].'|'.$_POST['total_available_stock'],
            'moq' =>$this->session->userdata['product']['moq'].'|'.$_POST['moq'],
            'stock_status' =>$this->session->userdata['product']['stock_status'].'|'.$_POST['stock_status'],
            'attribute1' =>$this->session->userdata['product']['attribute1'].'|'.$attribute1,
            'attribute2' =>$this->session->userdata['product']['attribute2'].'|'.$attribute2,
            'attribute3' =>$this->session->userdata['product']['attribute3'].'|'.$attribute3,
            'varient1' =>$this->session->userdata['product']['varient1'].'|'.$varient1,
            'varient2' =>$this->session->userdata['product']['varient2'].'|'.$varient2,
            'varient3' =>$this->session->userdata['product']['varient3'].'|'.$varient3,
            'product_type_ref' =>'packet',
            'pri_attcolor' =>$this->session->userdata['product']['pri_attcolor'].'|'.$pri_attcolor,
            'item_image1' =>$this->session->userdata['product']['item_image1'].'|'.substr($item_image1,6),
            'item_image2' =>$this->session->userdata['product']['item_image2'].'|'.substr($item_image2,6)
            );
        }
        else{
           $stock_unit='';
           if(isset($_POST['stock_unit'])){
               $stock_unit = $_POST['stock_unit'];
           }
        //   print_r($stock_unit);
        //   die;
        $final_data = array(
            'sale_unit' =>$_POST['sale_unit'],
            'pack_content' =>$_POST['pack_content'],
            'display_name' =>$_POST['display_name'],
            'mrp_price' =>$_POST['mrp_price'],
            'mop_price' =>$_POST['mop_price'],
            'offer_price' =>$_POST['offer_price'],
            'price_to_display' =>$_POST['price_to_display'],
            'display_stock' =>$_POST['display_stock'],
            'stock_unit' =>$stock_unit,
            'total_available_stock' =>$_POST['total_available_stock'],
            'moq' =>$_POST['moq'],
            'stock_status' =>$_POST['stock_status'],
            'attribute1' =>$attribute1,
            'attribute2' =>$attribute2,
            'attribute3' =>$attribute3,
            'varient1' =>$varient1,
            'varient2' =>$varient2,
            'varient3' =>$varient3,
            'pri_attcolor'=>$pri_attcolor,
            'product_type_ref' =>'packet',
            'item_image1'=>substr($item_image1,6),
            'item_image2'=>substr($item_image2,6)
            );
        }
        if($_POST['display_stock']=='Yes'){
       if($_POST['sale_unit']!='' && $_POST['pack_content']!='' && $_POST['display_name']!='' && ($_POST['mrp_price']!='' || $_POST['mop_price']!='' || $_POST['offer_price']!='') && $_POST['price_to_display']!='' && $_POST['display_stock']!='' && $_POST['total_available_stock']!='' && $_POST['stock_status']!=''){
            $this->session->set_userdata('product' ,$final_data);
            echo 'MEASUREMENT ADDED';
        }else{
            echo 'Please entry All fields';
        }
        }
        else{
             if($_POST['sale_unit']!='' && $_POST['pack_content']!=''&& $_POST['display_name']!='' && ($_POST['mrp_price']!='' || $_POST['mop_price']!='' || $_POST['offer_price']!='') && $_POST['price_to_display']!='' && $_POST['display_stock']!='' && $_POST['moq']!='' && $_POST['stock_status']!=''){
            $this->session->set_userdata('product' ,$final_data);
            echo 'MEASUREMENT ADDED';
        }else{
            echo 'Please entry All fields';
        }
            
        }
        }
        // echo 'Something went wrong, please try again..!';
        }
        else{
           echo 'Something went wrong, please try again..!';
        }
    }
    public function update_packet_attributes(){
        //if($_FILES['item_image1'] =="" && $_FILES['item_image2'] ==""){
            //echo 'Please select product image';
            //die;
        //}
        $item_image1 =""; $item_image2="";
        if(isset($_POST['pack_itemid'])){
            $pack_itemid = $_POST['pack_itemid'];
            $get_imgs = $this->db->query("select item_images from product_itemdtl where prod_itemid =$pack_itemid ")->result();
            if($get_imgs){
                    $ex_imgs = explode("|",$get_imgs[0]->item_images);
                    if(isset($ex_imgs[0])){
                        $item_image1 = $ex_imgs[0];
                    }if(isset($ex_imgs[1])){
                        $item_image2 = $ex_imgs[1];
                    }
            }
        }    
        if(isset($_FILES['item_image1']['name'])){
            if($_FILES['item_image1']['name']!=""){
                    $config = set_upload_service("../../assets/uploads/products");
                    $this->load->library('upload');
                    $config['file_name'] = time()."_".$_FILES['item_image1']['name'];
                    $this->upload->initialize($config);
                    $this->upload->do_upload('item_image1');
                    $upload_data = $this->upload->data();
                     $item_image1 = $config['upload_path']."/".$upload_data['file_name'];
                     $item_image1 = substr($item_image1,6);
            }}
            if(isset($_FILES['item_image2']['name'])){
            if($_FILES['item_image2']['name']!=""){
                    $config = set_upload_service("../../assets/uploads/products");
                    $this->load->library('upload');
                    $config['file_name'] = time()."_".$_FILES['item_image2']['name'];
                    $this->upload->initialize($config);
                    $this->upload->do_upload('item_image2');
                    $upload_data = $this->upload->data();
                    $item_image2 = $config['upload_path']."/".$upload_data['file_name'];
                    $item_image2 = substr($item_image2,6);
            }
        }
            $item_images = $item_image1.'|'.$item_image2;
            $item_images = trim($item_images,"|");
        if($_POST){ 
             $product_id = $_POST['product_id'];
             $data_productitemdtl = array(
                                'prod_id' => $product_id,
                                //'display_name' => $_POST['display_name'][0],
                                'display_name' => $_POST['display_name'],
                                'sale_unit' => $_POST['sale_unit'],
                                'pack_content' => $_POST['pack_content'],
                                'att1' => $_POST['attribute1'],
                                'att2' => $_POST['attribute2'],
                                'att3' => $_POST['attribute3'],
                                'var1' => $_POST['varient1'],
                                'var2' => $_POST['varient2'],
                                'var3' => $_POST['varient3'],
                                'mrp_price' => $_POST['mrp_price'],
                                'mop_price' => $_POST['mop_price'],
                                'offer_price' => $_POST['offer_price'],
                                'price_to_display' => $_POST['price_to_display'],
                                'display_stock' => $_POST['display_stock'],
                                'stock_unit' => $_POST['stock_unit'],
                                'item_totstock' => $_POST['total_available_stock'],
                                'item_moq' => $_POST['moq'],
                                'item_stocksts' => $_POST['stock_status'],
                                'item_availability' => $_POST['stock_status'],
                                'item_images' => $item_images

                            );
            if(isset($_POST['pri_attcolor'][0])){
                 $data_productitemdtl['pri_attcolor']= $_POST['pri_attcolor'];
             }
            if(isset($_POST['pack_itemid'])){ //update
                $prod_itemid = $_POST['pack_itemid'];
                $status = $this->db->update('product_itemdtl',$data_productitemdtl,array('prod_itemid'=>$prod_itemid));
                echo 'MEASUREMENT UPDATED';
            }else { //insert
                    
            $product_itemdtl = $this->Product_model->insert_data('product_itemdtl', $data_productitemdtl);
            $item_id = $this->db->insert_id();
            $item_uid = 'ITM'.str_pad($item_id, 3, '0', STR_PAD_LEFT);
            $upd_data['item_uid'] = $item_uid;
            $status = $this->db->update('product_itemdtl',$upd_data,array('prod_itemid'=>$item_id));
            echo 'MEASUREMENT ADDED';
            }
            
        }
        else{
           echo 'Something went wrong, please try again..!';
        }
    }
    public function update_loose_attributes(){
        if($_POST){ 
             $product_id = $_POST['product_id'];
             $data_productitemdtl = array(
                                'prod_id' => $product_id,
                                'display_name' => $_POST['loose_display_name'][0],
                                'sale_unit' => $_POST['loose_sale_unit'][0],
                                'pack_content' => $_POST['loose_pack_content'][0],
                                'mrp_price' => $_POST['loose_mrp_price'][0],
                                'mop_price' => $_POST['loose_mop_price'][0],
                                'offer_price' => $_POST['loose_offer_price'][0],
                                'price_to_display' => $_POST['loose_price_to_display'][0]
                            );
            if(isset($_POST['loose_itemid'])){ //update
                $prod_itemid = $_POST['loose_itemid'];
                $status = $this->db->update('product_itemdtl',$data_productitemdtl,array('prod_itemid'=>$prod_itemid));
                echo 'MEASUREMENT UPDATED';
            }else { //insert
                $product_itemdtl = $this->Product_model->insert_data('product_itemdtl', $data_productitemdtl);
                $item_id = $this->db->insert_id();
                $item_uid = 'ITM'.str_pad($item_id, 3, '0', STR_PAD_LEFT);
                $upd_data['item_uid'] = $item_uid;
                $status = $this->db->update('product_itemdtl',$upd_data,array('prod_itemid'=>$item_id));
                echo 'MEASUREMENT ADDED';
            }
            
        }
        else{
           echo 'Something went wrong, please try again..!';
        }
    }
    public function edit_data_packet(){
    if($_POST){
        $prod_itemid = $_POST['prod_itemid'];
        $get_itemdata = $this->db->query("SELECT sale_unit,display_name,pack_content,mrp_price,mop_price,offer_price,item_totstock,item_moq,att1,att2,att3,price_to_display,display_stock,item_stocksts,stock_unit,var1,var2,var3,pri_attcolor,item_images FROM product_itemdtl prodtl WHERE prod_itemid = $prod_itemid")->result();
        $stock_unit ='';
        if(isset($get_itemdata[0])){
        $units = $this->db->query("select * from product_units")->result();
        $sal_unit = $get_itemdata[0]->sale_unit;
             foreach($units as $t)  {  //show only unit which select in sale unit
                                    $id = $t->id;
                                if($sal_unit==$id) { 
                                $stock_unit_option = '<option value='.$t->id.' "selected"="">'.$t->unit.'</option>';
                                } }  

            $stock_unit = "<select class='form-control' name='stock_unit[]' id='stock_unit'>
                                        ".$stock_unit_option."</select>";    
        }
        $item_image1 ="";$item_image2 ="";
        if($get_itemdata[0]->item_images!=""){
            $ex_itemimg = explode("|",$get_itemdata[0]->item_images);
            if(isset($ex_itemimg[0])){
                $item_image1 = base_url('../../').$ex_itemimg[0];
            }if(isset($ex_itemimg[1])){
                $item_image2 = base_url('../../').$ex_itemimg[1];
            }
        }
        $data  = array(
            'display_name'=>(isset($get_itemdata[0]->display_name))?$get_itemdata[0]->display_name:'',
            'sale_unit'=>(isset($get_itemdata[0]->sale_unit))?$get_itemdata[0]->sale_unit:'',
            'pack_content'=> (isset($get_itemdata[0]->pack_content))?$get_itemdata[0]->pack_content:0,
            'mrp_price'=> (isset($get_itemdata[0]->mrp_price))?$get_itemdata[0]->mrp_price:0,
            'mop_price'=> (isset($get_itemdata[0]->mop_price))?$get_itemdata[0]->mop_price:0,
            'offer_price'=> (isset($get_itemdata[0]->offer_price))?$get_itemdata[0]->offer_price:0,
            'total_available_stock'=> (isset($get_itemdata[0]->item_totstock))?$get_itemdata[0]->item_totstock:0,
            'moq'=> (isset($get_itemdata[0]->item_moq))?$get_itemdata[0]->item_moq:0,
            'attribute1' => (isset($get_itemdata[0]->att1))?$get_itemdata[0]->att1:'',
            'attribute2' => (isset($get_itemdata[0]->att2))?$get_itemdata[0]->att2:'',
            'attribute3' => (isset($get_itemdata[0]->att3) && $get_itemdata[0]->att3!=null)?$get_itemdata[0]->att3:'',
            'price_to_display' => (isset($get_itemdata[0]->price_to_display))?$get_itemdata[0]->price_to_display:'',
            'display_stock' => (isset($get_itemdata[0]->display_stock))?$get_itemdata[0]->display_stock:'',
            'stock_unit' => $stock_unit,
            'varient1' => (isset($get_itemdata[0]->var1))?$get_itemdata[0]->var1:'',
            'varient2' => (isset($get_itemdata[0]->var2))?$get_itemdata[0]->var2:'',
            'varient3' => (isset($get_itemdata[0]->var3))?$get_itemdata[0]->var3:'',
            'stock_status' => (isset($get_itemdata[0]->item_stocksts))?$get_itemdata[0]->item_stocksts:0,
            'prod_itemid' => $prod_itemid,
            'pri_attcolor' => (isset($get_itemdata[0]->pri_attcolor))?$get_itemdata[0]->pri_attcolor:'',
            'item_image1' => $item_image1,
            'item_image2' => $item_image2
        );

echo json_encode($data);
        
    }    
    }
    public function edit_data_loose(){
    if($_POST){
        $prod_itemid = $_POST['prod_itemid'];
        $get_itemdata = $this->db->query("SELECT sale_unit,display_name,pack_content,mrp_price,mop_price,offer_price,item_totstock,item_moq,att1,att2,att3,price_to_display,display_stock,item_stocksts,stock_unit,var1,var2,var3 FROM product_itemdtl prodtl WHERE prod_itemid = $prod_itemid")->result();
        $data  = array(
        'display_name'=>(isset($get_itemdata[0]->display_name))?$get_itemdata[0]->display_name:'',
        'sale_unit'=>(isset($get_itemdata[0]->sale_unit))?$get_itemdata[0]->sale_unit:'',
        'pack_content'=> (isset($get_itemdata[0]->pack_content))?$get_itemdata[0]->pack_content:0,
        'mrp_price'=> (isset($get_itemdata[0]->mrp_price))?$get_itemdata[0]->mrp_price:'',
        'mop_price'=> (isset($get_itemdata[0]->mop_price))?$get_itemdata[0]->mop_price:'',
        'offer_price'=> (isset($get_itemdata[0]->offer_price))?$get_itemdata[0]->offer_price:'',
        'item_id' =>$prod_itemid,
        'price_to_display' =>(isset($get_itemdata[0]->price_to_display))?$get_itemdata[0]->price_to_display:'',
        );

echo json_encode($data);
        
    }    
    }
    public function add_session_loose(){

        if($_POST){
        $final_data =array();
        if(!empty($this->session->userdata['product'])){
        $final_data = array(
            'sale_unit' =>$this->session->userdata['product']['sale_unit'].'|'.$_POST['loose_sale_unit'][0],
            'pack_content' =>$this->session->userdata['product']['pack_content'].'|'.$_POST['loose_pack_content'][0],
            'display_name' =>$this->session->userdata['product']['display_name'].'|'.$_POST['loose_display_name'][0],
            'mrp_price' =>$this->session->userdata['product']['mrp_price'].'|'.$_POST['loose_mrp_price'][0],
            'mop_price' =>$this->session->userdata['product']['mop_price'].'|'.$_POST['loose_mop_price'][0],
            'offer_price' =>$this->session->userdata['product']['offer_price'].'|'.$_POST['loose_offer_price'][0],
            'price_to_display' =>$this->session->userdata['product']['price_to_display'].'|'.$_POST['loose_price_to_display'][0],
            'display_stock' =>'',
            'stock_unit' =>'',
            'total_available_stock' =>'',
            'moq' =>'',
            'stock_status' =>'',
            'attribute1' =>'',
            'attribute2' =>'',
            'attribute3' =>'',
            'varient1' =>'',
            'varient2' =>'',
            'varient3' =>'',
            'product_type_ref' =>'loose'
            );
        }
        else{
        $final_data = array(
            'sale_unit' =>$_POST['loose_sale_unit'][0],
            'pack_content' =>$_POST['loose_pack_content'][0],
            'display_name' =>$_POST['loose_display_name'][0],
            'mrp_price' =>$_POST['loose_mrp_price'][0],
            'mop_price' =>$_POST['loose_mop_price'][0],
            'offer_price' =>$_POST['loose_offer_price'][0],
            'price_to_display' =>$_POST['loose_price_to_display'][0],
            'display_stock' =>'',
            'stock_unit' =>'',
            'total_available_stock' =>'',
            'moq' =>'',
            'stock_status' =>'',
            'attribute1' =>'',
            'attribute2' =>'',
            'attribute3' =>'',
            'varient1' =>'',
            'varient2' =>'',
            'varient3' =>'',
            'product_type_ref' =>'loose'
            );
        }
        // print_r($_POST);
        // die;
        if($_POST['loose_sale_unit'][0]!='' && $_POST['loose_pack_content'][0]!='' && $_POST['loose_display_name'][0]!='' && ($_POST['loose_mrp_price'][0]!='' || $_POST['loose_mop_price'][0]!='' || $_POST['loose_offer_price'][0]!='') && $_POST['loose_price_to_display'][0]!=''){
            $this->session->set_userdata('product' ,$final_data);
            echo 'MEASUREMENT ADDED';
        }else{
            echo 'Please entry All fields';
        }
        
            
        }
        else{
           echo 'Something went wrong, please try again..!';
        }
    }
    public function get_varient(){
        $varient_id = $_POST['data'];
        $col_id =  $_POST['col_id'];
        $dt = $this->db->query("select varient_values from varients where varient_id = $varient_id")->result();
        $var = $dt[0]->varient_values;
        $varient =  explode("|",$var);
        $varient = json_decode(json_encode($varient));
        // print_r($varient);
        // die;
        ?>   <select class="form-control" name="varient<?php echo $col_id?>[]" id="varient-<?php echo $col_id?>" >
                                             <option value="">Select Varient</option>
                                         <?php foreach($varient as $p){?>
                                             <option value="<?php echo $p;?>"><?php echo $p;?></option>
                                         <?php }?>
                                         </select>     <? 
    }
    public function change_stock_unit(){
        $sale_unit = $_POST['data'];
        // alert($sale_unit);
        $units = $this->db->query("select * from product_units")->result();
        ?>   <select class="form-control" name="stock_unit[]" id="stock_unit" >
                            <option value="">Select</option>
                                <?php if($sale_unit!="0"){ ?>
                                <?php foreach($units as $t)  {  //show only unit which select in sale unit
                                    $id = $t->id;
                                if($sale_unit==$id) { ?>
                                
                                <option value="<?php echo $t->id; ?>"  <?php echo ($sale_unit == "$t->id")?"selected":""?>><?php echo $t->unit;?></option>
                                <?php } }} ?>  

                                         </select>     <? 
    }
    public function change_loosestock_unit(){
        $sale_unit = $_POST['data'];
        ?>   <select class="form-control" name="loose_stock_unit[]" id="loose_stock_unit" >
                                <option value="">Select</option>
                                <?php if($sale_unit!="0"){ ?>
                                <?php if($sale_unit == "1"){?>
                                <option value="1" <?php if($sale_unit == "1"){?>selected<?php }?>>ml</option>
                                <option value="2" <?php if($sale_unit == "1"){?>selected<?php }?>>ltr</option>
                                <?php }else if($sale_unit == "2"){?> 
                                <option value="2" <?php if($sale_unit == "2"){?>selected<?php }?>>ltr</option>
                                <?php }else if($sale_unit == "3"){?> 
                                <option value="3" <?php if($sale_unit == "3"){?>selected<?php }?>>gm</option>
                                <option value="5" <?php if($sale_unit == "5"){?>selected<?php }?>>kg</option>
                                <?php }else if($sale_unit == "4"){?> 
                                <option value="4" <?php if($sale_unit == "4"){?>selected<?php }?>>box</option>
                                <?php }else if($sale_unit == "5"){?> 
                                <option value="5" <?php if($sale_unit == "5"){?>selected<?php }?>>kg</option>
                                <?php }else if($sale_unit == "6"){?> 
                                <option value="4" <?php if($sale_unit == "4"){?>selected<?php }?>>box</option>
                                <option value="6" <?php if($sale_unit == "6"){?>selected<?php }?>>pcs</option>
                                <option value="7" <?php if($sale_unit == "7"){?>selected<?php }?>>nos</option>
                                <?php }else if($sale_unit == "7"){?> 
                                <option value="4" <?php if($sale_unit == "4"){?>selected<?php }?>>box</option>
                                <option value="6" <?php if($sale_unit == "6"){?>selected<?php }?>>pcs</option>
                                <option value="7" <?php if($sale_unit == "7"){?>selected<?php }?>>nos</option>
                                <?php } else { ?>
                                <option value="8" <?php if($sale_unit == "8"){?>selected<?php }?>>packet</option>
                                <option value="9" <?php if($sale_unit == "9"){?>selected<?php }?>>plate</option>
                                <?php }} ?>
                                         </select>     <? 
    }
    public function editproduct($product_id){
        if(trim($GLOBALS['role_name']) == 'Supervisor (System Default)'){ 
            redirect(base_url('access_denied'));
        }
                $userData = $this->session->userdata['user'];
              $store_id = $userData->store_id;
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(empty($product_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/viewProducts'));
        }
        $template['page'] = 'Product/editproduct';
        $template['menu'] = "Product Management";
        $template['smenu'] = "Edit Product";
        $template['pDescription'] = "Edit Product Details";
        $template['pTitle'] = "Edit Product";
        $template['product_id'] = $product_id;
        $template['store_id'] = $store_id;
        $product_id = decode_param($product_id);
        //print_r($product_id);exit;
        $template['product_data'] = $this->Product_model->getProduct_dtl($product_id);
        $template['product_itemdata'] = $this->Product_model->getpro_itemdtl($product_id);
        $shopper_id = ($this->session->userdata['user_type']==2)?$this->session->userdata['id']:''; 
        $template['store_data'] = $this->Product_model->getallStores($shopper_id);
        $template['attribute_list'] = $this->db->query("select * from attributes")->result();
            $type = $template['product_data']->type_name;
        //get units
            if(strtoupper($type)=="LOOSE"){
                $get_stkid = $this->db->query("select stock_unit from product_itemdtl where pro_id = $product_id")->result();
                if($get_stkid){
                    $stock_unit = $get_stkid[0]->stock_unit;
                    if($stock_unit==1){//ml
                        $template['units'] = $this->db->query("select * from product_units where id in (1)")->result(); 
                    }else  if($stock_unit==2){//ltr
                        $template['units'] = $this->db->query("select * from product_units where id in (1,2) ")->result(); 
                    }
                    else  if($stock_unit==3){//gram
                        $template['units'] = $this->db->query("select * from product_units where id in (3) ")->result(); 
                    }else  if($stock_unit==5){//kg
                        $template['units'] = $this->db->query("select * from product_units where id in (3,5) ")->result(); 
                    }else { //others
                        $template['units'] = $this->db->query("select * from product_units where id in ($stock_unit) ")->result(); 
                    }
              }
            }else{//other than loose
            $template['units'] = $this->db->query("select * from product_units ")->result(); 
            }
        
        $template['packettype'] = $this->db->query("select * from packettype_master order by id")->result();
        $template['pricingtype'] = $this->db->query("select id,price_type from product_pricing where status = 1 order by id")->result();
        $selected_related_pro = explode(",",$template['product_data']->related_prod_ids);
        $rel_products =  $this->db->query("SELECT DISTINCT pro.prod_id,pro.prod_name FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id WHERE pro.prod_status = 1 and pro.prod_id != $product_id order by pro.prod_name")->result();
        $related_products =array();
        foreach($rel_products as $re){
            if(in_array($re->prod_id, $selected_related_pro)){
                $selected =1;
            }else{
                $selected =0;
            }
            $related_products[] = array(
                'prod_id' => $re->prod_id,
                'prod_name' => $re->prod_name,
                'selected' => $selected
                );
        }
        $template['related_products']= json_decode(json_encode($related_products));
    // print_r($template);exit;
        $this->load->view('template',$template);
    }
    public function updateproduct($product_id = ''){
          $err = 0;
        $errMsg = '';
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(!isset($_POST) || empty($_POST)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/editproduct/'.$product_id));
        }else if($err == 0 && (!isset($_POST['product_name']) || empty($_POST['product_name']))){
            $err = 1;
            $errMsg = 'Provide a Product Name';
        }
        else if($err == 0 && (!isset($_POST['brand']) || empty($_POST['brand']))){
            $err = 1;
            $errMsg = 'Provide a Brand Name';
        }
        else if($err == 0 && (!isset($_POST['description']) || empty($_POST['description']))){
            $err = 1;
            $errMsg = 'Provide a Product Description';
        }
        // else if($err == 0 && (!isset($_POST['category_name']) || empty($_POST['category_name']))){
        //     $err = 1;
        //     $errMsg = 'Provide a Category';
        // }
        
        // else if($err == 0 && (!isset($_POST['type']) || empty($_POST['type']))){
        //     $err = 1;
        //     $errMsg = 'Provide a Pack Type';
        // }
        else if($err == 0 && (!isset($_FILES['product_image']) || empty($_FILES['product_image']))){
               $err = 1;
               $errMsg = 'Provide Product Picture';
        }
       if($_FILES['product_image']['name'] ==''){
            $_POST['product_image']= '';
        }
        if($_FILES['product_image']['name'] !=''){
        if($err == 0){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_image')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $_POST['product_image'] = $config['upload_path']."/".$upload_data['file_name'];
            }
        }
        }
        
        if($_FILES['product_image_1']['name'] !=''){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_1']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_1');
            $upload_data = $this->upload->data();
            $_POST['product_image_1'] = $config['upload_path']."/".$upload_data['file_name'];
            
        }
        // else{
        //     $_POST['product_image_1'] = ''; 
        // }
        
        if($_FILES['product_image_2']['name'] !=''){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_2']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_2');
            $upload_data = $this->upload->data();
            $_POST['product_image_2'] = $config['upload_path']."/".$upload_data['file_name'];
            
        }
        
        if($_FILES['product_image_3']['name'] !=''){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_3']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_3');
            $upload_data = $this->upload->data();
            $_POST['product_image_3'] = $config['upload_path']."/".$upload_data['file_name'];
            
        }
        
        if($_FILES['product_image_4']['name'] !=''){
            $config = set_upload_service("../../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_image_4']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('product_image_4');
            $upload_data = $this->upload->data();
            $_POST['product_image_4'] = $config['upload_path']."/".$upload_data['file_name'];
            
        }
         if($err == 1){
            $flashMsg['message'] = $errMsg;
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/editproduct/'.$product_id));
        }
        
         $status = $this->Product_model->updateProduct(decode_param($product_id),$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'product updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Product/viewProducts'));
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Product/viewProducts/'));
    }
    
    public function getProductData(){
        $return_arr = array('status'=>'0');
        if(!isset($_POST)||empty($_POST)||!isset($_POST['product_id'])||empty($_POST['product_id'])){
            echo json_encode($return_arr);exit;
        }
        $product_id = decode_param($_POST['product_id']);
        $product_data = $this->Product_model->get_product_data(array('product_id'=>$product_id));
        if(!empty($product_data)){
            $return_arr['status'] = 1;
            $return_arr['product_data'] = $product_data;
        }
        echo json_encode($return_arr);exit;
    }
    public function change_packet_primaryatt(){
        $attribute1 = $_POST['data'];
        $attributes = $this->db->query("select * from attributes")->result();
        ?> <label for="serve_for" id="label_PA">Choose the Product Primary Attribute</label>  
        <select name="primary_varient" class="form-control" id ="primary_varient" > <?php 
         foreach($attributes as $t)  {  //show only attributes which select in sale unit
                                    $id = $t->id;
                                if($attribute1==$id) { ?>
                                
                                <option value="<?php echo $t->id; ?>"  <?php echo ($attribute1 == "$t->id")?"selected":""?>><?php echo $t->attribute_name;?></option>
                                <?php } } ?>  

                                         </select>     <?php 
    }
    public function productsUpload(){
        $template['page'] = 'Product/productsUpload';
        $template['menu'] = 'Product Management';
        $template['smenu'] = 'View Products';
        $template['pTitle'] = "View Products";
        $template['pDescription'] = "View and Manage Product";
        $store_id = $this->session->userdata['user']->store_id;
        $template['unpro_data'] = $this->Product_model->unprocessed_product($store_id);
        $this->load->view('template',$template);
    }
    public function unique_id(){
    $today = date("Ymd");
    $rand=mt_rand(10000,99999);
    $auto_id = $today . $rand;
    return $auto_id;
}
//UPLOADED CSV DATA SAVED INTO DATATABLE
 function csv_upload() {
     $data = $this->input->post();
     $store_id = $this->session->userdata['user']->store_id;
     if($data['type'] ==1 ){ //Product Update
         $exists_chk1 = $this->db->query("select * from product_process where process_status = 0 and store_id = $store_id")->result(); //process_status = 0 means Previous store products not processed , So before upload New store data, process current Store Products
        if($exists_chk1){
        $this->session->set_flashdata('message', 'Please Process the existing Store Product And try to upload New Store Products');
        redirect('Product/productsUpload');
        }
        $exists_chk2 = $this->db->query("select * from product_process where process_status = 2 and store_id = $store_id")->result(); //process_status = 2 means Previous store products processed but wrong entry product data not downnloaded , So before upload new store data, download wrong entry products
        if($exists_chk2){
        $this->session->set_flashdata('message', 'Please Download Wrong entry products CSV data And try to upload New Store Products');
        redirect('Product/productsUpload');
        }
        $exists_chk2 = $this->db->query("select * from product_process where process_status = 3 and store_id = $store_id")->result(); //process_status = 2 means Previous store products processed but wrong entry product data not downnloaded , So before upload new store data, download wrong entry products
        if($exists_chk2){
        $this->session->set_flashdata('message', 'Please Download Products CSV data And try to upload As Store STOCK UPPDATE');
        redirect('Product/productsUpload');
        }
         
     }
        $jt=0;
        $unique_id=$this->unique_id();
        //$data1['u_id']=$unique_id;
        $path = $_FILES["userfile"]["tmp_name"];

  if(!empty($_FILES)){
	    $filename= $_FILES["userfile"]["name"][0];
        $file_ext = pathinfo($filename,PATHINFO_FILENAME);
    
        $j = 1;                 
        foreach($_FILES as $filekey=>$fileattachments){
            foreach($fileattachments as $key=>$val){
                if(is_array($val)){
                    $i = 1;
                    foreach($val as $v){
                        $field_name = "multiple_".$filekey."_".$i;
                        $_FILES[$field_name][$key] = $v;
                        $i++;   
                    }
                }else{
                    $field_name = "single_".$filekey."_".$j;
                    $_FILES[$field_name] = $fileattachments;
                    $j++;
                    break;
                }
            }                       
            // Unset the useless one 
            unset($_FILES[$filekey]);
        }


        $filetest=array();
    	foreach($_FILES as $field_name => $file){
        if(isset($file['error']) && $file['error']==0){
          $config['upload_path']   =   "application/controllers/csv/";
          //$config['file_name'] = time();
       		$config['allowed_types'] =   "xlsx|csv"; 
       		$config['max_size']      =   "50000";
       		$config['max_width']     =   "60000";
       		$config['max_height']    =   "50000";
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ( ! $this->upload->do_upload($field_name)){
                $error = array('error' => $this->upload->display_errors());
                echo "Error Message : ". $error['error'];
            }else{
                $data = $this->upload->data();
                
                $filetest[$jt]= base_url().'application/controllers/csv/'.$data['file_name'];  
            }}
        else{
        $filetest[$jt]='';}
        $jt++;
        }   
  }
  

 
        $data = $this->input->post();
        $data['file_name']=$file_ext;
        $data['file_path'] = $filetest[0];
        $path_parts = pathinfo($filetest[0]);
        $current_file_name =$path_parts['basename'];
        $upl_type = $data['type'];
        $array_data = array();
        $r = 0;
        $flag = true;
        $status = 1;
if (($handle = fopen(dirname(__FILE__).'/csv/'.$current_file_name, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 100000, ",")) !== FALSE) {
    	if($flag) { $flag = false; continue; } //to remove first line (heading)
    	if($upl_type ==1 ){ //Product Update
        	if(count($data)!=29){ //column count represent - 1.sno,2.display name,3.product name etc.,
        	$this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check the data');
                    redirect('Product/productsUpload'); 
        	}
        	if((trim($data[2])=='')||(trim($data[3])=='')||(trim($data[4])=='')||(trim($data[5])=='')||(trim($data[6])=='')||(trim($data[7])=='')||(trim($data[8])=='')||(trim($data[9])=='') || (trim($data[10])=='')||(trim($data[23])=='')||(trim($data[24])=='')||(trim($data[25])=='')||(trim($data[26])=='')){
        	 $status = 0;   
        	}
    	
        	if((trim($data[2])=='')&&(trim($data[3])=='')&&(trim($data[4])=='')&&(trim($data[5])=='')&&(trim($data[6])=='')&&(trim($data[7])=='')&&(trim($data[8])=='')&&(trim($data[9])=='')&&(trim($data[10])=='')&&(trim($data[11])=='') &&(trim($data[12])=='')){
        	 $status = 3;    //If all column empty means empty line so status = 3
        	}
        	else{
                    if((trim($data[2])=='')||(trim($data[3])=='')||(trim($data[5])=='')||(trim($data[6])=='')||(trim($data[7])=='')||(trim($data[8])=='') ||(trim($data[9])=='') ||(trim($data[10])=='')||(trim($data[23])=='')||(trim($data[24])=='')){
                    $status = 2;   
                    $this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check Mandatory Fields');
                    redirect('Product/productsUpload');
                    }
        	    }
    	
        	if( (trim($data[20])<trim($data[21])) ||(trim($data[20])<trim($data[21])) ){
        	  $status = 2;   
        	 $this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check MRP Price Should greater than MOP & Offer Price');
                        redirect('Product/productsUpload');
            }
        	if( (trim($data[18])=='0') && (trim($data[18])=='') || (trim($data[19])=='0') && (trim($data[19])=='') ){ //CGST , SGST/IGST
        	  $status = 2;   
        	 $this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check CGST,SGST/IGST values ');
                        redirect('Product/productsUpload');
            }
            if($status != 3){
        	$array_data[$r]=array( 
        	    'display_name' => trim($data[2]),
        		'product_name' => trim($data[3]),
        		'brand' => trim($data[4]),
        		'description' => trim($data[5]),
        		'category_name' => trim($data[6]),
        		'type' => trim($data[7]),
        		'pack_content' => trim($data[8]),
        		'sale_unit' => trim($data[9]),
        		'add_varient' => trim($data[10]),
        		'attribute1' => trim($data[11]),
        		'varient1' => trim($data[12]),
        		'attribute2' => trim($data[13]),
        		'varient2' => trim($data[14]),
        		'attribute3' => trim($data[15]),
        		'varient3' => trim($data[16]),
        		'primary_varient' => trim($data[17]),
        		'mrp_price' =>trim($data[20]),
        		'mop_price' =>trim($data[21]),
        		'offer_price' =>trim($data[22]), 
        		'price_to_display'=>trim($data[23]),
        		'display_stock'=>trim($data[24]),
        		'stock_unit'=>trim($data[25]),
        		'moq'=>trim($data[26]),
        		'total_available_stock'=>trim($data[27]),
        		'stock_status'=>trim($data[28]),
        		'HSN_code'=>trim($data[1]),
        		'CGST'=>trim($data[18]),
        		'SGST_IGST'=>trim($data[19]),
        		'status'=>$status
        	);
        	$r++;
        	}
        	else{
        	    $status = 0;
        	    }
    	}
    	else if($upl_type ==2 ){ //Stock Update
            	if(count($data)!=5){ //column count represent - 1.proid,2.product name,3.variantid,4.variantname,5.stock
            	   $this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check the data');
                        redirect('Product/productsUpload'); 
            	}
    	
    	        if(trim($data[0])=='' || trim($data[1])=='' || trim($data[2])=='' || trim($data[4])==''){
                $this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check Mandatory Fields');
                redirect('Product/productsUpload');
                          }
                else{
                    $array_data[$r]=array( 
                    'pro_uid' => trim($data[0]),
                    'product_name' => trim($data[1]),
                    'vid' => trim($data[2]),
                    'variant_name' => trim($data[3]),
                    'stock'=>trim($data[4])
                    );
                    $r++;
              }
    	}
    }
    fclose($handle);
}
// echo '<pre>';
// print_r($array_data);
// die;
if($upl_type==1){ //product update
// $csvData = json_decode(json_encode($array_data));
$csvData = (object) $array_data;
$ex_stock_unit =''; $ex_stock_status ='';$ex_product_name='';
  foreach ($csvData as $value) {
      $value = (object) $value;
      $type = $value->type;
      $product_name = $value->product_name;
      $price_to_display = trim($value->price_to_display);
      if(strtoupper($price_to_display)=='MRP'){ //1
          $mrp_price = $value->mrp_price;
          if($mrp_price=='' || $mrp_price==0){
              $status = 2;
          }
      }elseif(strtoupper($price_to_display)=='MOP'){ //2
          $mop_price = $value->mop_price;
          if($mop_price=='' || $mop_price==0){
              $status = 2;
          }
      }elseif(strtoupper($price_to_display)=='OFFER PRICE'){ //3
          $offer_price = $value->offer_price;
          if($offer_price=='' || $offer_price==0){
              $status = 2;
          }
      }elseif(strtoupper($price_to_display)=='PRICE RANGE'){ //4
          $mrp_price = $value->mrp_price;
          $mop_price = $value->mop_price;
          if($mrp_price=='' || $mrp_price==0 || $mop_price=='' || $mop_price==0){
              $status = 2;
          }
          
      }else{ // REQUEST TO PRICE //5
          $mrp_price = $value->mrp_price;
          if($mrp_price=='' || $mrp_price==0){
              $status = 2;
          }
      }
      $display_stock = $value->display_stock;
      if(strtoupper($display_stock)=='YES'){
          $total_available_stock = $value->total_available_stock;
          if($total_available_stock=''){
              $status = 2;
          }
      }
      else{
          $moq = $value->moq;
          if($moq=''){
              $status = 2;
          }
      }
  }
if($status==2){
    $this->session->set_flashdata('message', 'Failed to Upload CSV file, Please check Mandatory Fields');
    redirect('Product/productsUpload');
}
}
//  $csvData = json_decode(json_encode($array_data));
$csvData = (object) $array_data;
 if($upl_type==1){ //product update
foreach ($csvData as $value) {
      $value = (object) $value;
      //map stockunit and get stockunit_id from msater table
      $sale_unit = '';
      $unit =strtolower($value->sale_unit);
      $unit_data = $this->db->query("SELECT * FROM `product_units` where unit = '$unit'")->result();
      if($unit_data){
          $sale_unit = $unit_data[0]->id;
      }
      
      $price_to_display = 0;
      $chk_price_to_display = trim($value->price_to_display);
      $get_pricetype_id = $this->db->query("select * from product_pricing where price_type ='$chk_price_to_display'")->result();
      if($get_pricetype_id){ //1- MRP 2- MOP 3- offer price 4- range price 5- request of pricing
          $price_to_display = $get_pricetype_id[0]->id;
      }

      //get stock unit id from master table
      $stock_unit = '';
      $stk_unit =strtolower($value->stock_unit);
      $stkunit_data = $this->db->query("SELECT * FROM `product_units` where unit = '$stk_unit'")->result();
      if($stkunit_data){
          $stock_unit = $stkunit_data[0]->id;
      }
      
      // attribute1 start here //
      $attribute1 = '';
      $a1 = trim($value->attribute1);
      if($a1!='' ){
      $chk_attribute1 = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$a1'")->result();
      if($chk_attribute1){
          $attribute1 = $chk_attribute1[0]->id;
      }
      else{
          $insert_data= array();
          $insert_data['attribute_name'] = $a1;
		  $this->db->insert('attributes',$insert_data);
		  $chk_attribute1 = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$a1'")->result();
		  $attribute1 = $chk_attribute1[0]->id;
      }
      
      //update attibute_ids in store table 
      $str_att = $this->db->query("select * from stores where store_id = $store_id")->result();
      $attribute_ids = $str_att[0]->attribute_ids;
      if($attribute_ids!=''){
        $ary =  explode(',',$attribute_ids);
          if (in_array("$attribute1", $ary))
              {
              //varient name exists
              }
              else{
                   $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute_ids.','.$attribute1);
                   $this->Product_model->update_data('stores', $value_data, $where);
              }
           }
        else{
                   $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute1);
                   $this->Product_model->update_data('stores', $value_data, $where);
            }
      }
      //.................//
      
      $attribute2 = '';
      $a2 = trim($value->attribute2);
      if($a2!='' ){
      $chk_attribute2 = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$a2'")->result();
      if($chk_attribute2){
          $attribute2 = $chk_attribute2[0]->id;
      }
      else{
          $insert_data=array();
          $insert_data['attribute_name'] =$a2;
		  $this->db->insert('attributes',$insert_data);
		  $chk_attribute2 = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$a2'")->result();
		  $attribute2 = $chk_attribute2[0]->id;
      }
      //update attibute_ids in store table 
      $str_att = $this->db->query("select * from stores where store_id = $store_id")->result();
      $attribute_ids = $str_att[0]->attribute_ids;
      if($attribute_ids!=''){
     $ary =  explode(',',$attribute_ids);
          if (in_array("$attribute2", $ary))
              {
              //varient name exists
              }
              else{
                   $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute_ids.','.$attribute2);
                   $this->Product_model->update_data('stores', $value_data, $where);
              }
        }
        else{
          $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute2);
                   $this->Product_model->update_data('stores', $value_data, $where);
        }
      }
      
      $attribute3 = '';
      $a3 = trim($value->attribute3);
      if($a3!='' ){
      $chk_attribute3 = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$a3'")->result();
      if($chk_attribute3){
          $attribute3 = $chk_attribute3[0]->id;
      }
      else{
          $insert_data=array();
          $insert_data['attribute_name'] =$a3;
		  $this->db->insert('attributes',$insert_data);
		  $chk_attribute3 = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$a3'")->result();
		  $attribute3 = $chk_attribute3[0]->id;
      }
      //update attibute_ids in store table 
      
      $str_att = $this->db->query("select * from stores where store_id = $store_id")->result();
      $attribute_ids = $str_att[0]->attribute_ids;
      if($attribute_ids!=''){
          $ary =  explode(',',$attribute_ids);
          if (in_array("$attribute3", $ary))
              {
              //varient name exists
              }
              else{
                   $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute_ids.','.$attribute3);
                   $this->Product_model->update_data('stores', $value_data, $where);
              }
     
      }
      else{
          $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute3);
                   $this->Product_model->update_data('stores', $value_data, $where);
      }
      }
      ///////////////////
      
      if($value->varient1){
          if($attribute1){
              $varient1 = $value->varient1; //storewise variant,attribute will change 
            $chk_varients1 = $this->db->query("SELECT * FROM varients WHERE att_id = $attribute1 and varient_name ='$varient1' and store_id = $store_id ")->result();
            if(empty($chk_varients1)){
                $insert_data=array();
                $insert_data['varient_name'] =$varient1;
                $insert_data['att_id'] =$attribute1;
                $insert_data['store_id'] =$store_id;
		        $this->db->insert('varients',$insert_data);
            }
          }
    	}
    
      if($value->varient2){
          if($attribute2){
              $varient2 = $value->varient2;
            $chk_varients2 = $this->db->query("SELECT * FROM varients WHERE att_id = $attribute2 and varient_name ='$varient2' and store_id = $store_id")->result();
            if(empty($chk_varients2)){
                $insert_data=array();
                $insert_data['varient_name'] =$varient2;
                $insert_data['att_id'] =$attribute2;
                $insert_data['store_id'] =$store_id;
		        $this->db->insert('varients',$insert_data);
            }
          }
    	}
    	
      if($value->varient3){
          if($attribute3){
              $varient3 = $value->varient3;
            $chk_varients3 = $this->db->query("SELECT * FROM varients WHERE att_id = $attribute3 and varient_name ='$varient3' and store_id = $store_id")->result();
            if(empty($chk_varients3)){
                $insert_data=array();
                $insert_data['varient_name'] =$varient3;
                $insert_data['att_id'] =$attribute3;
                $insert_data['store_id'] =$store_id;
		        $this->db->insert('varients',$insert_data);
            }
          }
    	}
    	
    	$primary_attribute_id = '';
    	$primary_attribute = trim($value->primary_varient); //Primary attribute example 'Color' 'Receipe'
    	$chk_primary_attribute = $this->db->query("SELECT * FROM `attributes` WHERE attribute_name  = '$primary_attribute'")->result();
    	if($chk_primary_attribute){
		  $primary_attribute_id = $chk_primary_attribute[0]->id;
    	}
    	
    $product_name = $value->product_name;
    $brand = $value->brand;
    $category_name = trim($value->category_name);
    $category_id = 0;
if($category_name!=''){
        $chk_exists = $this->db->query("select * from sub_category where subcategory_name ='$category_name' and store_id = $store_id")->result(); 
		if($chk_exists){
		    $maincategory_id = $chk_exists[0]->maincategory_id;
		    $category_id = $chk_exists[0]->category_id;
		    $subcat_id = $chk_exists[0]->subcat_id;
		}
		else{
		  $cat_data['subcategory_name'] = trim($value->category_name); 
		  $cat_data['status'] = 1; 
		  $cat_data['store_id'] = $store_id; 
		  $this->db->insert('sub_category',$cat_data); //insert category if not exists
		  $chk = $this->db->query("select * from sub_category where subcategory_name ='$category_name' and store_id = $store_id")->result();
		    $maincategory_id = 0;
		    $category_id  = 0;//for newly added sub category , category_id = 0 we have to do mapping from admin 
		    $subcat_id  = $chk[0]->subcat_id; 
		}
		if($category_id!='' && $category_id!=0){
		$cat = $this->db->query("select * from sub_category where subcat_id ='$subcat_id' and store_id = $store_id")->result();
		$category_name = $cat[0]->subcategory_name; // subCategory Name
		}
}

$pack_type = $value->type;
 $chk_brand = $this->db->query("select * from brand where brand_name ='$brand' and store_id = $store_id ")->result();
 if($chk_brand){
     $brand_id =$chk_brand[0]->brand_id; 
 }else{
         $br_data['brand_name'] = $brand; 
		  $br_data['store_id'] = $store_id; 
		  $this->db->insert('brand',$br_data);
		  $brand_id = $this->db->insert_id();
     
 }
 $pack_type_id = 0;
 $chk_typeid = $this->db->query("SELECT * FROM packettype_master WHERE type_name ='$pack_type'")->result();
 if($chk_typeid){
     $pack_type_id = $chk_typeid[0]->id;
 }
$data = $this->Product_model->chkProudctExists($product_name,$brand_id,$subcat_id,$pack_type_id,$store_id);
if($data){ //if product exists update item table
        $prod_id = $data->prod_id;
        if(strtoupper($value->stock_status)=='AVAILABLE'){
                $availability = 1;
            }else{
                $availability = 0;
            }
        $data_productitemdtl = array(
                                'prod_id' => $prod_id,
                                'display_name' => $value->display_name,
                                'sale_unit' => $sale_unit,
                                'pack_content' => $value->pack_content,
                                'att1' => $attribute1,
                                'att2' => $attribute2,
                                'att3' => $attribute3,
                                'var1' => $value->varient1,
                                'var2' => $value->varient2,
                                'var3' => $value->varient3,
                                'pri_attcolor'=>'',
                                'mrp_price' => $value->mrp_price,
                                'mop_price' => $value->mop_price,
                                'offer_price' => $value->offer_price,
                                'price_to_display' => $price_to_display,
                                'display_stock' => $value->display_stock,
                                'stock_unit' => $stock_unit,
                                'item_totstock' => $value->total_available_stock,
                                'item_moq' => $value->moq,
                                'item_stocksts' =>$availability ,
                                'item_availability' => $availability
                            );
        $product_itemdtl = $this->Product_model->insert_data('product_itemdtl_process', $data_productitemdtl);
        $item_id = $this->db->insert_id();
        $item_uid = 'ITM'.str_pad($item_id, 3, '0', STR_PAD_LEFT);
            $upd_data['item_uid'] = $item_uid;
            $status = $this->db->update('product_itemdtl_process',$upd_data,array('prod_itemid'=>$item_id));
        
         }
else{ // insert new item
    
        if($value->product_name!==''){
            if(strtoupper($value->type)=='LOOSE'){
               $add_varient = 'No'; 
            }
            else{
               $add_varient = $value->add_varient;
            }
            
            if(strtoupper($value->stock_status)=='AVAILABLE'){
                $availability = 1;
            }else{
                $availability = 0;
            }
                  $data_product = array(
                                'prod_name' => $value->product_name,
                                'brand_id' => $brand_id,
                                'description' => $value->description,
                                'cat_name' => $category_name,
                                'maincat_id' => $maincategory_id,
                                'cat_id' =>$category_id,
                                'subcat_id' =>$subcat_id,
                                'packtype_id' => $pack_type_id,
                                'store_id' => $store_id,
                                'add_variant' => $add_varient,
                                'pri_att' =>$primary_attribute_id,
                                'hsn_code' => $value->HSN_code,
                                'cgst' => $value->CGST,
                                'sgst' => $value->SGST_IGST,
                                'prod_status' =>1,
                                'prod_createddate' => date('Y-m-d H:i:s'),
                                'file_name'=>$current_file_name,
                                'process_status' => 0
                            );
                            
        $product = $this->Product_model->insert_data('product_process', $data_product);
            $prod_id = $this->db->insert_id();
           $pro_uid = 'P'.str_pad($prod_id, 3, '0', STR_PAD_LEFT);
            $up_data['prod_uid'] = $pro_uid;
            $status = $this->db->update('product_process',$up_data,array('prod_id'=>$prod_id));
            
        $data_productitemdtl = array(
                                'prod_id' => $prod_id,
                                'display_name' => $value->display_name,
                                'sale_unit' => $sale_unit,
                                'pack_content' => $value->pack_content,
                                'att1' => $attribute1,
                                'att2' => $attribute2,
                                'att3' => $attribute3,
                                'var1' => $value->varient1,
                                'var2' => $value->varient2,
                                'var3' => $value->varient3,
                                'pri_attcolor'=>'',
                                'mrp_price' => $value->mrp_price,
                                'mop_price' => $value->mop_price,
                                'offer_price' => $value->offer_price,
                                'price_to_display' => $price_to_display,
                                'display_stock' => $value->display_stock,
                                'stock_unit' => $stock_unit,
                                'item_totstock' => $value->total_available_stock,
                                'item_moq' => $value->moq,
                                'item_stocksts' => $availability,
                                'item_availability' => $availability
                            );
        $product_itemdtl = $this->Product_model->insert_data('product_itemdtl_process', $data_productitemdtl);
        $item_id = $this->db->insert_id();
        $item_uid = 'ITM'.str_pad($item_id, 3, '0', STR_PAD_LEFT);
            $upd_data['item_uid'] = $item_uid;
            $status = $this->db->update('product_itemdtl_process',$upd_data,array('prod_itemid'=>$item_id));
}
         }

}
$this->session->set_flashdata('status', 'Product Uploaded successfully');
redirect('Product/productsUpload');
}else if($upl_type==2){
    die;
    foreach ($csvData as $value) {
        $pro_uid = $value->pro_uid;
        $vid = $value->vid;
        $stock = $value->stock;
        $stock_data = $this->db->query("select * from products where pro_uid='$pro_uid'")->result();
        if($stock_data){
        $sale_unit = $stock_data[0]->sale_unit;
        $varwise_stock =  explode('|',$sale_unit);
        $display_stock = $stock_data[0]->display_stock;
        $expdisplay_stock =  explode('|',$display_stock);
        $moq = $stock_data[0]->moq;
        $total_available_stock= $stock_data[0]->total_available_stock;
        $t=0;$update_moq='';$update_total_available_stock='';
        foreach($varwise_stock as $stk){
            $disp_stock = $expdisplay_stock[$t];
        if(strtoupper($disp_stock)=='NO'){//update MSU 
                $exmoq =  explode('|',$moq);
                $var_id = ltrim($vid, 'V'); //V003
                $variant_id = intval($var_id);//003 to 3
                
                if($t==($variant_id-1)){
                    if($update_moq==''){
                    $update_moq = $stock;
                    }else{
                    $update_moq = $update_moq.'|'.$stock;
                    }
                }else{
                    if($update_moq==''){
                    $update_moq = $exmoq[$t];
                    }else{
                    $update_moq = $update_moq.'|'.$exmoq[$t];
                    }
                }
                $update_stk['moq']=$update_moq;
            }
            if(strtoupper($disp_stock)=='YES'){//update Stock 
                $total_available_stock =  explode('|',$total_available_stock);
                $var_id = ltrim($vid, 'V'); //V003
                $variant_id = intval($var_id);//003 to 3
                
                if($t==($variant_id-1)){   
                    if($update_total_available_stock==''){
                    $update_total_available_stock = $total_available_stock[$t] + $stock;
                    }else{
                        $stock = $total_available_stock[$t] + $stock;
                        $update_total_available_stock = $update_total_available_stock.'|'.$stock;
                    }
                }else{
                    if($update_total_available_stock==''){
                    $update_total_available_stock = $total_available_stock[$t];
                    }else{
                    $update_total_available_stock = $update_total_available_stock.'|'.$total_available_stock[$t];
                    }
                }
                $update_stk['total_available_stock']=$update_total_available_stock;
            }  
            $t++;
        $where5 = array('pro_uid' => $pro_uid);
        $this->Product_model->update_data('products', $update_stk, $where5); 
        }
        
        }
        }
$this->session->set_flashdata('status', 'Stock Updated successfully');
redirect('Product/productsUpload');
    }
    
    
}
//PROCESS PRODUCT TABLE
public function Process_product(){
    if($_POST['process'] == 'process_data'){
        $store_id = $this->session->userdata['user']->store_id;
        $process_data = $this->Product_model->process_product($store_id);
        foreach($process_data as $dt){
            $product_id = $dt->prod_id;
            $data['process_status'] = 1;  //Update process_status = 0 if any one conditions not satisfied
		    $result = $this->db->update('product_process',$data,array('prod_id'=>$product_id));
        }
        //Update or insert Successfully Processed Product to "Product table and delete from "products_process" table
        $processed_data = $this->Product_model->processed_product(); //Processed Correct product
        foreach($processed_data as $data){
            $product_name = $data->prod_name;
            $brand_id = $data->brand_id;
            $subcat_id = $data->subcat_id;
            $pack_type_id = $data->packtype_id;
            $store_id = $data->store_id;
            $chk_product_exists =$this->db->query("SELECT * FROM product AS PRD WHERE PRD.prod_name='$product_name' AND PRD.brand_id='$brand_id' AND PRD.subcat_id='$subcat_id' AND PRD.packtype_id='$pack_type_id' AND PRD.store_id='$store_id'")->result();
            if($chk_product_exists){ //Update stock and varient
                     $product_id = $chk_product_exists->prod_id;
                     $update_data['process_status'] = 3;  //Update process_status = 3 if same product try to upload in that case try stockupdate option
                     $result = $this->db->update('product_process',$update_data,array('prod_id'=>$product_id));
            }
            else { //insert new product
            $subcat_id = $data->subcat_id;
            $find_cat = $this->db->query("select * from sub_category where subcat_id  = $subcat_id and store_id = $store_id")->result();
            $maincategory_id = $find_cat[0]->maincat_id;
            $category_id = $find_cat[0]->cat_id;
            
                        $data_product = array(
                                'prod_name' => $data->prod_name,
                                'brand_id' => $data->brand_id,
                                'description' => $data->description,
                                'cat_name' => $data->cat_name,
                                'maincat_id' => $data->maincat_id,
                                'cat_id' =>$data->cat_id,
                                'subcat_id' =>$data->subcat_id,
                                'packtype_id' => $data->packtype_id,
                                'store_id' => $data->store_id,
                                'add_variant' => $data->add_variant,
                                'pri_att' =>$data->pri_att,
                                'hsn_code' => $data->hsn_code,
                                'cgst' => $data->cgst,
                                'sgst' => $data->sgst,
                                'prod_status' =>$data->prod_status,
                                'prod_createddate' => date('Y-m-d H:i:s'),
                            );
                     $product = $this->Product_model->insert_data('product', $data_product);
                     $last_id=$this->db->insert_id();
                     $sequence_num = str_pad($last_id, 3, 0, STR_PAD_LEFT);
                     $pro_uid = "P".$sequence_num;
                     $update_data1['prod_uid'] = $pro_uid;
                     $status = $this->db->update('product',$update_data1,array('prod_id'=>$last_id));
                    //  remove data from process products table
                    $product_id = $data->prod_id;
                     $this->db->query("delete from product_process where prod_id =$product_id");
                     
                     
                     $item_tbl = $this->db->query("select * from product_itemdtl_process where prod_id =$product_id ")->result();
                     if($item_tbl){
           foreach($item_tbl as $item){
        $data_productitemdtl = array(
                                'prod_id' => $last_id,
                                'display_name' => $item->display_name,
                                'sale_unit' => $item->sale_unit,
                                'pack_content' => $item->pack_content,
                                'att1' => $item->att1,
                                'att2' => $item->att2,
                                'att3' => $item->att3,
                                'var1' => $item->var1,
                                'var2' => $item->var2,
                                'var3' => $item->var3,
                                'pri_attcolor'=>$item->pri_attcolor,
                                'mrp_price' => $item->mrp_price,
                                'mop_price' => $item->mop_price,
                                'offer_price' => $item->offer_price,
                                'price_to_display' => $item->price_to_display,
                                'display_stock' => $item->display_stock,
                                'stock_unit' => $item->stock_unit,
                                'item_totstock' => $item->item_totstock,
                                'item_moq' => $item->item_moq,
                                'item_stocksts' => $item->item_stocksts,
                                'item_availability' => $item->item_availability
                            );
        $product_itemdtl = $this->Product_model->insert_data('product_itemdtl', $data_productitemdtl);
        $item_id = $this->db->insert_id();
        $item_uid = 'ITM'.str_pad($item_id, 3, '0', STR_PAD_LEFT);
            $upd_data['item_uid'] = $item_uid;
            $status = $this->db->update('product_itemdtl',$upd_data,array('prod_itemid'=>$item_id));
            $prod_itemid = $item->prod_itemid;
            $this->db->query("delete from product_itemdtl_process where prod_itemid =$prod_itemid");
                     }}
            }
                
        }
        if($process_data){
            $flashMsg = 'Product Processed';
            $this->session->set_flashdata('success',$flashMsg);
        }else{
            $flashMsg = 'There is no unprocessed product to Process';
            $this->session->set_flashdata('message',$flashMsg);
        }
            redirect(base_url('Product/productsUpload'));  
         }
    else if($_POST['process'] == 'export_data'){
        $store_id = $_POST['store_id'];
         $file_name = 'export_unprocessed_data_'.date('Ymd').'.csv'; 
     header("Content-Description: File Transfer"); 
     header("Content-Disposition: attachment; filename=$file_name"); 
     header("Content-Type: application/csv;");

     $query = $this->db->query("select * from product_process where process_status in (2,3) and store_id = $store_id order by product_id")->result();
     $r = 0;$array_data =array();
    	foreach($query as $dt){
    	    $unpro_product_name = trim($dt->prod_name);
    	    $current_file_name = $dt->file_name;
    	   // $current_file_name = 'Yellow_Mart_Bulk_Restaurant_SaltnPepper_-_Description12.csv';
            if (($handle = fopen(dirname(__FILE__).'/csv/'.$current_file_name, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 100000, ",")) !== FALSE) {
            // 	if($flag) { $flag = false; continue; } //to remove first line (heading)
            	$excelsheet_proname = trim($data[3]);
            	if($unpro_product_name==$excelsheet_proname){
            	    $array_data[$r]=array( 
            'sno' => trim($data[0]),
            'HSN_code'=>trim($data[1]),
    	    'display_name' => trim($data[2]),
    		'product_name' => trim($data[3]),
    		'brand' => trim($data[4]),
    		'description' => trim($data[5]),
    		'category_name' => trim($data[6]),
    		'type' => trim($data[7]),
    		'pack_content' => trim($data[8]),
    		'sale_unit' => trim($data[9]),
    		'add_varient' => trim($data[10]),
    		'attribute1' => trim($data[11]),
    		'varient1' => trim($data[12]),
    		'attribute2' => trim($data[13]),
    		'varient2' => trim($data[14]),
    		'attribute3' => trim($data[15]),
    		'varient3' => trim($data[16]),
    		'primary_varient' => trim($data[17]),
    		'CGST'=>trim($data[18]),
    		'SGST_IGST'=>trim($data[19]),
    		'mrp_price' =>trim($data[20]),
    		'mop_price' =>trim($data[21]),
    		'offer_price' =>trim($data[22]), 
    		'price_to_display'=>trim($data[23]),
    		'display_stock'=>trim($data[24]),
    		'stock_unit'=>trim($data[25]),
    		'moq'=>trim($data[26]),
    		'total_available_stock'=>trim($data[27]),
    		'stock_status'=>trim($data[28])
    	);
    	//once unprocessed product exported delete the product from products_process table
    		 $product_id = $dt->product_id;
             $this->db->query("delete from product_process where prod_id =$product_id and process_status in (2,3) and store_id = $store_id  ");  
                 	$r++;
            	}
            }}
     
    	}
    // 	echo '<pre>';
    // 	print_r($array_data);
    // 	die;
    	$export_data = json_decode(json_encode($array_data), true);    
     // file creation 
     if(!empty($export_data)){
     $file = fopen('php://output', 'w');
     $header = array("S.No","HSN Code","Display Name","Product/Model Name","Brand","Product Description","Category","Pack Type","Pack Content","Sale Unit","Add Varient","Attribute 1","Variant 1",
     "Attribute 2","Variant 2","Attribute 3","Variant 3","Primary  Varient","CGST","SGST/IGST","MRP (Rs.)","MOP (Rs.)","Offer Rate (Rs.)","Display Price","Display Stock?","Stock Unit","MOQ","Stock","Status"); 
     fputcsv($file, $header);
     foreach ($export_data as  $value)
     { 
       fputcsv($file, $value); 
     }
     fclose($file);
     }
   
    //  redirect(base_url('Product/productsUpload'));
    }
      
    }
     public function test(){
        $this->session->set_userdata('product','');
     } 
}
?>
