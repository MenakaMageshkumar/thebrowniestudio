<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Content extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Content_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        $userData = $this->session->userdata['user'];
        
        $store_id = $userData->store_id;
        $chk_access = 1;
        if($userData->user_type !=2){ //content management enable for store admin only
            $chk_access==0;
        }
        $exclusive_app_enabled= $this->db->query("select exclusive_app_enabled from stores where store_id =$store_id ")->result();
        if($exclusive_app_enabled){
            if($exclusive_app_enabled[0]->exclusive_app_enabled!=1){ //0- default app 1- exclusive app
            $chk_access = 0;
            }
        }else
        {
            $chk_access = 0;
        }
        if($chk_access==0){
          redirect(base_url('access_denied'));
        }

        }
    
     public function ManageContent(){
         $userData = $this->session->userdata['user'];
        $store_id = $userData->store_id;
        $template['page'] = 'Content/view_content';
        $template['pTitle'] = "App Content";
        $template['pDescription'] = "Manage Content";
        $template['menu'] = "Content";
        $template['smenu'] = "Content";
        $template['content']= $this->db->query("select store_id,app_terms_conditions,app_contact_us from stores where store_id =$store_id")->result();
        $this->load->view('template',$template);
    }
      public function editContent(){
          $id = $this->uri->segment(3);
          $content_id = $this->uri->segment(4);
        $template['page'] = 'Content/update_content';
        $template['pTitle'] = "Edit Content";
        $template['pDescription'] = "Update App Content";
        $template['menu'] = "Content Menu";
        $template['smenu'] = "Update Content";
        $template['store_id'] = decode_param($id);
        $store_id = decode_param($id);
        $template['content_data']= $this->db->query("select store_id,app_terms_conditions,app_contact_us,$content_id as content_id from stores where store_id =$store_id")->result();
        $this->load->view('template',$template);
    }
       function updateContent($store_id = ''){
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Content/ManageContent'));
        }
        $store_id = decode_param($store_id);
       $status = $this->Content_model->updateContent($_POST);
       if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'App Content Updated';
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Content/ManageContent'));
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Content/ManageContent'));
           
       }   
}