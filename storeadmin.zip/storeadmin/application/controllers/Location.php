<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Location_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        error_reporting(0);
        $userData = $this->session->userdata['user'];
          if ( $userData->user_type ==3){
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='delivery_location'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }
          }
    }
      public function ManageLocation(){
        $template['page'] = 'Location/ManageLocation';
        $template['menu'] = 'Location Management';
        $template['smenu'] = 'View Delivery Address';
        $template['pTitle'] = "Manage Delivery Location";
        $template['pDescription'] = "View and Manage Address";
        $store_id = $this->session->userdata['user']->store_id;
        $template['Location_data'] = $this->Location_model->getstore_deliverylocation($store_id);
        $this->load->view('template',$template);
    }
    public function AddLocation(){
        $template['page'] = 'Location/AddLocation';
        $template['menu'] = 'Location Management';
        $template['smenu'] = 'Add Delivery Address';
        $template['pTitle'] = "Update Delivery Location";
        $template['pDescription'] = "View and Manage Address";
        $store_id = $this->session->userdata['user']->store_id;
        $template['Location_data'] = $this->Location_model->getstore_deliverylocationdtl($store_id);
        $template['store_id'] = $store_id;
        $template['state'] = $this->Location_model->getstate();
        $template['district'] = $this->Location_model->getdistrict();
        $template['city'] = $this->Location_model->getcity();
        $template['area'] = $this->Location_model->getarea();
        $this->load->view('template',$template);
    }
    public function deleteLocation(){
        $str_addressid = decode_param($this->uri->segment(3));
        $this->Location_model->deleteLocation($str_addressid);
        redirect('Location/ManageLocation');
    }
    public function ajax_getdistrict(){
        $state_id = $_POST['stateID'];
        $district = $this->Location_model->getdistrict($state_id);
        ?>
                                             <option selected value="0">Select Your District</option>
                                         <?php foreach($district as $dt){?>
                                             <option value="<?php echo $dt->district_id;?>"><?php echo $dt->district;?></option>
                                         <?php }

    }
     public function ajax_getcity(){
        $district_id = $_POST['districtID'];
        $city = $this->Location_model->getcity($district_id);
        ?>
                                             <option selected value="0">Select Your City</option>
                                         <?php foreach($city as $ct){?>
                                             <option value="<?php echo $ct->id;?>"><?php echo $ct->city_name;?></option>
                                         <?php }

    }
    public function ajax_getarea(){
        $city_id = $_POST['cityID'];
        $store_id = $this->session->userdata['user']->store_id;
        $existing_areas = $this->db->query("select area.id,area.area_locality,area.pincode from  area inner join store_address on area.id = store_address.area_id where store_id = $store_id and area.city_id = $city_id AND default_address =0")->result();
        
        //don't load default area in selection //default_address = 1
        if($existing_areas){
          $area = $this->db->query("select * from area where city_id = $city_id and id not in (select area_id from store_address where store_id = $store_id)")->result();
        }else{
          $area = $this->db->query("select * from area where city_id = $city_id")->result();    
        }
        $t ='';$pincode =''; $m='';
        
         
         //existing area so checked
         foreach($existing_areas as $a){
             if($t==''){
                     $t ='<input type="checkbox" name="area_id[]" value="'.$a->id.'"  data-parsley-trigger="change" required="" class="area" checked/> '.$a->area_locality.' <br>';
             }else{
                     $t = $t.'<input type="checkbox" name="area_id[]" value="'.$a->id.'"  data-parsley-trigger="change" required="" class="area" checked/> '.$a->area_locality.' <br>';
             }
             
             if($pincode==''){
                 $pincode = $a->pincode;
             }else{
                 $pincode = $pincode.', '.$a->pincode;
             }
         }
         foreach($area as $a){
             if($t==''){
                     $t ='<input type="checkbox" name="area_id[]" value="'.$a->id.'"  data-parsley-trigger="change" class="area" required="" /> '.$a->area_locality.' <br>';
             }else{
                     $t = $t.'<input type="checkbox" name="area_id[]" value="'.$a->id.'"  data-parsley-trigger="change" class="area" required="" /> '.$a->area_locality.' <br>';
             }
         }

            $response = array('first'=>$t,
            'second'=>$pincode
	     	     );
	       echo json_encode($response);
                    
    }
    public function ajax_getpincode(){
        $area_array = $_POST['area_id'];
        $area_id = implode(',',$area_array);
        $store_id = $this->session->userdata['user']->store_id;
        $pincode ='';
        if($area_id!=''){
        $area = $this->db->query("select * from area where id in ($area_id) and id not in (select area_id from store_address where store_id = $store_id and default_address=1)")->result();
        foreach($area as $a){
            if($pincode!=''){
                $pincode = $pincode.', '.$a->pincode;
            }else{
                $pincode = $a->pincode;
            }
        }
        }
         $response = array('first'=>$pincode
	     	     );
	       echo json_encode($response);
    }
    public function updateLocation(){
        $store_id = $this->uri->segment(3);
        $this->Location_model->updateLocation($_POST,$store_id);
        redirect('Location/ManageLocation');
    }
}
?>