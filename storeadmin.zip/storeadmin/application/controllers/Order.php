<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {
public function __construct() {
		parent::__construct();
		date_default_timezone_set("Asia/Kolkata");
		$this->load->helper('pushnotification_helper'); 
     	if(!$this->session->userdata('logged_in_storeadmin')) {
			redirect(base_url('Login'));
		}
		$userData = $this->session->userdata['user'];
          if ( $userData->user_type ==3){
              $access_denied = 0;
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='order_management'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }
              
          }
 	}
 	public function ViewOrders(){
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $template['page'] = 'Order/order_view';
        $template['page_title'] = "View Orders";
        $template['page_desc'] = "View and Manage Order"; 
        $template['menu'] = "Orders";
        $template['smenu'] = "View Orders";
        $template['store_id'] = $store_id;
        $accepted_order = $this->db->query("SELECT ord.UTN_number FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id LEFT join  delivery_persondtl del on del.deli_boy_id = ord.delivery_person_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) order by ord.order_id desc")->result();
        $completed_order = $this->db->query("SELECT ord.UTN_number FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id LEFT join  delivery_persondtl del on del.deli_boy_id = ord.delivery_person_id WHERE str.store_id = $store_id and delivery_status in (2,3,6) order by ord.order_id desc")->result();
        $template['accepted_order'] = count($accepted_order);
        $template['completed_order'] = count($completed_order);
        $this->load->view('template',$template);
 	}
 	public function AcceptedOrders1(){
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $template['page'] = 'Order/accepted_orders_old';
        $template['pTitle'] = "View Orders";
        $template['pDescription'] = "View and Manage Order"; 
        $template['menu'] = "Orders";
        $template['smenu'] = "View Orders";
        $template['store_id'] = $store_id;
        $preutn="";$predate="";$pretime="";
        $fi_array = array();
        $orderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (1,4,5,7) order by ord.order_id desc")->result(); 
 foreach($orderData as $ord){
          $order_id = $ord->order_id;
          $product_name =""; $preferred_del_date="";$preferred_del_time="";$weight="";$quantity="";
          $get_item_data = $this->db->query("select * from cart where order_id=$order_id")->result();
          if($get_item_data){
              $sno =1;
              foreach($get_item_data as $itm){
                  $preferred_del_date = $itm->preferred_del_date;
                  $preferred_del_time = $itm->preferred_del_time;
                  $var = explode(";",$itm->varient_name);
                  $weight = $var[0];
                  $pro_nm = $itm->product_name;
                  $qty = $itm->quantity;
                  $product_name = $product_name.''.$sno.'.&nbsp'.$pro_nm.' - '.$weight.' - '.$qty.' nos'.'<br>';
                  $sno++;
              }
              
          }
            $fi_array[] = array(
                'UTN_number'=>$ord->UTN_number,
                'orderby_name'=>$ord->orderby_name,
                 'orderby_contact'=>$ord->orderby_contact,
                 'deliveryto_name'=>$ord->deliveryto_name,
                 'deliveryto_contact'=>$ord->deliveryto_contact,
                'order_id'=>$ord->order_id,
                'store_id'=>$ord->store_id,
                'product_name'=>$product_name,
                'preferred_del_date'=>$preferred_del_date,
                'preferred_del_time'=>$preferred_del_time,
                'booking_time'=>$ord->booking_time,
                'cust_name'=>$ord->cust_name,
                'cust_phone'=>$ord->cust_phone,
                'payment_method'=>$ord->payment_method,
                'payment_status'=>$ord->payment_status,
                'delivery_status'=>$ord->delivery_status,
                'delivery_status_flg'=>$ord->delivery_status_flg,
                'address1'=>$ord->address1,
                'address2'=>$ord->address2,
                'landmark'=>$ord->landmark,
                'area'=>$ord->area,
                'city'=>$ord->city,
                'district'=>$ord->district,
                'state'=>$ord->state,
                'pincode'=>$ord->pincode
                );
        }
        $template['orderData'] = json_decode(json_encode($fi_array), FALSE);
        // print_r($template['orderData']);
        // die;
        $this->load->view('template',$template);
 	}
 	public function AcceptedOrders(){
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $template['page'] = 'Order/accepted_orders';
        $template['pTitle'] = "View Orders";
        $template['pDescription'] = "View and Manage Order"; 
        $template['menu'] = "Orders";
        $template['smenu'] = "View Orders";
        $template['store_id'] = $store_id;
        $template['del_time'] = $this->db->query("SELECT * FROM `delivery_slot` where enable=1")->result();
        $this->load->view('template',$template);
 	}
 	public function load_AcceptedOrders(){
 	    $postData = $this->input->post();
 	    $filter = "";
	    $fil_orddate_from = $_POST['orddate_from'];
	    $fil_orddate_to = $_POST['orddate_to'];
	    if($fil_orddate_from!="" && $fil_orddate_to!=""){
	        if($fil_orddate_from==$fil_orddate_to){
	            $filter = $filter." AND DATE_FORMAT(booking_time,'%Y-%m-%d') = '$fil_orddate_to'";
	        }else{
	            $filter = $filter." AND DATE_FORMAT(booking_time,'%Y-%m-%d') BETWEEN '$fil_orddate_from' AND '$fil_orddate_to'";
	        }
	    }
	    $fil_deldate_from = $_POST['deldate_from'];
	    $fil_deldate_to = $_POST['deldate_to'];
	    $fil_pincode = $_POST['pincode'];
	    $fil_phoneno = $_POST['phoneno'];
	    $fil_ord_type = $_POST['ord_type'];
	    $fil_del_time = trim($_POST['del_time']);
	    $fil_del_status = trim($_POST['del_status']);
	    if($fil_ord_type=="DO"){ //DElivery order inside chennai //Courier order outside chennai
	        $filter = $filter." AND ord.district = 'Chennai'";
	    }
	    if($fil_ord_type!="DO"){ //DElivery order inside chennai //Courier order outside chennai
	        $filter = $filter." AND ord.district != 'Chennai'";
	    }
	    if(trim($fil_phoneno)!=""){
	       // if($fil_orddate_from=="" && $fil_orddate_to=="" && $fil_deldate_from=="" && $fil_deldate_to==""){
	       //     $filter = $filter." AND (ord.deliveryto_contact like '%".$fil_phoneno."%' || ord.orderby_contact like '%".$fil_phoneno."%')";
	       // }
	        if($fil_orddate_from=="" && $fil_orddate_to=="" && $fil_deldate_from!="" && $fil_deldate_to!="" ){
	            $filter = $filter." AND ord.deliveryto_contact like '%".$fil_phoneno."%'";
	        }else if($fil_orddate_from!="" && $fil_orddate_to!="" && $fil_deldate_from=="" && $fil_deldate_to=="" ){
	            $filter = $filter." AND ord.orderby_contact like '%".$fil_phoneno."%'";
	        }else{
	           $filter = $filter." AND (ord.deliveryto_contact like '%".$fil_phoneno."%' || ord.orderby_contact like '%".$fil_phoneno."%')"; 
	        }
	    }
	    if(trim($fil_pincode)!=""){
	        $filter = $filter." AND ord.pincode like '%".$fil_pincode."%'";
	    }
	    if($fil_del_status!=""){
	        if($fil_del_status==1){
	            $fil_del_status  = '0,1';
	        }
	        $filter = $filter." AND ord.delivery_status in ($fil_del_status)";
	    }

     ## Read value
     $draw = $postData['draw'];
     $start = $postData['start'];
     $rowperpage = $postData['length']; // Rows display per page
     $columnIndex = $postData['order'][0]['column']; // Column index
     $columnName = $postData['columns'][$columnIndex]['data']; // Column name
     $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
     $searchValue = $postData['search']['value']; // Search value
     $store_id = 1;
     ## Search 
     $searchQuery = "";
     if($searchValue != ''){
        $searchQuery = "and (ord.UTN_number like '%".$searchValue."%' or ord.orderby_name like '%".$searchValue."%' or ord.orderby_contact like '%".$searchValue."%' or ord.deliveryto_contact like '%".$searchValue."%' or ord.address1 like '%".$searchValue."%' or ord.address2 like '%".$searchValue."%' or ord.landmark like '%".$searchValue."%' or ord.area like '%".$searchValue."%' or ord.city like '%".$searchValue."%' or ord.district like '%".$searchValue."%' or ord.state like '%".$searchValue."%' or ord.pincode like '%".$searchValue."%') ";
     }
     
 	     $preutn="";$predate="";$pretime="";
        $fi_array = array();
        $totorderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) $filter order by ord.order_id desc")->result(); 
             if($searchQuery != ''){ //with search filter
	              $totfil_orderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) $filter $searchQuery order by ord.order_id desc ")->result();
	              $totalRecordwithFilter = count($totfil_orderData);
	          }else{ //else 
	              $totalRecordwithFilter = count($totorderData);
	          }
	          if($rowperpage==-1){// show all
	              if($searchQuery != ''){
    	              $orderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) $filter $searchQuery order by ord.order_id desc")->result();
    	          }else{
    	              $orderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) $filter order by ord.order_id desc ")->result();
    	          }
	          }else{
    	          if($searchQuery != ''){
    	              $orderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) $filter $searchQuery order by ord.order_id desc LIMIT $rowperpage OFFSET $start")->result();
    	          }else{
    	              $orderData = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.order_id,ord.store_id,ord.UTN_number ,ord.orderby_name, ord.orderby_contact, ord.booking_time ,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0,1,4,5,7) $filter order by ord.order_id desc LIMIT $rowperpage OFFSET $start")->result();
    	          }
	          }
       
       $totalRecords = count($totorderData);
       $i = 1;
 foreach($orderData as $ord){
          $order_id = $ord->order_id;
          $product_name =""; $preferred_del_date="";$preferred_del_time="";$weight="";$quantity=""; $filter2="";
          if(trim($fil_del_time)!=""){
              $filter2 = $filter2." and preferred_del_time ='$fil_del_time'";
          }
	    if($fil_deldate_from!="" && $fil_deldate_to!=""){
	        if($fil_deldate_from==$fil_deldate_to){
	            $filter2 = $filter2." AND DATE_FORMAT(preferred_del_date,'%Y-%m-%d') = '$fil_deldate_to'";
	        }else{
	            $filter2 = $filter2." AND DATE_FORMAT(preferred_del_date,'%Y-%m-%d') BETWEEN '$fil_deldate_from' AND '$fil_deldate_to'";
	        }
	    }
          $get_item_data = $this->db->query("select * from cart where product_status!=0 and order_id=$order_id $filter2")->result();
          if($get_item_data){
              $sno =1;
              foreach($get_item_data as $itm){
                  if($itm)
                  $preferred_del_date = $itm->preferred_del_date;
                  $preferred_del_time = $itm->preferred_del_time;
                  $var = explode(";",$itm->varient_name);
                  $weight = $var[0];
                  $pro_nm = $itm->product_name;
                  $qty = $itm->quantity;
                  $product_name = $product_name.''.$sno.'.&nbsp'.$pro_nm.' - '.$weight.' - '.$qty.' nos'.'<br>';
                  $sno++;
              }
                       $address =  $ord->deliveryto_name.', '.$ord->address1.','.$ord->address2.', '.$ord->landmark.', '.$ord->area.', '.$ord->city.', '.$ord->district.', '.$ord->state.' - '.$ord->pincode;
                        $dt_frmt=date_create($ord->booking_time);
                        $order_del_date = date_format($dt_frmt,"d/m/Y  h:i A");
                           $del_date ="";$del_time ="";
                        if($preferred_del_date!="0000-00-00"){
                            $del_dt=date_create($preferred_del_date);
                            $del_date = date_format($del_dt,"d/m/Y");
                        }
                        if($preferred_del_time!=""){
                            $del_time = $preferred_del_time;
                        }
                        $order_del_date = $order_del_date.'<br><strong>'.$del_date.' '.$del_time.'</strong>';
                        
                        $curr_delivery_status = $ord->delivery_status;
                        $selectStr0 = ($curr_delivery_status == "0") ? 'selected': '';
                        $selectStr4 = ($curr_delivery_status == "4") ? 'selected': '';
                        $selectStr7 = ($curr_delivery_status == "7") ? 'selected': '';
                        $selectStr2 = ($curr_delivery_status == "2") ? 'selected': '';
                        $selectStr3 = ($curr_delivery_status == "3") ? 'selected': '';
                         
                                      if($ord->payment_status ==1){
                                           $delivery_type ='Paid'; 
                                           $delivery_type_color ='#000000';
                                        } else { 
                                           $delivery_type ='Unpaid'; 
                                           $delivery_type_color ='#FF0000';
                                        }

    $delivery_status = '<select  name="delivery_status" class="form-control mx_auto_custom text-center" style="padding: 0px;" id="'.$ord->UTN_number.'" onchange="submitOrderStatus(this)" >
    <option value="" '.$selectStr0.'>Select</option>
      <option value="4" '.$selectStr4.'>Packed</option>
      <option value="7" '.$selectStr7.'>Shipped</option>
      <option value="2" '.$selectStr2.'>Delivered</option>
      <option value="3" '.$selectStr3.'>Returned</option>
      </select>';
    // </select>&emsp;&emsp; <div style="color:'.$delivery_type_color.'">'.$delivery_type.'</div>';
    if($curr_delivery_status==0 || $curr_delivery_status==1){
        $view_order_btn = '<a class="btn btn-sm btn-pri" target="_blank" href='. base_url("Order/item_view/".encode_param($ord->order_id)).'">View Order</a>&emsp;<br> <a class="btn btn-sm btn-pri" target="_blank" href='. base_url("Order/edit_order/".encode_param($ord->order_id)).'">Edit Order</a>&emsp;'; 
    }else{
        $view_order_btn = '<a class="btn btn-sm btn-pri" target="_blank" href='. base_url("Order/item_view/".encode_param($ord->order_id)).'">View Order</a>&emsp;';
    }
                        
                        $status = "";
            $fi_array[] = array(
                'SNo'=>$i,
                'UTN_number'=>$ord->UTN_number,
                'orderby_name'=>$ord->orderby_name,
                 'orderby_contact'=>$ord->orderby_contact,
                 'deliveryto_name'=>$ord->deliveryto_name,
                 'deliveryto_contact'=>$ord->deliveryto_contact,
                'order_id'=>$ord->order_id,
                'store_id'=>$ord->store_id,
                'product_name'=>$product_name,
                'order_del_date'=>$order_del_date,
                'cust_name'=>$ord->cust_name,
                'cust_phone'=>$ord->cust_phone,
                'payment_method'=>$ord->payment_method,
                'payment_status'=>$ord->payment_status,
                'delivery_status'=>$ord->delivery_status,
                'delivery_status_flg'=>$ord->delivery_status_flg,
                'address'=>$address,
                'status' => $delivery_status,
                'action'=>$view_order_btn
                );
                $i++;
        }
 }
         $output = array(
              "draw" => intval($draw),
                "iTotalRecords" => $totalRecords,
                "iTotalDisplayRecords" => $totalRecordwithFilter,
                "aaData" => $fi_array
        );
        
        // Output to JSON format
        echo json_encode($output);
 	
 
 }
 	public function item_view($ord_id=0){
 	      $store_id = $this->session->userdata['user']->store_id;
 	      $final_data =array();
 	      $order_id = decode_param($ord_id);
 	      $itemdata = $this->db->query("select cart.quantity,gift,phone_no,address1,address2,landmark,area,city,district,state,pincode, ord.orderby_name, ord.orderby_contact,ord.deliveryto_name,deliveryto_contact, ord.booking_time,ord.UTN_number,varient_name,product_name,preferred_del_date,preferred_del_time,message_on_cake,notes_on_chef,product_image from cart INNER JOIN orders ord ON cart.order_id = ord.order_id inner join user_profile usr on usr.user_id = ord.user_id where ord.order_id =$order_id  AND cart.product_status !=0")->result();
 	      foreach($itemdata as $it){
 	          $varient_name = $it->varient_name;
 	          $ex_var = explode(';',$varient_name);
 	          $egg_type = '-';$cake_shape = "-";$cake_weight="-";
 	          if((isset($ex_var[1]) && strtoupper($ex_var[1])=='EGG')){
 	              $egg_type = 'Egg';
 	          }
 	          if((isset($ex_var[1]) && strtoupper($ex_var[1])=='EGGLESS')){
 	              $egg_type = 'Eggless';
 	          }
 	          if(isset($ex_var[2])){
 	              $cake_shape = $ex_var[2];
 	          }
 	          if(isset($ex_var[0])){
 	              $cake_weight = $ex_var[0];
 	          }
 	          if($it->gift==1){
 	              $isitgift = "Yes";
 	          }else{
 	              $isitgift = "No";
 	          }
 	          $final_data[] =  array(
 	              'orderid'=>$it->UTN_number,
 	              'orderby_name'=>$it->orderby_name,
                 'orderby_contact'=>$it->orderby_contact,
                 'deliveryto_name'=>$it->deliveryto_name,
                 'deliveryto_contact'=>$it->deliveryto_contact,
 	              'product_name'=>$it->product_name.' - '.$cake_weight.' - '.$it->quantity.' nos',
 	              'booking_date'=>$it->booking_time,
 	              'preferred_del_date'=>$it->preferred_del_date,
 	              'preferred_del_time'=>$it->preferred_del_time,
 	              'message_on_cake'=>$it->message_on_cake,
 	              'notes_on_chef'=>$it->notes_on_chef,
 	              'cake_type'=>$egg_type,
 	              'cake_shape'=>$cake_shape,
 	              'product_image'=>$it->product_image,
 	              'address1'=>$it->address1,
 	              'address2'=>$it->address2,
 	              'landmark'=>$it->landmark,
 	              'area'=>$it->area,
 	              'city'=>$it->city,
 	              'district'=>$it->district,
 	              'state'=>$it->state,
 	              'pincode'=>$it->pincode,
 	              'phone_no'=>$it->phone_no,
 	              'gift'=>$isitgift
 	              );
 	      }
 	      $data['orderData'] = $final_data;
 	      $this->load->view('Order/item_view',$data);

 	}
 	public function dashboard(){
 	      
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $tdy = date('Y-m-d');
 	    $month = date('m');
 	    $tmw =  date("Y-m-d", strtotime("+1 day"));
 	    $sterday =  date("Y-m-d", strtotime("-1 day"));
 	    $dayafter =  date("Y-m-d", strtotime("+2 day"));
 	    $third_day = date("Y-m-d", strtotime("+3 day"));
 	    $seventh_day = date("Y-m-d", strtotime("+7 day"));
 	    ///Today No of Orders
 	    $get_sdy_order = $this->db->query("SELECT COUNT(*)cnt FROM orders WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') ='$sterday'")->result();
 	    $template['yesterday_order'] = $get_sdy_order[0]->cnt;
 	    $get_tdy_order = $this->db->query("SELECT COUNT(*)cnt FROM orders WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') ='$tdy'")->result();
 	    $template['tdy_order'] = $get_tdy_order[0]->cnt;
 	    $yesterday_ordercnt = $get_sdy_order[0]->cnt;  $today_ordercnt = $get_tdy_order[0]->cnt;
 	    if($yesterday_ordercnt!=0){
 	        $template['tdy_order_perc'] = round((($yesterday_ordercnt - $today_ordercnt) / $yesterday_ordercnt) *100,0); 
 	    }else{
 	     $template['tdy_order_perc'] = 0;    
 	    }
 	    
 	    /// end here //Today No of Orders
 	
 	   ////Today Orders Value
 	    $get_sdy_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM orders WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') ='$sterday'")->result();
 	    $template['sterdy_ordervalue'] = $get_sdy_ordervalue[0]->tot;
 	    $get_tdy_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM orders WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') ='$tdy'")->result();
 	    $template['tdy_ordervalue'] = $get_tdy_ordervalue[0]->tot;
 	     $yesterday_ordervalue = $get_sdy_ordervalue[0]->tot;  $today_ordervalue = $get_tdy_ordervalue[0]->tot;
 	     if($yesterday_ordervalue!=0){
 	        $template['tdy_ordervalue_perc'] = round((($yesterday_ordervalue - $today_ordervalue) / $yesterday_ordervalue) *100,0);     
 	     }else{
 	         $template['tdy_ordervalue_perc'] = 0;
 	     }
 	    /// end here //Today Orders Value
 	    
 	    ////This Month Orders
        $get_lastmonth_order = $this->db->query("SELECT COUNT(*)cnt FROM orders WHERE MONTH(booking_time) = MONTH('$tdy' - INTERVAL 1 MONTH)")->result();
 	    $template['lastmonth_order'] = $get_lastmonth_order[0]->cnt;
 	    $get_month_order = $this->db->query("SELECT COUNT(*)cnt FROM orders WHERE MONTH(booking_time) = MONTH('$tdy')")->result();
 	    $template['month_order'] = $get_month_order[0]->cnt;
        $lastmonth_order = $get_lastmonth_order[0]->cnt;  $month_order = $get_month_order[0]->cnt;
        if($lastmonth_order!=0){
            $template['month_order_perc'] = round((($lastmonth_order - $month_order) / $lastmonth_order) *100,0);    
        }else{
            $template['month_order_perc'] = 0;
        }
 	    ///end here ///This Month Orders
 	   
 	    //This Month Orders Value
 	    $get_lastmonth_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM orders WHERE MONTH(booking_time) = MONTH('$tdy' - INTERVAL 1 MONTH)")->result();
 	    $template['lastmonth_ordervalue'] = $get_lastmonth_ordervalue[0]->tot;
 	    $get_month_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM orders WHERE MONTH(booking_time) = MONTH('$tdy')")->result();
 	    $template['month_ordervalue'] = $get_month_ordervalue[0]->tot;
 	    $lastmonth_ordervalue = $get_lastmonth_ordervalue[0]->tot; $month_ordervalue = $get_month_ordervalue[0]->tot;
 	    if($lastmonth_ordervalue!=0){
 	        $template['month_ordervalue_perc'] = round((($lastmonth_ordervalue - $month_ordervalue) / $lastmonth_ordervalue) *100,0);    
 	    }else{
 	        $template['month_ordervalue_perc'] = 0;
 	    }
 	    //end here //This Month Orders Value
             	   
        //Today Orders  
 	    $get_today_order = $this->db->query("SELECT COUNT(*)cnt FROM `orders` WHERE district='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$tdy')")->result();
 	    $template['today_order'] = $get_today_order[0]->cnt;
 	    $get_today_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM `orders` WHERE district='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$tdy')")->result();
 	    $template['today_ordervalue'] = $get_today_ordervalue[0]->tot;

 	    //Tomorrow Orders  
 	    $get_tmw_order = $this->db->query("SELECT COUNT(*)cnt FROM `orders` WHERE district='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$tmw')")->result();
 	    $template['tmw_order'] = $get_tmw_order[0]->cnt;
 	    $get_tmw_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM `orders` WHERE district='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$tmw')")->result();
 	    $template['tmw_ordervalue'] = $get_tmw_ordervalue[0]->tot;
 	    //Day after Orders  
 	    $get_dayaf_order = $this->db->query("SELECT COUNT(*)cnt FROM `orders` WHERE district='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$dayafter')")->result();
 	    $template['dayaf_order'] = $get_dayaf_order[0]->cnt;
 	    $get_dayaf_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM `orders` WHERE district='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$dayafter')")->result();
 	    $template['dayaf_ordervalue'] = $get_dayaf_ordervalue[0]->tot;
 	    //Courier Order and value
 	    $get_cour_tdy_order = $this->db->query("SELECT COUNT(*)cnt FROM `orders` WHERE district!='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$tdy')")->result();
 	    $template['cour_tdy_order'] = $get_cour_tdy_order[0]->cnt;
 	    $get_cour_tdy_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM `orders` WHERE district!='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date='$tdy')")->result();
 	    $template['cour_tdy_ordervalue'] = $get_cour_tdy_ordervalue[0]->tot;
 	    
 	    $get_cour_3dy_order = $this->db->query("SELECT COUNT(*)cnt FROM `orders` WHERE district!='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date BETWEEN '$tmw' AND '$third_day')")->result();
 	    $template['cour_3dy_order'] = $get_cour_3dy_order[0]->cnt;
 	    $get_cour_3dy_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM `orders` WHERE district!='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date BETWEEN '$tmw' AND '$third_day')")->result();
 	    $template['cour_3dy_ordervalue'] = $get_cour_3dy_ordervalue[0]->tot;
 	    
 	    $get_cour_7dy_order = $this->db->query("SELECT COUNT(*)cnt FROM `orders` WHERE district!='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date BETWEEN '$tmw' AND '$seventh_day')")->result();
 	    $template['cour_7dy_order'] = $get_cour_7dy_order[0]->cnt;
 	    $get_cour_7dy_ordervalue = $this->db->query("SELECT SUM(total_amount)tot FROM `orders` WHERE district!='Chennai' and order_id IN (SELECT DISTINCT order_id FROM cart WHERE preferred_del_date BETWEEN '$tmw' AND '$seventh_day')")->result();
 	    $template['cour_7dy_ordervalue'] = $get_cour_7dy_ordervalue[0]->tot;
 	    // end here
 	    
 	    
 	    $yes_delivery1_cnt = 0; $yes_delivery2_cnt = 0; $yes_delivery3_cnt = 0;
 	    //Order list tomorrow
 	    $getyes_list = $this->db->query("SELECT slot.time_slot,slot.delivery_range, cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id INNER JOIN delivery_slot slot ON slot.time_slot = cart.preferred_del_time WHERE cart.preferred_del_date ='$sterday' ORDER BY delivery_range")->result();
 	    foreach($getyes_list as $yesord){
 	        if($yesord->delivery_range==1){
 	            $yes_delivery1_cnt =  $yes_delivery1_cnt + 1; 
 	        }
 	        if($yesord->delivery_range==2){
 	            $yes_delivery2_cnt =  $yes_delivery2_cnt + 1; 
 	        }
 	        if($yesord->delivery_range==3){
 	            $yes_delivery3_cnt =  $yes_delivery3_cnt + 1; 
 	        }
 	    }
 	    
 	    $today_list = array(); $today_delivery =array(); 
 	    $delivery1_cnt = 0; $delivery2_cnt = 0; $delivery3_cnt = 0;
  	    //Order list today
 	    //$tdy_orderlist = $this->db->query("SELECT cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id WHERE cart.preferred_del_date ='$tdy' ORDER BY preferred_del_time")->result();
 	    $tdy_orderlist = $this->db->query("SELECT slot.time_slot,slot.delivery_range, cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id INNER JOIN delivery_slot slot ON slot.time_slot = cart.preferred_del_time WHERE cart.preferred_del_date ='$tdy' ORDER BY delivery_range")->result();
 	    foreach($tdy_orderlist as $ord){
 	        if($ord->delivery_range==1){
 	            $delivery1_cnt =  $delivery1_cnt + 1; 
 	        }
 	        if($ord->delivery_range==2){
 	            $delivery2_cnt =  $delivery2_cnt + 1; 
 	        }
 	        if($ord->delivery_range==3){
 	            $delivery3_cnt =  $delivery3_cnt + 1; 
 	        }
 	        $ex_varient_name = explode(";",$ord->varient_name);
 	        $today_list[] = array(
 	            'item_name' => $ord->product_name,
 	            'weight' => $ex_varient_name[0],
 	            'quantity' => $ord->quantity,
 	            'preferred_del_time' => $ord->preferred_del_time,
 	            'preferred_del_date' => $ord->preferred_del_date,
 	            'delivery_range' => $ord->delivery_range
 	            );
 	            $delivery1_perc = 0; $delivery2_perc = 0;  $delivery3_perc = 0;
 	            if((($yes_delivery1_cnt - $delivery1_cnt))!=0 && $yes_delivery1_cnt!=0) {
 	                $delivery1_perc =  round(((($yes_delivery1_cnt - $delivery1_cnt) / $yes_delivery1_cnt ) *100),0);   
 	            }
 	            if((($yes_delivery2_cnt - $delivery2_cnt))!=0 && $yes_delivery2_cnt!=0){
 	                $delivery2_perc =  round(((($yes_delivery2_cnt - $delivery2_cnt) / $yes_delivery2_cnt ) *100),0);   
 	            }
 	            if((($yes_delivery3_cnt - $delivery3_cnt))!=0 && $yes_delivery3_cnt!=0){
 	                $delivery3_perc =  round(((($yes_delivery3_cnt - $delivery3_cnt) / $yes_delivery3_cnt ) *100),0);   
 	            }
 	            
 	      $today_delivery = array(
 	                'delivery1_cnt' =>$delivery1_cnt,
 	                'delivery2_cnt' =>$delivery2_cnt,
 	                'delivery3_cnt' =>$delivery3_cnt,
 	                'delivery1_perc' =>$delivery1_perc,
 	                'delivery2_perc' =>$delivery2_perc,
 	                'delivery3_perc' =>$delivery3_perc
 	                );
 	        
 	    }
 	    $template['today_ordlist'] = $today_list;
 	    $template['today_delivery'] = $today_delivery;
 	   
 	    $tmw_list = array(); $tmw_delivery =array();
 	    $delivery1_cnt = 0; $delivery2_cnt = 0; $delivery3_cnt = 0;
 	    //Order list tomorrow
 	  //  $gettmw_list = $this->db->query("SELECT cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id WHERE cart.preferred_del_date ='$tmw' ORDER BY preferred_del_time")->result();
 	    $gettmw_list = $this->db->query("SELECT slot.time_slot,slot.delivery_range, cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id INNER JOIN delivery_slot slot ON slot.time_slot = cart.preferred_del_time WHERE cart.preferred_del_date ='$tmw' ORDER BY delivery_range")->result();
 	    foreach($gettmw_list as $tmord){
 	        if($tmord->delivery_range==1){
 	            $delivery1_cnt =  $delivery1_cnt + 1; 
 	        }
 	        if($tmord->delivery_range==2){
 	            $delivery2_cnt =  $delivery2_cnt + 1; 
 	        }
 	        if($tmord->delivery_range==3){
 	            $delivery3_cnt =  $delivery3_cnt + 1; 
 	        }
 	        $ex_varient_name = explode(";",$tmord->varient_name);
 	        $tmw_list[] = array(
 	            'item_name' => $tmord->product_name,
 	            'weight' => $ex_varient_name[0],
 	            'quantity' => $tmord->quantity,
 	            'preferred_del_time' => $tmord->preferred_del_time,
 	            'preferred_del_date' => $tmord->preferred_del_date,
 	            'delivery_range' => $tmord->delivery_range
 	            );
 	             $delivery1_perc = 0; $delivery2_perc = 0;  $delivery3_perc = 0;
 	            if((($yes_delivery1_cnt - $delivery1_cnt))!=0 && $yes_delivery1_cnt!=0){
 	                $delivery1_perc =  round(((($yes_delivery1_cnt - $delivery1_cnt) / $yes_delivery1_cnt ) *100),0);   
 	            }
 	            if((($yes_delivery2_cnt - $delivery2_cnt))!=0 && $yes_delivery2_cnt!=0){
 	                $delivery2_perc =  round(((($yes_delivery2_cnt - $delivery2_cnt) / $yes_delivery2_cnt ) *100),0);   
 	            }
 	            if((($yes_delivery3_cnt - $delivery3_cnt))!=0 && $yes_delivery3_cnt!=0){
 	                $delivery3_perc =  round(((($yes_delivery3_cnt - $delivery3_cnt) / $yes_delivery3_cnt ) *100),0);   
 	            }
 	            
 	            $tmw_delivery = array(
 	                'delivery1_cnt' =>$delivery1_cnt,
 	                'delivery2_cnt' =>$delivery2_cnt,
 	                'delivery3_cnt' =>$delivery3_cnt,
 	                'delivery1_perc' =>$delivery1_perc,
 	                'delivery2_perc' =>$delivery2_perc,
 	                'delivery3_perc' =>$delivery3_perc
 	                );
 	        
 	    }
 	  
 	    $template['tmw_ordlist'] = $tmw_list;
 	    $template['tmw_delivery'] = $tmw_delivery;
 	    
 	    
 	   	  //   echo '<pre>';
 	  //  print_r($tmw_delivery);
 	  //  die;
 	  //Summary collection from yesterday to 30days beforth /// 2days once
       $cur_daterangefrom = date("Y-m-d", strtotime("-30 day"));; $range_price = 0;
       $var = 29;
      for($j=1;$j<=15;$j++){
           $date_range =  date("Y-m-d", strtotime("-$var day"));
           $cur_daterangeto  = $date_range;
           $find_price = $this->db->query("SELECT IFNULL(SUM(total_amount), 0) as tot FROM orders WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') BETWEEN '$cur_daterangefrom' AND '$cur_daterangeto'")->result();
           if($find_price){
               $range_price = round($find_price[0]->tot,0);
           }
            $date_format = date_format(date_create($date_range),"d-m-Y");
           $final_daterange[] = array(
               'date_range' =>$date_format,
               'range_price' =>$range_price
               );
             $var = $var - 2;
             $cur_daterangefrom = $date_range;
       }
       /////
 	  //echo '<pre>';
 	  //print_r($final_daterange);
 	  //die;
 	  $template['summary_date'] = $final_daterange;
 	    $template['page'] = 'Dashboard';
        $template['pTitle'] = "View Dashboard";
        $template['pDescription'] = "Dashboard"; 
        $template['menu'] = "Dashboard";
        $template['smenu'] = "View Dashboard";
        $template['store_id'] = $store_id;
        $this->load->view('template',$template);

 	}
public function ajax_add_trackid(){
    $orderutn_id = $_POST['ordid'];
    $track_id = $_POST['track_id'];
    $new_deliverycharge = $_POST['delivery_charge'];
    $get_delcharge = $this->db->query("select delivery_charge,total_amount from orders where UTN_number='$orderutn_id'")->result();
    if(!empty($get_delcharge) && $new_deliverycharge!=0 && trim($new_deliverycharge!="")){
        $old_delivery_charge = $get_delcharge[0]->delivery_charge;
        $total = $get_delcharge[0]->total_amount - $old_delivery_charge + $new_deliverycharge;
        
        $this->db->set('changesin_deliverycharge',$old_delivery_charge); // update old delivery charge here
        $this->db->set('delivery_charge',$new_deliverycharge);//update new delivery charge here
        $this->db->set('total_amount', round($total,0));
    }
            $this->db->where("UTN_number = '$orderutn_id'");
            $this->db->set('track_id',$track_id);
            $st = $this->db->update('orders');
            if($st){
                echo 'Order Shipped & TrackID updated';
            }else{
                echo 'Something went wrong Please try again';
            }

}
public function submitOrderStatus(){
    // delivery_status =2 ->delivered, delivery_status =3 -> returned ,  delivery_status= 4 -> Order Packed , 7 - shipped
        $orderutn_id = $_POST['order_id'];
        $status = $_POST['order_status'];
       if($status ==2 || $status ==4 || $status ==5 || $status ==7) {
            $this->db->where("UTN_number = '$orderutn_id'");
            $this->db->set('delivery_status',$status);
            $st = $this->db->update('orders');
          
        
            if($status==7){ //picked
                 //send push notification to customer,merchant,deliveryadmin
             $customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name,delivery_person_id,seller.token_key merchant_tokenkey from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where  ord.UTN_number = '$orderutn_id'")->result();
             if($customer){
                 $client_id =0;
                 if($customer){  
                    //  $client_id =  $customer[0]->client_id; 
                    //for home delivery send notification to customer once delivery person assinged
                    $user_id = $customer[0]->user_id;
                    $delivery_boyid = $customer[0]->delivery_person_id;
                    $token_key_cust = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name;
                    $title = 'Order shipped';
                    //$message="Order shipped and is on the way for Delivery";
                    $message="Order ID : $orderutn_id - Order shipped and is on the way for delivery.";
                    $notify_type = "order_shipped";
                    $seller_id = $customer[0]->seller_id;
                    $notified_person = "customer";
                    if($token_key_cust!=''){
                    $this->send_pushnotification($token_key_cust,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    }
                    
                    // $getda = $this->db->query("select token_key deliveryadmin_tk from client where id = $client_id")->result();
                    // $deliveryadmin_tk =  $getda[0]->deliveryadmin_tk;
                    // $message="Order Picked and is on the way for Delivery";
                    // $notified_person = "deliveryadmin";
                    // if($deliveryadmin_tk!=''){
                    // $this->send_pushnotification($deliveryadmin_tk,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    // }
                }}
                echo '7';
                //echo 'Order shipped';
                die;
            }if($status==4){ //packed
                 //send push notification to customer,merchant,deliveryadmin
             $customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name,delivery_person_id,seller.token_key merchant_tokenkey from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where  ord.UTN_number = '$orderutn_id'")->result();
             if($customer){
                 $client_id =0;
                 if($customer){
                    //  $client_id =  $customer[0]->client_id; 
                    //for home delivery send notification to customer once delivery person assinged
                    $user_id = $customer[0]->user_id;
                    $delivery_boyid = $customer[0]->delivery_person_id;
                    $token_key_cust = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name;
                    $title = 'Order packed';
                    $message="Order ID : $orderutn_id - Order packed.";
                    $notify_type = "order_packed";
                    $seller_id = $customer[0]->seller_id;
                    $notified_person = "customer";
                    if($token_key_cust!=''){
                    $this->send_pushnotification($token_key_cust,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    }
                    
                    // $getda = $this->db->query("select token_key deliveryadmin_tk from client where id = $client_id")->result();
                    // $deliveryadmin_tk =  $getda[0]->deliveryadmin_tk;
                    // $message="Order Packed";
                    // $notified_person = "deliveryadmin";
                    // if($deliveryadmin_tk!=''){
                    // $this->send_pushnotification($deliveryadmin_tk,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    // }
                }}
                echo 'Order packed';
                die;
            }else{
                
                          // //create invoice 
                $order = $this->db->query("select orders.order_id,orders.total_amount,orders.store_id,stores.store_name from orders inner join stores on orders.store_id = stores.store_id where UTN_number = '$orderutn_id'")->result();
                if($order){
                $order_id = $order[0]->order_id;
                $chk_exists = $this->db->query("SELECT * FROM invoice WHERE ord_id = $order_id")->result();
                if(empty($chk_exists)){
                $order_amount = $order[0]->total_amount;
                $store_id = $order[0]->store_id;
                $store_name = $order[0]->store_name;
                 $dt = $this->db->query("SELECT MAX(invid)invid FROM invoice WHERE store_id = $store_id")->result();
                if(isset($dt[0]->invid)!=''){
                    $invid = $dt[0]->invid;
                $inv_dt = $this->db->query("select inv_no from invoice where invid =$invid ")->result();
                $invno = $inv_dt[0]->inv_no; //"YBS240521001"
                $remove = substr($invno, 9); //001
                $id = ltrim($remove, '0');//1
                }else{
                    $id = 0;
                }
                $sequence_num = str_pad($id + 1, 3, 0, STR_PAD_LEFT);
                //$store_2letter = strtoupper(substr($store_name, 0, 2)); // BS Brownie Studio,
                $store_2letter ="BS";
                $d = date("dmy");//Invoice Format "YBS240521001" Y - Yellowmart, BS Brownie Studio, 24052 datemonthyear, store wise sequence 001
                $INV_number = "Y".$store_2letter.$d.$sequence_num;
                 $insert_invdata  = array(
                        'inv_no'=>$INV_number,
                        'ord_id'=>$order_id,
                        'store_id'=>$store_id,
                        'total_final_bill_amt'=>$order_amount,
                        'inv_view_status '=>0
                    );
                $this->db->insert('invoice',$insert_invdata);
                }}
                //end
                     //send push notification to customer,merchant,deliveryadmin
             $customer  = $this->db->query("select  ord.orderby_name ,ord.deliveryto_name , ord.deliveryto_contact, ord.uptodate_email,ord.booking_time, seller.id seller_id, usr.email, usr.fullname, usr.user_id,usr.token_key,str.store_name,delivery_person_id,seller.token_key merchant_tokenkey from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where  ord.UTN_number = '$orderutn_id'")->result();
          
            // $customer  = $this->db->query("SELECT seller.email seller_email,seller.shopper_name seller_name,usr.email, usr.fullname,str.store_name,delivery_person_id,ord.UTN_number,ord.booking_time,ord.total_amount,ord.payment_method,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN user_profile usr ON usr.user_id = ord.user_id INNER JOIN shopper seller on seller.store_id = str.store_id  WHERE ord.UTN_number ='$orderutn_id'")->result();
            //  $customer  = $this->db->query("select seller.id seller_id, usr.email, usr.fullname, usr.user_id,usr.token_key,str.store_name,delivery_person_id,seller.token_key merchant_tokenkey from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id , ord.UTN_number , ord.booking_time , ord.total_amount  INNER JOIN stores str ON str.store_name, str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id  where  ord.UTN_number = '$orderutn_id'")->result();
             if($customer){
                 $client_id =0;
                 if($customer){  
                    //  $client_id =  $customer[0]->client_id; 
                    //for home delivery send notification to customer once delivery person assinged
                    $user_id = $customer[0]->user_id;
                    $delivery_boyid = $customer[0]->delivery_person_id;
                    $token_key_cust = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name;
                    $title = 'Order delivered';
                    $dt_frmt=date_create($customer[0]->booking_time);
                    $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
                    //$message="Order Delivered Successfully. Please contact our support for any queries";
                    $message="Order ID : $orderutn_id - Order Delivered Successfully. Please contact our support for any queries.";   
                  
                    $notify_type = "order_delivered";
                    $seller_id = $customer[0]->seller_id;
                    $notified_person = "customer";
                    if($token_key_cust!='')
                    {
                    $this->send_pushnotification($token_key_cust,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    }
                      
         
                    // $merchant_tokenkey =  $customer[0]->merchant_tokenkey;
                    // $message="Order Delivered Successfully";
                    // $notified_person = "seller";
                    // if($merchant_tokenkey!=''){
                    // $this->send_pushnotification($merchant_tokenkey,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    // }
                    
                    // $getda = $this->db->query("select token_key deliveryadmin_tk from client where id = $client_id")->result();
                    // $deliveryadmin_tk =  $getda[0]->deliveryadmin_tk;
                    // $message="Order Delivered Successfully";
                    // $notified_person = "deliveryadmin";
                    // if($deliveryadmin_tk!=''){
                    // $this->send_pushnotification($deliveryadmin_tk,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id);
                    // }
                     
                }}
   
             
               echo 'Order delivered';
                //print_r($email);die;
                $uptodate_email = $customer[0]->uptodate_email;
                if($uptodate_email!=""){
                    $email = $uptodate_email;
                }else{
                    $email = $customer[0]->email;
                }
                      
                        // $email = 'kowsalyajayakumar1994@gmail.com';
                      
                // 			mail start
                 //send welcome mail to Customer
                                if(trim($email)!=''){
                               
                                $to_receiver_email = $email ;
                                
                                $cust_name = $customer[0]->orderby_name;;
                                $from_email = 'yellowmart17@gmail.com';
                                $from_emailpassword = 'yellowmart123';
                                $from_username = 'The Brownie Studio';
                                $subject="Order Delivered";
                                $dt['item_dtl'] = $this->db->query("SELECT changesin_deliverycharge,cart.preferred_del_date , cart.preferred_del_time , cart.varient_name, cart.product_name, cart.product_image,cart.product_desc,cart.quantity,cart.rate,cart.price,ord.packing_charge,ord.delivery_charge,ord.total_amount,ord.discount_amount,ord.coupon_discount FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$orderutn_id'")->result();
                                $dt['del_address'] = $this->db->query("SELECT ord.track_id, ord.deliveryto_name , ord.deliveryto_contact, ord.address1,ord.address2,ord.landmark,ord.area,city,district,state,pincode,gps_coordinates,address_name FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$orderutn_id'")->result();                   
                                $delivery_type ="Home Delivery";
                                $dt['heading'] = "Order Delivered";
                                 $dt['order_id'] = $orderutn_id;
                                  $dt['invoice_data'] = $this->db->query("SELECT str.store_id,invoice.inv_no,ord.total_amount total_final_bill_amt,str.store_name,seller.shopper_name seller_name,seller.phone_no,ord.UTN_number,ord.delivery_status,ord.order_id FROM orders ord INNER JOIN invoice on invoice.ord_id = ord.order_id INNER JOIN stores str on str.store_id = ord.store_id INNER JOIN shopper seller on seller.store_id = ord.store_id and seller.store_id = str.store_id WHERE ord.UTN_number ='$orderutn_id'")->result(); 
                    
                    $dt['message'] = 
                "Dear $cust_name, <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Greetings from <strong>  The Brownie Studio! ORDER DELIVERED! </strong>,  Thanks for shopping with us. <br><br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong style='font-size:17px;margin-left:130px'> ORDER ID : ORDER#$orderutn_id </strong>   <br><br>
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Store Name : </strong> $store_name <br>
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Order Date : </strong> $booking_time <br>
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Status : </strong>  Order Delivered  <br>
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Delivery Type :  </strong>   $delivery_type <br>
                ";
                 
                $message_html = $this->load->view('Templates/order_template', $dt, TRUE);
                                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                                 
                                 if($response['status']==0)
                                 {
                                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                                 }
                               
                                 
                            }
                
                      
                // mail end
                die;
            }
}else{
    echo 'Something went wrong, Please try again';
}
    }
     	public function CompletedOrders(){
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $template['page'] = 'Order/completed_orders';
        $template['pTitle'] = "View Orders";
        $template['pDescription'] = "View and Manage Order"; 
        $template['menu'] = "Orders";
        $template['smenu'] = "View Orders";
        $template['store_id'] = $store_id;
         $template['orderData'] = $this->db->query("SELECT '' as preferred_del_date,'' as preferred_del_time, delivery_charge,changesin_deliverycharge,ord.deliveryto_name,deliveryto_contact,ord.orderby_name, ord.orderby_contact, invoice.inv_no,ord.store_id ,ord.order_id,ord.UTN_number,ord.booking_time,cust.fullname cust_name,cust.phone_no cust_phone,ord.address1,ord.address2,ord.landmark,ord.area,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.total_amount,ord.payment_method,ord.payment_status,ord.delivery_status,ord.delivery_status_flg FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id LEFT JOIN invoice on invoice.ord_id=ord.order_id LEFT join delivery_persondtl del on del.deli_boy_id = ord.delivery_person_id WHERE str.store_id = $store_id and delivery_status in (2,3,6) order by ord.order_id desc")->result();
        $ord = $this->db->query("SELECT ord.order_id FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id INNER JOIN user_profile cust on cust.user_id = ord.user_id LEFT JOIN invoice on invoice.ord_id=ord.order_id LEFT join delivery_persondtl del on del.deli_boy_id = ord.delivery_person_id WHERE str.store_id = $store_id and delivery_status in (2,3,6) order by ord.order_id desc")->result();
        $order_id = $ord[0]->order_id;
       
        $template['get_item_data'] = $this->db->query("select * from cart where order_id=$order_id")->result();
        $this->load->view('template',$template);
 	}
 	public function get_itemdata(){
	    $order_id=$_POST['order_id'];
	$item_data = $this->db->query("select cart.*,product.prod_name product_name,prodtl.display_name from cart inner join product ON cart.product_id =  product.prod_id INNER JOIN product_itemdtl prodtl ON product.prod_id = prodtl.prod_id AND cart.item_id =  prodtl.prod_itemid  WHERE cart.order_id =$order_id and cart.product_status in (1,2)")->result();
    $item_array = array();
    if($item_data){
    foreach($item_data as $dt){ 
                
        $exp_cgst = explode(':',$dt->CGST);
        $CGSTperc = $exp_cgst[0];
        $CGST = $exp_cgst[1];
        
        $exp_si = explode(':',$dt->SGST_IGST);
        $SGST_IGSTperc = $exp_si[0];
        $SGST_IGST = $exp_si[1];
        $item_array[] = array (
        'HSN_code' => $dt->HSN_code,
        'display_name' => $dt->display_name,
        'variant_name' => $dt->varient_name,
        'quantity' => $dt->quantity,
        'base_amt' => $dt->base_amt,
        'CGST' => $CGST,
        'SGST_IGST' => $SGST_IGST
        );
    }
    }
    $item = json_decode(json_encode($item_array));

	       ?>
	       <table id="driverTable" class="table table-bordered table-striped datatable ">
	           <thead>
            <tr>
              <th width="5%" class="text-center">S.No</th>
              <th width="40%;" class="text-center">Product Name</th>
              <th width="20%;" class="text-center">Variant</th>
              <th width="5%;" class="text-center">Qty</th>
              <th width="10%;" class="text-center">Base Price</th>
              <!--<th width="5%;">Discount</th>-->
              <th width="5%;" class="text-center">CGST</th>
              <th width="5%;" class="text-center">SGST/IGST</th>
              <th width="10%;" class="text-center">Total</th>
            </tr>
          </thead>
           <tbody>
               
               <?php $cnt = 1; foreach($item as $i){?>
               
               <tr>
                   <td class="text-center"><?= $cnt; ?></td>
                 <td ><?= $i->display_name ?></td>
                 <td class="text-center"><?= $i->variant_name ?></td>
                 <td class="text-center"><?= $i->quantity ?></td>
                 <td class="text-center"><?= $i->base_amt ?></td>
                 <td class="text-center"><?= $i->CGST ?></td>
                 <td class="text-center"><?= $i->SGST_IGST ?></td>
                 <td class="text-center"><?= round($i->base_amt + $i->CGST + $i->SGST_IGST,0) ?></td>
                 
                 </tr>
                     
               <?php $cnt++; }?>
               </tbody>
        </table>
<?php 
	    }
public function submitPaymentStatus(){
    // payment_status = 0 unpaid payment_status = 1 paid 
        $ordertutn_id = $_POST['order_id'];
        $payment_status = $_POST['payment_status'];
        // print_r($payment_status);die;
        $dt  = $this->db->query("select * from orders where utn_number ='$ordertutn_id'")->result();
        $customer = $this->db->query("SELECT * FROM user_profile INNER JOIN orders on orders.user_id = user_profile.user_id WHERE orders.UTN_number= '$ordertutn_id'")->result();
      
        //Please update the previous status
        $curr_delivery_status = $dt[0]->delivery_status;
        $payment_method = $dt[0]->payment_method;
        if($curr_delivery_status!=2){//once order delivered then allow to pay
            echo '404';
            exit;
        }
            $this->db->where("UTN_number = '$ordertutn_id'");
            $this->db->set('payment_status',$payment_status);
            $status = $this->db->update('orders');
            if($payment_status==1)
                    {
                        $dt['item_dtl'] = $this->db->query("SELECT cart.preferred_del_date , cart.preferred_del_time , cart.varient_name, cart.product_name, cart.product_image,cart.product_desc,cart.quantity,cart.rate,cart.price,ord.packing_charge,ord.delivery_charge,ord.total_amount FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$ordertutn_id'")->result();
                        $dt['del_address'] = $this->db->query("SELECT ord.track_id, ord.address1,ord.address2,ord.landmark,ord.area,city,district,state,pincode,gps_coordinates,address_name FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$ordertutn_id'")->result();
                      
                        $email = $customer[0]->email;
                        if(isset($email) || !empty($email))
                        {
                            $to_receiver_email = $email ;
                            
                            $cust_name = $customer[0]->fullname;;
                            $from_email = 'yellowmart17@gmail.com';
                            $from_emailpassword = 'yellowmart123';
                            $from_username = 'The Brownie Studio';
                            $subject="Payment Confirmation";
                            $dt['heading'] = "Payment Confirmation";
                            
                                $dt['message'] = 
                            "Dear $cust_name, <br>
                            
                          Thanks for the payment for <strong> Your Order ID : ORDER#$ordertutn_id </strong><br>
                          Your order will be delivered shortly and you will receive the confirmation on the same.<br><br>
                            
                          
                            
                            ";
                             $message_html = $this->load->view('Templates/payment_template', $dt, TRUE);
                             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                             
                             if($response['status']==0)
                             {
                                 echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                            }
                        }
                    }
            if($status){
                 echo '200';
            }else{
                echo '4';
            }
    
    
    }
    function send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person,$client_id){
    if($token_key!=''){
                    $data = array(
                    "action"=>1,    
                    "message"=> "$message",
                    "title"=>"$title"
                        );
                        if($notified_person=='seller'){
                    $sendNotification = seller_send_push_notification($token_key,$data);
                        }else if($notified_person=='customer'){
                    $sendNotification = send_push_notification($token_key,$data);
                        }else if($notified_person=='deliveryadmin'){
                    $sendNotification = delivery_send_push_notification($token_key,$data);
                        }
                    $insert_data  = array(
                        'notify_type'=>"$notify_type",
                        "title"=>"$title",
                        'content'=>"$message",
                        'user_id'=>$user_id,
                        'seller_id'=>$seller_id,
                        'delivery_boyid' =>$delivery_boyid,
                        'notified_person' =>"$notified_person", 
                        'notify_date' => date('Y-m-d H:i:s'),
                        'read_status' => 0,
                        // 'client_id' =>$client_id // not for clifton
                    );
                $this->db->insert('pushnotifications',$insert_data);
                }
}
function sendmail_notification($from_email='',$from_emailpassword='',$from_username='',$to_receiver_email='',$subject,$message=''){
            $config['protocol'] = 'ssmtp';
            $config['smtp_host'] = 'ssl://ssmtp.gmail.com';
            $config['smtp_port'] = 465;
            $config['smtp_user'] = $from_email;
            $config['smtp_pass'] = $from_emailpassword;
            
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            
           // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            $this->email->clear(); 
            // $this->email->initialize($config);
            $this->email->set_newline("\r\n");
            /*html call*/
            $this->email->set_mailtype("html");
            // Sender email address
            $this->email->from($from_email, $from_username);
            // Receiver email address
            $this->email->to($to_receiver_email);
            // Subject of email
            $this->email->subject($subject);
            // Message in email
            $this->email->message($message);
            if ($this->email->send()) {
                return $result = array('status'=>1,'message'=>'Mail sent'); 
            } else {
                return $result = array('status'=>0,'message'=>'Failed to send Mail'); 
            }
}
function ajax_top10listselling(){
    $from_date = $_POST['from'];
    $from_to = $_POST['to'];
     $list = array();
 	    //Order list 
 	    $orderlist = $this->db->query("SELECT cart.item_id,cart.product_name,cart.varient_name,SUM(cart.quantity)quantity,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id WHERE cart.preferred_del_date BETWEEN '$from_date' AND '$from_to' GROUP BY item_id ORDER BY quantity DESC LIMIT 10")->result();
 	    if($orderlist){
 	        $tot_qty = 0;
            foreach($orderlist as $ord){
         	        $ex_varient_name = explode(";",$ord->varient_name);
         	        $list[] = array(
         	            'item_name' => $ord->product_name,
         	            'weight' => $ex_varient_name[0],
         	            'quantity' => $ord->quantity,
         	            'preferred_del_time' => $ord->preferred_del_time
         	            );
         	            $tot_qty = $tot_qty + $ord->quantity;
            }
            ?>
            <table class="table table-bordered table-striped datatable_1" id="report_table">
                          <thead>
                            <tr>
                              <th scope="col" class="font_13 py_15 text-center px-6-cus" style="width:10px">S.No</th>
                              <th scope="col" class="font_13 py_15 text-center">ITEM NAME</th>
                              <th scope="col" class="font_13 py_15 pl-0 pr-0 text-center" style="width:70px">WEIGHT</th>
                              <th scope="col" class="font_13 py_15 text-center px-6-cus" style="width:12px">QTY</th>
                              <th scope="col" class="text-center px-6-cus" style="width:25px ">PERC.%</th>
                            </tr>
                          </thead>
                          <tbody>
 	           <?php $i= 1;
 	           if(!empty($list)){
 	            foreach($list as $li){ ?>
                     <tr>
                      <td class="text-center"><?php echo $i; ?></td>
                      <td><a class="table_text_title py_15"><?php echo $li['item_name']; ?></a></td>
                      <td class="font_13 py_15 pl-0 pr-0 text-center"><?php echo $li['weight']; ?></td>
                      <td class="font_13 py_15 text-center"><?php echo $li['quantity']; ?></td>
                      <td class="text-center">
                      <?php
                           $qty = $li['quantity'];
                            $perc = ($qty/$tot_qty) * 100;
                            echo round($perc,0).'%';  ?> </td>
                    </tr>
                <?php $i++; }
 	    }else{ ?>
 	        <tr></tr>
 	        <?php } ?>
 	          </tbody>
                        </table>
 	    <?php }
      
}
function ajax_dashorderlist(){
	    $del_range =$_POST['delivery_range']; //1 -> (8am -12noon) 2 -> (12pm - 6pm) 3 -> (6pm - 12am)
	    $ex_date = explode("|",$del_range);
	    $preferred_del_date = $ex_date[0];
	    $delivery_range = $ex_date[1];
	    if($delivery_range==1){
	        $del_rangetiming = '(8am to 12noon)';
	    }else  if($delivery_range==2){
	        $del_rangetiming = '(12pm to 6pm)';
	    }else {
	        $del_rangetiming = '(6pm to 12am)';
	    }
         $ordlist = array();
        $orderlist = $this->db->query("SELECT cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id INNER JOIN delivery_slot slot ON slot.time_slot = cart.preferred_del_time WHERE cart.preferred_del_date ='$preferred_del_date' AND slot.delivery_range =$delivery_range ORDER BY preferred_del_time")->result();
 	    // $orderlist = $this->db->query("SELECT cart.product_name,cart.varient_name,cart.quantity,preferred_del_date,preferred_del_time FROM orders ord INNER JOIN cart ON ord.order_id = cart.order_id WHERE cart.preferred_del_date ='$preferred_del_date' AND cart.preferred_del_time ='$preferred_del_time' ORDER BY preferred_del_time")->result();
 	    foreach($orderlist as $ord){
 	        $ex_varient_name = explode(";",$ord->varient_name);
 	        $ordlist[] = array(
 	            'item_name' => $ord->product_name,
 	            'weight' => $ex_varient_name[0],
 	            'quantity' => $ord->quantity,
 	            'preferred_del_time' => $ord->preferred_del_time,
 	            'preferred_del_date' => $ord->preferred_del_date
 	            );
 	        
 	    }
     ?>
        <div class="card bg_white_cus p_7_cus border_rad_3">
          <div class="card-body ">
           <table class="table">
              <thead>
                <tr>
                  <th scope="col" class=" font_13 py_15 text-uppercase">Item Name</th>
                  <th scope="col" class="text-center font_13 py_15 pl-0 pr-0 text-uppercase">Weight</th>
                  <th scope="col" class="text-center font_13 py_15 text-uppercase">Qty</th>
                </tr>
              </thead>
              <tbody>
                  <?php
                  $var_d = $ordlist[0]['preferred_del_date'];
                   ?>
                  <!--<h5 class="modal-title text-center font_16 font_600 text-capitalize" id="orderlistLabel" style="margin-bottom:10px"> <?php //echo 'DELIVERY - '.date("d-m-Y", strtotime($var_d) ).' ('.$ordlist[0]['preferred_del_time'].')'; ?> </h5>-->
                  <h5 class="modal-title text-center font_16 font_600 text-uppercase" id="orderlistLabel" style="margin-bottom:10px"> <?php echo 'DELIVERY - '.date("d/m/Y", strtotime($var_d) ).' '.$del_rangetiming.''; ?> </h5>
                 <?php $j =1; foreach($ordlist as $or) {  ?>
                <tr>
                  <td><a class="table_text_title py_15"><?php echo $j.'. '.$or['item_name']; ?></a></td>
                  <td class=" text-center font_13 py_15 pl-0 pr-0"><?php echo $or['weight']; ?></td>
                  <td class="text-center font_13 py_15"><?php echo $or['quantity']; ?></td>
                </tr>
                <?php $j++; } ?> 
                
              </tbody>
            </table>
          </div>
        </div>
        <?php 
	    }
public function ajax_summarycolection(){
    $from_date = $_POST['from'];
    $from_to = $_POST['to'];
    if($from_date==$from_to){
        $get_summary = $this->db->query("SELECT ord.total_amount,ord.items_in_cart  FROM orders AS ord WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') = '$from_date'")->result();        
    }else{
        $get_summary = $this->db->query("SELECT ord.total_amount,ord.items_in_cart  FROM orders AS ord WHERE DATE_FORMAT(booking_time,'%Y-%m-%d') BETWEEN  '$from_date' AND  '$from_to'")->result();
    }
    $ord_cnt = count($get_summary); $tot_products =0;$tot_amount=0;
    foreach($get_summary as $sum){
        $tot_products = $tot_products + $sum->items_in_cart;
        $tot_amount = $tot_amount + $sum->total_amount;
    }
    ?>
        <table class="table table-bordered table-striped datatable" id="all_report_table">
                          <thead>
                            <tr>
                              <!--<th scope="col" class="font_13 py_15 text-center">S.No</th>-->
                              <th scope="col" class="font_13 py_15 text-center">Total Order</th>
                              <th scope="col" class="font_13 py_15 pl-0 pr-0 text-center">Total Product</th>
                              <th scope="col" class="font_13 py_15 text-center">Order Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                              <tr>
                              <!--<td class="font_13 py_15 text-center"><?php echo 1; ?></td>-->
                              <td class="font_13 py_15 text-center"><?php echo $ord_cnt; ?></td>
                              <td class="font_13 py_15 text-center"><?php echo $tot_products; ?></td>
                              <td class="font_13 py_15 text-center"><?php echo $tot_amount; ?></td>
                              </tr>
                          </tbody>
                        </table>
            
        
    <?php 
    
}
function edit_order($ord_id=0){
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $template['page'] = 'Order/edit_order';
        $template['pTitle'] = "Update Order";
        $template['pDescription'] = "View and Manage Order"; 
        $template['menu'] = "Orders";
        $template['smenu'] = "Update Order";
        $template['store_id'] = $store_id;
 	    $final_data =array();
 	    $order_id = decode_param($ord_id);
 	    $template['ord_id'] = $ord_id;
 	    $ord_data = $this->db->query("select ord.user_id,ord.order_id,ord.UTN_number,ord.booking_time,ord.delivery_charge,ord.orderby_name,ord.orderby_contact from orders as ord where order_id = $order_id")->result();
 	    $template['user_id'] = $ord_data[0]->user_id;
 	    $ord_array = array();
 	    foreach($ord_data as $ord){
 	        $dt_frmt=date_create($ord->booking_time);
            $order_del_date = date_format($dt_frmt,"d/m/Y  h:i A");
            $delivery_date = ""; $delivery_time = "";
            $del_data = $this->db->query("SELECT DISTINCT preferred_del_date,preferred_del_time FROM cart WHERE order_id = $order_id")->result();
            if($del_data){
                $delivery_date = $del_data[0]->preferred_del_date;
                $delivery_time = $del_data[0]->preferred_del_time;
            }
 	        $ord_array = array(
 	            'order_id' =>$ord->order_id,
 	            'UTN_number' =>$ord->UTN_number,
 	            'order_date' =>$order_del_date,
 	            'delivery_date' =>$delivery_date,
 	            'delivery_time' =>$delivery_time
 	            );
 	    }
 	    $template['ord_data'] = $ord_array;
 	    $itemwise_qry = $this->db->query("SELECT cart.cart_id,cart.product_image,o.UTN_number,cart.mrp_rate,cart.rate,cart.product_name,cart.cart_id item_id,cart.product_desc ,cart.varient_name,cart.varient_id,cart.quantity,cart.price,cart.product_status,o.payment_method,p.prod_name as product_name,cart.preferred_del_date,cart.preferred_del_time FROM orders o INNER join cart ON cart.order_id = o.order_id INNER JOIN product p on cart.product_id = p.prod_id WHERE o.order_id = $order_id and cart.product_status!=0")->result(); //don't show unselected item
 	    $grand_tot = 0;
        $item_array =array();
        foreach($itemwise_qry as $item){
                $item_array[] = array (
                    'cart_id' =>$item->cart_id,
                    'order_id'=>$item->UTN_number,
                    'item_id'=>$item->item_id,
                    'product_name' =>$item->product_name,
                    'product_image' =>$item->product_image,
                    'variant' =>$item->varient_name,
                    'quantity' =>$item->quantity,
                    'unit_price' =>$item->rate,
                    'price' =>$item->price,
                    'mrp_price' =>$item->mrp_rate,
                    'product_status' =>$item->product_status
                    );
                    $grand_tot = $grand_tot + $item->price;
            }
        $template['item_data'] = $item_array;
        $template['item_cnt'] = count($itemwise_qry);
        $product_array =array();
        $UTN_number = $itemwise_qry[0]->UTN_number;
        $product_qry = $this->db->query("SELECT CASE WHEN prodtl.price_to_display =1 THEN prodtl.mrp_price ELSE CASE WHEN prodtl.price_to_display =2 THEN prodtl.mop_price ELSE CASE WHEN prodtl.price_to_display =3 THEN prodtl.offer_price ELSE CASE WHEN prodtl.price_to_display =4 THEN prodtl.mop_price END END END END as price_orderby,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.pri_att,image_type,item_images  from product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND pro.prod_status = 1")->result();
         if($product_qry){
           if($product_qry){
            $res = $this->func_productlist($product_qry,'edit_order',$UTN_number);//func_productlist(query,mainfunciton name, UTNumber)
            if($res['status']==1){
                $product_array = $res['data'];
            }
            }
        }

$preferred_del_time ="";
$preferred_del_date ="";
if($itemwise_qry){
            $originalDate = $itemwise_qry[0]->preferred_del_date;
            $preferred_del_date = date("d/m/Y", strtotime($originalDate));
            $preferred_del_time = $itemwise_qry[0]->preferred_del_time;
}
        $template['preferred_del_time'] = $preferred_del_time;  
        $template['preferred_del_date'] = $preferred_del_date;
        $template['search_products'] = json_decode(json_encode($product_array), FALSE);
        if($preferred_del_date==""){
                $selected_date =  date('Y-m-d');     
        }else{
            $selected_date = $preferred_del_date;
        }
        $delivery_slotary = $this->get_deliveryslot($selected_date);
        $template['delivery_slot'] = json_decode(json_encode($delivery_slotary['data']), FALSE);
 	  //  echo '<pre>';
 	  //  print_r($template['search_products']);
 	  //  die;
        $this->load->view('template',$template);
 	}
function func_productlist($qry,$mainfunction,$UTN_number){ //func_productlist(query,mainfunciton name, UTNumber)
    if($qry){
            $final_array = array();
            foreach($qry as $dt){
                $subcat_name = $dt->subcategory_name;
                $prod_itemid = $dt->prod_itemid;
                $product_id = $dt->prod_id;
                //Price start here
                $price_to_display = $dt->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $dt->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $dt->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $dt->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $dt->mop_price .' - ₹ '.$dt->mrp_price; //
                   }
                 } //Price end here
                 $display_type = $dt->price_to_display;
                 $final_mrpprice = $dt->mrp_price; 
                 $type = $dt->type;
                 $add_variant = $dt->add_variant;
                 $sale_unit = $dt->sale_unit;
                 $stock_unit = $dt->stock_unit;
                 $pack_content = $dt->pack_content;
                 //get variant name 
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $dt->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $dt->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $dt->att1;
                     $variant1 = $dt->var1;
                     $att2_id = $dt->att2;
                     $variant2 = $dt->var2;
                     $att3_id = $dt->att3;
                     $variant3 = $dt->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $dt->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $size_n = $variant2.';'.$variant3; 
                          $size_n = rtrim($size_n, ";");
                          $size_value = trim($size_n);
                     }
                     
                     $getcnt = explode(";",$variant_name); //masala;egg;corainder
                     $variant_cnt = count($getcnt);//3
                 }
                 //
                 
                 $stock_qty = 0; 
                 //get stock start here
                 if(trim(strtoupper($dt->display_stock))=="NO"){ //follow MOQ
                     $stock_qty = $dt->item_moq;
                 }else {
                     if(strtoupper($type)=="LOOSE"){ //loose product
                         $stock_qty = $dt->item_totstock; 
                      //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock //Only applicable for loose product
                            if($sale_unit!=$stock_unit){
                                if($sale_unit == 1 || $sale_unit == 3){ //1-ml to ltr  ex. 5ltr total stck 500ml packet content //3-gram to kg
                                    $converted = $pack_content / 1000;   // 500ml /1000 = 0.5ltr
                                    $stock_qty = $stock_qty / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                                }
                                else if($sale_unit == 2 || $sale_unit == 5){ //2- ltr to ltr //5-kg to kg
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else if($sale_unit == 4 || $sale_unit == 6 || $sale_unit == 7 || $sale_unit == 8 || $sale_unit == 9){//4-box//6-pcs//7-nos //8-packet//9-plate
                                    $stock_qty = $stock_qty;
                                }
                            }
                            else{
                                 if(($sale_unit == 1) || ($sale_unit == 2) || ($sale_unit == 3) || ($sale_unit == 5) ){
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else {
                                    $stock_qty = $stock_qty;
                                }
                            }
                            $stock_qty = (int)$stock_qty;
                     } else { //Other than loose product
                         $stock_qty = $dt->item_totstock; 
                     }
                 }
                 $fi_stock_qty = round($stock_qty);
                 // stock calculation end here
                 if($mainfunction=='edit_order'){//for this if item quanity 2means show 8quanty only (maximum 10)
                       if($fi_stock_qty>10){ //(maximum 10)
                            $fi_stock_qty = 10;
                        }
                    $ord_data = $this->db->query("select product_id,item_id,SUM(quantity)quantity from orders ord inner join cart on ord.order_id = cart.order_id where ord.UTN_number = '$UTN_number' and product_id =$product_id and cart.item_id= $prod_itemid and cart.product_status not in (0) GROUP BY product_id,item_id")->result();
                    if($ord_data){
                        foreach($ord_data as $od){
                            if($od->item_id==$prod_itemid){// for example in this order -> user added brownie box qty=3 means allow only 7 
                                        $useraddedqty = $od->quantity;//2
                                        $chk_qty = $useraddedqty + $fi_stock_qty;
                                        $chk_qty = 10 - $useraddedqty;
                                        if($chk_qty<=$fi_stock_qty){
                                            $fi_stock_qty = 10 - $useraddedqty;
                                        }else{
                                            $fi_stock_qty = $fi_stock_qty;
                                        }
                                    }
                        }
                    }
                 }
                
                //Stock status    
                if($dt->item_stocksts==1){
                     $stock_status_final='Available';
                }
                
                if($fi_stock_qty <=0 ){
                    $stock_status_final = 'Out of Stock';
                }
                if($dt->item_availability ==0 ){//check availability
                    $stock_status_final = 'Sold Out';
                }
                 $final_mrpprice =round($final_mrpprice,0);    
                 $price_final =round($price_final,0);
                    if($dt->image_type==2){//variant wise image
                            $ex_im = explode('|',$dt->item_images);
                            $image = $ex_im[0];
                    }else{ //generic image
                        $image = $dt->prod_img1;
                    }
                    if($mainfunction=='add_stock'){ // for this function load product which have zero stock (out of  stock)
                        if($fi_stock_qty==0){
                            $final_array[] = array(
                                'product_id'=>$dt->prod_id,
                                'product_name'=>$dt->display_name,
                                'variant_name'=>$variant_name,
                                'type' => $dt->type,
                                'stock' =>$fi_stock_qty,
                                'price'=>"$price_final",
                                'display_price'=>"$price_final",
                                'item_id'=>$prod_itemid,
                                'quantity'=>"$fi_stock_qty"
                                );
                        }

                    }else {
                        if($fi_stock_qty>0 && $stock_status_final=='Available'){
                             $final_array[] = array(
                                'product_id'=>$dt->prod_id,
                                'product_name'=>$dt->display_name,
                                'variant_name'=>$variant_name,
                                'stock' =>$fi_stock_qty,
                                'price'=>"$price_final",
                                'display_price'=>"$price_final",
                                'item_id'=>$prod_itemid,
                                'quantity'=>"$fi_stock_qty"
                                );
                                }
                    }
            }
            return $result = array('status'=>1,'message'=>'product available','data'=>$final_array); 
    }
    return $result = array('status'=>0,'message'=>'product not found'); 
}
function seller_addproduct(){
    if($_POST){
        $order_id = $_POST['order_id'];
        $item_id = $_POST['item_id'];
        $quantity = $_POST['qty'];
        $message_on_cake = trim($_POST['message_on_cake']);
        $var = $_POST['preferred_del_date'];//dd/mm/yyyy
        $date = str_replace('/', '-', $var);//dd-mm-yyyy
        $preferred_del_date =  date('Y-m-d', strtotime($date));
        $preferred_del_time = $_POST['preferred_del_time'];
        $notes_on_chef = "";
        
    $pro_data = $this->db->query("SELECT pro.prod_id,pro.store_id,description,pro.prod_img1,ptype.type_name,prodtl.price_to_display,prodtl.display_stock,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,prodtl.display_name,hsn_code,cgst,sgst,add_variant,sale_unit,pack_content,pri_att,att1,att2,att3,var1,var2,var3 FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id INNER JOIN packettype_master ptype ON ptype.id = pro.packtype_id WHERE prodtl.prod_itemid = $item_id")->result();
    if(empty($pro_data)){
        echo json_encode(array('status'=>0,'message'=>'Somethng went wrong please try again')); exit;
    }
    $product_desc  = $pro_data[0]->description;
    $product_image  = $pro_data[0]->prod_img1;
    $type = $pro_data[0]->type_name;
    $display_name  = $pro_data[0]->display_name;
    $product_id = $pro_data[0]->prod_id;
    $store_id = $pro_data[0]->store_id;
    $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0; $mrp_final = 0; $mop_final =0; $offer_final=0; $billing_rate =0; $billing_price=0;$mrp_rate = 0; $mrp_price = 0;$range_pricing =0;
        if($pro_data){
            $price_to_display = $pro_data[0]->price_to_display;
            $mrp_prc = $pro_data[0]->mrp_price;
            $mrp_final = $pro_data[0]->mrp_price;
            $mop_prc = $pro_data[0]->mop_price;
             $variant_name ='';
             //get variant name 
                $type = $pro_data[0]->type_name;
                $add_variant = $pro_data[0]->add_variant;
                $sale_unit = $pro_data[0]->sale_unit;
                $pack_content = $pro_data[0]->pack_content;
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;

                 }else{
                     $primary_attibuteid = $pro_data[0]->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     //Attribute1 //variant2
                     $att1_id = $pro_data[0]->att1;
                     $variant1 = $pro_data[0]->var1;
                     $att2_id = $pro_data[0]->att2;
                     $variant2 = $pro_data[0]->var2;
                     $att3_id = $pro_data[0]->att3;
                     $variant3 = $pro_data[0]->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                 }
                 //
    
    
            if($price_to_display==1){ //MRP
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==2){ //Mop
                        $display_rate =  $mop_prc;
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==3){ //Offer price
                        $offer_prc = $pro_data[0]->offer_price; 
                        $display_rate =  $offer_prc;
                        $billing_rate = $offer_prc;
                   }else if($price_to_display==4){ //range price
                        // $rangeprice = ($exmop_prc[$varient_id] + $exmrp_prc[$varient_id])/2; // take verage of mop & mrp for price range
                        $range_pricing = $mrp_prc; // take maximum price so mrp 
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                    }else{
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mrp_prc;
                    }
                ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_final);
        $mrp_price = str_replace(',','',$mrp_final) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display;
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_final;
            $billing_price = str_replace(',','',$mrp_final) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->hsn_code;
        $CGSTperc = $pro_data[0]->cgst;
        $SGST_IGSTperc = $pro_data[0]->sgst;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        
        }
        $ord_data = $this->db->query("select * from orders where order_id =$order_id")->result();
        $ord_id = $ord_data[0]->order_id;
        $user_id = $ord_data[0]->user_id;
      $status= $this->db->insert('cart', array('user_id'=>$user_id,'product_name'=>$display_name,'product_id'=>$product_id,'store_id'=>$store_id,'item_id'=>$item_id,'quantity'=>$quantity,'product_desc'=>$product_desc,'product_image'=>$product_image,'rate'=>$billing_rate,'price'=>$billing_price,'mrp_rate'=>$mrp_rate,'billing_type'=>$billing_type,'mrp_price'=>$mrp_price,'type'=>$type,'varient_name'=>$variant_name,'product_status'=>3,'base_amt'=>$base_amt,'hsn_code'=>$HSN_code,'CGST'=>$CGST,'SGST_IGST'=>$SGST_IGST,'display_rate'=>$display_rate,'display_price'=>$display_price,'display_type'=> $display_type,'range_pricing'=> $range_pricing,'message_on_cake'=>$message_on_cake,'preferred_del_date'=>$preferred_del_date,'preferred_del_time'=>$preferred_del_time,'notes_on_chef'=>$notes_on_chef,'order_id'=>$order_id));    
      $this->db->query("update cart set preferred_del_date='$preferred_del_date',preferred_del_time='$preferred_del_time' where user_id = $user_id and order_id = $ord_id"); 
//update stock for only newly added item
if($status){
    $result = $this->db->query("select cart.store_id,cart_id,cart.product_id,ptype.type_name,cart.item_id,sale_unit,pack_content,stock_unit,display_stock,item_totstock,cart.quantity from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product pro  ON pro.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND prodtl.prod_itemid = cart.item_id INNER JOIN packettype_master ptype ON ptype.id = pro.packtype_id where user.user_id = $user_id and cart.product_status in (3) and order_id =$order_id and stockupdate_status=0 ")->result();
    $count = count($result);
    // print_r($result);
    // die;
     $final_array =array();
     $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data){ 
        $product_id  = $data->product_id;
        $type = $data->type_name;
        $item_id = $data->item_id;
           $item_totstock = 0; $item_moq = 0;
        if(strtoupper($type)=='LOOSE'){
            $sale_unit = $data->sale_unit;
            $pack_content = $data->pack_content;
            $stock_unit = $data->stock_unit;
            $display_stock = $data->display_stock;
            $stock_add = 0;
            $total_available_stock_final =""; $moq_final ="";
            if(strtoupper($display_stock)=='YES'){
                $item_totstock = $data->item_totstock;
                //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock
                if($sale_unit!=$stock_unit){
                     if($sale_unit == 1){ //ml to ltr
                    $stock_add = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 3){ //gram to kg
                    $stock_add = 0.001 * ($pack_content * $data->quantity);
                }
                else {
                    $stock_add = ($pack_content * $data->quantity);
                }
                $total_available_stock_final = $item_totstock - $stock_add;
                }
                else{ //if sale unit and stock unit same unit, so directly minus quantity
                    $total_available_stock_final = $item_totstock - ($pack_content * $data->quantity);
                 }
                
            }
        }
        if(strtoupper($type)!='LOOSE'){
            $display_stock =  $data->display_stock;
             $total_available_stock_final= ''; $moq_final = '';
             if(strtoupper($display_stock)=='YES'){
                 $item_totstock = $data->item_totstock;
                 $total_available_stock_final = $item_totstock - ($pack_content * $data->quantity);
             }//for MOQ no need to add/minus stock 
            
        }
    
        $update_data['item_totstock'] ='';
              if($total_available_stock_final!='' || $total_available_stock_final ==0){
                $update_data['item_totstock'] = $total_available_stock_final;
                }
            if(isset($update_data)){
                if($update_data['item_totstock']!='' || $update_data['item_totstock']==0){
          $status = $this->db->update('product_itemdtl',$update_data,array('prod_itemid'=>$item_id));
                }
            }

    if($result){
    $cart_id = $data->cart_id;
    $this->db->query("update cart set product_addby_seller = 1,stockupdate_status =1 where cart_id = $cart_id and product_status = 3 and user_id =$user_id");   // 0 - default added by customer 1- add by seller 
    }
    else{
        echo json_encode(array('status'=>0,'message'=>'Somethng went wrong please try again')); exit;
    }
    
    }
$ttl_discount = 0;
    $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status in (1,2,3) and order_id = $order_id AND user_id = $user_id")->result();
            if($total_discount){
                $ttl_discount =  $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
                $this->db->query("update orders set discount_amount = $ttl_discount where user_id = $user_id and order_id = $order_id");
            }

$cancelled_item_total = 0;$cancelled_item_discount =0; $discount_amount =0; $cmrp =0; $mrp =0;
$result_excart = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product pro ON pro.prod_id = cart.product_id where user.user_id = $user_id and cart.product_status in (0,1,2,3) and order_id =$order_id ")->result();
foreach($result_excart as $ct){
    $items_in_cart = $items_in_cart + $ct->quantity;
    if($ct->product_status==0){
        $cancelled_item_total = $cancelled_item_total + $ct->price ;
        $cmrp = $cmrp + $ct->mrp_price;
    }else{
       $total = $total + $ct->price;  
       $mrp = $mrp + $ct->mrp_price;
    }
    
    $total_mrp =  $total_mrp + $ct->mrp_price;
}
$cancelled_item_discount = $cmrp -  $cancelled_item_total;
$discount_amount = $mrp - $total;
    
$total_amount =  $total;
$payment_method =  $ord_data[0]->payment_method;
$payment_type =  $ord_data[0]->payment_type;
$payment_status =  $ord_data[0]->payment_status;
    if($result){
         $update_data  = array(
            'user_id'=>$user_id,
            'store_id'=>$data->store_id,
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total_amount,
            'discount_amount' =>$discount_amount,
            'items_in_cart' => $items_in_cart,
            'payment_method'=>$payment_method,
            'payment_type'=>$payment_type,
            'payment_status'=>0,
            'booking_time'=>date('Y-m-d H:i:s'),
            'cancel_product_amt' => $cancelled_item_total,
            'cancel_discount_amt' => $cancelled_item_discount,
            'status'=>0
        
        );
    $status = $this->db->update('orders',$update_data,array('order_id'=>$order_id));
    
         //update packing charge & delivery Charge
    $store_id = $data->store_id;
    
    $str = $this->db->query("select orders.district,orders.state,cancel_product_amt,tot_order_base_amt,orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method,delivery_km from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and order_id =$order_id ")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        if($delivery_type==1)//store pickup
        {
            $est_delivery_charge = 0;
        }
        else { //home delivery
            // $est_delivery_charge = $str[0]->min_dc;
             $min_dc = $str[0]->min_dc;
            $delivery_km = $str[0]->delivery_km;
            $dc_freekm = $str[0]->dc_freekm;
            $dc_perkm = $str[0]->dc_perkm;
            if($delivery_km > $dc_freekm){
                $del_charge = $min_dc + (($delivery_km - $dc_freekm ) * $dc_perkm);
                $est_delivery_charge = $del_charge;
            }else {
            $est_delivery_charge = $min_dc;
            }
        }
        if(strtoupper($str[0]->district)=="CHENNAI" && strtoupper($str[0]->state)=="TAMILNADU"){
                $est_delivery_charge = $est_delivery_charge; // FOr  inside chennai km depends delivery charge
            }else if(strtoupper($str[0]->district)!="CHENNAI" && strtoupper($str[0]->state)=="TAMILNADU"){ //outside chennai inside tamilnadu courier charge 75 rs.
                $est_delivery_charge = 75; 
            }else{ //outside tamilnadu courier charge 130.rs
                $est_delivery_charge = 130; 
            }
        $packing_charges = $str[0]->packing_charges;
        $delivery_charges = $str[0]->delivery_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $billing_price = $str[0]->tot_order_base_amt;
            $items = $str[0]->items_in_cart;
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            $active_itemcnt = 0;
                $cnt = $this->db->query("Select sum(quantity)quantity from cart where order_id = $order_id and product_status!=0" )->result();
                if($cnt) {
                    $active_itemcnt = $cnt[0]->quantity;
                }
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
            }else{ //unitwise
            $est_packing_charge =  round(($active_itemcnt * $pc_unit_value),2);
            }   
        }
        // $total_amount = $str[0]->tot_order_base_amt + $str[0]->cancel_product_amt +  $est_packing_charge + $est_delivery_charge;
        $total_amount = $str[0]->tot_order_base_amt +  $est_packing_charge + $est_delivery_charge;
        //update packing charge & delivery Charge
      $this->db->query("update orders set packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and order_id = $order_id");  
    }
    $order = $this->db->query("select * from orders where order_id = $order_id")->result();
    $order_amount = $order[0]->total_amount;
    $update_invdata  = array(
            'total_final_bill_amt'=>$order_amount
        );
    }}
    echo json_encode(array('status'=>1,'message'=>'Product added successfully')); exit;
    }else{
        echo 'Something went wrong please try again';
    }
}
function get_deliveryslot($selected_date=""){
    $list = $this->db->query("select * from delivery_slot where enable =1")->result();
    $del_array = array();
    if($list){
        foreach($list as $dt){
            $del_date = explode("to",$dt->time_slot);
            $deldate_from =  date("H", strtotime($del_date[0]));
            $deldate_to =  date("H", strtotime($del_date[1]));
            $cur_time = date("H");
            $allow = 0;
            $today = date('Y-m-d'); 
            if(($deldate_from >= $cur_time + 1) || $selected_date!=$today){ //1. for today check timing condition 2.for futute delivery date allow all the timing
                $allow = 1;
            }
            if($allow==1){
                $del_array[] = array(
                    'id' => $dt->id,
                    'time_slot'=>$dt->time_slot,
                    'time_slot_view'=>$dt->time_slot_view
                    );
            }
        }
    }
    return $result = array('status'=>1,'data'=>$del_array); 
}
function removeitem(){ //ajax funciton // edit_order menu  // remove item 
    if($_POST){
        
               $order_id= $_POST['order_id'];
               $cart_id= $_POST['cart_id'];
          //updated product_status= 0 item removed by seller 
            $this->db->where("order_id = '$order_id'");
            $this->db->where("cart_id = '$cart_id'");
            $this->db->set('product_status','0');
            $status2 = $this->db->update('cart');
            $getuser = $this->db->query("select user_id,store_id from orders where order_id = $order_id")->result();
            if($getuser){
                $user_id = $getuser[0]->user_id;
                $store_id = $getuser[0]->store_id;
            }else{
                echo 'Something went wrong please try again';
                exit;
            }
        $ord_id = $order_id;
        $total =0;
$cancelled_item_total = 0;$cancelled_item_discount =0; $discount_amount =0; $cmrp =0; $mrp =0;$items_in_cart =0; $total_mrp =0;
$result_excart = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product p on cart.product_id = p.prod_id where user.user_id = $user_id and cart.product_status in (0,1,2,3) and order_id =$ord_id ")->result();
foreach($result_excart as $ct){
    $items_in_cart = $items_in_cart + $ct->quantity;
    if($ct->product_status==0){
        $cancelled_item_total = $cancelled_item_total + $ct->price ;
        $cmrp = $cmrp + $ct->mrp_price;
    }else{
       $total = $total + $ct->price;  
       $mrp = $mrp + $ct->mrp_price;
    }
    
    $total_mrp =  $total_mrp + $ct->mrp_price;
}
$cancelled_item_discount = $cmrp -  $cancelled_item_total;
$discount_amount = $mrp - $total;
    
$total_amount =  $total;
         $update_data  = array(
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total_amount,
            'discount_amount' =>$discount_amount,
            'cancel_product_amt' => $cancelled_item_total,
            'cancel_discount_amt' => $cancelled_item_discount,
        );
    $status = $this->db->update('orders',$update_data,array('order_id'=>$ord_id));
    
    //update packing charge & delivery Charge
    $str = $this->db->query("select orders.district,orders.state,cancel_product_amt,tot_order_base_amt,orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method,orders.delivery_km from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and order_id =$ord_id ")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        if($delivery_type==1)//store pickup
        {
            $est_delivery_charge = 0;
        }
        
        else { //home delivery
            $min_dc = $str[0]->min_dc;
            $delivery_km = $str[0]->delivery_km;
            $dc_freekm = $str[0]->dc_freekm;
            $dc_perkm = $str[0]->dc_perkm;
            if($delivery_km > $dc_freekm){
                $del_charge = $min_dc + (($delivery_km - $dc_freekm ) * $dc_perkm);
                $est_delivery_charge = $del_charge;
            }else {
                $est_delivery_charge = $min_dc;
            }
            if(strtoupper($str[0]->district)=="CHENNAI" && strtoupper($str[0]->state)=="TAMILNADU"){
                $est_delivery_charge = $est_delivery_charge; // FOr  inside chennai km depends delivery charge
            }else if(strtoupper($str[0]->district)!="CHENNAI" && strtoupper($str[0]->state)=="TAMILNADU"){ //outside chennai inside tamilnadu courier charge 75 rs.
                $est_delivery_charge = 75; 
            }else{ //outside tamilnadu courier charge 130.rs
                $est_delivery_charge = 130; 
            }
        }
        $packing_charges = $str[0]->packing_charges;
        $delivery_charges = $str[0]->delivery_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $billing_price = $str[0]->tot_order_base_amt;
            $items = $str[0]->items_in_cart;
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            $active_itemcnt = 0;
                $cnt = $this->db->query("Select sum(quantity)quantity from cart where order_id = $order_id and product_status!=0" )->result();
                if($cnt) {
                    $active_itemcnt = $cnt[0]->quantity;
                }
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
            }else{ //unitwise
            $est_packing_charge =  round(($active_itemcnt * $pc_unit_value),2);
            }   
        }
        // print_r($str[0]->tot_order_base_amt);
        // echo '<pre>';
        // print_r($est_packing_charge);
        // echo '<pre>';
        // print_r($est_delivery_charge);
        // die;
        // $total_amount = $str[0]->tot_order_base_amt + $str[0]->cancel_product_amt +  $est_packing_charge + $est_delivery_charge;
        $total_amount = $str[0]->tot_order_base_amt +  $est_packing_charge + $est_delivery_charge;
        //update packing charge & delivery Charge
      $this->db->query("update orders set packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and order_id = $ord_id");  
    }
    $order = $this->db->query("select * from orders where order_id = $ord_id")->result();
    $order_amount = $order[0]->total_amount;
    $update_invdata  = array(
            'total_final_bill_amt'=>$order_amount
        );
    $status = $this->db->update('invoice',$update_invdata,array('ord_id'=>$ord_id));
    
    //final total update 
            $this->db->where("order_id = '$ord_id'");
            $ord_final_total_update = $this->db->query("select * from orders where order_id =$ord_id ")->result();
            $tot_order_base_amt = $ord_final_total_update[0]->tot_order_base_amt;
            $cancel_product_amt = $ord_final_total_update[0]->cancel_product_amt;
            $packing_charge = $ord_final_total_update[0]->packing_charge;
            $delivery_charge = $ord_final_total_update[0]->delivery_charge;
            // $total_amount = $tot_order_base_amt - $cancel_product_amt +  $packing_charge + $delivery_charge;
            $total_amount = $tot_order_base_amt +  $packing_charge + $delivery_charge;
            $this->db->set('total_amount',$total_amount);
            $status2 = $this->db->update('orders'); 
            echo 'Order Item updated';
    }else{
        echo 'something went wrong please try again';
    }
}
public function ajaxload_deliveryslot(){
    if($_POST){
        $var = $_POST['preferred_del_date'];//dd/mm/yyyy
        $date = str_replace('/', '-', $var);//dd-mm-yyyy
        $preferred_del_date =  date('Y-m-d', strtotime($date));
        $user_id = $_POST['user_id'];
        //load previous cart product preferred date and time default
         $pre_deldate = "";$pre_deltime = "";
        $get_datetime = $this->db->query("select preferred_del_date,preferred_del_time from cart where order_id = 0 and user_id = $user_id")->result();
        if($get_datetime){
            if($get_datetime[0]->preferred_del_date!='0000-00-00'){
                $pre_deldate = $get_datetime[0]->preferred_del_date;
            }
            if($get_datetime[0]->preferred_del_time!=''){
                $pre_deltime = $get_datetime[0]->preferred_del_time;
            }
        }
        $delivery_slot = $this->get_deliveryslot($preferred_del_date);
        $delivery_slotarray = $delivery_slot['data'];?>
                    <option value=""<?php echo ($pre_deltime == '')?"selected":"" ?> >Select Time</option>
		            <?php if($delivery_slotarray){ foreach($delivery_slotarray as $sl){ ?>
				                <option value="<?php echo $sl['time_slot'];?>"<?php echo ($pre_deltime == $sl['time_slot'])?"selected":"" ?>><?php echo $sl['time_slot_view'];?></option>      
				          <?php } } 
    }else{
        echo 'Something went wrong please try again!';
    }
}
}