<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {
		parent::__construct();
		date_default_timezone_set("Asia/Kolkata");
		$this->load->helper(array('form'));
		$this->load->model('login_model');
		$this->load->helper('security');
		if($this->session->userdata('logged_in_storeadmin')) {
			redirect(base_url());
		}
		
	}

	public function index(){
		$template['page_title'] = "Login/Login";
		if(isset($_POST)) {
			$this->load->library('form_validation');
			$this->form_validation->set_rules('username','Username','trim|required');
			$this->form_validation->set_rules('password','Password','trim|required|callback_checkUsrLogin');
			if($this->form_validation->run() == TRUE) {
				redirect(base_url());
			}
		}
		$this->load->view('Login/loginform');
	}
	public function store_login($id=''){ //chain store login or exclusive store login
	if($id==''){
	    redirect(base_url());
	}
	    $template['page_title'] = "Login/Login";
		if(isset($_POST)) {
			$this->load->library('form_validation');
			$this->form_validation->set_rules('username','Username','trim|required');
			$this->form_validation->set_rules('password','Password','trim|required|callback_checkUsrLogin');
			if($this->form_validation->run() == TRUE) {
				redirect(base_url());
			}
		}
		$data['store_data'] = $this->db->query("select theme_color,font_color,store_logo from stores where store_id = $id")->result();
		$this->load->view('Login/loginform',$data);
	    
	}

	function checkUsrLogin($password) {
		$username = $this->input->post('username');
		 $store_useractivests = $this->db->query("Select * from store_users where phone_no ='$username' and password ='$password'")->result();
       if($store_useractivests){
           $active_status = $store_useractivests[0]->user_status;
           if($active_status == 1){
               $status ='active';
           }else {
               $status = 'inactive';
		        $this->form_validation->set_message('checkUsrLogin', 'User Inactive Please contact Store Admin');
		        return FALSE;
		    }
           }

		$result = $this->login_model->login($username, $password);  
		if($result && !empty($result)) {
			$this->session->set_userdata('id',$result->id);
			$this->session->set_userdata('user',$result);
			$this->session->set_userdata('logged_in_storeadmin','1');
			$this->session->set_userdata('product','');
			$this->session->set_userdata('user_type',$result->user_type);
// 			redirect('Order/ViewOrders');
            $url = 'Order/Dashboard';
            $userData = $this->session->userdata['user'];
            if ( $userData->user_type ==3){
                $access_denied = 0;
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select roles_assigned from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='order_management'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
          if($access_denied==0){
                  $url = 'dashboard';
                  $this->session->set_userdata('logo_url',$url);
              redirect(base_url('dashboard'));
              
          }else{
              $this->session->set_userdata('logo_url',$url);
               	redirect('Order/Dashboard');
          }
              
          }
              else{
                  $this->session->set_userdata('logo_url',$url);
    			redirect('Order/Dashboard');              
              }
			return TRUE;
		}
		else {
			$this->form_validation->set_message('checkUsrLogin', 'Invalid username or password');
			return FALSE;
		}
	}
}
?>