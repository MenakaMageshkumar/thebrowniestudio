<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {
		parent::__construct();
		date_default_timezone_set("Asia/Kolkata");
		if(!$this->session->userdata('logged_in_storeadmin')) {
			redirect(base_url('Login'));
		}
	}
	
	public function index() {
	                $template['page'] = 'access';
                    $template['page_title'] = "";
                    $template['page_desc'] = "";
                    $template['access_denied'] ='';
                    // $a ='19';
                    // $b =&$a; //both variable values are same
                    // $b = "2$b";
                    // echo $a.", ".$b; // 219, 219
                    // die;
                    
                    $this->load->view('template',$template);
        
	}
	public function access_denied() {
	                $template['page'] = 'access';
                    $template['page_title'] = "Access Denied";
                    $template['page_desc'] = "Store";
                    $template['access_denied'] ='Access Denied for this user login!';
                    $this->load->view('template',$template);
        
	}
}
?>