<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coupon extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Coupon_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
    }
     public function viewcoupon(){
        $template['page'] = 'Coupon/view_coupon';
        $template['pTitle'] = "View Coupon";
        $template['pDescription'] = "View and Manage Coupon"; 
        $template['menu'] = "Coupom Management";
        $template['smenu'] = "View category";
        $template['coupondata'] = $this->Coupon_model->get_coupon();
        $this->load->view('template',$template);
    }
    
     public function addcoupon(){
        $template['page'] = 'Coupon/add_coupon';
        $template['pTitle'] = "Add New Coupon";
        $template['pDescription'] = "Create New Coupon";
        $template['menu'] = "Coupon Management";
        $template['smenu'] = "Add Coupon";
        // $template['coupondata']= $this->Coupon_model->get_coupon();
        // $template['storedata']= $this->Coupon_model->get_store();
        $this->load->view('template',$template);
    }
    
     public function editcoupon($id)
    {
      
        $id_coupon = decode_param($id);
        $template['coupon_id'] = $id_coupon;
        $template['page'] = 'Coupon/add_coupon';
        $template['pTitle'] = "Edit Coupon";
        $template['pDescription'] = "Update  Coupon";
        $template['menu'] = "Coupon Management";
        $template['smenu'] = "Edit Coupon";
        $template['coupondata']= $this->db->query("select * from yms_offercoupon where id = $id_coupon")->result();;
        $template['storedata']= $this->Coupon_model->get_store();
        $this->load->view('template',$template);
    
    }
    
    // Add coupon function
    // creating coupon
    public function save_coupon()
    {

        $err = 0;
        $errMsg = '';
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(!isset($_POST) || empty($_POST))
        {
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Coupon/addcoupon'));
        }
        if($err == 0 && (!isset($_POST['cp_title']) || empty($_POST['cp_title'])))
        {
            $err = 0;
            $errMsg = 'Provide a  Title';
        }
        $_POST['offer_image'] = '';
        if($err == 0){
            $config = set_upload_service("../../assets/uploads/category");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['offer_image']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('offer_image')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }else{
                $upload_data = $this->upload->data();
                $_POST['offer_image'] = $config['upload_path']."/".$upload_data['file_name'];
            }
        }
        $userData = $this->session->userdata['user'];
        $_POST['store_id'] = $userData->store_id;
        $status = $this->Coupon_model->savecoupon($_POST);
        if($status == 1)
        {
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Coupon Created';
            $this->session->set_flashdata('message',$flashMsg);
           redirect(base_url('Coupon/viewcoupon'));
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Coupon/addcoupon'));
        print_r($_POST);die;
    }
    
    // verify offer code
        public function verify_coupon_offer()
        {
            $cp_offer_code = $_POST['cp_offer_code'];
            $cp_offer_code_result = $this->db->query("select offer_code from yms_offercoupon where offer_code = '$cp_offer_code' ")->result();
                if(!empty($cp_offer_code_result))
                {
                   echo '0';
                   die;
                }
            echo '1';
        }
        
    // update coupon
    
    function save_edit_coupon($id = '')
    {
        
            $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
            if(empty($id))
            {
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Coupon/viewcoupon'));
            } 
            $id = decode_param($id);
            $err = 0;
            $errMsg = '';
            if(!isset($_POST) || empty($_POST))
            {
                $this->session->set_flashdata('message',$flashMsg);
              redirect(base_url('Coupon/addcoupon'));
            }
             if($err == 0 && (!isset($_POST['cp_title']) || empty($_POST['cp_title'])))
            {
                $err = 0;
                $errMsg = 'Provide a  Title';
            }
            
             $config = set_upload_service("../../assets/uploads/category");
             $this->load->library('upload');
             $config['file_name'] = time()."_".$_FILES['offer_image']['name'];
             $this->upload->initialize($config);
            if($this->upload->do_upload('offer_image'))
            {
                $upload_data = $this->upload->data();
                $_POST['offer_image'] = $config['upload_path']."/".$upload_data['file_name'];
            }
            
            $userData = $this->session->userdata['user'];
            $_POST['store_id'] = $userData->store_id;
            
            $status = $this->Coupon_model->updatecoupon($id,$_POST);
            if($status == 1)
            {
                $flashMsg['class'] = 'success';
                $flashMsg['message'] = 'Coupon Details Updated';
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Coupon/viewcoupon'));
            }
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Coupon/editcoupon/'.$id));
            
    }
     function deletecoupon($id = '')
    {
        
            $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
            if(empty($id))
            {
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Coupon/viewcoupon'));
            } 
            $id = decode_param($id);
            $status = $this->Coupon_model->deletecoupon($id);
            if($status == 1)
            {
                $flashMsg['class'] = 'success';
                $flashMsg['message'] = 'Coupon Deleted';
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Coupon/viewcoupon'));
            }
            $this->session->set_flashdata('message',$flashMsg);
            
    }
    
   
}
?>