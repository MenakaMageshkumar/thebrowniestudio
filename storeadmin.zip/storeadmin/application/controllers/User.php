<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        
        if($this->session->userdata['user_type'] !=2 && $this->session->userdata['user_type'] !=3){ //don't allow admin to access 
                   redirect(base_url('access_denied'));
        }
  $userData = $this->session->userdata['user'];
 
    }
    public function viewProfile(){
        $store_id = $this->session->userdata['user']->store_id;
        $template['page'] = 'User/view_profile';
        $template['pTitle'] = "View Profile";
        $template['pDescription'] = "View Store Profile"; 
        $template['menu'] = "Profile";
        $template['smenu'] = "View Profile";
        $template['store'] = $this->db->query("SELECT store_maplocation,seller.id,seller.shopper_name seller_name,seller.email seller_email,seller.phone_no,seller.shopper_image seller_image,str.store_id,str.store_name,str.store_image,str.store_address1 as str_address1,str.store_address2 as  str_address2,area.area_locality,city.city_name,str.city_town as str_citytown,district.district,state.state,str.pincode str_pincode,str.store_gst str_gstnumber,str.store_phone str_phone_no,store_banner1,store_banner2,store_banner3,str.offer_images,str.store_opening_status,str.order_prep_time,str.delivery_time,str.gps_coordinates FROM shopper as seller INNER JOIN stores as str on seller.store_id = str.store_id INNER JOIN area ON area.id = str.area_id INNER JOIN city ON city.id = str.city_id INNER JOIN district on district.district_id = str.district_id INNER JOIN state ON  state.state_id = str.state_id WHERE str.store_id = $store_id ")->result();
        $this->load->view('template',$template);
    }
}