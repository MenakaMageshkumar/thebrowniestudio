<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends CI_Controller {

public function __construct() {
		parent::__construct();
		date_default_timezone_set("Asia/Kolkata");
		if(!$this->session->userdata('logged_in_storeadmin')) {
			redirect(base_url('Login'));
		}
		$userData = $this->session->userdata['user'];
          if ( $userData->user_type ==3){
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='invoice'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }
              
          }
           
        
 	}
public function ViewInvoice(){
    $user_type = $this->session->userdata('user_type');
    $store_list = $this->db->query("select store_id,store_name from stores where status = 1")->result();
    $store_id = 0;
    
    if($user_type==2){ //seller/store login
    $seller_id = $this->session->userdata['user']->id;
    $slr = $this->db->query("select * from shopper where id = $seller_id")->result();
    $store_id = $slr[0]->store_id;
    }
    if($user_type==3){// store user login
    $store_id = $this->session->userdata['user']->store_id;
    $getseller = $this->db->query("select * from shopper where store_id =$store_id ")->result();
    $seller_id = 0;
    if(!empty($getseller)){
    $seller_id = $getseller[0]->id;
    }
    }
    if(isset($_POST['store_id'])){
    if(!empty(decode_param($_POST['store_id']))){
        $store_id = decode_param($_POST['store_id']);
    }
    }
        $template['page'] = 'Invoice/invoice_view';
        $template['pTitle'] = "View Invoice";
        $template['pDescription'] = "View and Manage Invoice"; 
        $template['menu'] = "Invoice";
        $template['smenu'] = "View Invoice";
        $template['store_id'] = $store_id;
        $template['storelist'] = $store_list;
        // print_r($store_id);die;
         if($store_id==0 || $store_id==''){
          $template['InvoiceData'] = $this->db->query("SELECT str.store_id,invoice.inv_no,ord.total_amount total_final_bill_amt,str.store_name,seller.shopper_name seller_name,seller.phone_no,ord.UTN_number,ord.delivery_status,ord.order_id FROM orders ord INNER JOIN invoice on invoice.ord_id = ord.order_id INNER JOIN stores str on str.store_id = ord.store_id INNER JOIN shopper seller on seller.store_id = ord.store_id and seller.store_id = str.store_id order by store_name, invoice.invid DESC")->result();
        }else{
          $template['InvoiceData'] = $this->db->query("SELECT str.store_id,invoice.inv_no,ord.total_amount total_final_bill_amt,str.store_name,seller.shopper_name seller_name,seller.phone_no,ord.UTN_number,ord.delivery_status,ord.order_id FROM orders ord INNER JOIN invoice on invoice.ord_id = ord.order_id INNER JOIN stores str on str.store_id = ord.store_id INNER JOIN shopper seller on seller.store_id = ord.store_id and seller.store_id = str.store_id WHERE str.store_id = $store_id  order by invoice.invid  DESC")->result();
        }
        $this->load->view('template',$template);
}
public function livesearch($q){
	     $q =  $this->uri->segment(3);
         $p =  $this->uri->segment(4);
        if (strlen($q)>0){
        	$hint="";
        	$skucode=$q;
        	$query=$this->db->query("select * from stores where status=1 and store_name LIKE '%$skucode%'");
            $store_check=$query->result();
            
            if(!empty($store_check)){
            echo "<ul class='show'>"; 
            foreach ($store_check as $str) {
			 if($str->store_name!='') {?> <li class="name" >
			 <a  onclick="get_product_details(<?php echo  $str->store_id;?>,<?php echo $p; ?>)" style="cursor:pointer;"><?php echo $str->store_name.' '; ?><?php }  echo "</a></li>";
           
}
echo   "</ul>";
                //$hint=$product_check->product_name;
            }
          
            if ($hint==""){
              $response="no suggestion";
            }else{
              echo $response=$hint;
            }
        }
     }
  public function get_itemdata(){
      $order_id=$_POST['order_id'];
  $item_data = $this->db->query("select cart.*,product.prod_name product_name,prodtl.display_name from cart inner join product ON cart.product_id =  product.prod_id INNER JOIN product_itemdtl prodtl ON product.prod_id = prodtl.prod_id AND cart.item_id =  prodtl.prod_itemid  WHERE cart.order_id =$order_id and cart.product_status in (1,2)")->result();
    $item_array = array();
    if($item_data){
    foreach($item_data as $dt){ 
                
        $exp_cgst = explode(':',$dt->CGST);
        $CGSTperc = $exp_cgst[0];
        $CGST = $exp_cgst[1];
        
        $exp_si = explode(':',$dt->SGST_IGST);
        $SGST_IGSTperc = $exp_si[0];
        $SGST_IGST = $exp_si[1];
        $item_array[] = array (
        'HSN_code' => $dt->HSN_code,
        'display_name' => $dt->display_name,
        'variant_name' => $dt->varient_name,
        'quantity' => $dt->quantity,
        'base_amt' => $dt->base_amt,
        'CGST' => $CGST,
        'SGST_IGST' => $SGST_IGST
        );
    }
    }
    $item = json_decode(json_encode($item_array));

         ?>
         <table id="driverTable" class="table table-bordered table-striped datatable ">
             <thead>
            <tr>
              <th width="5%" class="text-center">S.No</th>
              <th width="40%;" class="text-center">Product Name</th>
              <th width="20%;" class="text-center">Variant</th/>
              <th width="5%;" class="text-center">Qty</th/>
              <th width="10%;" class="text-center">Base Price</th/>
              <!--<th width="5%;">Discount</th>-->
              <th width="5%;" class="text-center">CGST</th>
              <th width="5%;" class="text-center">SGST/IGST</th>
              <th width="10%;" class="text-center">Total</th>
            </tr>
          </thead>
           <tbody>
               
               <?php $cnt = 1; foreach($item as $i){?>
               
               <tr>
                   <td class="text-center"><?= $cnt; ?></td>
                 <td ><?= $i->display_name ?></td>
                 <td class="text-center"><?= $i->variant_name ?></td>
                 <td class="text-center"><?= $i->quantity ?></td>
                 <td class="text-center"><?= $i->base_amt ?></td>
                 <td class="text-center"><?= $i->CGST ?></td>
                 <td class="text-center"><?= $i->SGST_IGST ?></td>
                 <td class="text-center"><?= round($i->base_amt + $i->CGST + $i->SGST_IGST,0) ?></td>
                 
                 </tr>
                     
               <?php $cnt++; }?>
               </tbody>
        </table>
<? 
      }
}?>