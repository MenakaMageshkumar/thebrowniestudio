<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delivery extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Delivery_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        $userData = $this->session->userdata['user'];
        
  $store_id = $userData->store_id;
  $mastersettings_delivery_enable = 0;
  $delivery_enable= $this->db->query("select * from store_mastersettings where store_id =$store_id ")->result();
  if($delivery_enable){
  if(($delivery_enable[0]->delivery_type==2) || ($delivery_enable[0]->delivery_type==3)){ //2-home delivery 3-both
  $mastersettings_delivery_enable = 1;    //Super admin give access for delivery related menu's for this store
  }
  }
          if ( $userData->user_type ==3){
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='delivery_menu' && $mastersettings_delivery_enable == 1){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }
              
          }
          
           if($mastersettings_delivery_enable==0){
              redirect(base_url('access_denied'));
          }

        }
    
    public function addprofile(){
        $template['page'] = 'Delivery/add_delperson';
        $template['pTitle'] = "Add New Delivery Person";
        $template['pDescription'] = "Create New Profile";
        $template['menu'] = "Delivery Person";
        $template['smenu'] = "Add Delivery Person";
        $this->load->view('template',$template);
    }
     public function editdelivery($id){
        $template['page'] = 'Delivery/add_delperson';
        $template['pTitle'] = "Edit Profile";
        $template['pDescription'] = "Update Delivery Profile";
        $template['menu'] = "Delivery Profile Menu";
        $template['smenu'] = "Update Profile";
        $template['deli_boy_id'] = decode_param($id);
        $deli_boy_id = decode_param($id);
        $template['delboy_data']= $this->db->query("select * from delivery_persondtl where deli_boy_id =$deli_boy_id")->result();
        $this->load->view('template',$template);
    }
        public function ViewProfiles(){
        $template['page'] = 'Delivery/view_deliveryprofile';
        $template['pTitle'] = "View Delivery Profiles";
        $template['pDescription'] = "View and Manage Delivery Person"; 
        $template['menu'] = "Delivery Profile";
        $template['smenu'] = "View Profile";
        // $seller_id = $this->session->userdata['id'];
        if($this->session->userdata['user']->user_type == 3){ //store user login
    $store_id = $this->session->userdata['user']->store_id;
    $getseller = $this->db->query("select * from shopper where store_id =$store_id order by shopper.id DESC")->result();
    $seller_id = 0;
    if(!empty($getseller)){
    $seller_id = $getseller[0]->id;
    }
    }else{ //store login
    $seller_id = $this->session->userdata['user']->id;    
    }
        $template['delprofile_list'] = $this->Delivery_model->get_deliveryprofiles($seller_id);
        $this->load->view('template',$template);
    }
    public function createdelprofile(){
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        
        $config = set_upload_service("../assets/uploads/deliveryboy");
        $this->load->library('upload');
        $config['file_name'] = time()."_".$_FILES['deli_profile_image']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('deli_profile_image')){
            $upload_data = $this->upload->data();
            $_POST['deli_profile_image'] = $config['upload_path']."/".$upload_data['file_name'];
        }
        // $seller_id = $this->session->userdata['id'];
            if($this->session->userdata['user']->user_type == 3){ //store user login
            $store_id = $this->session->userdata['user']->store_id;
            $getseller = $this->db->query("select * from shopper where store_id =$store_id ")->result();
            $seller_id = 0;
            if(!empty($getseller)){
            $seller_id = $getseller[0]->id;
            }
            }else{ //store login
            $seller_id = $this->session->userdata['user']->id;    
            }
        $sel_data = $this->db->query("select * from shopper where id = $seller_id")->result();
        $_POST['store_id'] = $sel_data[0]->store_id;
        $_POST['seller_id'] = $seller_id;
        $status = $this->Delivery_model->createdelprofile($_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Delivery Profile Created';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Delivery/ViewProfiles'));
        }else if($status == 2){
            $flashMsg['message'] = 'Contact already in use.';
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Delivery/ViewProfiles'));
    }
    function updateprofile($deli_boy_id = ''){
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(empty($deli_boy_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Delivery/ViewProfiles'));
        }
        $deli_boy_id = decode_param($deli_boy_id);
        $config = set_upload_service("../assets/uploads/deliveryboy");
        $this->load->library('upload');
        $config['file_name'] = time()."_".$_FILES['deli_profile_image']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('deli_profile_image')){
            $upload_data = $this->upload->data();
            $_POST['deli_profile_image'] = $config['upload_path']."/".$upload_data['file_name'];
        }
        $status = $this->Delivery_model->updateprofile($deli_boy_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Delivery Person Details Updated';
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Delivery/ViewProfiles'));
        }else if($status == 2){
            $flashMsg['message'] = 'Contact already in use.';
        }
        $this->session->set_flashdata('message',$flashMsg);
        // redirect(base_url('Category/editcategory/'.$category_id));
        redirect(base_url('Delivery/ViewProfiles'));
    }
    function changeStatus($deli_boy_id = '',$status = '1'){
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(empty($deli_boy_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Delivery/ViewProfiles'));
        }
        $deli_boy_id = decode_param($deli_boy_id);
        $status = $this->Delivery_model->changeStatus($deli_boy_id,$status);
        if(!$status){
            $this->session->set_flashdata('message',$flashMsg);
        }
        redirect(base_url('Delivery/ViewProfiles'));
    }


    
}