<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Role_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        
        if($this->session->userdata['user_type'] !=2){ //don't allow admin to access 
                   redirect(base_url('access_denied'));
        }
  $userData = $this->session->userdata['user'];
  $store_id = $userData->store_id;
  $mastersettings_delivery_enable = 0;
  $delivery_enable= $this->db->query("select * from store_mastersettings where store_id =$store_id ")->result();
  if($delivery_enable){
  if(($delivery_enable[0]->delivery_type==2) || ($delivery_enable[0]->delivery_type==3)){ //2-home delivery 3-both
  $mastersettings_delivery_enable = 1;    //Super admin give access for delivery related menu's for this store
  }
  }
  $GLOBALS['mastersettings_delivery_enable']= $mastersettings_delivery_enable;
    }
   public function create_storeuser(){
        if(isset($_POST['btn'])=='submit'){ //new user submit
            $flashMsg['class'] = 'danger';
            $flashMsg['message'] = 'Something went wrong Please try again';
            $_POST['store_id'] = $this->session->userdata['user']->store_id;
            $status = $this->Role_model->create_storeuser($_POST);
            if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Store User Created';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/view_storeuser'));
        }else if($status == 2){
            $flashMsg['message'] = 'Contact already in use.';
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Role/view_storeuser'));
            
        }else { //edit view and update
        
        $storeuserid = $this->uri->segment(3);
        if ($storeuserid!=''){
        $template['page'] = 'Role/create_storeuser';
        $template['pTitle'] = "Update User";
        $template['pDescription'] = "Update User";
        $template['menu'] = "Store User";
        $template['smenu'] = "Update Store User";
        $store_userid = decode_param($this->uri->segment(3));
        $template['store_userloginid'] = $store_userid;
        $template['storeuser_data'] = $this->db->query("select * from store_users where id =$store_userid ")->result();
        $store_id = $this->session->userdata['user']->store_id;
        $template['store_roles'] = $this->db->query("select * from roles where store_id =$store_id")->result();
        $this->load->view('template',$template);
            
        }else { //create new
        $template['page'] = 'Role/create_storeuser';
        $template['pTitle'] = "Create New User";
        $template['pDescription'] = "Create New User";
        $template['menu'] = "Store User";
        $template['smenu'] = "Create Store User";
        $store_id = $this->session->userdata['user']->store_id;
        $template['store_roles'] = $this->db->query("select * from roles where store_id =$store_id")->result();
        $this->load->view('template',$template);
        }
        }
    }
    
        public function view_storeuser(){
        $template['page'] = 'Role/view_storeuser';
        $template['pTitle'] = "View Store Users";
        $template['pDescription'] = "View and Manage Store Users"; 
        $template['menu'] = "Store User";
        $template['smenu'] = "View Users";
        $store_id = $this->session->userdata['user']->store_id;
        $template['storeuser_data'] = $this->Role_model->get_storeuserdata($store_id);
        $this->load->view('template',$template);
    }
    public function update_storeuser(){
            $store_userid = decode_param($this->uri->segment(3));
            $_POST['id'] = $store_userid;
            $status = $this->Role_model->update_storeuser($_POST);
            if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Store User Updated';
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/view_storeuser'));
            }
            else if($status == 2){
            $flashMsg['class'] = 'danger';
            $flashMsg['message'] = 'Contact already in use.';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/view_storeuser'));
             }
            redirect(base_url('Role/view_storeuser'));
            
        
    }
      public function manage_roles(){
        $template['page'] = 'Role/manage_roles';
        $template['pTitle'] = "View All Roles";
        $template['pDescription'] = "View and Manage Store Roles"; 
        $template['menu'] = "Store Role";
        $template['smenu'] = "View Roles";
        $store_id = $this->session->userdata['user']->store_id;
        $template['roles_data'] = $this->Role_model->get_storeroles($store_id);
        $this->load->view('template',$template);
    }
    public function create_role(){
        if(isset($_POST['btn'])=='submit'){ //update roles
            $flashMsg['class'] = 'danger';
            $flashMsg['message'] = 'Something went wrong Please try again';
            $_POST['store_id'] = $this->session->userdata['user']->store_id;
            $status = $this->Role_model->create_role($_POST);
            if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Store Roles Created';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/manage_roles'));
             }else if($status == 2){
            $flashMsg['class'] = 'danger';
            $flashMsg['message'] = 'Role Name Exists!Please try new Role';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/manage_roles'));
             }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Role/manage_roles'));
            
        }else { 
        $template['page'] = 'Role/create_role';
        $template['pTitle'] = "Create Role";
        $template['pDescription'] = "Create Store Roles"; 
        $template['menu'] = "Create Role";
        $template['smenu'] = "Add Role";
        $store_id = $this->session->userdata['user']->store_id;
        if($GLOBALS['mastersettings_delivery_enable']==1){ //show delivery_menu for role assign else hide
        $allmenu = $this->db->query("Select * from roles_menu order by id")->result();    
        }else{
        $allmenu = $this->db->query("Select * from roles_menu where menu_name !='delivery_menu' order by id")->result();    
        }
        $template['allmenu'] = $allmenu;
        $this->load->view('template',$template);
        }
        
    }
    public function update_roles(){
        if(isset($_POST['btn'])=='submit'){ //update roles
            $flashMsg['class'] = 'danger';
            $flashMsg['message'] = 'Something went wrong Please try again';
            $_POST['role_id'] = decode_param($this->uri->segment(3));
            $_POST['store_id'] = $this->session->userdata['user']->store_id;
            $status = $this->Role_model->update_roles($_POST);
            if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Store Roles Updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/manage_roles'));
             }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Role/manage_roles'));
            
        }else { //view edit page
        $role_id = decode_param($this->uri->segment(3));
        $template['role_id'] = $role_id;
        $template['page'] = 'Role/update_roles';
        $template['pTitle'] = "Update Roles";
        $template['pDescription'] = "View and Manage Store Roles"; 
        $template['menu'] = "Store Role";
        $template['smenu'] = "Update Roles";
        $store_id = $this->session->userdata['user']->store_id;
        $template['roles_data'] = $this->db->query("select id,role_name,store_id,roles_assigned,'' menu_name from roles  where id = $role_id ")->result();
        if($template['roles_data']){
        $roles_assigned = $template['roles_data'][0]->roles_assigned;
        if($roles_assigned=='') $roles_assigned = 0;
        // $role_menu = $this->db->query("Select * from roles_menu where id in ($roles_assigned) and  menu_name !='delivery_menu' order by id")->result();
        if($GLOBALS['mastersettings_delivery_enable']==1){ //show delivery_menu for role assign else hide
        $role_menu = $this->db->query("Select * from roles_menu where id in ($roles_assigned)  order by id")->result(); 
        }else{//hide delivery menu
        $role_menu = $this->db->query("Select * from roles_menu where id in ($roles_assigned) and  menu_name !='delivery_menu' order by id")->result();
        }
        $menu_name = '';
        foreach($role_menu as $menu){
            if($menu_name==''){
                $menu_name = $menu->menu_display_name;
            }else{
             $menu_name= $menu_name.','. $menu->menu_display_name;
            }
        }
        $template['roles_data'][0]->menu_name = $menu_name; //selected menu's
        if($GLOBALS['mastersettings_delivery_enable']==1){ //show delivery_menu for role assign else hide
        $allmenu = $this->db->query("Select * from roles_menu order by id")->result();    
        }else{
        $allmenu = $this->db->query("Select * from roles_menu where menu_name !='delivery_menu' order by id")->result();    
        }
        $template['roles_data'][0]->allmenu = $allmenu;
        }
        $this->load->view('template',$template);
        }
        
    }
    function changeStatus($id = '',$status = '1'){
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'danger');
        if(empty($id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Role/view_storeuser'));
        }
        $id = decode_param($id);
        $status = $this->Role_model->changeStatus($id,$status);
        if($status){
            $flashMsg = array('message'=>'User Status updated','class'=>'success');
            $this->session->set_flashdata('message',$flashMsg);
        }
        redirect(base_url('Role/view_storeuser'));
    }
}