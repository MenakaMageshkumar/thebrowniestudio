<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {
public function __construct() {
		parent::__construct();
		date_default_timezone_set("Asia/Kolkata");
		$this->load->helper('pushnotification_helper'); 
     
		
 	}
 
 	public function item_view($ord_id=0){
 	      //$store_id = $this->session->userdata['user']->store_id;
 	       $store_id = '1';
 	      $final_data =array();
 	      $order_id = decode_param($ord_id);
 	      $itemdata = $this->db->query("select cart.quantity,gift,phone_no,address1,address2,landmark,area,city,district,state,pincode, ord.orderby_name, ord.orderby_contact,ord.deliveryto_name,deliveryto_contact, ord.booking_time,ord.UTN_number,varient_name,product_name,preferred_del_date,preferred_del_time,message_on_cake,notes_on_chef,product_image from cart INNER JOIN orders ord ON cart.order_id = ord.order_id inner join user_profile usr on usr.user_id = ord.user_id where ord.order_id =$order_id  AND cart.product_status !=0")->result();
 	      foreach($itemdata as $it){
 	          $varient_name = $it->varient_name;
 	          $ex_var = explode(';',$varient_name);
 	          $egg_type = '-';$cake_shape = "-";$cake_weight="-";
 	          if((isset($ex_var[1]) && strtoupper($ex_var[1])=='EGG')){
 	              $egg_type = 'Egg';
 	          }
 	          if((isset($ex_var[1]) && strtoupper($ex_var[1])=='EGGLESS')){
 	              $egg_type = 'Eggless';
 	          }
 	          if(isset($ex_var[2])){
 	              $cake_shape = $ex_var[2];
 	          }
 	          if(isset($ex_var[0])){
 	              $cake_weight = $ex_var[0];
 	          }
 	          if($it->gift==1){
 	              $isitgift = "Yes";
 	          }else{
 	              $isitgift = "No";
 	          }
 	          $final_data[] =  array(
 	              'orderid'=>$it->UTN_number,
 	              'orderby_name'=>$it->orderby_name,
                 'orderby_contact'=>$it->orderby_contact,
                 'deliveryto_name'=>$it->deliveryto_name,
                 'deliveryto_contact'=>$it->deliveryto_contact,
 	              'product_name'=>$it->product_name.' - '.$cake_weight.' - '.$it->quantity.' nos',
 	              'booking_date'=>$it->booking_time,
 	              'preferred_del_date'=>$it->preferred_del_date,
 	              'preferred_del_time'=>$it->preferred_del_time,
 	              'message_on_cake'=>$it->message_on_cake,
 	              'notes_on_chef'=>$it->notes_on_chef,
 	              'cake_type'=>$egg_type,
 	              'cake_shape'=>$cake_shape,
 	              'product_image'=>$it->product_image,
 	              'address1'=>$it->address1,
 	              'address2'=>$it->address2,
 	              'landmark'=>$it->landmark,
 	              'area'=>$it->area,
 	              'city'=>$it->city,
 	              'district'=>$it->district,
 	              'state'=>$it->state,
 	              'pincode'=>$it->pincode,
 	              'phone_no'=>$it->phone_no,
 	              'gift'=>$isitgift
 	              );
 	      }
 	      $data['orderData'] = $final_data;
 	      $this->load->view('Order/item_view',$data);

 	}
 

 


}