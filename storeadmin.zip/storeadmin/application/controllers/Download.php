<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Download extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        $userData = $this->session->userdata['user'];
          if ( $userData->user_type ==3){
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='download'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }
              
          }
          
        
    }
public function Inventoryfile(){
     $file_name = 'export_inventory_data_'.date('Ymd').'.csv'; 
     header("Content-Description: File Transfer"); 
     header("Content-Disposition: attachment; filename=$file_name"); 
     header("Content-Type: application/csv;");
        $userData = $this->session->userdata['user'];
        $store_id = $userData->store_id;
        if($store_id){
            $inventory_ary =array();
            $inv_data = $this->db->query("select * from products where store_id = $store_id order by product_id")->result();
            if($inv_data){
            foreach($inv_data as $pro){
                $sale_unit = $pro->sale_unit; //
                $sale_unit = explode('|',$sale_unit);
                $pack_content = $pro->pack_content; //
                $pack_content = explode('|',$pack_content);
                $w=0; $attribute_name1='';
                $display_stock = $pro->display_stock;
                $total_available_stock = $pro->total_available_stock;
                $exp_total_available_stock = explode('|',$total_available_stock);
                $moq = $pro->moq;
                $exp_moq = explode('|',$moq);
                    foreach($sale_unit as $value){
                        $add_variant = $pro->add_varient;
                        $stock = 0;
                        if(strtoupper($pro->type)=='LOOSE'){
                                       $d_stock =  explode('|',$display_stock);
                                       $final_display_stock = $d_stock[0];
                                        if(strtoupper($final_display_stock)=='YES'){
                                        $stock = $exp_total_available_stock[0];
                                        }
                                        else{
                                            $stock = $exp_moq[0];
                                        }
                                    }else{
                                        $d_stock =  explode('|',$display_stock);
                                        $final_display_stock = $d_stock[$w];
                                        if(strtoupper($final_display_stock)=='YES'){
                                        $stock = $exp_total_available_stock[$w];
                                        }
                                        else{
                                            $stock = $exp_moq[$w];
                                        }
                                    }
                        if(strtoupper($add_variant)=='YES'){ //Product with Variant
                                    $sequence_num = str_pad($w+1, 3, 0, STR_PAD_LEFT);
                                    $Vnum = "V".$sequence_num;
                                    $variantid = $Vnum;
                                    $primary_varient = $pro->primary_varient; //which means Primary attribute ID
                                    $attribute1 = $pro->attribute1;
                                    $attribute1  = explode('|',$attribute1);
                                    $attribute1_id = $attribute1[$w];
                                    $att_name = $this->db->query("select * from attributes where id  =$attribute1_id ")->result();
                                    if($att_name){
                                        $attribute_name1 = $att_name[0]->attribute_name;
                                    }
                                    $varient1 = $pro->varient1;
                                    $varient1  = explode('|',$varient1);
                                    $variant_name = $varient1[$w];
                                            $inventory_ary[] = array(
                                            'ProductID' =>$pro->pro_uid,
                                            'Product Name' =>$pro->product_name,
                                            'VariantID' =>$variantid,
                                            'Variant Name' =>$attribute_name1.' - '.$variant_name,
                                            'Stock' =>$stock
                                            );
                        }
                        else{ //No variant
                                    $sequence_num = str_pad($w+1, 3, 0, STR_PAD_LEFT);
                                    $Vnum = "V".$sequence_num;
                                    $variantid = $Vnum;
                                    $novariant_name ='';
                                    $get_saleunit = $this->db->query("select * from product_units where id = $value")->result();
                                    if($get_saleunit){
                                        $saleunit = $get_saleunit[0]->unit;
                                        $novariant_name = $pack_content[$w].' '.$saleunit;
                                    }
                                     $inventory_ary[] = array(
                                            'ProductID' =>$pro->pro_uid,
                                            'Product Name' =>$pro->product_name,
                                            'VariantID' =>$variantid,
                                            'Variant Name' =>$novariant_name,
                                            'Stock' =>$stock
                                            );
                        }
                        $w++;
                    }
                }
                // echo '<pre>';
                //   print_r($inventory_ary);
                //   die;
                     $export_data = json_decode(json_encode($inventory_ary), true);   
                     $file = fopen('php://output', 'w');
                     $header = array("ProductID","Product Name","VariantID","Variant Name","Stock"); 
                     fputcsv($file, $header);
                     foreach ($export_data as  $value)
                     { 
                      fputcsv($file, $value); 
                     }
                     fclose($file);
     
            }
        }
    }
    
}
