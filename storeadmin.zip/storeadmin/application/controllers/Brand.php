<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brand extends CI_Controller {
    
  public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Brand_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
    }
     public function Viewbrand(){
        $store_id = $this->session->userdata['user']->id;
        $template['page'] = 'Brand/view_brand';
        $template['pTitle'] = "View Brand";
        $template['pDescription'] = "View Brand"; 
        $template['menu'] = "Brand";
        $template['smenu'] = "View Brand";
        $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $stores_id = $userData->store_id;
        $template['brand_Data'] = $this->db->query("SELECT * from brand where store_id = $stores_id order by brand.brand_id desc")->result();
        $this->load->view('template',$template);
    }
   
      public function edit_brand($brand_id)
      {
         $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
         if(empty($brand_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $brand_id = decode_param($brand_id);
        $template['brand_id'] =  $brand_id;
        $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $stores_id = $userData->store_id;
        $template['brand_data'] = $this->db->query("SELECT * from brand where store_id = $stores_id and brand_id = $brand_id ")->result();
        $template['page'] = 'Brand/add_brand';
        $template['pTitle'] = "Edit Brand";
        $template['pDescription'] = "Edit"; 
        $template['menu'] = "Brand";
        $template['smenu'] = "Edit Brand";
        $this->load->view('template',$template);
    }
     public function addBrand()
     {
        $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $template['page'] = 'Brand/add_brand';
        $template['pTitle'] = "Add Brand";
        $template['pDescription'] = "Add Brand "; 
        $template['menu'] = "Brand";
        $template['smenu'] = "Add Brand";
        $this->load->view('template',$template);
    }
    
       function updatebrand($brand_id = '')
    {
        
            $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
            if(empty($brand_id))
            {
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Brand/Viewbrand'));
            } 
            $brand_id = decode_param($brand_id);
            $err = 0;
            $errMsg = '';
            if(!isset($_POST) || empty($_POST))
            {
                $this->session->set_flashdata('message',$flashMsg);
                // redirect(base_url('Store/addstorecattype'));
                 redirect(base_url('Brand/addbrand'));
            }
            if($err == 0 && (!isset($_POST['brand_name']) || empty($_POST['brand_name'])))
            {
                $err = 0;
                $errMsg = 'Provide a  brand name';
            }
            $userData = $this->session->userdata['user'];
            $stores_id = $userData->store_id;
            $_POST['store_id'] =  $stores_id ;
            
            // convert base64 into image file and upload
           ////////////////////////////////////////////////////// 
           if(empty($_POST['brand_image_crop_file']))
           {
                $img_old_ = $_POST['brand_image_crop_file_1'];
                $_POST['brand_image_crop_file'] = $img_old_ ;
           }
           else
           {
               $img = $_POST['brand_image_crop_file'];
                $img = str_replace('data:image/png;base64,', '', $img);
                $img = str_replace(' ', '+', $img);
                $data = base64_decode($img);
               $file = "../../assets/uploads/category/" . uniqid() . '.png';
                $success = file_put_contents($file, $data);
                $_POST['brand_image_crop_file'] = $success;
                $_POST['brand_image_crop_file'] = $file ;
           }
           
                
                
            /////////////////////////////////////////////////////////////
            // convert base64 into image file and upload
           
             $status = $this->Brand_model->updatebrand($brand_id,$_POST);
            if($status == 1)
            {
                $flashMsg['class'] = 'success';
                $flashMsg['message'] = ' brand Details Updated';
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Brand/Viewbrand'));
            }
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Brand/edit_brand/'.$brand_id));
            
    }
    
     public function createbrand(){
        $err = 0;
        $errMsg = '';
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(!isset($_POST) || empty($_POST)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('brand/addbrand'));
        }
        if($err == 0 && (!isset($_POST['brand_name']) || empty($_POST['brand_name'])))
            {
                $err = 0;
                $errMsg = 'Provide a  brand name';
            }
        $userData = $this->session->userdata['user'];
        $stores_id = $userData->store_id;
        $_POST['store_id'] =  $stores_id ;

       
        // $_POST['brand_image_crop_file'] = '';
        if($err == 0)
        {
                $img = $_POST['brand_image_crop_file'];
                $img = str_replace('data:image/png;base64,', '', $img);
                $img = str_replace(' ', '+', $img);
                $data = base64_decode($img);
                 $file = "../../assets/uploads/category/" . uniqid() . '.png';
                $success = file_put_contents($file, $data);
                $_POST['brand_image_crop_file'] = $success;
                $_POST['brand_image_crop_file'] = $file ;
        }
        if($err == 1){
            $flashMsg['message'] = $errMsg;
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('brand/addbrand'));
        }
        $status = $this->Brand_model->createbrand($_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Brand Created';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Brand/viewbrand'));
        }else if($status == 2){
            $flashMsg['message'] = 'Brand already in use.';
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('brand/addbrand'));
    }
    
    
    


 

}