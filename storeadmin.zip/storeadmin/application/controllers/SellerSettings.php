<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SellerSettings extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Settings_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
      $userData = $this->session->userdata['user'];
      $store_id = $userData->store_id;
  $mastersettings_delivery_enable = 0;
  $delivery_enable= $this->db->query("select * from store_mastersettings where store_id =$store_id ")->result();
  if($delivery_enable){
  if(($delivery_enable[0]->delivery_type==2) || ($delivery_enable[0]->delivery_type==3)){ //2-home delivery 3-both
  $mastersettings_delivery_enable = 1;    //Super admin give access for delivery related menu's for this store
  }
  }
          if ( $userData->user_type ==3){
              $store_id = $userData->store_id;
              $role_id = $userData->role_id;
              $chk_rls = $this->db->query("select * from roles where id = $role_id")->result();
              if(!empty($chk_rls)){
                  $roles_assigned = $chk_rls[0]->roles_assigned;
                  if($roles_assigned!=''){
                      $menu_assigned = $this->db->query("select * from roles_menu where id in ($roles_assigned)")->result();
                  }else{
                      $menu_assigned ='';
                  }
                  if($menu_assigned!=''){
                      foreach($menu_assigned as $dt){
                          if($dt->menu_name =='master_settings'){
                              $access_denied = 1;
                          }
                      }
                  }
                  
              }
              else{
                  $access_denied = 0;
              }
              if($access_denied==0){
              redirect(base_url('access_denied'));
          }  
              
          }
          
          //Store Master setting of Delivery 
  $storesettings_delivery_enable =0;
  $storesettings_enable = $this->db->query("select store_delivery_type from stores where store_id =$store_id ")->result();
  if($storesettings_enable){
      if(($storesettings_enable[0]->store_delivery_type==2) || ($storesettings_enable[0]->store_delivery_type==3)){ //2-home delivery 3-both
      $storesettings_delivery_enable =1;
      }
  }
$GLOBALS['mastersettings_delivery_enable']  =$mastersettings_delivery_enable;
$GLOBALS['storesettings_delivery_enable']  =$storesettings_delivery_enable; 
    }

public function PackingCharges(){
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    // $seller_id = $this->session->userdata['user']->id;
    if($this->session->userdata['user']->user_type == 3){ //store user login
    $store_id = $this->session->userdata['user']->store_id;
    $getseller = $this->db->query("select * from shopper where store_id =$store_id ")->result();
    $seller_id = 0;
    if(!empty($getseller)){
    $seller_id = $getseller[0]->id;
    }
    }else{ //store login
    $seller_id = $this->session->userdata['user']->id;    
    }
    $str_settings = $this->db->query("select * from stores str inner join shopper slr on str.store_id = slr.store_id where slr.id = $seller_id ")->result();
    if(empty($str_settings)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
    
        $template['page'] = 'seller_settings/packing_charges';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Packing Charges";
        $template['pDescription'] = "View and Update";
        $template['settings_pc'] = $this->Settings_model->getPackingCharges($seller_id);
        $template['seller_id'] = $seller_id;
        $this->load->view('template',$template);
    
    
}
public function update_package($seller_id){
    $seller_id = decode_param($seller_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($seller_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['seller_id'] = $seller_id;
        $status = $this->Settings_model->update_package($seller_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/PackingCharges'));
        }
    
}
public function DeliveryCharges(){
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    
    if($this->session->userdata['user']->user_type == 3){ //store user login
    $store_id = $this->session->userdata['user']->store_id;
    $getseller = $this->db->query("select * from shopper where store_id =$store_id ")->result();
    $seller_id = 0;
    if(!empty($getseller)){
    $seller_id = $getseller[0]->id;
    }
    }else{ //store login
    $seller_id = $this->session->userdata['user']->id;    
    }
    
    $str_settings = $this->db->query("select * from stores str inner join shopper slr on str.store_id = slr.store_id where slr.id = $seller_id ")->result();
    if(empty($str_settings)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
    
        $template['page'] = 'seller_settings/delivery_charges';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Delivery Charges";
        $template['pDescription'] = "View and Update";
        $template['settings_dc'] = $this->Settings_model->getDeliveryCharges($seller_id);
        $template['seller_id'] = $seller_id;
        $this->load->view('template',$template);
    
    
}
public function update_delivery($seller_id){
    $seller_id = decode_param($seller_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($seller_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['seller_id'] = $seller_id;
        $status = $this->Settings_model->update_delivery($seller_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/DeliveryCharges'));
        }
    
}
public function AddScreen(){
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    // $seller_id = $this->session->userdata['user']->id;
    if($this->session->userdata['user']->user_type == 3){ //store user login
    $store_id = $this->session->userdata['user']->store_id;
    $getseller = $this->db->query("select * from shopper where store_id =$store_id ")->result();
    $seller_id = 0;
    if(!empty($getseller)){
    $seller_id = $getseller[0]->id;
    }
    }else{ //store login
    $seller_id = $this->session->userdata['user']->id;    
    }
    $str_settings = $this->db->query("select str.store_id,add_appscreen,add_appdescription from stores str inner join shopper slr on str.store_id = slr.store_id where slr.id = $seller_id ")->result();
    if(empty($str_settings)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
    
        $template['page'] = 'seller_settings/add_appscreen';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Website App Screen';
        $template['pTitle'] = "App Screen";
        $template['pDescription'] = "View and Update";
        $template['addappscreen'] = $str_settings;
        $template['seller_id'] = $seller_id;
        $this->load->view('template',$template);
    
    
}
public function updateAppscreen($seller_id){
    $seller_id = decode_param($seller_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($seller_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['seller_id'] = $seller_id;

         if($_FILES['image1']['name']){
            $config = set_upload_service("../assets/uploads/addscreen");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['image1']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('image1');
            $upload_data = $this->upload->data();
            $_POST['image1'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['image1'] = '';
        }
     
     if($_FILES['image2']['name']){
            $config = set_upload_service("../assets/uploads/addscreen");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['image2']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('image2');
            $upload_data = $this->upload->data();
            $_POST['image2'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['image2'] = '';
        } 
        
         if($_FILES['image3']['name']){
            $config = set_upload_service("../assets/uploads/addscreen");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['image3']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('image3');
            $upload_data = $this->upload->data();
            $_POST['image3'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['image3'] = '';
        } 
        
         if($_FILES['image4']['name']){
            $config = set_upload_service("../assets/uploads/addscreen");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['image4']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('image4');
            $upload_data = $this->upload->data();
            $_POST['image4'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['image4'] = '';
        } 
        
         if($_FILES['image5']['name']){
            $config = set_upload_service("../assets/uploads/addscreen");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['image5']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('image5');
            $upload_data = $this->upload->data();
            $_POST['image5'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['image5'] = '';
        } 
        
         if($_FILES['image6']['name']){
            $config = set_upload_service("../assets/uploads/addscreen");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['image6']['name'];
            $this->upload->initialize($config);
            $this->upload->do_upload('image6');
            $upload_data = $this->upload->data();
            $_POST['image6'] = $config['upload_path']."/".$upload_data['file_name'];
        }else{
            $_POST['image6'] = '';
        } 
        
        
        $status = $this->Settings_model->update_appscreen($seller_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'App Screen data updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/AddScreen'));
        }
         $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/AddScreen'));
    
}
   public function DeliveryType(){
        if($GLOBALS['mastersettings_delivery_enable'] ==1){ 
            $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    $store_id = $this->session->userdata['user']->store_id;
    $str_settings = $this->db->query("select store_delivery_type from stores where store_id =$store_id  ")->result();
    if(empty($str_settings)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
    
        $template['page'] = 'seller_settings/delivery_type';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Delivery Type";
        $template['pDescription'] = "View and Update";
        $template['store_deltype'] = $str_settings;
        $template['store_id'] = $store_id;
        $this->load->view('template',$template);
        }else{
              redirect(base_url('access_denied'));
          
        }
    }
    public function update_deliverytype($store_id){
        $store_id = decode_param($store_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
         if(count($_POST['store_delivery_type'])==2) //support home delivery and store pickup
            {
                $_POST['store_delivery_type'] = 3;
            }
            else //enable
            {
               $_POST['store_delivery_type'] = $_POST['store_delivery_type'][0];
            }
            if($_POST['store_delivery_type']==2 || $_POST['store_delivery_type']==3){ //if enable home delivery check delivery person availability
                $chk_delperson_availability = $this->db->query("select * from delivery_persondtl where store_id = $store_id and active_status=1 ")->result();
                if(empty($chk_delperson_availability)){
                    $flashMsg = array('message'=>'Please Create Delivery Person and enable home delivery..!','class'=>'error');
                    $this->session->set_flashdata('message',$flashMsg);
                    redirect(base_url('SellerSettings/DeliveryType'));
                }
            }else{ //if only store pickup means check all open order are close or not
                $open_order = $this->db->query("SELECT ord.UTN_number orderid,cust.fullname,cust.email,cust.phone_no,'' as address,ord.booking_time FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE str.store_id = $store_id and delivery_status in (0) order by ord.order_id desc")->result();
                if(!empty($open_order)){
                    $flashMsg = array('message'=>'Please Close Open Orders and Disable home delivery..!','class'=>'error');
                    $this->session->set_flashdata('message',$flashMsg);
                    redirect(base_url('SellerSettings/DeliveryType'));
                }
            }
        $_POST['store_id'] = $store_id;
        $status = $this->Settings_model->update_deliverytype($store_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/DeliveryType'));
        }
        
    }
    public function StoreLocation(){
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    $store_id = $this->session->userdata['user']->store_id;
    $str_settings = $this->db->query("select * from stores str inner join shopper slr on str.store_id = slr.store_id where str.store_id = $store_id ")->result();
    if(empty($str_settings)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
    
        $template['page'] = 'seller_settings/update_storelocation';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Store Location";
        $template['pDescription'] = "View and Update";
        $template['store_location'] = $str_settings[0]->store_maplocation;
        $template['store_id'] = $store_id;
        $this->load->view('template',$template);
    
    
}
public function update_storelocation($store_id){
    $store_id = decode_param($store_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['store_id'] = $store_id;
        
        $status = $this->Settings_model->update_storelocation($store_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/StoreLocation'));
        }
    
}

public function ThemeSettings(){
        $template['page'] = 'seller_settings/theme_settings';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Theme Settings";
        $template['pDescription'] = "View and Update";
        $store_id = $this->session->userdata['user']->store_id;
        $template['store_id'] = $store_id;
        $template['store_data'] = $this->db->query("select store_name,store_banner1,theme_color,font_color from stores where store_id = $store_id ")->result();
        $this->load->view('template',$template);
}
public function update_theme($store_id){
    $store_id = decode_param($store_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['store_id'] = $store_id;
        $status = $this->Settings_model->update_theme($store_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Theme Settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/ThemeSettings'));
        }
    
}
public function InvoiceFormat(){
        $store_id = $this->session->userdata['user']->store_id;
        $template['page'] = 'seller_settings/invoice_format';
        $template['menu'] = 'Master Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Invoice Format";
        $template['pDescription'] = "View and Update";
        $template['settings_if'] = $this->Settings_model->getinvoiceformat($store_id);
        $template['store_id'] = $store_id;
        $this->load->view('template',$template);
    
}
public function update_invoiceformat($store_id){
    $store_id = decode_param($store_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['store_id'] = $store_id;
        $status = $this->Settings_model->update_invoiceformat($store_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Invoice Settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/InvoiceFormat'));
        }
    
}
	public function Comments(){
 	    $store_id = $this->session->userdata['user']->store_id;
 	    $template['page'] = 'seller_settings/comments';
        $template['pTitle'] = "View Comments";
        $template['pDescription'] = "View and Manage Comments"; 
        $template['menu'] = "Orders";
        $template['smenu'] = "View Comments";
        $template['store_id'] = 1;
        $template['comments'] = $this->db->query("SELECT re.id cmt_id,usr.fullname username,pro.prod_name as product_name,'' display_name,re.star_count,re.review_type,re.comment,re.view_status,re.date_reviewed FROM user_reviews re INNER JOIN product pro ON re.product_id = pro.prod_id INNER JOIN user_profile usr ON usr.user_id = re.user_id WHERE pro.store_id = $store_id ORDER BY re.id DESC")->result();
        $this->load->view('template',$template);
 	}
 	 function changecomment_status(){
        $data['view_status'] = $this->uri->segment(4);
        $data['id'] = decode_param($this->uri->segment(3));
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        $status = $this->Settings_model->changecomment_status($data);
        if(!$status){
            $this->session->set_flashdata('message',$flashMsg);
        }
        redirect(base_url('SellerSettings/Comments'));
    }
public function StoreSettings(){
        $store_id = $this->session->userdata['user']->store_id;
        $template['page'] = 'seller_settings/store_settings';
        $template['menu'] = 'Store Settings';
        $template['smenu'] = 'Update Settings';
        $template['pTitle'] = "Store Delivery & Preparation Time Update ";
        $template['pDescription'] = "View and Update";
        //default 1 for minutes 30 - value  =>>> 30minutes
        $data = array(
                'del_type' => 1,
                'del_value' => 30,
                'prep_type' => 1,
                'prep_value' => 30
                );
        $storedata = $this->Settings_model->getstoredelprep($store_id);
        if($storedata){
            $del_time = $storedata[0]->del_time; 
            $ex_deltime = explode('|',$del_time);
            $prep_time = $storedata[0]->prep_time; 
            $ex_preptime = explode('|',$prep_time);
            $data = array(
                'del_type' => $ex_deltime[0],
                'del_value' => $ex_deltime[1],
                'prep_type' => $ex_preptime[0],
                'prep_value' => $ex_preptime[1]
                );
            }
        $template['data'] = $data; 
        $template['store_id'] = $store_id;
        $this->load->view('template',$template);  
}
public function update_storesettings($store_id){
    $store_id = decode_param($store_id);
    $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
    if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $_POST['store_id'] = $store_id;
        $status = $this->Settings_model->update_storesettings($store_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Store settings updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('SellerSettings/StoreSettings'));
        }
    
}
}    