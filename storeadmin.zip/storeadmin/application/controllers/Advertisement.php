<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Advertisement extends CI_Controller {
    
  public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Advertisement_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
    }
     public function ViewBanner(){
        $store_id = $this->session->userdata['user']->id;
        $template['page'] = 'Advertisement/view_banner';
        $template['pTitle'] = "View Banner";
        $template['pDescription'] = "View App Banner"; 
        $template['menu'] = "Banner";
        $template['smenu'] = "View Banner";
        $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $stores_id = $userData->store_id;
        $template['banner'] = $this->db->query("SELECT strweb_banners from stores where store_id = $stores_id order by stores.store_id DESC")->result();
        $this->load->view('template',$template);
    }
    
    //   public function AddBanner($store_id=''){
    //      if($store_id!=''){
    //       $store_id = decode_param($store_id);
    //       $template['banner'] = $this->db->query("SELECT banner_image,id as store_id from client WHERE id = $store_id ")->result();
    //      }
    //     $store_id = $this->session->userdata['user']->id;
    //     $template['page'] = 'Advertisement/add_banner';
    //     $template['pTitle'] = "View Banner";
    //     $template['pDescription'] = "View App Banner"; 
    //     $template['menu'] = "Banner";
    //     $template['smenu'] = "View Banner";
    //     $template['store_id'] = $store_id;
    //     $this->load->view('template',$template);
    // }
    
      public function editBanner($store_id)
      {
          $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
         if(empty($store_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $store_id = decode_param($store_id);
        $template['banner'] = $this->db->query("SELECT strweb_banners from stores WHERE store_id = $store_id ")->result();
        $template['page'] = 'Advertisement/add_banner';
        $template['pTitle'] = "View Banner";
        $template['pDescription'] = "View App Banner"; 
        $template['menu'] = "Banner";
        $template['smenu'] = "View Banner";
        $template['store_id'] = $store_id;
        $this->load->view('template',$template);
    }

    public function update_Advertisement($store_id){
         $store_id = decode_param($store_id);
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(empty($store_id)){
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url());
            }
        $_POST['store_id'] = $store_id;
       
        
        $config = set_upload_service("../../assets/ymservice/clientbanner");
        $this->load->library('upload');
        if(isset($_FILES['banner_1']['name']))
        {
        $config['file_name'] = time()."_".$_FILES['banner_1']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('banner_1')){
            $upload_data = $this->upload->data();
            $_POST['banner_1'] = $config['upload_path']."/".$upload_data['file_name'];
        } }
        
        if(isset($_FILES['banner_2']['name'])){
        $config['file_name'] = time()."_".$_FILES['banner_2']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('banner_2')){
            $upload_data = $this->upload->data();
            $_POST['banner_2'] = $config['upload_path']."/".$upload_data['file_name'];
        }}
        
        if(isset($_FILES['banner_3']['name'])){
        $config['file_name'] = time()."_".$_FILES['banner_3']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('banner_3')){
            $upload_data = $this->upload->data();
            $_POST['banner_3'] = $config['upload_path']."/".$upload_data['file_name'];
        }}
        $status = $this->Advertisement_model->update_Advertisement($store_id,$_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Banner updated';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Advertisement/ViewBanner'));
        }else{
            redirect(base_url('Advertisement/ViewBanner'));
        }
        
    }

}