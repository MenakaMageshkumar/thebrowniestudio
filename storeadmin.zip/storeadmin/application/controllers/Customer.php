<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Customer_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
        $userData = $this->session->userdata['user'];
        $store_id = $userData->store_id;
        $chk_access = 1;
        if($userData->user_type !=2){ //customer management enable for store admin only
            $chk_access==0;
        }
        // $exclusive_app_enabled= $this->db->query("select exclusive_app_enabled from stores where store_id =$store_id ")->result();
        // if($exclusive_app_enabled){
        //     if($exclusive_app_enabled[0]->exclusive_app_enabled!=1){ //0- default app 1- exclusive app
        //     $chk_access = 0;
        //     }
        // }else
        // {
        //     $chk_access = 0;
        // }
        if($chk_access==0){
          redirect(base_url('access_denied'));
        }

        }
    
     public function ManageCustomer(){ //My circle customer
         $userData = $this->session->userdata['user'];
        $store_id = $userData->store_id;
        $template['page'] = 'Customer/view_customer';
        $template['pTitle'] = "Customer";
        $template['pDescription'] = "Manage Customer";
        $template['menu'] = "Customer";
        $template['smenu'] = "Customer";
//        $template['customer']= $this->db->query("SELECT * FROM user_profile WHERE my_circle = $store_id")->result();
        $template['customer']= $this->db->query("SELECT * FROM user_profile ORDER BY user_profile.user_id DESC")->result();
        $this->load->view('template',$template);
    }
      public function editCustomer(){
        $id = $this->uri->segment(3);
        $template['page'] = 'Customer/edit_customer';
        $template['pTitle'] = "Edit Customer";
        $template['pDescription'] = "Update Customer";
        $template['menu'] = "Customer Menu";
        $template['smenu'] = "Update Customer";
        $template['user_id'] = decode_param($id);
        $user_id = decode_param($id);
        $template['customer_data']= $this->db->query("select * from user_profile where user_id =$user_id")->result();
        $this->load->view('template',$template);
    }
       function updateCustomer($user_id = ''){
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(empty($user_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Content/ManageCustomer'));
        }
        $user_id = decode_param($user_id);
       $status = $this->Customer_model->updateCustomer($_POST,$user_id);
       if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'Customer profile updated';
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Customer/ManageCustomer'));
        }
        $this->session->set_flashdata('message',$flashMsg);
        redirect(base_url('Customer/ManageCustomer'));
           
       }  
       public function updateUsertype(){
    $user_id = $_POST['user_id'];
    $user_type = $_POST['user_type'];
            $this->db->where("user_id = $user_id");
            $this->db->set('user_type',$user_type);
            $st = $this->db->update('user_profile');
            if($st){
                echo 'User type updated';
            }else{
                echo 'Something went wrong Please try again';
            }

}
}