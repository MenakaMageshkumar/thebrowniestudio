<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logout extends CI_Controller {

	public function __construct() {
		parent::__construct();
		date_default_timezone_set("Asia/Kolkata");
		$base_url ='Login';
		$userData = $this->session->userdata['user'];
        $store_id = $userData->store_id;
        $exclusive_app_enabled= $this->db->query("select exclusive_app_enabled from stores where store_id =$store_id ")->result();
        if($exclusive_app_enabled){
            if($exclusive_app_enabled[0]->exclusive_app_enabled==1){ //0- default app 1- exclusive app
            $base_url ='Login/'.$store_id;
            }
        }
        
		if(!$this->session->userdata('logged_in_storeadmin')) {
			redirect(base_url($base_url));
		}
 	}
	
	function index() {
	    $base_url ='Login';
	    $userData = $this->session->userdata['user'];
        $store_id = $userData->store_id;
        $exclusive_app_enabled= $this->db->query("select exclusive_app_enabled from stores where store_id =$store_id ")->result();
        if($exclusive_app_enabled){
            if($exclusive_app_enabled[0]->exclusive_app_enabled==1){ //0- default app 1- exclusive app
            $base_url ='Login/'.$store_id;
            }
        }
		$this->session->unset_userdata('logged_in_storeadmin');
// 		session_destroy();
		redirect(base_url($base_url));
	}
}
?>