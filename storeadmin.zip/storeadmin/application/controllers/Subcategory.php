<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subcategory extends CI_Controller {
    
  public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model('Subcategory_model');
        if(!$this->session->userdata('logged_in_storeadmin')) {
            redirect(base_url('Login'));
        }
    }
     public function Viewsub_cat(){
        $store_id = $this->session->userdata['user']->id;
        $template['page'] = 'Subcategory/view_sub_category';
        $template['pTitle'] = "View Subcategory";
        $template['pDescription'] = "View Subcategory"; 
        $template['menu'] = "Subcategory";
        $template['smenu'] = "View Subcategory";
        $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $stores_id = $userData->store_id;
        $template['scatData'] = $this->db->query("SELECT * from sub_category where store_id = $stores_id order by sub_category.subcat_id asc")->result();
        $this->load->view('template',$template);
    }
   
      public function editsub_cat($subcat_id)
      {
         $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
         if(empty($subcat_id)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url());
        }
        $subcat_id = decode_param($subcat_id);
        $template['subcat_id'] =  $subcat_id;
        $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $stores_id = $userData->store_id;
        $template['main_cat'] = $this->db->query("SELECT * FROM categories")->result();
        $template['category'] = $this->db->query("SELECT * FROM category")->result();
        $template['scatData'] = $this->db->query("SELECT * from sub_category where store_id = $stores_id and subcat_id = $subcat_id ")->result();
        $template['page'] = 'Subcategory/edit_sub_cat';
        $template['pTitle'] = "Edit Subcategory";
        $template['pDescription'] = "Edit"; 
        $template['menu'] = "Subcategory";
        $template['smenu'] = "Edit Subcategory";
        $this->load->view('template',$template);
    }
     public function addsubcategory()
     {
         $userData = $this->session->userdata['user'];
        $template['store_id'] = $userData->store_id;
        $template['main_cat'] = $this->db->query("SELECT * FROM categories")->result();
        $template['category'] = $this->db->query("SELECT * FROM category")->result();
        $template['page'] = 'Subcategory/edit_sub_cat';
        $template['pTitle'] = "Add Subcategory";
        $template['pDescription'] = "Add Subcategory "; 
        $template['menu'] = "Subcategory";
        $template['smenu'] = "Add Subcategory";
        $this->load->view('template',$template);
    }
    
      function updatesubcategory($subcat_id = '')
    {
        
            $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
            if(empty($subcat_id))
            {
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Subcategory/Viewsub_cat'));
            } 
            $subcat_id = decode_param($subcat_id);
            $err = 0;
            $errMsg = '';
            if(!isset($_POST) || empty($_POST))
            {
                $this->session->set_flashdata('message',$flashMsg);
                // redirect(base_url('Store/addstorecattype'));
                 redirect(base_url('Subcategory/Viewsub_cat'));
            }
            if($err == 0 && (!isset($_POST['subcategory_name']) || empty($_POST['subcategory_name'])))
            {
                $err = 0;
                $errMsg = 'Provide a  Sub category name';
            }
            $userData = $this->session->userdata['user'];
            $stores_id = $userData->store_id;
            $_POST['store_id'] =  $stores_id ;
            
            // convert base64 into image file and upload
           ////////////////////////////////////////////////////// 
           if(empty($_POST['category_image_crop_file']))
           {
                $img_old_ = $_POST['category_image_crop_file_1'];
                $_POST['category_image_crop_file'] = $img_old_ ;
           }
           else
           {
               $img = $_POST['category_image_crop_file'];
                $img = str_replace('data:image/png;base64,', '', $img);
                $img = str_replace(' ', '+', $img);
                $data = base64_decode($img);
                $file = "../../assets/uploads/category/" . uniqid() . '.png';
                $success = file_put_contents($file, $data);
                $_POST['category_image_crop_file'] = $success;
                $_POST['category_image_crop_file'] = $file ;
           }
           
                
                
            /////////////////////////////////////////////////////////////
            // convert base64 into image file and upload
           
             $status = $this->Subcategory_model->updatesubcategory($subcat_id,$_POST);
            if($status == 1)
            {
                $flashMsg['class'] = 'success';
                $flashMsg['message'] = 'Sub Category Details Updated';
                $this->session->set_flashdata('message',$flashMsg);
                redirect(base_url('Subcategory/Viewsub_cat'));
            }
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Subcategory/editsub_cat/'.$subcat_id));
            
    }
    
     public function createsubcategory(){
        $err = 0;
        $errMsg = '';
        $flashMsg = array('message'=>'Something went wrong, please try again..!','class'=>'error');
        if(!isset($_POST) || empty($_POST)){
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Subcategory/addsubcategory'));
        }
        if($err == 0 && (!isset($_POST['subcategory_name']) || empty($_POST['subcategory_name'])))
            {
                $err = 0;
                $errMsg = 'Provide a  Sub category name';
            }
        $userData = $this->session->userdata['user'];
        $stores_id = $userData->store_id;
        $_POST['store_id'] =  $stores_id ;

       
        // $_POST['category_image_crop_file'] = '';
        if($err == 0)
        {
                $img = $_POST['category_image_crop_file'];
                $img = str_replace('data:image/png;base64,', '', $img);
                $img = str_replace(' ', '+', $img);
                $data = base64_decode($img);
                $file = "../../assets/uploads/category/" . uniqid() . '.png';
                $success = file_put_contents($file, $data);
                $_POST['category_image_crop_file'] = $success;
                $_POST['category_image_crop_file'] = $file ;
        }
        if($err == 1){
            $flashMsg['message'] = $errMsg;
            $this->session->set_flashdata('message',$flashMsg);
             redirect(base_url('Subcategory/addsubcategory'));
        }
        $status = $this->Subcategory_model->createsubcategory($_POST);
        if($status == 1){
            $flashMsg['class'] = 'success';
            $flashMsg['message'] = 'sub category Created';
            
            $this->session->set_flashdata('message',$flashMsg);
            redirect(base_url('Subcategory/Viewsub_cat'));
        }else if($status == 2){
            $flashMsg['message'] = 'sub category already in use.';
        }
        $this->session->set_flashdata('message',$flashMsg);
         redirect(base_url('Subcategory/addsubcategory'));
    }

 

}