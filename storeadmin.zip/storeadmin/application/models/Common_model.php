<?php
/*---------------------------------------------------------
	| Author		: Aman Suryawanshi
	| Date Created	: 27.02.2019
	| Date Modifies	: 27.02.2019
	| Remark		: Controller for Seller admin API for Libazon
	|----------------------------------------------------------*/
class Common_model extends CI_Model {
	
        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
        }
		
	/*---------------------------------------------------------
	| Name			: renderError
	| Usage			: Returning/ Rendering Error
	| Parameters 	: 
	|	msg	: array or string
	| Retrun Type 	: JSON
	| Return Value: Error with status 'false' error messages 
	|----------------------------------------------------------*/
	public function renderError($val){
// 		echo json_encode(array('status'=>'false','value'=>$val));
        echo json_encode(array('status'=>0,'message'=>$val));
		exit;
	}
	/*---------------------------------------------------------
	| Name		: renderSuccess
	| Usage		: Returning/ Rendering Success
	| Parameters : 
	|	msg	: array or string
	| Retrun Type : JSON
	| Return Value: Success with status 'true' success message
	|----------------------------------------------------------*/
	public function renderSuccess($val){
// 		echo json_encode(array('status'=>'true','value'=>$val));
       echo json_encode(array('status'=>1,'message'=>$val));
		exit;
	}
	/*---------------------------------------------------------
	| Name		: generate_key
	| Usage		: Used to generate random keys 
	| Parameters : nil
	| Retrun Type : String
	| Return Value: Key
	|----------------------------------------------------------*/
	public function generate_key(){
		return random_string('unique');
	}
	/*---------------------------------------------------------
	| Name		: insert
	| Usage		: Used to insert the values into a table 
	| Parameters : 
	|				$val : array of values to insert
	|				$table : table name into which we need to insert the value
	| Retrun Type : Boolean
	| Return Value: True/False
	|----------------------------------------------------------*/
	public function insert($table,$val=array()){
		if($this->db->insert($table, $val)){
			return $this->db->insert_id();
		}
		else
			return false;
	}
	/*---------------------------------------------------------
	| Name		: insert
	| Usage		: Used to insert the values into a table 
	| Parameters : 
	|				$val : array of values to insert
	|				$table : table name into which we need to insert the value
	| Retrun Type : Boolean
	| Return Value: True/False
	|----------------------------------------------------------*/
	public function insertBatch($table,$val=array()){
		if($this->db->insert_batch($table, $val))
			return true;
		else
			return false;
	}
	/*---------------------------------------------------------
	| Name		: update
	| Usage		: Used to update the values into a table 
	| Parameters : 
	|				$val : array of values to update
	|				$table : table name into which we need to update the value
	|				$where : array of conditions
	| Retrun Type : Boolean
	| Return Value: True/False
	|----------------------------------------------------------*/
	public function update($table='',$val=array(),$where=array()){
		if($this->db->update($table, $val,$where))
			return true;
		else
			return false;
	}
	/*---------------------------------------------------------
	| Name		: selectAll
	| Usage		: Used to select all the values from a table 
	| Parameters : 
	|				$table :  table name from which we need to fetch the value
	|				$where : array of conditions
	|				$limit : limit
	|				$offset: offset
	| Retrun Type : array
	| Return Value: array of values
	|----------------------------------------------------------*/
	public function selectAll($table='',$where=array(),$limit='', $offset=''){
		$query = $this->db->get_where($table,$where,$limit,$offset);
		return $query->result();
	}
	/*---------------------------------------------------------
	| Name		: select
	| Usage		: Used to select some fields the values from a table 
	| Parameters : 
	|				$table : table name from which we need to fetch the value
	|				$where : array of conditions
	|				$limit : limit
	|				$offset: offset
	| Retrun Type : array
	| Return Value: array of values
	|----------------------------------------------------------*/
	public function select($fields='*',$table='',$where=array(),$limit='', $offset=''){
		$this->db->select($fields);
		$this->db->where($where);
		$query = $this->db->get($table,$limit,$offset);
		return $query->result();
	}
	/*---------------------------------------------------------
	| Name		: selectJoin
	| Usage		: Used to select some fields the values from a table 
	| Parameters : 
	|				$table : table name from which we need to fetch the value
	|				$where : array of conditions
	|				$join : array of joins
	|				$limit : limit
	|				$offset: offset
	| Retrun Type : array
	| Return Value: array of values
	|----------------------------------------------------------*/
	public function selectJoin($fields='*',$table='',$join=array(),$where=array(),$limit='', $offset=''){
		$this->db->select($fields);
		$this->db->from($table);
		foreach($join as $j){
			if(isset($j['type']))
				$this->db->join($j['table'],$j['condition'],$j['type']);
			else
				$this->db->join($j['table'],$j['condition']);
		}
		$this->db->where($where);
		$this->db->limit($limit,$offset);
		$query = $this->db->get();
		//echo $this->db->last_query();
		return $query->result();
	}
	/*---------------------------------------------------------
	| Name		: Custom Query
	| Usage		: 
	| Parameters : 
	|				$query : query string
	| Retrun Type : array
	| Return Value: array of values
	|----------------------------------------------------------*/
	public function query($query=''){
		
		$query = $this->db->query($query);
		return $query->result();
	}
	/*---------------------------------------------------------
	| Name		: Custom Query No return value
	| Usage		: 
	| Parameters : 
	|				$query : query string
	| Retrun Type : array
	| Return Value: array of values
	|----------------------------------------------------------*/
	public function query_noreturn($query=''){
		
		$query = $this->db->query($query);
		return $query;
	}
	/*---------------------------------------------------------
	| Name		: delete
	| Usage		: Used to delete a row from a table 
	| Parameters : 
	|				$table : table name from which we need to fetch the value
	|				$where : array of conditions
	|				$offset: offset
	| Retrun Type : Boolean
	| Return Value: True/False
	|----------------------------------------------------------*/
	public function delete($table='',$where=array()){
		$this->db->where($where);
		return $this->db->delete($table);
	}
	public function is_login($api_token=''){
		if(count($this->select(array('userid'),'users',array('api_token'=>$api_token)))>0)
			return true;
		else
			return false;
	}
	public function get_user_data($where=array()){
		$usersArray = $this->selectAll('users',$where);
		if(count($usersArray)>0)
			return $usersArray[0];
		else
			return false;
	}
	public function getFirstEngagedUserServiceDetails($data){
		$this->db->select('users.partner,engage.sender_id,engage.service_a_id,engage.service_b_id');
		$this->db->from('engage');
		$this->db->join('users','engage.sender_id=users.userid');
		$this->db->where($data);
		$this->db->limit(1);
		$query = $this->db->get();
		return $query->result();
	}

	public function final_agreement($data){
		$agreement_details = $this->select('id','final_agreement_service_details',array('type_a_service_id'=>$data['type_a_service_id'],'type_b_service_id'=>$data['type_b_service_id']));
		if(count($agreement_details)>0){
			return $agreement_details[0]->id;
		}
		else{
			return $this->insert('final_agreement_service_details',$data);
		}
	}
	public function updateCredit($credit=0,$userid=0){
		$this->db->set('total_credits','total_credits+'.$credit,FALSE);
		$this->db->where('userid',$userid);
		//$this->db->update('user_credits');
		//echo $this->db->last_query();
		return $this->db->update('user_credits');
	}
	public function gcm_messaging($userids_array=array(),$message="",$extra=""){
		$this->db->select("gcm_token");
		$this->db->where_in("userid",$userids_array);
		$query = $this->db->get("users");
		//echo $this->db->last_query();
		$registration_ids_array= $query->result();
			$registatoin_ids = array();
			//var_dump($registration_ids_array);
			foreach($registration_ids_array as $r){
				if($r->gcm_token)
					$registatoin_ids[]=$r->gcm_token;
			}
			//var_dump($registatoin_ids);
			if(count($registatoin_ids)>0){
				$url = 'https://android.googleapis.com/gcm/send';
				//$url = 'https://gcm-http.googleapis.com/gcm/send';
				if($extra ==""){
					$fields = array(
						'registration_ids' => $registatoin_ids,
						'data' => array("message" =>$message),
					);
				}
				else if(isset($extra['order_id'])){
					$fields = array(
						'registration_ids' => $registatoin_ids,
						'data' => array("message" =>$message,"order_id"=>$extra['order_id']),
					);
				}
				// Google Cloud Messaging GCM API Key
						
				$headers = array(
					'Authorization: key=' . GOOGLE_API_KEY,
					'Content-Type: application/json'
				);
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);	
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
				$result = curl_exec($ch);				
				if ($result === FALSE) {
					die('Curl failed: ' . curl_error($ch));
				}
				curl_close($ch);
				
				//return $result;
				if($result){
					return 1;
				}
				else
					return 0;
			}
			else
				return 0;
		
	}
	public function get_stroreid($apitoken){
	    $query=$this->db->query("SELECT * FROM `users` JOIN store ON users.userid=store.owner_id WHERE users.api_token='".$apitoken."'");
	    $resultes=$query->result();
	    return  $resultes[0]->id;
	}

}