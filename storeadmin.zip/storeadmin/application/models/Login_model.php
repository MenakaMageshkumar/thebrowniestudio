<?php

class Login_model extends CI_Model {

	public function _construct(){
		parent::_construct();
	}

	public function login($username, $password)	{
	     //seller or shopper // mobile no is login
       $phone = trim($username);
       $chk_storeuser_exists = $this->db->query("select phone_no from store_users where phone_no ='$phone'")->result();
       if($chk_storeuser_exists){
       $query1 = $this->db->query("Select id,name as username,phone_no as login_phone,name as display_name,''profile_image,3 as user_type,role_id,store_id,'' qrcode,''store_logo from store_users where phone_no ='$phone' and password ='$password' and user_status=1 ");//Store user login
       if($query1->num_rows() > 0 && !empty($query1)){
           $result = $query1->row();
           $store_id = $result->store_id;
           $get_qrcode = $this->db->query("select * from stores where store_id =$store_id ")->result();
           if($get_qrcode){
               $result->qrcode = $get_qrcode[0]->qrcode;
               $result->store_logo = $get_qrcode[0]->store_logo;
           }
     		return $result;
       }
       }
       // else store admin
       $password =md5($password);// for store admin md5 decrypt password match check
	   $query = $this->db->query("SELECT adminseller.*,seller.*,stores.qrcode,stores.store_logo FROM admin_users as adminseller INNER JOIN shopper as seller on adminseller.id = seller.shopper_id inner join stores ON stores.store_id = seller.store_id WHERE adminseller.user_type = 2 and trim(phone_no) = '$phone' and adminseller.password ='$password'");
		if($query->num_rows() > 0 && !empty($query)){
			$result = $query->row();
		} else {
			$result = 0;
		}
		return $result;
    }
}
?>