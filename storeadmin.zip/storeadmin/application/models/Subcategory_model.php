<?php 
class Subcategory_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	
    function updatesubcategory($subcat_id = '',$subcategory_data){
        // print_r($subcategory_data);die;
        $update_subcategory_data['maincategory_id'] = $subcategory_data['maincategory_id'];
        $update_subcategory_data['category_id'] = $subcategory_data['category_id'];
        $update_subcategory_data['subcategory_name'] = $subcategory_data['subcategory_name'];
        if(isset($subcategory_data['addto_popular']))
        {
           $update_subcategory_data['addto_popular'] =1;
        }
        else
        {
            $update_subcategory_data['addto_popular'] =0;
        }
        
        if(isset($subcategory_data['category_image_crop_file'])){
            $update_subcategory_data['image'] = substr($subcategory_data['category_image_crop_file'],6);
        }
        $store_id = $subcategory_data['store_id'];
        $update_subcategory_data['status'] = 1;
        $status = $this->db->update('sub_category',$update_subcategory_data,array('subcat_id'=>$subcat_id));
        //update products
        $cat = $this->db->query("select * from sub_category where subcat_id = $subcat_id and store_id = $store_id ")->result();
        $pro['maincat_id'] = isset($cat[0]->maincategory_id)?$cat[0]->maincategory_id:0;
        $pro['cat_id'] = isset($cat[0]->category_id)?$cat[0]->category_id:0;
        $pro['subcat_id'] = isset($cat[0]->subcat_id)?$cat[0]->subcat_id:0;
        $pro['cat_name']  = isset($cat[0]->subcategory_name)?$cat[0]->subcategory_name:''; 
        $pro['prod_status']  =1;
        $this->db->update('product',$pro,array('subcat_id'=>$subcat_id, 'store_id' =>$store_id));
        return ($status)?1:0;;
    }
    function createsubcategory($subcategory_data){
        // print_r($subcategory_data);die;
        $insert_subcategory_data['maincategory_id'] = $subcategory_data['maincategory_id'];
        $insert_subcategory_data['category_id'] = $subcategory_data['category_id'];
        $insert_subcategory_data['subcategory_name'] = $subcategory_data['subcategory_name'];
        $insert_subcategory_data['store_id'] = $subcategory_data['store_id'];
        if(isset($subcategory_data['addto_popular']))
        {
           $insert_subcategory_data['addto_popular'] =1;
        }
        else
        {
            $insert_subcategory_data['addto_popular'] =0;
        }
        
        if(isset($subcategory_data['category_image_crop_file'])){
            $insert_subcategory_data['image'] = substr($subcategory_data['category_image_crop_file'],6);
        }
        $insert_subcategory_data['status'] = 1;
        //   print_r($insert_subcategory_data);die;
        $status = $this->db->insert('sub_category',$insert_subcategory_data);
        return ($status)?1:0;;
    }

}
?>