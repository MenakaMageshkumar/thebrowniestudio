<?php 
class Location_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
function getstore_deliverylocation($store_id=''){
        $result = $this->db->query("SELECT stradd.str_addressid,area.area_locality,area.pincode,city.city_name,district.district,state.state,default_address FROM store_address stradd INNER JOIN area on stradd.area_id = area.id INNER JOIN city on stradd.city_id = city.id INNER JOIN district on district.district_id = stradd.district_id INNER JOIN state ON state.state_id = stradd.state_id WHERE stradd.store_id = $store_id ORDER BY default_address DESC")->result();
		if(empty($result)){return;}
		return $result;
	}
function getstore_deliverylocationdtl($store_id=''){
		$result = $this->db->query("SELECT stradd.str_addressid,stradd.area_id, area.area_locality,area.pincode,stradd.city_id,city.city_name,stradd.district_id,district.district,stradd.state_id,state.state,default_address FROM store_address stradd INNER JOIN area on stradd.area_id = area.id INNER JOIN city on stradd.city_id = city.id INNER JOIN district on district.district_id = stradd.district_id INNER JOIN state ON state.state_id = stradd.state_id WHERE stradd.store_id = $store_id")->result();
		if(empty($result)){return;}
		return $result;
	}
function deletelocation($str_addressid=''){	
    $result = $this->db->query("delete from store_address where str_addressid = $str_addressid and default_address=0");
    return $result;
}
function getstate(){	
    $result = $this->db->query("select * from state order by state_id")->result();
    return $result;
}
function getdistrict($state_id=''){	
    if($state_id!=''){
    $result = $this->db->query("select * from district  where state_id =$state_id ")->result();
    }else{
        $result = $this->db->query("select * from district ")->result();
    }
    return $result;
}

function getcity($district_id=''){	
    if($district_id!=''){
        $result = $this->db->query("select * from city where district_id =$district_id ")->result();
    }else{
        $result = $this->db->query("select * from city")->result();
    }
    return $result;
}
function getarea($city_id=''){	
    if($city_id!=''){
        $result = $this->db->query("select * from area where city_id =$city_id ")->result();
    }else{
        $result = $this->db->query("select * from area")->result();
    }
    return $result;
}
function updateLocation($data,$store_id=''){
    $area_cnt = count($data['area_id']);
    $area = $data['area_id'];
    $state_id = $data['state_id'];
    $district_id = $data['district_id'];
    $city_id = $data['city_id'];
    for($i=0;$i<$area_cnt;$i++){
        $area_id =$area[$i]; 
        $get_areapincode = $this->db->query("Select * from area where id = $area_id ")->result();
        $chk_exists = $this->db->query("select * from store_address where store_id = $store_id and state_id=$state_id and district_id = $district_id and city_id = $city_id and area_id = $area_id")->result();
        if(empty($chk_exists)){
        $insert['store_id'] = $store_id;
        $insert['state_id'] = $data['state_id'];
        $insert['district_id'] = $data['district_id'];
        $insert['city_id'] = $data['city_id'];
        $insert['area_id'] = $area_id;
        if($get_areapincode){
        $insert['pincode'] = $get_areapincode[0]->pincode;
        }else{
            $insert['pincode'] ='';
        }
        $insert['default_address'] = 0;
        $this->db->insert('store_address',$insert);
        }
        
    }
    
}	
	
}
?>