<?php 
class Product_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	
	public function createProduct($product_data = array(),$product_id){ //
	$prod_status  = 1; 
	$store_id = $product_data['store_id']; 
	//get brand id
    	$brand = $product_data['brand'];
     $chk_brand = $this->db->query("select * from brand where brand_name ='$brand' and store_id = $store_id ")->result();
     if($chk_brand){
         $brand_id =$chk_brand[0]->brand_id; 
     }else{
             $br_data['brand_name'] = $brand; 
    		  $br_data['store_id'] = $store_id; 
    		  $this->db->insert('brand',$br_data);
    		  $brand_id = $this->db->insert_id();
     }
     //get packtype id
     $pack_type = $product_data['type'];
     $pack_type_id = 0;
     $chk_typeid = $this->db->query("SELECT * FROM packettype_master WHERE type_name ='$pack_type'")->result();
     if($chk_typeid){
         $pack_type_id = $chk_typeid[0]->id;
     }
	//create/get sub category data
	    $category_name = trim($product_data['category_name']); 
		$chk_exists = $this->db->query("select * from sub_category where subcategory_name ='$category_name' and store_id = $store_id")->result();
		if($chk_exists){
		    $maincat_id = $chk_exists[0]->maincategory_id;
		    $cat_id = $chk_exists[0]->category_id;
		    $subcat_id = $chk_exists[0]->subcat_id;
		}
		else{
		    $cat_data['subcategory_name'] = trim($product_data['category_name']); 
		    $cat_data['store_id'] = $product_data['store_id']; 
		    $this->db->insert('sub_category',$cat_data); //insert sub_category if not exists
		    $cat_id =0; //after mapping cat & main cat ID will update automatically
		    $maincat_id = 0;
		    $subcat_id = $this->db->insert_id();
		    $prod_status  = 0;  //if cat not mapped then set that pproduct status as '0'
		}
	if(isset($product_data['add_varient'])){
	    $add_variant = $product_data['add_varient'];
	}else{
	    $add_variant = "NO";
	}
		//$prod_img1 = substr($product_data['product_image'],6); 
		if($product_data['product_image']){
		    $prod_img1 = substr($product_data['product_image'],6);  //    ../assets/uploads/category/1612348523_download_(2).jpg save as(
		}else{
		    $prod_img1 = '';
		}
		if($product_data['product_image_1']){
		    $prod_img2 = substr($product_data['product_image_1'],6);  //    ../assets/uploads/category/1612348523_download_(2).jpg save as(remove ../) assets/uploads/category/1612348523_download_(2).jpg
		}else{
		    $prod_img2 = '';
		}
		
		if($product_data['product_image_2']){
		    $prod_img3 = substr($product_data['product_image_2'],6); 
		}else{
		    $prod_img3 = '';
		}
		
		if($product_data['product_image_3']){
		    $prod_img4 = substr($product_data['product_image_3'],6); 
		}else{
		    $prod_img4 = '';
		}
		
		if($product_data['product_image_4']){
		    $prod_img5 = substr($product_data['product_image_4'],6); 
		}else{
		    $prod_img5 = '';
		}
    if(isset($product_data['primary_varient'])){
	    $pri_att = $product_data['primary_varient'];
	}else{
	    $pri_att = "";
	}
        $hsn_code = $product_data['HSN_code'];
        $cgst = $product_data['CGST'];
        $sgst = $product_data['SGST_IGST'];
        if(isset($product_data['image_type'])){
        	$image_type = $product_data['image_type'];
        }else{
        	$image_type =1; //GENERIC
        }
        if(isset($product_data['best_selling'])){
		    $best_selling = 1;
		}else{
		    $best_selling = 0;
		}
		$related_pro = implode(",",$product_data['related_pro']); 
	$data_product = array(
                                'prod_name' => $product_data['product_name'],
                                'brand_id' => $brand_id,
                                'description' => $product_data['description'],
                                'cat_name' => $category_name,
                                'maincat_id' => $maincat_id,
                                'cat_id' =>$cat_id,
                                'subcat_id' =>$subcat_id,
                                'packtype_id' => $pack_type_id,
                                'store_id' => $store_id,
                                'add_variant' => $add_variant,
                                'prod_img1'=>$prod_img1,
                                'prod_img2'=>$prod_img2,
                                'prod_img3'=>$prod_img3,
                                'prod_img4'=>$prod_img4,
                                'prod_img5'=>$prod_img5,
                                'pri_att' =>$pri_att,
                                'hsn_code' => $hsn_code,
                                'cgst' => $cgst,
                                'sgst' => $sgst,
                                'prod_status' =>$prod_status,
                                'prod_createddate' => date('Y-m-d H:i:s'),
                                'image_type' =>$image_type,
                                'best_selling'=>$best_selling,
                                'related_prod_ids'=>$related_pro
                            );
                            //INSERT INTO PRODUCT HEADER TABLE
                     $product = $this->Product_model->insert_data('product', $data_product);
                     $last_id=$this->db->insert_id();
                     $sequence_num = str_pad($last_id, 3, 0, STR_PAD_LEFT);
                     $pro_uid = "P".$sequence_num;
                     $update_data1['prod_uid'] = $pro_uid;
                     $status = $this->db->update('product',$update_data1,array('prod_id'=>$last_id));
               ////////////////////////Common
        $display_name =explode("|",$this->session->userdata['product']['display_name']);
        $sale_unit =explode("|",$this->session->userdata['product']['sale_unit']);
        $pack_content =explode("|",$this->session->userdata['product']['pack_content']);
        $mrp_price =explode("|",$this->session->userdata['product']['mrp_price']);
        $mop_price =explode("|",$this->session->userdata['product']['mop_price']);
        $offer_price =explode("|",$this->session->userdata['product']['offer_price']);
        $price_to_display =explode("|",$this->session->userdata['product']['price_to_display']);

		 if(strtoupper($pack_type)=='LOOSE'){ //loose product 
            		$display_stock = implode("|",$product_data['loose_display_stock']);
            		$stock_unit = implode("|",$product_data['loose_stock_unit']);
            		$total_available_stock = isset($product_data['loose_total_available_stock'])?$product_data['loose_total_available_stock']:'';
            	 	$moq= isset($product_data['loose_moq'])?$product_data['loose_moq']:'';
            		$stock_status = implode("|",$product_data['loose_stock_status']);
            		$att1 ='';$att2='';$att3='';$var1='';$var2='';$var3='';$pri_attcolor='';$item_image1='';$item_image2='';
		}
		else{ //variant wise stock
    		$exdisplay_stock =explode("|",$this->session->userdata['product']['display_stock']);
    		$exstock_unit  =explode("|",$this->session->userdata['product']['stock_unit']);
    		$extotal_available_stock =explode("|",$this->session->userdata['product']['total_available_stock']);
    		$exmoq =explode("|", $this->session->userdata['product']['moq']);
    		$exstock_status =explode("|", $this->session->userdata['product']['stock_status']);
    		$exattribute1 =explode("|", $this->session->userdata['product']['attribute1']);
    		$exattribute2 =explode("|", $this->session->userdata['product']['attribute2']);
    		$exattribute3 =explode("|", $this->session->userdata['product']['attribute3']);
    		$exvarient1 =explode("|", $this->session->userdata['product']['varient1']);
    		$exvarient2 =explode("|", $this->session->userdata['product']['varient2']);
    		$exvarient3 =explode("|", $this->session->userdata['product']['varient3']);
    		$expri_attcolor =explode("|", $this->session->userdata['product']['pri_attcolor']);
    		$exitem_image1 =  explode("|", $this->session->userdata['product']['item_image1']);
    		$exitem_image2 =  explode("|", $this->session->userdata['product']['item_image2']);
		}
      	if($sale_unit!=''){
		    $cnt = count($sale_unit);
	for($i=0;$i<$cnt;$i++){
		 $item_images =''; 
        if(strtoupper($pack_type)!='LOOSE'){
    		$display_stock = $exdisplay_stock[$i];
    		$stock_unit = $exstock_unit[$i];
    		$total_available_stock = isset($extotal_available_stock[$i])?$extotal_available_stock[$i]:0;
    		$moq = isset($exmoq[$i])?$exmoq[$i]:0;
    		$stock_status = $exstock_status[$i];
    		$att1 = isset($exattribute1[$i])?$exattribute1[$i]:'';
    		$att2 = isset($exattribute2[$i])?$exattribute2[$i]:'';
    		$att3 = isset($exattribute3[$i])?$exattribute3[$i]:'';
    		$var1 = isset($exvarient1[$i])?$exvarient1[$i]:'';
    		$var2 = isset($exvarient2[$i])?$exvarient2[$i]:'';
    		$var3 = isset($exvarient3[$i])?$exvarient3[$i]:'';
    		$pri_attcolor= isset($expri_attcolor[$i])?$expri_attcolor[$i]:'';
    		$item_image1= isset($exitem_image1[$i])?$exitem_image1[$i]:'';
    		$item_image2= isset($exitem_image2[$i])?$exitem_image2[$i]:'';
    		$item_images = $item_image1.'|'.$item_image2;		
		}
		
		        ///PRODUCT ITEM TABLE
$data_productitemdtl = array(
                                'prod_id' => $last_id,
                                'display_name' => $display_name[$i],
                                'sale_unit' => $sale_unit[$i],
                                'pack_content' => $pack_content[$i],
                                'att1' => $att1,
                                'att2' => $att2,
                                'att3' => $att3,
                                'var1' => $var1,
                                'var2' => $var2,
                                'var3' => $var3,
                                'pri_attcolor'=>$pri_attcolor,
                                'mrp_price' => $mrp_price[$i],
                                'mop_price' => $mop_price[$i],
                                'offer_price' => $offer_price[$i],
                                'price_to_display' => $price_to_display[$i],
                                'display_stock' => $display_stock,
                                'stock_unit' => $stock_unit,
                                'item_totstock' => $total_available_stock,
                                'item_moq' => $moq,
                                'item_stocksts' => 1,
                                'item_availability' => 1,
                                'item_images' => trim($item_images,"|")

                            );
        $product_itemdtl = $this->Product_model->insert_data('product_itemdtl', $data_productitemdtl);
        $item_id = $this->db->insert_id();
        $item_uid = 'ITM'.str_pad($item_id, 3, '0', STR_PAD_LEFT);
            $upd_data['item_uid'] = $item_uid;
            $status = $this->db->update('product_itemdtl',$upd_data,array('prod_itemid'=>$item_id));

		    }
		}
		$this->session->set_userdata('product','');
		
		 //update attibute_ids in store table 
      $str_att = $this->db->query("select * from stores where store_id = $store_id")->result();
      $attribute_ids = $str_att[0]->attribute_ids;
      $attribute1 = $data['attribute1']  ;
      if($attribute1!=''){
      if($attribute_ids!='' ){
     $ary =  explode(',',$attribute_ids);
          if (in_array("$attribute1", $ary))
              {
              //attribute name exists
              }
              else{
                   $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute_ids.','.$attribute1);
                   $this->Product_model->update_data('stores', $value_data, $where);
              }
     
      }
        else{
          $where = array('store_id'=>$store_id);
                   $value_data = array('attribute_ids' => $attribute1);
                   $this->Product_model->update_data('stores', $value_data, $where);
      }
      }
		return $status;
	
	    
	}
	
	function getProduct($store_id=''){//
		
		$result = $this->db->query("SELECT PRD.prod_id,PRD.prod_name, PRD.prod_img1,PRD.cat_name,PRD.prod_status  FROM product as PRD 
									join stores as ST on ST.store_id=$store_id
									where PRD.store_id=$store_id group by PRD.prod_id order by PRD.prod_id desc" );
		if(empty($result)){return;}
		return $result->result();
		
	}
	public function getProudctDetailsData($product_id='',$product_name = '',$brand ='',$category_name ='',$pack_type ='',$store_id =''){ //
	    //echo '<pre>';print_r($product_id);die;
	    if($product_id){
	       	$result =$this->db->query("SELECT PRD.*
    		FROM products AS PRD
    		WHERE PRD.product_id=$product_id");
    		return $val=$result->row(); 
	    }
	    
	    if($product_name && $brand && $category_name && $pack_type){
	       	$result =$this->db->query("SELECT PRD.*
    		FROM products_process AS PRD
    		WHERE PRD.product_name='$product_name' AND PRD.brand='$brand' AND PRD.category_name='$category_name' AND PRD.type='$pack_type' AND PRD.store_id='$store_id'");
    		return $val=$result->row(); 
	    }
	
		
	}
	public function chkProudctExists($product_name = '',$brand_id =0,$subcat_id =0,$pack_type_id =0,$store_id =0){
	       	$result =$this->db->query("SELECT * FROM product_process AS PRD
    		WHERE PRD.prod_name='$product_name' AND PRD.brand_id='$brand_id' AND PRD.subcat_id='$subcat_id' AND PRD.packtype_id='$pack_type_id' AND PRD.store_id='$store_id'");
    		return $val=$result->row(); 
	}
	function changeStatus($product_id){ //
	    $status = 0;
		if(empty($product_id)){
			return 0;
		}
		$status = $this->db->update('products',array('status'=>$status), array('product_id'=>$product_id));
		return $status;
	}
	
	function changeproduct_availstatus($data){ //
	    $availability = 0;
	    $availability = $data['availability'];
	    $product_id = $data['product_id'];
		$status = $this->db->update('products',array('availability'=>$availability), array('product_id'=>$product_id));
		return $status;
	}
	function updateProduct($product_id = '', $product_data = array()){ //
	    if(empty($product_id) || empty($product_data)){
			return 0;
		}
	
		$product_img = $this->getProduct_dtl($product_id);
   $store_id = $product_data['store_id']; 
	//get brand id
    	$brand = $product_data['brand'];
     $chk_brand = $this->db->query("select * from brand where brand_name ='$brand' and store_id = $store_id ")->result();
     if($chk_brand){
         $brand_id =$chk_brand[0]->brand_id; 
     }else{
             $br_data['brand_name'] = $brand; 
    		  $br_data['store_id'] = $store_id; 
    		  $this->db->insert('brand',$br_data);
    		  $brand_id = $this->db->insert_id();
     }
    if(isset($product_data['add_varient'])){
	    $add_variant = $product_data['add_varient'];
	}else{
	    $add_variant = "NO";
	}
		if($product_data['product_image']){
		    $prod_img1 = substr($product_data['product_image'],6);  //    ../assets/uploads/category/1612348523_download_(2).jpg save as(remove ../) assets/uploads/category/1612348523_download_(2).jpg
		}else{
		    $prod_img1 = $product_img->prod_img1;
		} 
		if($product_data['product_image_1']){
		    $prod_img2 = substr($product_data['product_image_1'],6);  //    ../assets/uploads/category/1612348523_download_(2).jpg save as(remove ../) assets/uploads/category/1612348523_download_(2).jpg
		}else{
		    $prod_img2 = $product_img->prod_img2;
		}
		
		if($product_data['product_image_2']){
		    $prod_img3 = substr($product_data['product_image_2'],6); 
		}else{
		    $prod_img3 = $product_img->prod_img3;
		}
		
		if($product_data['product_image_3']){
		    $prod_img4 = substr($product_data['product_image_3'],6); 
		}else{
		    $prod_img4 = $product_img->prod_img4;
		}
		
		if($product_data['product_image_4']){
		    $prod_img5 = substr($product_data['product_image_4'],6); 
		}else{
		    $prod_img5 = $product_img->prod_img5;
		}
    if(isset($product_data['primary_varient'])){
	    $pri_att = $product_data['primary_varient'];
	}else{
	    $pri_att = "";
	}
        $hsn_code = $product_data['HSN_code'];
        $cgst = $product_data['CGST'];
        $sgst = $product_data['SGST_IGST'];
        if(isset($product_data['best_selling'])){
		    $best_selling = 1;
		}else{
		    $best_selling = 0;
		}
		$related_pro = implode(",",$product_data['related_pro']); 
	$data_product = array(
                                'prod_name' => $product_data['product_name'],
                                'brand_id' => $brand_id,
                                'description' => $product_data['description'],
                                'add_variant' => $add_variant,
                                'prod_img1'=>$prod_img1,
                                'prod_img2'=>$prod_img2,
                                'prod_img3'=>$prod_img3,
                                'prod_img4'=>$prod_img4,
                                'prod_img5'=>$prod_img5,
                                'pri_att' =>$pri_att,
                                'hsn_code' => $hsn_code,
                                'cgst' => $cgst,
                                'sgst' => $sgst,
                                'best_selling' => $best_selling,
                                'related_prod_ids'=>$related_pro
                            );
		$status = $this->db->update('product',$data_product,array('prod_id'=>$product_id));
		return ($status)?1:0;
	}
	function get_product_data($product_id,$view_all = 0){ //
		$cond = ($view_all != 0)?' PRD.status IN (0,1) ':' PRD.status IN (1) ';
		$cond .= (!empty($product_id))?" AND PRD.product_id = '$product_id[product_id]'":"";
		$result = $this->db->query("SELECT PRD.*,CG.category_name,ST.store_name
								FROM products AS PRD
								LEFT JOIN categories AS CG ON (PRD.category_id=CG.category_id AND CG.status='1')
								LEFT JOIN stores AS ST ON (PRD.store_id=ST.store_id AND ST.status='1') WHERE $cond");
		$val=$result->result();
		//print_r($this->db->last_query());exit;
		//print_r($val);exit;
		if(empty($val)){
			return;
		}
		return (empty($product_id))?$result->result():$result->row();
	}
	function getProduct_dtl($product_id){ //
	    $result = $this->db->query("SELECT pro.related_prod_ids,pro.best_selling,pro.store_id,pro.prod_id,pro.prod_name,brand.brand_name,pro.description,pro.cat_name,ptype.id typeid,ptype.type_name,pro.add_variant,pro.pri_att,pro.hsn_code,pro.cgst,pro.sgst,pro.prod_img1,prod_img2,prod_img3,prod_img4,prod_img5 FROM product pro  inner JOIN brand ON brand.brand_id = pro.brand_id inner JOIN packettype_master ptype ON pro.packtype_id = ptype.id WHERE pro.prod_id = $product_id")->result();
	    if($result){
		$productData = $result[0];
			return $productData;
	    }
	    else{
	        return 0;
	    }
	}
	function getpro_itemdtl($product_id){
	    $result = $this->db->query("SELECT prod_itemid,prodtl.pack_content,slunit.unit sale_unit,atts1.attribute_name attri1,atts2.attribute_name attri2,atts3.attribute_name attri3,var1,var2,var3,prodtl.mrp_price,mop_price,offer_price,skunit.unit stock_unit, prodtl.item_totstock,prodtl.item_moq,item_stocksts,prodtl.item_availability FROM product_itemdtl prodtl INNER JOIN product_units slunit ON prodtl.sale_unit = slunit.id INNER JOIN product_units skunit ON skunit.id = prodtl.stock_unit LEFT JOIN attributes atts1 ON atts1.id = prodtl.att1 LEFT JOIN attributes atts2 ON atts2.id = prodtl.att2 LEFT JOIN attributes atts3 ON atts3.id = prodtl.att3 WHERE prod_id = $product_id")->result();
	    return $result;
	}
	
		function insert_data($table,$data) {
        //echo '<pre>';print_r($data);die;
       
        $sql = $this->db->insert_string($table,$data);
        $this->db->query($sql);
        $last_id = $this->db->insert_id();
        return $last_id;
        
    }
    
    function update_data($table,$data,$where) 
    {
        
        $this->db->where($where);
        $this->db->update($table,$data);
        return $this->db->affected_rows();
        
        
    }
     public function process_product($store_id){
        $process_data = $this->db->query("select * from product_process where process_status = 0 and store_id = $store_id order by prod_id")->result();
        return $process_data;
    }
     public function processed_product(){
        $processed_data = $this->db->query("select * from product_process where process_status = 1   order by prod_id")->result();
        return $processed_data;
    }
    function unprocessed_product(){ //unprocessed and processed wrong entry data //
        $qry = $this->db->query("SELECT pro.prod_name, str.store_name,brand.brand_name,pro.description,pro.cat_name,ptype.type_name,pro.process_status FROM product_process pro INNER JOIN stores str ON str.store_id = pro.store_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN  packettype_master ptype ON ptype.id = pro.packtype_id where process_status in (0,2,3)")->result();
        if($qry){
            return $qry;
        }else{
            return false;
        }
    }
    public function getStores($store_id=''){ //
         if($store_id!=''){
        $store_list = $this->db->query("select * from stores where status = 1 and store_id = $store_id  order by store_name")->result();
         }else{
        $store_list = $this->db->query("select * from stores where status = 1 order by store_name")->result();     
         }
        return $store_list;
    }
    	public function getallStores($store_id=''){
		if(!empty($store_id)){
			$result = $this->db->query("SELECT stores.* FROM stores WHERE store_id=$store_id");
			return $result->result();
		}
	}
}
?>