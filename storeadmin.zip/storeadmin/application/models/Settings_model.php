<?php 
class Settings_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	function getPackingCharges($seller_id=''){
	    $result = $this->db->query("select str.store_id , slr.id seller_id,str.packing_charges,str.pc_type,str.pc_perc,str.pc_unit_value from stores str inner join shopper slr on str.store_id = slr.store_id where slr.id =$seller_id")->result();
	    if($result){
	        return $result;
	    }else{
	        return false;
	    }
	    }
	    function getstoredelprep($store_id=''){
	        $result = $this->db->query("select store_id,del_time,prep_time from stores where store_id = $store_id")->result();
	        return $result;
	    }
	    
	    
	function update_package($seller_id = '', $data = array()){
	   // print_r($data);die;
            if($data['packing_charges']==0) //Disable
            {
                $update_data['packing_charges'] = $data['packing_charges'];
            }
            else //enable
            {
                $update_data['packing_charges'] = $data['packing_charges'];
                $update_data['pc_type'] = $data['pc_type'];
                if($data['pc_type']==0){ //packing charge in percentage
                $update_data['pc_perc'] = $data['pc_perc'];
                }else{ //pc unitwise
                $update_data['pc_unit_value'] = $data['pc_unit_value'];
                }
            }
	    $seller_id = $data['seller_id'];
	    $getstrid = $this->db->query("select * from shopper where id = $seller_id")->result();
	    if($getstrid){
	        $store_id = $getstrid[0]->store_id;
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;
	    }else {
	        return 0;
	    }
	    
	}
		function getDeliveryCharges($seller_id=''){
	    $result = $this->db->query("select str.store_id , slr.id seller_id,str.delivery_charges,str.min_dc,str.delivery_note,str.dc_freekm,str.dc_perkm from stores str inner join shopper slr on str.store_id = slr.store_id where slr.id =$seller_id")->result();
	    if($result){
	        return $result;
	    }else{
	        return false;
	    }
	    }
	    
	    function update_storesettings($store_id = '', $data = array()){
                $update_data['del_time'] = $data['del_type'].'|'.$data['del_value'];
                $update_data['prep_time'] = $data['prep_type'].'|'.$data['prep_value'];
                if($store_id){
        	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
        		return ($status)?1:0;
        	    }else {
        	        return 0;
        	    }
	    
	}
function update_delivery($seller_id = '', $data = array()){
    if($data['delivery_charges']==0){ //disable
	    $update_data['delivery_charges'] = $data['delivery_charges'];
    }else{ //enable
        $update_data['delivery_charges'] = $data['delivery_charges'];
	    $update_data['dc_freekm'] = $data['dc_freekm'];
	    $update_data['dc_perkm'] = $data['dc_perkm'];
	    $update_data['min_dc'] = $data['min_dc'];
	    $update_data['delivery_note'] = $data['delivery_note'];
    }
	    $seller_id = $data['seller_id'];
	    $getstrid = $this->db->query("select * from shopper where id = $seller_id")->result();
	    if($getstrid){
	        $store_id = $getstrid[0]->store_id;
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;
	    }else {
	        return 0;
	    }
	    
	}
	function updateContent($data ,$content_id = ''){
	    $update_data['menu'] = $data['menu'];
	    $update_data['sub_menu'] = $data['sub_menu'];
	    $update_data['content'] = $data['content'];
	    $status = $this->db->update('website_content',$update_data,array('id'=>$content_id));
		return ($status)?1:0;
	    
	}
	
	function update_appscreen($seller_id = '', $data = array()){
	    $seller_id = $data['seller_id'];
	    $image1 = $data['image1'];
	    $image2 = $data['image2'];
	    $image3 = $data['image3'];
	    $image4 = $data['image4'];
	    $image5 = $data['image5'];
	    $image6 = $data['image6'];
	    $str = $this->db->query("select str.store_id,add_appscreen,add_appdescription from stores str inner join shopper slr on str.store_id = slr.store_id where slr.id = $seller_id ")->result();
	    $scrn = $str[0]->add_appscreen;
	    $store_id = $str[0]->store_id;
	    if($scrn){
	        $screens = explode('|',$scrn);
	        if($image1==''){
	        if(isset($screens[0])  && !empty($screens[0]) ){
	            $image1= $screens[0];
	        }}else{
	            $image1 = substr($image1,3); //    ../assets/uploads/category/1612348523_download_(2).jpg save as(remove ../) assets/uploads/category/1612348523_download_(2).jpg
	        }
	        if($image2==''){
	        if(isset($screens[1])  && !empty($screens[1]) ){
	            $image2= $screens[1];
	        }}
	        else{
	            $image2 = substr($image2,3); 
	        }
	        if($image3==''){
	        if(isset($screens[2])  && !empty($screens[2]) ){
	            $image3= $screens[2];
	        }}else{
	            $image3 = substr($image3,3); 
	        }
	        if($image4==''){
	        if(isset($screens[3])  && !empty($screens[3]) ){
	            $image4= $screens[3];
	        }}
	        else{
	            $image4 = substr($image4,3); 
	        }
	        if($image5==''){
	        if(isset($screens[4])  && !empty($screens[4]) ){
	            $image5= $screens[4];
	        }}else{
	            $image5 = substr($image5,3); 
	        }
	        if($image6==''){
	        if(isset($screens[5])  && !empty($screens[5]) ){
	            $image6= $screens[5];
	        }}
	        else{
	            $image6 = substr($image6,3); 
	        }
	    }
	    $update['add_appscreen'] = $image1.'|'.$image2.'|'.$image3.'|'.$image4.'|'.$image5.'|'.$image6;
	    $update['add_appdescription'] = $data['add_appdescription'];
	    $status = $this->db->update('stores',$update,array('store_id'=>$store_id));
		return ($status)?1:0;
	}
	function update_deliverytype($store_id = '', $data = array()){
	    $update_data['store_delivery_type'] = $data['store_delivery_type'];
	    $store_id = $data['store_id'];
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;
	}
	
	function update_storelocation($store_id = '', $data = array()){
	    $update_data['store_maplocation'] = $data['store_maplocation'];
	    $store_id = $data['store_id'];
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;
	}
	function getinvoiceformat($store_id=''){
	    $status = $this->db->query("select invoice_format from stores where store_id = $store_id ")->result();
	    return $status;
	}
	function update_invoiceformat($store_id = '', $data = array()){
        $update_data['invoice_format'] = $data['invoice_format'];
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;

	}
	function update_theme($store_id = '', $data = array()){
        $update_data['theme_color'] = $data['theme_color'];
        $update_data['font_color'] = $data['font_color'];
	    $store_id = $data['store_id'];
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;
	}
	function changecomment_status($data){ 
	    $view_status = $data['view_status'];
	    $id = $data['id'];
		$status = $this->db->update('user_reviews',array('view_status'=>$view_status), array('id'=>$id));
		return $status;
	}
}

?>