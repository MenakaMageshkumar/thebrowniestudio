<?php 
class Role_model extends CI_Model {
    
    public function _consruct(){
        parent::_construct();
        
    }
    function create_storeuser($data){ 
        $phone_no = trim($data['phone_no']);
        $contact_exists = $this->db->query("Select * from store_users where phone_no = '$phone_no'")->result(); //check store user table if same contact exists
        if($contact_exists){
            return 2;
        }
        $chk_seller = $this->db->query("select * from shopper seller where phone_no  = '$phone_no'")->result(); // check store/seller table if same contact exists
            if($chk_seller){
            return 2;
            }
        $insert_data['name'] = $data['name'];
        $insert_data['phone_no'] = $data['phone_no'];
        $insert_data['mail_address'] = $data['mail_address'];
        $insert_data['password'] = $data['password'];
        $insert_data['store_id'] = $data['store_id'];
        if(isset($data['role_id'])){
        $insert_data['role_id'] = $data['role_id'];
        }
        $status = $this->db->insert('store_users',$insert_data);
        
        if($status){
            return $status;
        }else{
            return false;
        }
    }
    function create_role($data){
        $role_name = trim($data['role_name']);
        $store_id = $data['store_id'];
        $role_exists = $this->db->query("Select * from roles where role_name = '$role_name' and store_id = $store_id")->result();
        if($role_exists){
            return 2;
        }
        $insert_data['role_name'] = $data['role_name'];
        $insert_data['roles_assigned'] = implode(',',$data['roles_assigned']);
        $insert_data['store_id'] = $data['store_id'];
        $status = $this->db->insert('roles',$insert_data);
        
        if($status){
            return $status;
        }else{
            return false;
        }
    }
    function get_storeuserdata($store_id){
        // $result = $this->db->query("Select * from store_users where store_id =$store_id ")->result();
         $result = $this->db->query("Select struser.id,struser.name,struser.phone_no,struser.mail_address,roles.role_name,struser.user_status from store_users struser INNER JOIN roles ON struser.role_id = roles.id  AND struser.store_id =  roles.store_id WHERE struser.store_id = $store_id ")->result();
        return $result;
    }
     function get_storeroles($store_id){
        $result = $this->db->query("Select * from roles where store_id =$store_id ")->result();
        return $result;
    }
    
    function update_storeuser($data){
        $phone_no = trim($data['phone_no']);
        $id = $data['id'];
        $contact_exists = $this->db->query("Select * from store_users where phone_no = '$phone_no' and id != $id")->result();
            if($contact_exists){
              return 2;  
            }
        $chk_seller = $this->db->query("select * from shopper seller where phone_no  = '$phone_no'")->result(); // check store/seller table if same contact exists
            if($chk_seller){
            return 2;
            }
        $update['name'] = $data['name'];
        $update['phone_no'] = $data['phone_no'];
        $update['mail_address'] = $data['mail_address'];
        $update['password'] = $data['password'];
        if(isset($data['role_id'])){
        $update['role_id'] = $data['role_id'];
        }
        $status = $this->db->update('store_users',$update,array('id'=>$id));
        if($status){
           return 1;    
        }else{
            return 0;
        }
        
    }
    function update_roles($data){
        $id = $data['role_id'];
        $update['role_name'] = $data['role_name'];
        $roles_assigned = $data['roles_assigned'];
        $update['roles_assigned'] = implode(',',$roles_assigned);
        $status = $this->db->update('roles',$update,array('id'=>$id));
        if($status){
           return 1;    
        }else{
            return 0;
        }
        
    }
    function changeStatus($id = '', $status = '0'){
        if(empty($id)){
            return 0;
        }
        $status = $this->db->update('store_users',array('user_status'=>$status), array('id'=>$id));
        return $status;
    }
}