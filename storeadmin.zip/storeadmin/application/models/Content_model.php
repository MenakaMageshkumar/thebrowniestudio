<?php 
class Content_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	function updateContent($data){
	    $store_id =$data['store_id'];
	    if(isset($data['app_terms_conditions'])){
	    $update_data['app_terms_conditions'] = $data['app_terms_conditions'];    
	    }
	    if(isset($data['app_contact_us'])){
	    $update_data['app_contact_us'] = $data['app_contact_us'];    
	    }
	    $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
		return ($status)?1:0;
	    
	}

}
?>