<?php 
class Customer_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	function updateCustomer($data,$user_id){
	    $update_data['fullname'] = $data['fullname'];    
	    $update_data['phone_no'] = $data['phone_no'];    
	    $update_data['email'] = $data['email'];    
	    $status = $this->db->update('user_profile',$update_data,array('user_id'=>$user_id));
		return ($status)?1:0;
	}

}
?>