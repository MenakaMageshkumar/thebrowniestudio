<?php 
class Coupon_model extends CI_Model {
    
    public function _consruct(){
        parent::_construct();
    }
    // GET COUPON DATA
        function get_coupon(){
        $result = $this->db->query("SELECT * FROM yms_offercoupon order by yms_offercoupon.id DESC");
        $val=$result->result();
        if(empty($val)){
            return;
        }
        return (empty($coupon_id))?$result->result():$result->row();
    }
    // Get STORE DATA
    
   function get_store(){
        $result = $this->db->query("Select store_id, store_name from stores  ");
        $val=$result->result();
        if(empty($val)){
            return;
        }
        return (empty($coupon_id))?$result->result():$result->row();
    }
    
    
    // 	create coupon
	function savecoupon($coupon_data = array())
	{ 
	   // print_r($coupon_data);
	   // die;
	    $insert_data['offer_image']=substr($coupon_data['offer_image'],3);
	    $insert_data['title'] =$coupon_data['cp_title'];
	    $insert_data['offer_code'] =$coupon_data['cp_offer_code'];
	    $insert_data['terms_conds'] =$coupon_data['cp_terms_condition'];
	    $insert_data['rule_type'] =$coupon_data['cp_rule_type'];
	    $insert_data['client_id '] =0;
	    $insert_data['applicable_str '] ="";
	    $insert_data['rule_value'] =$coupon_data['rule_value'];
	    $insert_data['condition_chkvalue'] =$coupon_data['cp_condition'];
	   // $insert_data['validity_from'] =$coupon_data['cp_valid_from'];
	    $date_from = $coupon_data['cp_valid_from'];
        $insert_data['validity_from'] = date("Y-m-d", strtotime($date_from));
        
	   // $insert_data['validity_to'] =$coupon_data['cp_valid_to'];
	    $date_from = $coupon_data['cp_valid_to'];
        $insert_data['validity_to'] = date("Y-m-d", strtotime($date_from));
	    
	    $insert_data['offer_usage'] =$coupon_data['cp_offer_usage'];
	    $insert_data['store_id '] =$coupon_data['store_id'];
        $status = $this->db->insert('yms_offercoupon',$insert_data);
        // $res = array('status'=>1,'data'=>'');
        return ($status)?1:0;;
    }
// update coupon
    function updatecoupon($id = '',$coupon_data)
    {
        // print_r($coupon_data);
        if(isset($coupon_data['offer_image']))
        {
            $update_data['offer_image']=substr($coupon_data['offer_image'],3); //    ../assets/uploads/category/1612348523_download_(2).jpg save as(remove ../) assets/uploads/category/1612348523_download_(2).jpg
        }
	    $update_data['title'] =$coupon_data['cp_title'];
	    $update_data['offer_code'] =$coupon_data['cp_offer_code'];
	    $update_data['terms_conds'] =$coupon_data['cp_terms_condition'];
	    $update_data['rule_type'] =$coupon_data['cp_rule_type'];
	    $update_data['client_id '] =0;
	    $update_data['applicable_str '] ="";
	    $update_data['rule_value'] =$coupon_data['rule_value'];
	    $update_data['condition_chkvalue'] =$coupon_data['cp_condition'];
	   // $update_data['validity_from'] =$coupon_data['cp_valid_from'];
	    $date_from = $coupon_data['cp_valid_from'];
        $update_data['validity_from'] = date("Y-m-d", strtotime($date_from));
	   // $update_data['validity_to'] =$coupon_data['cp_valid_to'];
	    $date_to = $coupon_data['cp_valid_to'];
        $update_data['validity_to'] = date("Y-m-d", strtotime($date_to));
	    $update_data['offer_usage'] =$coupon_data['cp_offer_usage'];
	    $update_data['store_id '] =$coupon_data['store_id'];
	     
	   //  print_r($update_data); die;
        $status = $this->db->update('yms_offercoupon',$update_data,array('id'=>$id));
        return ($status)?1:0;;
    }
   // delete coupon
    function deletecoupon($id = '')
    {
	    $id = $id;
        $status = $this->db->delete('yms_offercoupon',array('id'=>$id));
        return ($status)?1:0;;
    }
   
  

}
?>