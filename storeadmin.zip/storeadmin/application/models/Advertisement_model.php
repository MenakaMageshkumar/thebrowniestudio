<?php 
class Advertisement_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	
	public function update_Advertisement($store_id,$data){
	    $get_banner = $this->db->query("select strweb_banners from stores where store_id = $store_id")->result();
	    if($get_banner){
	        $banner_array = explode('|',$get_banner[0]->strweb_banners);
	    }
	    $banner1 ='';$banner2='';$banner3='';
	    if(isset($data['banner_1'])){
		    $banner1 = substr($data['banner_1'],6); 
		}else{
		    if(isset($banner_array[0])){
		       $banner1 =  $banner_array[0];
		    }
		}
		
		if(isset($data['banner_2'])){
		    $banner2 = substr($data['banner_2'],6); 
		}else{
		    if(isset($banner_array[1])){
		       $banner2 =  $banner_array[1];
		    }
		}
		
		if(isset($data['banner_3'])){
		    $banner3 = substr($data['banner_3'],6); 
		}else{
		    if(isset($banner_array[2])){
		       $banner3 =  $banner_array[2];
		    }
		}
		if(isset($data['banner_1']) || isset($data['banner_2'])  || isset($data['banner_3'])){
		    $updatedata['strweb_banners'] =  $banner1.'|'.$banner2.'|'.$banner3;
            $status = $this->db->update('stores',$updatedata,array('store_id'=>$store_id));
         $status = 1;
        }else{
		 $status = 2;
		}
        return $status; 
	}

}
?>