<?php 
class Brand_model extends CI_Model {
	
	public function _consruct(){
		parent::_construct();
	}
	
	 function updatebrand($brand_id = '',$brand_data){
        // print_r($brand_data);die;
       
        $update_brand_data['brand_name'] = $brand_data['brand_name'];
          $update_brand_data['brand_desc'] = $brand_data['brand_desc'];
        if(isset($brand_data['top_brand']))
        {
           $update_brand_data['top_brand'] =1;
        }
        else
        {
            $update_brand_data['top_brand'] =0;
        }
        
        if(isset($brand_data['brand_image_crop_file'])){
            $update_brand_data['brand_image'] = substr($brand_data['brand_image_crop_file'],6);
        }
        $store_id = $brand_data['store_id'];
       
        $status = $this->db->update('brand',$update_brand_data,array('brand_id'=>$brand_id));
        return ($status)?1:0;;
    }
    function createbrand($brand_data){
        // print_r($brand_data);die;
        $insert_brand_data['brand_name'] = $brand_data['brand_name'];
        $insert_brand_data['brand_desc'] = $brand_data['brand_desc'];
        $insert_brand_data['store_id'] = $brand_data['store_id'];
        if(isset($brand_data['top_brand']))
        {
           $insert_brand_data['top_brand'] =1;
        }
        else
        {
            $insert_brand_data['top_brand'] =0;
        }
        
        if(isset($brand_data['brand_image_crop_file'])){
            $insert_brand_data['brand_image'] = substr($brand_data['brand_image_crop_file'],6);
        }

        //   print_r($insert_brand_data);die;
        $status = $this->db->insert('brand',$insert_brand_data);
        return ($status)?1:0;;
    }



}
?>