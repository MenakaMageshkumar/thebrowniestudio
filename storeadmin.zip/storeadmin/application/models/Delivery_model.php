<?php 
class Delivery_model extends CI_Model {
    
    public function _consruct(){
        parent::_construct();
    }
    function get_deliveryprofiles($seller_id){
         $result = $this->db->query("SELECT dp.deli_boy_id,dp.store_id,dp.seller_id,dp.deli_profile_image,dp.deli_name,dp.deli_phone,dp.deli_vehicle,dp.active_status FROM delivery_persondtl dp WHERE seller_id = $seller_id order by deli_boy_id");
         $val=$result->result();
        if(empty($val)){
            return;
        }
        return $val;
    }
    function updateprofile($deli_boy_id = '',$data){
         $deli_phone = $data['deli_phone'];
        $chk_exists = $this->db->query("select * from delivery_persondtl where deli_phone ='$deli_phone' and deli_boy_id != $deli_boy_id ")->result();
        if($chk_exists)
       {
           $status = 2;
        return $status;   
       }
       
       if(isset($data['deli_profile_image'])){
		    $data['deli_profile_image'] = substr($data['deli_profile_image'],3);  //    ../assets/uploads/category/1612348523_download_(2).jpg save as(remove ../) assets/uploads/category/1612348523_download_(2).jpg
		}
        $status = $this->db->update('delivery_persondtl',$data,array('deli_boy_id'=>$deli_boy_id));
        $deli_by_ids = '';
        $getseller= $this->db->query("select * from delivery_persondtl where deli_boy_id = $deli_boy_id ")->result();
        $seller_id = $getseller[0]->seller_id;
        $delboys_list = $this->db->query("select * from delivery_persondtl where seller_id =$seller_id")->result();
        if($delboys_list){
            foreach($delboys_list as $dt){
                if($deli_by_ids==''){
                   $deli_by_ids = $dt->deli_boy_id;     
                }else{
                   $deli_by_ids = $deli_by_ids.','.$dt->deli_boy_id; 
                }
            }
            $update['deli_by_ids'] = $deli_by_ids;
            $status = $this->db->update('shopper',$update,array('id'=>$seller_id));
        }
        return ($status)?1:0;;
    }
     function createdelprofile($data){ 
        $seller_id = $data['seller_id'];
          $deli_phone = $data['deli_phone'];
        $chk_exists = $this->db->query("select * from delivery_persondtl where deli_phone ='$deli_phone'")->result();
        if($chk_exists)
       {
           $status = 2;
        return $status; 
       }
       
       if(isset($data['deli_profile_image'])){
		    $data['deli_profile_image'] = substr($data['deli_profile_image'],3);  //  (remove ../) 
		}
        $status = $this->db->insert('delivery_persondtl',$data);
        $deli_by_ids = '';
        $delboys_list = $this->db->query("select * from delivery_persondtl where seller_id =$seller_id")->result();
        if($delboys_list){
            foreach($delboys_list as $dt){
                if($deli_by_ids==''){
                   $deli_by_ids = $dt->deli_boy_id;     
                }else{
                   $deli_by_ids = $deli_by_ids.','.$dt->deli_boy_id; 
                }
            }
            $update['deli_by_ids'] = $deli_by_ids;
            $status = $this->db->update('shopper',$update,array('id'=>$seller_id));
        }
        return ($status)?1:0;;
    }
    function changeStatus($deli_boy_id = '', $status = '0'){
        if(empty($deli_boy_id)){
            return 0;
        }
        $status = $this->db->update('delivery_persondtl',array('active_status'=>$status), array('deli_boy_id'=>$deli_boy_id));
        return $status;
    }
}