<?php

function send_push_notification($device_id,$message){

    //API URL of FCM
    $url = 'https://fcm.googleapis.com/fcm/send';

    /*api_key available in:
    Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    
    //$api_key = 'AAAASg_pmn4:APA91bHCx2c_vKU2njTUI7Y1gs8GTGIKOeD_4kaGCAyU6UDk8o-u06C5GCNBcK0x_oFjMktflOvXIeFdz8oYEie_6e1B4fA0XTff8cUqtKT1yj-gCnpJYePUAzE0Q4y26CZDuwdHBQXY';
    $api_key = 'AAAAllnPR3Y:APA91bGtrcPZwP_84CvbyaPObSA4fJ3vDVHeZhnLAO_KHa4OeUinPI2oELLEPzNEB8MOd4pnbRSOtW6oTqg9O-bCvG3nfoq98ULlBnNEpYcwajs4_48R6QoRcqAQ3aSLzmOHIDNhdSzQ';
                
    $fields = array (
        'registration_ids' => array (
                $device_id
        ),
        
        'notification' => array(
                "title" => $message['title'],
                "body"=>$message['message'],
                // "sound"=>"default",
                'sound' => "notification",
                'android_channel_id' => "Global",
                "badge" =>"1"
                ),
        
        'data' => array (
                "action" => $message['action'],
                "message"=>$message['message'],
                "title"=>$message['title']
               )
        
    );
    
    
    //print_r($fields);die;
    
    
    
    //header includes Content type and api key
    $headers = array(
        'Content-Type:application/json',
        'Authorization:key='.$api_key
    );
                
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
    return $result;
}

function seller_send_push_notification($device_id,$message){

    //API URL of FCM
    $url = 'https://fcm.googleapis.com/fcm/send';

    /*api_key available in:
    Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    
    //$api_key = 'AAAASg_pmn4:APA91bHCx2c_vKU2njTUI7Y1gs8GTGIKOeD_4kaGCAyU6UDk8o-u06C5GCNBcK0x_oFjMktflOvXIeFdz8oYEie_6e1B4fA0XTff8cUqtKT1yj-gCnpJYePUAzE0Q4y26CZDuwdHBQXY';
    $api_key = 'AAAAzUz2J3Y:APA91bEUlBB8DrmmqOaI1_pVeiwwO2xTs5iU5RlWsJG_-v9YRmE0KoWKb5xoox3RBMuHNLzR3DvKFdcFQ9MWcYBSa1ZzT8ITdd0x0Kv_BwisHpmAyB5ZXDw0qC2wR2_VDmYxpuiCEtpe';
                
    $fields = array (
        'registration_ids' => array (
                $device_id
        ),
        
        'notification' => array(
                "title" => $message['title'],
                "body"=>$message['message'],
                // "sound"=>"default",
                'sound' => "notification",
                'android_channel_id' => "Global",
                "badge" =>"1"
                ),
        
        'data' => array (
                "action" => $message['action'],
                "message"=>$message['message'],
                "title"=>$message['title']
               )
        
    );
    
    
    //print_r($fields);die;
    
    
    
    //header includes Content type and api key
    $headers = array(
        'Content-Type:application/json',
        'Authorization:key='.$api_key
    );
                
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
    return $result;
}
function delivery_send_push_notification($device_id,$message){

    //API URL of FCM
    $url = 'https://fcm.googleapis.com/fcm/send';

    /*api_key available in:
    Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    
    //$api_key = 'AAAASg_pmn4:APA91bHCx2c_vKU2njTUI7Y1gs8GTGIKOeD_4kaGCAyU6UDk8o-u06C5GCNBcK0x_oFjMktflOvXIeFdz8oYEie_6e1B4fA0XTff8cUqtKT1yj-gCnpJYePUAzE0Q4y26CZDuwdHBQXY';
    $api_key = 'AAAAE8dEvos:APA91bEm1TyvIW1okfu-CTz05YYwoiczuVdn51NVeUb4BBlRxhroaNEA3YaTJR_439Gqvzl1o4BrBvACD-3y-fEdD4MEES2ipZxfRM1MKNQmStwDYxYxsd4zhOzZNq6pBXCWpspcdCOq';
                
    $fields = array (
        'registration_ids' => array (
                $device_id
        ),
        
        'notification' => array(
                "title" => $message['title'],
                "body"=>$message['message'],
                // "sound"=>"default",
                'sound' => "notification",
                'android_channel_id' => "Global",
                "badge" =>"1"
                ),
        
        'data' => array (
                "action" => $message['action'],
                "message"=>$message['message'],
                "title"=>$message['title']
               )
        
    );
    
    
    //print_r($fields);die;
    
    
    
    //header includes Content type and api key
    $headers = array(
        'Content-Type:application/json',
        'Authorization:key='.$api_key
    );
                
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
    return $result;
}

?>