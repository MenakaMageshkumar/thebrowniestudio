<?php
class Commonapi_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }
    public function chk_active($request=''){
        if(!isset($request['userid']) || empty($request['userid']) || !isset($request['apptype']) || empty($request['apptype'])){
            return false;
        }
        $client_uniqid = $request['userid'];
        $apptype = $request['apptype'];
        $path ="";
        if($apptype=='selleradmin_app'){
            $path = 'sellerapi/';
        }else if($apptype=='deliveryadmin_app'){
            $path = 'deliveryadminapi/';
        }
       $result =  $this->db->query("select * from ym_clients where client_uniqid='$client_uniqid'")->result();
       if($result){
           if($path!=""){
                   $base_url = $result[0]->base_url.''.$path;
               }else{
                   $base_url = $result[0]->base_url;
               }
           $array = array(
               'client_uniqid'=>$result[0]->client_uniqid,
               'base_url'=>$base_url,
               'image_url'=>$result[0]->image_url
               );
           return $result = array('status'=>1,'message'=>'Valid user credentail', 'data'=>$array); 
       }else{
           return $result = array('status'=>0,'message'=>'Invalid user'); 
       }
    }
}?>