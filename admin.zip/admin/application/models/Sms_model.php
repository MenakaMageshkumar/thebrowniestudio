<?php

class Sms_model extends CI_Model {

	public function _construct(){
		parent::_construct();
	}

	 public function send_sms($country_code, $phone_number, $otp)
    {

        
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://2factor.in/API/V1/6f244959-d305-11ea-9fa5-0200cd936042/SMS/".$phone_number."/".$otp,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
//echo '<pre>';print_r($response);die;
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  return $result = "cURL Error #:" . $err;
} else {
  return $result = $response;
}
  //echo '<pre>';print_r($response);die;  

  }
}
?>