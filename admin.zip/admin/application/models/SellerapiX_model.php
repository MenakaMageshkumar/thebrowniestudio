<?php
class SellerapiX_model extends CI_Model {
    function __construct() {
        parent::__construct();
         $this->load->model('Sms_model','sms_model');
    }
public function login($request='') {
        if(!isset($request['phone_no']) || empty($request['phone_no'])  || !isset($request['password']) || empty($request['password'])){
            return false;
        }
        $phone_no = trim($request['phone_no']);
        $this->db->where("phone_no = '".$phone_no."'");
        $this->db->where('password', md5($request['password']));
        $this->db->where('status !=', 0);
        
        $query = $this->db->get('shopper');
        if ($query->num_rows() > 0) {
            $rs = $query->row();
            $store_id = $rs->store_id;
            $get_str = $this->db->query("select store_name,store_id from stores where store_id=$store_id")->result();
            if($get_str){
                $dt = $get_str[0];
             $str_name = str_replace(' ', '-', $dt->store_name); 
              $fnl_name=  preg_replace('/[^A-Za-z0-9\-]/', '-', $str_name);
              $share_link = 'https://yellowmart.biz/StoreDetail/'.$fnl_name.'/'.$dt->store_id;
              $YMwhatsapp_no = '+917502201999';
            return $result = array('status'=>1,'message'=>'Login Success', 'data'=>array('seller_id'=>$rs->id,'name'=>$rs->shopper_name,'email'=>$rs->email,'phone_no'=>$rs->phone_no,'image'=>str_replace("null","",$rs->shopper_image),'store_id'=>$rs->store_id,'share_link'=>$share_link,'YMsupport'=>$YMwhatsapp_no ));    
            }else{
                return false;
            }
        }
    }
public function forgot_password($request='') {
        if(!isset($request['phone_no']) || empty($request['phone_no'])){
            return false;
        }
        $phone_no = trim($request['phone_no']);
        $qry = $this->db->query("SELECT u.id seller_id,u.phone_no,u.otp from shopper u where u.phone_no='$phone_no'");
        if ($qry->num_rows() > 0) {
            $otp = rand(1111, 9999);
            $this->db->where('phone_no',$phone_no);
            $this->db->set('otp',$otp);
            $status = $this->db->update('shopper');
            $qry = $this->db->query("SELECT u.id seller_id,u.phone_no,u.otp from shopper u where u.phone_no='$phone_no'");
            $val = $qry->row();
            $message = 'your OTP is :';
            $message_otp = $otp;
            $message_final = $message.$message_otp;
            // return $result = array('status'=>'success', 'data'=>$val); 
            $result1 = $this->sms_model->send_sms(
                                        91,
                                        $request['phone_no'],
                                        $message_otp
                                    );
            return $result = array('status'=>1,'message'=>'OTP send to your phone number', 'data'=>$val); 
        }
    }    
      public function chck_user_exists($request=array()){
        if(!isset($request) || empty($request)){
            return false;
        }
        $phone_number = $request['phone_no'];
        $this->db->select('phone_no');
        $this->db->where('phone_no', $phone_number);
        // $this->db->where('status', 1);
        $phone_no= $this->db->get('shopper');
        $re= $phone_no->row_array();
        return $re;
    }
      public function verify_otp($postdata=array()){
        if(!isset($postdata['phone_no']) || empty($postdata['phone_no']) || !isset($postdata['otp_code']) || empty($postdata['otp_code'])){
            return false;
        }
        $phone_no = $postdata['phone_no'];
        $otp_code = $postdata['otp_code'];
        $qry = $this->db->query("SELECT u.id seller_id,u.phone_no from shopper u where u.phone_no='$phone_no'and u.otp=$otp_code");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $this->db->where("phone_no = '".$postdata['phone_no']."'");
            $this->db->where("otp = '".$postdata['otp_code']."'");
            $this->db->set('otp','');
            $status = $this->db->update('shopper');
            if ($status) {
            
                return $status = array('status'=>1,'message'=>'OTP verified', 'data'=>$val); 
            }
        }
        
    }
    
    public function update_password($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['new_password']) || empty($postdata['new_password'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $new_password = md5($postdata['new_password']);
        $qry = $this->db->query("SELECT u.id seller_id,u.phone_no,email,shopper_name,shopper_id from shopper u where u.id='$id'");
        if ($qry->num_rows() > 0) {
            
            $val = $qry->row();
            $this->db->where("id = '$id'");
            $this->db->set('password',$new_password);
            $status = $this->db->update('shopper');
            
            $id = $val->shopper_id;
            $this->db->where("id = '$id'");
            $this->db->set('password',$new_password);
            $status = $this->db->update('admin_users');
            
            if ($status) {
              $email = $val->email;
            if($email){
            $seller_name = $val->shopper_name;
            $to_receiver_email = $email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellwomart123';
            $from_username = 'Yellow Mart - Mail';
            $subject="Password Updated";
            $message = 
"Dear $seller_name,

Alert from YellowMart!.

Your Password has been updated.

Please reach out to us at hello@yellowmart.co.in, If this was not done by you.

Regards,
YellowMart Team";
             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
             if($response['status']==0){
                 return $result = array('status'=>1,'message'=>'Failed to send mail ', 'data'=>$val); 
             }                
    
            }
                return $status = array('status'=>1,'message'=>'Password changed successfully', 'data'=>$val); 
            }
        }
        
    }
    
          public function update_prep_time($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['store_id']) || empty($postdata['store_id'])|| !isset($postdata['order_id']) || empty($postdata['order_id']) || !isset($postdata['order_prep_time']) || empty($postdata['order_prep_time'])){
            return false;
        }
        
        $seller_id = $postdata['seller_id'];
        $store_id = $postdata['store_id'];
        $orderutn_id = $postdata['order_id'];
        $order_acpt_time = strtotime($postdata['order_acpt_time']);
        $prepvalue = $postdata['order_prep_time'];// 5
        
        $id = $postdata['seller_id'];
        $ordertutn_id = $postdata['order_id'];
        $selected_item_id = $postdata['selected_item_id'];
        $total_amt = $postdata['total_amt']; //except cancelled item
        if(!isset($postdata['packing_charge']) || !isset($postdata['delivery_km'])  || !isset($postdata['delivery_charge']) ) { //manditory  &&  it can be zero also
          return false;  
        }
        $pst_packing_charge = $postdata['packing_charge'];
        $pst_delivery_km = $postdata['delivery_km'];
        $pst_delivery_charge = $postdata['delivery_charge'];
        
        $item_ids = '';
        if($selected_item_id){
        $item_ids =explode("|",$selected_item_id);
        }
        $tot_line_item_selected =count($item_ids);
        $order_assigned_to ='';
        if(isset($postdata['delivery_person_id'])){
        $delivery_person_id = $postdata['delivery_person_id'];
            if($delivery_person_id!=0 && $delivery_person_id!=''){
            $this->db->where("UTN_number = '$ordertutn_id'");
            $this->db->set('delivery_person_id',$delivery_person_id);
            $status = $this->db->update('orders');
            $delivery_boy_name =''; $order_assigned_to ='';
        $sel_id = $this->db->query("select * from shopper where id ='$id' ")->result();
        $del_data = $this->db->query("select * from delivery_persondtl where seller_id = $id and deli_boy_id = $delivery_person_id")->result();
        $order_assigned_to = $del_data[0]->deli_name;
            }
          }
          
        if($item_ids){
        $data = $this->db->query("select * from orders where UTN_number ='$ordertutn_id' ")->result();
        if($data){
            $order_id= $data[0]->order_id;
            $user_id= $data[0]->user_id;
            $total_amount = $data[0]->total_amount; //include cancellled items
            $discount_amount = $data[0]->discount_amount; 
        }
        //update all cart products as not selected 
            $this->db->where("order_id = '$order_id'");
            $this->db->set('product_status','0');
            $this->db->set('stockupdate_status','0');
            $status1 = $this->db->update('cart'); 
        foreach($item_ids as $cart_id){ //updated selected item = 1 active
            $this->db->where("cart_id = '$cart_id'");
            $this->db->set('product_status','1');
            $this->db->set('stockupdate_status','1');
            $status2 = $this->db->update('cart');
        }
        $chk_cancelled_order = $this->db->query("Select * from cart where order_id ='$order_id' and product_status = 0")->result();
        if($chk_cancelled_order){
            $chk_cancelled_order = $this->db->query("Select sum(price)price,sum(mrp_price)mrp_price from cart where order_id ='$order_id' and product_status = 0")->result();
            $cancel_product_amt =$chk_cancelled_order[0]->price;
            $cancel_discount_amt =  $chk_cancelled_order[0]->mrp_price - $chk_cancelled_order[0]->price;
        }
        else{
            $cancel_product_amt = 0;
            $cancel_discount_amt = 0;
        }
         if($status2){
              $this->db->where("order_id = '$order_id'");
            // $this->db->set('status','2'); //deliverd
            $this->db->set('delivery_status','1'); //order accepted
            $this->db->set('packing_charge',$pst_packing_charge); 
            $this->db->set('delivery_km',$pst_delivery_km); 
            $this->db->set('delivery_charge',$pst_delivery_charge); 
            $this->db->set('cancel_product_amt',$cancel_product_amt); 
            $this->db->set('cancel_discount_amt',$cancel_discount_amt); 
            $this->db->set('discount_amount',$discount_amount - $cancel_discount_amt );
            $this->db->set('order_acpt_time',date('Y-m-d H:i:s'));
            $status2 = $this->db->update('orders'); 
            }
            //final total update 
            $this->db->where("order_id = '$order_id'");
            $ord_final_total_update = $this->db->query("select * from orders where order_id =$order_id ")->result();
            $tot_order_base_amt = $ord_final_total_update[0]->tot_order_base_amt;
            $cancel_product_amt = $ord_final_total_update[0]->cancel_product_amt;
            $packing_charge = $ord_final_total_update[0]->packing_charge;
            $delivery_charge = $ord_final_total_update[0]->delivery_charge;
            // $total_amount = $tot_order_base_amt - $cancel_product_amt +  $packing_charge + $delivery_charge;
            $total_amount = $tot_order_base_amt +  $packing_charge + $delivery_charge;
            $this->db->set('total_amount',$total_amount);
            $status2 = $this->db->update('orders'); 
            
            //For cancelled order update(add) stock back to products table
            $this->updatesellerremovedproduct_stock($ordertutn_id,$user_id);
            
            $ord_dt = $this->db->query("select user_id from orders where order_id =$order_id ")->result();
            $user_id = $ord_dt[0]->user_id;
            
            //send push notification to customer
$customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name,delivery_person_id from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where usr.user_id = $user_id AND ord.UTN_number = '$ordertutn_id'")->result();
             if($customer){
                    //for home delivery send notification to customer once delivery person assinged
                    $delivery_person_id = $customer[0]->delivery_person_id;
                    $token_key = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name;
                    if($delivery_person_id!=0 && $delivery_person_id!=''){
                    $title = 'Order accepted & delivery person assigned';
                    $message ="ORDER#$ordertutn_id   $store_name - Order accepted & delivery person assigned. Please track your order in 'My Orders'.";
                    }
                    else{
                    $title = 'Order accepted at the store';
                    $message ="ORDER#$ordertutn_id   $store_name - Order accepted for store pickup. Please track your order in 'My Orders'.";
                    }
                    $notify_type = "order_accepted";
                    $user_id = $user_id;
                    $seller_id = $customer[0]->seller_id;
                    $delivery_boyid = $delivery_person_id;
                    $notified_person = "customer";
                    if($token_key!=''){
                    $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
                    }
                }
                 
}

        $str_data = $this->db->query("select prep_time from stores where store_id =$store_id ")->result();
            // default 30mins update
            $order_prep_time = date("Y-m-d H:i:s", strtotime("+30 minutes", $order_acpt_time));
        if($str_data[0]->prep_time!=''){
            $ex_preptime = explode("|",$str_data[0]->prep_time);//1|45   45minutes  or 3|5 5days 
            $preptype = $ex_preptime[0]; 
            if($preptype==1){//minutes
            $order_prep_time = date("Y-m-d H:i:s", strtotime("+$prepvalue minutes", $order_acpt_time));
            }
            else if($preptype==2){//hours
            $order_prep_time = date("Y-m-d H:i:s", strtotime("+$prepvalue hours", $order_acpt_time));
            }
            else if($preptype==3){//days
            $order_prep_time = date("Y-m-d H:i:s", strtotime("+$prepvalue days", $order_acpt_time));
            }
        }

        $qry = $this->db->query("SELECT * from orders where utn_number='$orderutn_id'")->result();
        if ($qry) {
            $this->db->where("utn_number = '$orderutn_id'");
            $this->db->set('prep_time',$order_prep_time);
            $status = $this->db->update('orders');
            if ($status) {
                $order_id = $qry[0]->order_id;
                $sel = $this->db->query("select * from cart where order_id =$order_id and product_status = 1 ")->result();
                $tot_line_item_selected = count($sel);  
                $order_assigned_to ='';
                $delivery_person_id = $qry[0]->delivery_person_id;
                if($delivery_person_id > 0){
                    $del_per = $this->db->query("select * from delivery_persondtl where deli_boy_id = $delivery_person_id")->result();
                    $order_assigned_to = $del_per[0]->deli_name;
                }
                                //preparation time
                $other_data = array();
                $ord_dtl = $this->db->query("select ord.order_acpt_time,ord.prep_time from orders ord where utn_number='$orderutn_id'")->result();
                $dt_frmt = date_create($ord_dtl[0]->prep_time);
                $order_prep_time = date_format($dt_frmt,'d/m/Y  h:i A');
                if($ord_dtl){
                    $other_data =array(
                         'order_acpt_time' => $ord_dtl[0]->order_acpt_time,
                         'order_prep_time' => $order_prep_time
                        );
                   
                    
                }
                return $status = array('status'=>1,'message'=>'Data updated','Total line Item Accepted'=>$tot_line_item_selected,'Order Assigned to'=>$order_assigned_to,'data'=>$other_data);    
            }
        }
        
    }
    public function update_token($request=array()){
        if(!isset($request['phone_no']) || empty($request['phone_no']) || !isset($request['token_key']) || empty($request['token_key'])){
            return false;
        }
        $phone_no = $request['phone_no'];
        $token_key = $request['token_key'];
        $qry = $this->db->query("SELECT u.id seller_id,u.phone_no from shopper u where u.phone_no='$phone_no'");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $this->db->where("phone_no = '$phone_no'");
            $this->db->set('token_key',$token_key);
            $status = $this->db->update('shopper');
            if ($status) {
            
                return $status = array('status'=>1,'message'=>'Token updated'); 
            }
        }
        
    }
    public function dashboard($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $ord_qry = $this->db->query("SELECT ord.UTN_number orderid,cust.fullname,cust.email,cust.phone_no,'' as address,ord.booking_time FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE seller.id = $id and delivery_status in (0) order by ord.order_id desc")->result();
        $ord_array = array();
        foreach($ord_qry as $ord){
            $phone_no = substr($ord->phone_no, -10);  //$ord->phone_no = '919876543210' to remove 91 , i took last 10digit mobile no
            $dt_frmt=date_create($ord->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
        $ord_array[] = array(
            'orderid'=>$ord->orderid,
            'name' =>$ord->fullname,
            'email' =>$ord->email,
            'phone_no' =>$phone_no,
            'address' =>$ord->address,
            'order_time' =>$booking_time
            );
        }
        // $delivery_qry = $this->db->query("SELECT ord.delivery_status_flg,ord.UTN_number orderid,cust.fullname,cust.email,cust.phone_no,str.store_address1 as address,'' delivery_person,ord.delivery_person_id,ord.delivery_status,ord.booking_time,cust.address1,cust.address2,cust.landmark,cust.city_town city,district.district,state.state,cust.pincode FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id LEFT JOIN district on cust.district_id = district.district_id LEFT join state on state.state_id = cust.state_id WHERE seller.id = $id and delivery_status in (1,4,5) order by ord.order_id desc")->result();
        $delivery_qry = $this->db->query("SELECT ord.delivery_status_flg,ord.UTN_number orderid,cust.fullname,cust.email,cust.phone_no,str.store_address1 as address,'' delivery_person,ord.delivery_person_id,ord.delivery_status,ord.booking_time,ord.address1,ord.address2,ord.area,ord.landmark,ord.city,ord.district,ord.state,ord.pincode,ord.gps_coordinates FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id WHERE seller.id = $id and delivery_status in (1,4,5) order by ord.order_id desc")->result();
        $deliveryord_array = array();
        foreach($delivery_qry as $ord){
            $phone_no = substr($ord->phone_no, -10);  //$ord->phone_no = '919876543210' to remove 91 , i took last 10digit mobile no
            $delivery_person_name='';
            $dt_frmt=date_create($ord->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            if($ord->delivery_person_id!='' && $ord->delivery_person_id!=0){
                $deli_boy_id = $ord->delivery_person_id;
                $del_data = $this->db->query("select * from delivery_persondtl where seller_id = $id and deli_boy_id = $deli_boy_id")->result();
                if($del_data){
                    $delivery_person_name = $del_data[0]->deli_name;
                }
            }
            $delivery_status = $ord->delivery_status;
            $delivery_status_flg = $ord->delivery_status_flg;
// 0- Awaiting Store Confirmation
// 1- Order Accepted
// 2- Delivered
// 3- Order Returned
// 4 - Order Packed
// 5 - Order Picked
            if($delivery_status==0){
                 $status = 'Awaiting Store Confirmation';
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $status = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $status = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $status = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $status = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //green
            }
            else if($delivery_status==4){
                $status = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            // else if($delivery_status==5){
            //     $status = 'Order Picked';
            //     $delivery_sts_clr = '#800080'; //purle
            // }
            else if($delivery_status==5 && $delivery_status_flg ==0){
                $status = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }
            else if($delivery_status==6){
                $status = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }
            else{
                $status = 'Order Placed';
                $delivery_sts_clr = '#000000'; //black
            }
            $address = $ord->address1.', '.$ord->address2.', '.$ord->landmark.', '.$ord->area.', '.$ord->city.', '.$ord->district.', '.$ord->state.' - '.$ord->pincode;
            if($ord->address1==''){
            $address = '';
            }
        $deliveryord_array[] = array(
            'orderid'=>$ord->orderid,
            'name' =>$ord->fullname,
            'email' =>$ord->email,
            'phone_no' =>$phone_no,
            'address' =>$address,
            'gps_coordinates'=>$ord->gps_coordinates,
            'delivery_person' =>$delivery_person_name,
            'order_status' =>$status,
            'delivery_sts_clr' =>$delivery_sts_clr,
            'order_time' =>$booking_time
            );
        }
        $id = $postdata['seller_id'];
            $data = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id) AND (trim(product_image) ='' or trim(product_image_1='') or trim(product_image_2='') or trim(product_image_3='') or trim(product_image_4=''))")->result();
        $empty_image_cnt = count($data);
        
        $data1 = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id) AND trim(description) =''")->result();
        $empty_description_cnt = count($data1);
        
        $stock_cnt = 0;
        $data_stock = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id) order by product_id")->result();
        foreach($data_stock as $stock){
            $type = $stock->type;
            $display_stock = explode("|",$stock->display_stock);
            $total_available_stock = explode("|",$stock->total_available_stock);
            $moq = explode("|",$stock->moq);
            $i=0;
            foreach($display_stock as $data){
                if($type=='Loose'){
                    if($data=='Yes'){
                        $total_available = $stock->total_available_stock;
                        $stk = str_replace("|","","$total_available");
                        if($stk=='' || $stk==0){
                        $stock_cnt = $stock_cnt + 1;
                        }
                    }
                    else if($data=='No'){
                        $moq_stk = $stock->moq;
                        $stk =  str_replace("|","","$moq_stk");
                        if($stk=='' || $stk==0){
                        $stock_cnt = $stock_cnt + 1;
                        }
                    }
                }
                else{
                if($data=='Yes'){
                    if($total_available_stock[$i]=='' || $total_available_stock[$i]==0){
                    $stock_cnt = $stock_cnt + 1;
                    }
                }
                else if($data=='No'){
                    if($moq[$i]=='' || $moq[$i]==0){
                    $stock_cnt = $stock_cnt + 1;
                    }
                }
                }
            $i++;
                
            } 
            }
       $empty_stock_cnt =  $stock_cnt;
        $varient_cnt = 0;
        
        // $data_varient = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id) order by product_id")->result();
         $data_varient = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id) and type!='Loose' and add_varient='Yes' and REPLACE(attribute1,'|','')='' and REPLACE(attribute2,'|','')='' and REPLACE(attribute3,'|','')=''    order by product_id")->result();
        foreach($data_varient as $varient){
            $type = $varient->type;
            if($type!='Loose'){
                if((str_replace('|','',$varient->attribute1)=='')&&(str_replace('|','',$varient->attribute2)=='')&&(str_replace('|','',$varient->attribute3)=='')){
                     $varient_cnt = $varient_cnt + 1;
                }
            }
        }
       $empty_varient_cnt = $varient_cnt ;
       
       $product_array =array();
       $product_array[] = array(
            'image_cnt'=>$empty_image_cnt,
            'stock_cnt' =>$empty_stock_cnt,
            'description_cnt' =>$empty_description_cnt,
            'varient_cnt' => $empty_varient_cnt
            
            );
        return $status = array('status'=>1,'message'=>'Dashboard Details', 'product'=>$ord_array,'delivery'=>$deliveryord_array,'products'=>$product_array); 
        
    }
    public function orderdetail($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['order_id']) || empty($postdata['order_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $ordertutn_id = $postdata['order_id'];
        // $qry = $this->db->query("SELECT o.order_id ,o.UTN_number orderutnid,u.fullname,u.email,u.phone_no address,cart.cart_id item_id,cart.product_desc ,cart.varient_name,cart.quantity,cart.price,cart.product_status,seller.deli_by_name as delivery_person  FROM orders o INNER join cart ON cart.order_id = o.order_id INNER JOIN products p on cart.product_id = p.product_id INNER JOIN user_profile u on u.user_id = cart.user_id INNER JOIN shopper seller ON seller.store_id = cart.store_id AND seller.store_id = o.store_id AND cart.store_id = o.store_id  WHERE o.UTN_number = '$ordertutn_id'  AND seller.id =$id ");
        $ord_qry = $this->db->query("SELECT o.tot_order_base_amt,o.packing_charge,o.delivery_charge,o.store_id, o.order_confirmation,o.user_id,o.payment_type,o.order_id ,o.UTN_number orderutnid,u.fullname,u.email,u.phone_no,o.address1,o.address2,o.landmark,o.area,o.city,o.district,o.state,o.pincode,o.booking_time,o.payment_method as delivery_type,o.gps_coordinates FROM orders o INNER JOIN user_profile u on u.user_id = o.user_id WHERE o.UTN_number = '$ordertutn_id'")->result();
        $final_array =array ();
        foreach($ord_qry as $ord){
            $dt_frmt=date_create($ord->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            $ordutnid = $ord->orderutnid;
            $order_confirmation = $ord->order_confirmation;
            $itemwise_qry = $this->db->query("SELECT cart.mrp_rate,cart.rate,display_name,cart.cart_id item_id,cart.product_desc ,cart.varient_name,cart.varient_id,cart.quantity,cart.price,cart.product_status,o.payment_method,p.product_name FROM orders o INNER join cart ON cart.order_id = o.order_id INNER JOIN products p on cart.product_id = p.product_id WHERE o.UTN_number = '$ordutnid' and product_status !=0")->result(); //don't show unselected item
            //if order confirmation is zero but products added by (product_addby_seller = 1 ) seller means they have to request confirm button so enable confirm button  //$order_confirmation = 1;   
            if($order_confirmation==0){ //ACCEPT ORDER
            $chk_ord_confirm = $this->db->query("select * from cart inner join orders ord on cart.order_id = ord.order_id where UTN_number ='$ordutnid' and product_addby_seller = 1 and ord.order_confirmation = 0 ")->result();
            if($chk_ord_confirm){
             $order_confirmation = 1;   //CONFIRM ORDER
            }
            }
             $chk_ord_confirm = $this->db->query("select * from cart inner join orders ord on cart.order_id = ord.order_id where UTN_number ='$ordutnid' and ord.order_confirmation = 1 ")->result();
            if($chk_ord_confirm){
             $order_confirmation = 2;    //AWAITS CONFIRMATION
            }
            $chk_ord_confirm = $this->db->query("select * from cart inner join orders ord on cart.order_id = ord.order_id where UTN_number ='$ordutnid' and ord.order_confirmation = 2 ")->result();
            if($chk_ord_confirm){
             $order_confirmation = 0;    //AWAITS CONFIRMATION
            }
            $grand_tot = 0;
            $item_array =array();
            foreach($itemwise_qry as $item){
                //display name will change varient wise
                $dn_id = $item->varient_id;
                $varwise_display_name = explode("|",$item->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $item->product_name;
                }
                $stock =10;
                $item_array[] = array (
                    'order_id'=>$ordertutn_id,
                    'item_id'=>$item->item_id,
                    // 'product_desc' =>$item->product_name,
                    'product_desc' =>$display_name_final,
                    'varient' =>$item->varient_name,
                    'quantity' =>$item->quantity,
                    'unit_price' =>$item->rate,
                    'price' =>$item->price,
                    'mrp_price' =>$item->mrp_rate,
                    'stock' =>$stock,
                    'product_status' =>$item->product_status
                    
                    );
                    $grand_tot = $grand_tot + $item->price;
            }
            // $delivery_bo = $this->db->query("Select * from shopper as seller where id = $id")->result();
            $delivery_bo = $this->db->query("Select * from shopper as seller  INNER JOIN stores on seller.store_id = stores.store_id where id = $id")->result();
            $delivery_note = $delivery_bo[0]->delivery_note;
            $deli_by_ids = $delivery_bo[0]->deli_by_ids;
            // $delivery_type = $delivery_bo[0]->str_delivery_type;
            $delivery_type = $delivery_bo[0]->store_delivery_type;
            $delivery_ty ='';
            // if($delivery_type==2 && $item->payment_method==2){
            if($item->payment_method==2){
                $delivery_ty = 'Home Delivery';
            }
            else
            {
                $delivery_ty = 'Store Pickup';
            }
            $deli_array =array();
           if($deli_by_ids){
                $deli_by = $this->db->query("select * from delivery_persondtl where deli_boy_id in ($deli_by_ids)")->result();
                foreach($deli_by as $d){
                $deli_array[] =array( 
                'delivery_person_id' =>$d->deli_boy_id,
                'delivery_person' =>$d->deli_name
                );
                }
            }
            $order_acpt_min_perc =100;
            $config_data = $this->db->query("select * from configuration where id  = 1")->result();
            if($config_data){
                $order_acpt_min_perc = $config_data[0]->order_acpt_min_perc;
            }
            $store_id = $ord->store_id; $packing_charge = array(); $delivery_charge = array();
            $strdata = $this->db->query("select str.packing_charges,str.pc_type,str.pc_perc,str.pc_unit_value,str.delivery_charges,str.min_dc,str.dc_freekm,str.dc_perkm from stores str where store_id = $store_id ")->result();
            if($strdata){
            $pc_status = $strdata[0]->packing_charges; //1 - enable 0 - disable
            $pc_type = $strdata[0]->pc_type;
            // $packing_charge = array (
            //     "enable" =>$pc_status,
            //     "pc_perc_charge" =>$pc_perc_charge,
            //     "pc_unit_value" =>$pc_unit_value
            //     );
            if($pc_type==0){ //percentage wise charge
            $pc_perc_charge = $grand_tot * ($strdata[0]->pc_perc /100);
                 $pc = round($pc_perc_charge,0);
            }else{ //unitwise charge
                $pc_unit_value = $strdata[0]->pc_unit_value;
                $ord_d = $this->db->query("select * from orders where UTN_number ='$ordertutn_id' ")->result();
                $items_in_cart = $ord_d[0]->items_in_cart;
                $order_id = $ord_d[0]->order_id;
                $active_itemcnt = 0;
                $cnt = $this->db->query("Select sum(quantity)quantity from cart where order_id = $order_id and product_status!=0" )->result();
                if($cnt) {
                    $active_itemcnt = $cnt[0]->quantity;
                }
                if($cnt) {
                    $active_itemcnt = $cnt[0]->quantity;
                }
                $pc = round(($active_itemcnt  * $pc_unit_value),0);
            }
            $pc_type = $strdata[0]->pc_type;
            $pc_perc = $strdata[0]->pc_perc;
            $pc_unit_value = $strdata[0]->pc_unit_value;
            $packing_charge = round($ord->packing_charge,0);
            $packing_charge = array (
                "enable" =>"$pc_status",
                "pc_type" => "$pc_type",
                "pc_perc" =>"$pc_perc",
                "pc_unit_value" => "$pc_unit_value",
                "packing_charge" =>"$pc"
                
                );
            $dc_status = $strdata[0]->delivery_charges; //1 - enable 0 - disable
            // if($dc_status){
            $ord_d = $this->db->query("select * from orders where UTN_number ='$ordertutn_id'")->result();
            $payment_method = $ord_d[0]->payment_method;
            $delivery_km = $ord_d[0]->delivery_km;
            $delivery_charge = round($ord_d[0]->delivery_charge,0);
            if($payment_method ==1){ //for storepickup 
                $dc_status = 0; //disable delivery charge
            }
            $dc_freekm = $strdata[0]->dc_freekm;
            $dc_perkm = round($strdata[0]->dc_perkm,0);
            $min_dc = round($strdata[0]->min_dc,0);

            $delivery_charge = array (
                "enable" =>"$dc_status",
                "delivery_km" =>"$delivery_km",
                "min_dc"=>"$min_dc",
                "dc_freekm" =>"$dc_freekm",
                "dc_perkm" =>"$dc_perkm",
                "delivery_charge"=>"$delivery_charge",
                "delivery_note"=>$delivery_note
                );
            // }
            }
            $tot = round($ord->tot_order_base_amt + $ord->packing_charge + $ord->delivery_charge,0) ;
            if($ord->payment_type==1){
                $payment_text = 'Cash on Delivery';
            }else{
                $payment_text = 'UPI Based(Google Pay,PhonePe,Paytm)';
            }
            $address = $ord->address1.', '.$ord->address2.', '.$ord->landmark.', '.$ord->area.', '.$ord->city.', '.$ord->district.', '.$ord->state.' - '.$ord->pincode;
            if($ord->address1==''){
            $address = '';
            }
$final_array = array(
    // 'order_id'=>$ord->order_id,
    'user_id'=>$ord->user_id,
    'orderutnid'=>$ord->orderutnid,
    'custname' =>$ord->fullname,
    'address'=>$address,
    'gps_coordinates' =>$ord->gps_coordinates,
    'payment_type'=>$ord->payment_type,
    'payment_text' =>$payment_text,
    'state'=>$ord->state,
    'order_time' =>$booking_time,
    'itemwise_dtl' => $item_array,
    'total' => $tot,
    'delivery_type'=>$delivery_ty,
    'delivery_person' => $deli_array,
    'order_acpt_min_perc' =>$order_acpt_min_perc,
    'order_confirmation' =>$order_confirmation,
    'packing_charge' =>$packing_charge,
    'delivery_charge' =>$delivery_charge
    );
        }
        if ($final_array > 0) {
        
                        return $status = array('status'=>1,'message'=>'Order Detail', 'data'=>$final_array); 
            
        }
    }
    public function submit_orderdetail($postdata=array()){ // accept order api
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['order_id']) || empty($postdata['order_id'])|| !isset($postdata['selected_item_id']) || empty($postdata['selected_item_id']) || !isset($postdata['total_amt']) || empty($postdata['total_amt']) ){
            return false;
        }
        
        $id = $postdata['seller_id'];
        $ordertutn_id = $postdata['order_id'];
        $selected_item_id = $postdata['selected_item_id'];
        $total_amt = $postdata['total_amt']; //except cancelled item
        if(!isset($postdata['packing_charge']) || !isset($postdata['delivery_km'])  || !isset($postdata['delivery_charge']) ) { //manditory  &&  it can be zero also
          return false;  
        }
        $pst_packing_charge = $postdata['packing_charge'];
        $pst_delivery_km = $postdata['delivery_km'];
        $pst_delivery_charge = $postdata['delivery_charge'];
        
        $item_ids = '';
        if($selected_item_id){
        $item_ids =explode("|",$selected_item_id);
        }
        $tot_line_item_selected =count($item_ids);
        $order_assigned_to ='';
        if(isset($postdata['delivery_person_id'])){
        $delivery_person_id = $postdata['delivery_person_id'];
            if($delivery_person_id!=0 && $delivery_person_id!=''){
            $this->db->where("UTN_number = '$ordertutn_id'");
            $this->db->set('delivery_person_id',$delivery_person_id);
            $status = $this->db->update('orders');
            $delivery_boy_name =''; $order_assigned_to ='';
        $sel_id = $this->db->query("select * from shopper where id ='$id' ")->result();
        $del_data = $this->db->query("select * from delivery_persondtl where seller_id = $id and deli_boy_id = $delivery_person_id")->result();
        $order_assigned_to = $del_data[0]->deli_name;
            }
          }
          
        if($item_ids){
//         $data = $this->db->query("select * from orders where UTN_number ='$ordertutn_id' ")->result();
//         if($data){
//             $order_id= $data[0]->order_id;
//             $user_id= $data[0]->user_id;
//             $total_amount = $data[0]->total_amount; //include cancellled items
//             $discount_amount = $data[0]->discount_amount; 
//         }
//         //update all cart products as not selected 
//             $this->db->where("order_id = '$order_id'");
//             $this->db->set('product_status','0');
//             $this->db->set('stockupdate_status','0');
//             $status1 = $this->db->update('cart'); 
//         foreach($item_ids as $cart_id){ //updated selected item = 1 active
//             $this->db->where("cart_id = '$cart_id'");
//             $this->db->set('product_status','1');
//             $this->db->set('stockupdate_status','1');
//             $status2 = $this->db->update('cart');
//         }
//         $chk_cancelled_order = $this->db->query("Select * from cart where order_id ='$order_id' and product_status = 0")->result();
//         if($chk_cancelled_order){
//             $chk_cancelled_order = $this->db->query("Select sum(price)price,sum(mrp_price)mrp_price from cart where order_id ='$order_id' and product_status = 0")->result();
//             $cancel_product_amt =$chk_cancelled_order[0]->price;
//             $cancel_discount_amt =  $chk_cancelled_order[0]->mrp_price - $chk_cancelled_order[0]->price;
//         }
//         else{
//             $cancel_product_amt = 0;
//             $cancel_discount_amt = 0;
//         }
//          if($status2){
//               $this->db->where("order_id = '$order_id'");
//             // $this->db->set('status','2'); //deliverd
//             $this->db->set('delivery_status','1'); //order accepted
//             $this->db->set('packing_charge',$pst_packing_charge); 
//             $this->db->set('delivery_km',$pst_delivery_km); 
//             $this->db->set('delivery_charge',$pst_delivery_charge); 
//             $this->db->set('cancel_product_amt',$cancel_product_amt); 
//             $this->db->set('cancel_discount_amt',$cancel_discount_amt); 
//             $this->db->set('discount_amount',$discount_amount - $cancel_discount_amt );
//             $this->db->set('order_acpt_time',date('Y-m-d H:i:s'));
//             $status2 = $this->db->update('orders'); 
//             }
//             //final total update 
//             $this->db->where("order_id = '$order_id'");
//             $ord_final_total_update = $this->db->query("select * from orders where order_id =$order_id ")->result();
//             $tot_order_base_amt = $ord_final_total_update[0]->tot_order_base_amt;
//             $cancel_product_amt = $ord_final_total_update[0]->cancel_product_amt;
//             $packing_charge = $ord_final_total_update[0]->packing_charge;
//             $delivery_charge = $ord_final_total_update[0]->delivery_charge;
//             // $total_amount = $tot_order_base_amt - $cancel_product_amt +  $packing_charge + $delivery_charge;
//             $total_amount = $tot_order_base_amt +  $packing_charge + $delivery_charge;
//             $this->db->set('total_amount',$total_amount);
//             $status2 = $this->db->update('orders'); 
            
//             //For cancelled order update(add) stock back to products table
//             $this->updatesellerremovedproduct_stock($ordertutn_id,$user_id);
            
//             $ord_dt = $this->db->query("select user_id from orders where order_id =$order_id ")->result();
//             $user_id = $ord_dt[0]->user_id;
            
//             //send push notification to customer
// $customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name,delivery_person_id from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where usr.user_id = $user_id AND ord.UTN_number = '$ordertutn_id'")->result();
//              if($customer){
//                     //for home delivery send notification to customer once delivery person assinged
//                     $delivery_person_id = $customer[0]->delivery_person_id;
//                     $token_key = $customer[0]->token_key;
//                     $store_name = $customer[0]->store_name;
//                     if($delivery_person_id!=0 && $delivery_person_id!=''){
//                     $title = 'Order accepted & delivery person assigned';
//                     $message ="ORDER#$ordertutn_id   $store_name - Order accepted & delivery person assigned. Please track your order in 'My Orders'.";
//                     }
//                     else{
//                     $title = 'Order accepted at the store';
//                     $message ="ORDER#$ordertutn_id   $store_name - Order accepted for store pickup. Please track your order in 'My Orders'.";
//                     }
//                     $notify_type = "order_accepted";
//                     $user_id = $user_id;
//                     $seller_id = $customer[0]->seller_id;
//                     $delivery_boyid = $delivery_person_id;
//                     $notified_person = "customer";
//                     if($token_key!=''){
//                     $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
//                     }
//                 }
                 
                 //update order accept time
            $this->db->where("UTN_number = '$ordertutn_id'");
            $this->db->set('order_acpt_time',date("Y-m-d H:i:s"));
            $status = $this->db->update('orders');
            
//preparation time
$other_data = array();
// $ord_dtl = $this->db->query("select ord.order_acpt_time,DATE_FORMAT(str.order_prep_time, '%i')order_prep_time,DATE_FORMAT(str.order_prep_time, '%H')hours from orders ord inner join stores str on ord.store_id = str.store_id where utn_number='$ordertutn_id'")->result();
$ord_dtl = $this->db->query("select ord.order_acpt_time,str.prep_time from orders ord inner join stores str on ord.store_id = str.store_id where utn_number='$ordertutn_id'")->result();
if($ord_dtl){
    $prep_time = array();
    $order_acpt_time = strtotime($ord_dtl[0]->order_acpt_time);
    //default 30minutes
    if($ord_dtl[0]->prep_time!=''){
    $ex_preptime = explode("|",$ord_dtl[0]->prep_time);//1|45   45minutes  or 3|5 5days 
    $preptype = $ex_preptime[0]; $prepvalue = $ex_preptime[1];
    if($ex_preptime[0]==1){//minutes
        $minutes = $ex_preptime[1];
        $order_prep_time = date("Y-m-d H:i:s", strtotime("+$minutes minutes", $order_acpt_time));
        $prep_type ='Minutes';
    }
    if($ex_preptime[0]==2){//hours
        $hrs = $ex_preptime[1];
        $order_prep_time = date("Y-m-d H:i:s", strtotime("+$hrs hours", $order_acpt_time));
        $prep_type ='Hours';
    }
     if($ex_preptime[0]==3){//days
        $days = $ex_preptime[1];
        $order_prep_time = date("Y-m-d H:i:s", strtotime("+$days days", $order_acpt_time));
        $prep_type ='Days';
    }
    }else{ // else case default 30mins update
        $minutes = 30;
        $order_prep_time = date("Y-m-d H:i:s", strtotime("+$minutes minutes", $order_acpt_time));
        $preptype = 1; $prepvalue = 30;
        $prep_type ='Minutes';
    }

    if($preptype==1){//minutes
        $time1 = round($prepvalue/6,0); //if $tot_time =30mins (i.e)30/6= 5mins means  // 5,10,15,20,25,30
        $i = 0;
        $timex = 0;
        for($i=0;$i<6;$i++){
            $timex = $timex + $time1; 
            $prep_time[] =   $timex;
        }
    }
    if($preptype==2 || $preptype==3){//hours // days example $prepvalue = 5 means 1,2,3,4,5 hours
        $i = 1;
        for($i=1;$i<=$prepvalue;$i++){
            $prep_time[] = $i;
        }
    }
    $prep_time[] = 0;
    $other_data =array(
         'order_acpt_time' => $ord_dtl[0]->order_acpt_time,
         'order_prep_time' => $order_prep_time,
         'prep_time' => $prep_time,
         'prep_type' => $prep_type
        );
    
}

            return $status = array('status'=>1,'message'=>'Data Updated','Total line Item Accepted'=>$tot_line_item_selected,'Order Assigned to'=>$order_assigned_to,'data'=>$other_data);    
            
     }
     else{
      return $status = array('status'=>0,'message'=>'No Items Selected');    
     }
     }
     public function delivery_orderdetail($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['order_id']) || empty($postdata['order_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $ordertutn_id = $postdata['order_id'];
         $ord_qry = $this->db->query("SELECT o.cancel_product_amt,o.tot_order_base_amt,o.packing_charge,o.delivery_charge,o.delivery_status_flg,o.payment_type,o.order_id ,o.UTN_number orderutnid,u.fullname,u.email,u.phone_no,o.address1,o.address2,o.area,o.landmark,o.city,o.district,o.state,o.delivery_person_id,o.payment_method,o.delivery_status,o.pincode,o.booking_time,o.gps_coordinates FROM orders o INNER JOIN user_profile u on u.user_id = o.user_id WHERE o.UTN_number = '$ordertutn_id' ")->result();
    //   print_r($ord_qry);
    //   die;
        $final_array =array ();
        foreach($ord_qry as $ord){
            $dt_frmt=date_create($ord->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            $ordutnid = $ord->orderutnid;
            $itemwise_qry = $this->db->query("SELECT display_name,cart.cart_id item_id,cart.product_desc ,cart.varient_name,cart.varient_id,cart.quantity,cart.price,cart.product_status,p.product_name FROM orders o INNER join cart ON cart.order_id = o.order_id INNER JOIN products p on cart.product_id = p.product_id WHERE o.UTN_number = '$ordutnid' and product_status in (1,2)")->result();
            //product_status =1 means only show accepted order and their price
            $grand_tot = 0;
            $item_array =array();
            foreach($itemwise_qry as $item){
                 //display name will change varient wise
                $dn_id = $item->varient_id;
                $varwise_display_name = explode("|",$item->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $item->product_name;
                }
                
                $item_array[] = array (
                    'item_id'=>$item->item_id,
                    'product_desc' =>$display_name_final,
                    // 'product_desc' =>$item->product_name,
                    'varient' =>$item->varient_name,
                    'quantity' =>$item->quantity,
                    'price' =>$item->price
                    );
                    $grand_tot = $grand_tot + $item->price;
            }
            $delivery_bo = $this->db->query("Select * from shopper as seller  INNER JOIN stores on seller.store_id = stores.store_id where id = $id")->result();
            // $delivery_bo = $this->db->query("Select * from shopper as seller where id = $id")->result();
            // $delivery_type = $delivery_bo[0]->str_delivery_type;
            $delivery_type = $delivery_bo[0]->store_delivery_type;
            $delivery_ty ='';
            if($ord->payment_method==2){
                $delivery_ty = 'Home Delivery';
            }
            else
            {
                $delivery_ty = 'Store Pickup';
            }
           $delivery_person_name='';
            if($ord->delivery_person_id!='' && $ord->delivery_person_id!=0){
                $deli_boy_id = $ord->delivery_person_id;
                $del_data = $this->db->query("select * from delivery_persondtl where seller_id = $id and deli_boy_id = $deli_boy_id")->result();
                if($del_data){
                    $delivery_person_name = $del_data[0]->deli_name;
                }
            }
            $delivery_status = array();
             $delivery_status[] = array(
                'id'=> 4,
                'value'=>'Packed'
                );
            $delivery_status[] = array(
                'id'=> 2,
                'value'=>'Delivered'
                );
            $delivery_status[] = array(
                'id'=> 3,
                'value'=>'Returned'
                );
           
            $curr_delivery_status = $ord->delivery_status;
            $delivery_status_flg = $ord->delivery_status_flg;
            if(($curr_delivery_status==4 || $curr_delivery_status==5) && $delivery_status_flg == 1 ){
            $curr_delivery_status = 2;    
            }
            // $total = round($ord->tot_order_base_amt - $ord->cancel_product_amt  + $ord->packing_charge + $ord->delivery_charge,0);
            $total = round($ord->tot_order_base_amt  + $ord->packing_charge + $ord->delivery_charge,0);
            if($ord->payment_type==1){
                $payment_text = 'Cash on Delivery';
            }else{
                $payment_text = 'UPI Based(Google Pay,PhonePe,Paytm)';
            }
            $orderutnid = $ord->orderutnid;
            $str_dtl = $this->db->query("SELECT str.packing_charges,str.delivery_charges,ord.payment_method,ord.packing_charge,ord.delivery_charge,str.delivery_note FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id WHERE ord.UTN_number ='$orderutnid'")->result();
            $packing_charge = array(); $delivery_charge = array();$delivery_enable ="0";
            if($str_dtl[0]->payment_method==2){ //delivery charge only applicable for home delivery
                $delivery_enable = "1";
            }
            $packing_charge = array(
                'enable' => $str_dtl[0]->packing_charges,
                'packing_charge' =>$str_dtl[0]->packing_charge
                );
            $delivery_charge = array(
                'enable' => $delivery_enable,
                'delivery_charge' =>$str_dtl[0]->delivery_charge,
                'delivery_note' =>$str_dtl[0]->delivery_note
                );
            $address = $ord->address1.', '.$ord->address2.', '.$ord->landmark.', '.$ord->area.', '.$ord->city.', '.$ord->district.', '.$ord->state.' - '.$ord->pincode;
            if($ord->address1==''){
                
            $address = '';
            }
$final_array = array(
    // 'order_id'=>$ord->order_id,
    'orderutnid'=>$ord->orderutnid,
    'custname' =>$ord->fullname,
    'address'=>$address,
    'gps_coordinates'=>$ord->gps_coordinates,
    'payment_type'=>$ord->payment_type,
    'payment_method'=>$ord->payment_method,
    'payment_text' => $payment_text,
    'state'=>$ord->state,
    'order_time' =>$booking_time,
    'itemwise_dtl' => $item_array,
    'total' => $total,
    'delivery_type' =>$delivery_ty,
    'delivery_person' => $delivery_person_name,
    'delivery_status' =>$delivery_status,
    'current_status' =>$curr_delivery_status,
    'packing_charge'=>$packing_charge,
    'delivery_charge'=>$delivery_charge
    
    );
        }
        if ($final_array > 0) {
        
                        return $status = array('status'=>1,'message'=>'Delivery Order Detail', 'data'=>$final_array); 
            
        }
    }
    public function submitdelivery_orderdetail($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['order_id']) || empty($postdata['order_id'])|| !isset($postdata['delivery_status']) || empty($postdata['delivery_status'])){
            return false;
        }
        // print_r($postdata);die;
        // delivery_status =2 ->delivered, delivery_status =3 -> returned ,  delivery_status= 4 -> Order Packed
        $status_message = 'Order status updated successfully';
        $id = $postdata['seller_id'];
        $seller_id = $postdata['seller_id'];
        $ordertutn_id = $postdata['order_id'];
        $delivery_status = $postdata['delivery_status'];
        $o_dt  = $this->db->query("select * from orders where utn_number ='$ordertutn_id'")->result();
        
        //Please update the previous status
        $curr_delivery_status = $o_dt[0]->delivery_status;
        $payment_method = $o_dt[0]->payment_method;
        $error = 1;
        if($payment_method==1){//store pickup
            if($delivery_status==4 && $curr_delivery_status!=1 ){ //4- packed 1- accepted
              $error = 0;  
            }else if($delivery_status==2 && $curr_delivery_status!=4 ){ //4- delivered 1- packed
              $error = 0;  
            }
            else if($delivery_status==3 && $curr_delivery_status!=2 ){ // 2 -returned  2- delivered
              $error = 0;  
            }
        }else{
            if($delivery_status==4 && $curr_delivery_status!=1 ){ //4- packed 1- accepted
              $error = 0;  
            }else if($delivery_status==2 && $curr_delivery_status!=5 ){ //4- delivered 1- picked
              $error = 0;  
            }else if($delivery_status==3 && $curr_delivery_status!=2 ){ // 2 -returned  2- delivered
              $error = 0;  
            }
        }
        if($error==0){
            return $status = array('status'=>0,'message'=>'Please update the previous status');
        }
        
        
        $user_id = $o_dt[0]->user_id;
        $delivery_status_flg = 0;
        if($delivery_status==2){ 
            $delivery_status_flg = 1;
        }else if($delivery_status==3){
            $delivery_status_flg = 2;
        }
        if($delivery_status_flg > 0) { //this will update only for delivered and return status
            $delivery_status_flg_updatedtime = date('Y-m-d H:i:s');
            $this->db->where("UTN_number = '$ordertutn_id'");
            // $this->db->set('delivery_status',$delivery_status);
            $this->db->set('delivery_status_flg',$delivery_status_flg);
            $this->db->set('delivery_status_flg_updatedtime',$delivery_status_flg_updatedtime);
            $this->db->set('delivery_time',$delivery_status_flg_updatedtime);
            $status = $this->db->update('orders');
        }    
            //Update Item Status once delivered
            $dt  = $this->db->query("select * from orders where utn_number ='$ordertutn_id'")->result();
            if($dt){
                $order_id = $dt[0]->order_id;
                $product_status=1;
                if($delivery_status==2 || $delivery_status==3 ){
                   $product_status=2;
                }
                $this->db->query("update cart set product_status = $product_status where order_id = $order_id and product_status ='1'");
                
                //The below condition only applicable for // Store Pickup Orders
                $payment_method = $dt[0]->payment_method;
                // print_r($delivery_status);
                // print_r($payment_method);
                // die;
                if($delivery_status==2 && $payment_method ==1 ){
                //for store pickup once delivery status changes to "delivered" by seller app then update payment_status =1 completed and delivery_status = 2  delivered, and read delivery time
                $delivery_time = date('Y-m-d H:i:s');
                $this->db->query("update orders set delivery_status = 2 , status = 2, delivery_time = '$delivery_time' where order_id = $order_id");
                
                //once order delivered generate invoice
                // //create invoice 
                $order = $this->db->query("select orders.order_id,orders.total_amount,orders.store_id,stores.store_name from orders inner join stores on orders.store_id = stores.store_id where order_id = $order_id")->result();
                $order_id = $order[0]->order_id;
                $order_amount = $order[0]->total_amount;
                $store_id = $order[0]->store_id;
                $store_name = $order[0]->store_name;
                $dt = $this->db->query("SELECT MAX(invid)invid FROM invoice WHERE store_id = $store_id")->result();
                if(isset($dt[0]->invid)!=''){
                    $invid = $dt[0]->invid;
                $inv_dt = $this->db->query("select inv_no from invoice where invid =$invid ")->result();
                $invno = $inv_dt[0]->inv_no; //"YSA240521001"
                $remove = substr($invno, 9); //001
                $id = ltrim($remove, '0');//1
                }else{
                    $id = 0;
                }
                $sequence_num = str_pad($id + 1, 3, 0, STR_PAD_LEFT);
                $store_2letter = strtoupper(substr($store_name, 0, 2)); // SA salt n pepper,
                $d = date("dmy");//Invoice Format "YSA240521001" Y - Yellowmart, SA salt n pepper, 24052 datemonthyear, store wise sequence 001
                $INV_number = "Y".$store_2letter.$d.$sequence_num;
                 $insert_invdata  = array(
                        'inv_no'=>$INV_number,
                        'ord_id'=>$order_id,
                        'store_id'=>$store_id,
                        'total_final_bill_amt'=>$order_amount,
                        'inv_view_status '=>0
                    );
                $this->db->insert('invoice',$insert_invdata);

                }
                // else if($delivery_status==3 && $payment_method ==1 ){ //Product return
                else if($delivery_status==3 ){ //Product return
                $this->db->query("update orders set delivery_status = 3 where order_id = $order_id");    
                }
                else if($delivery_status==4 ){ //Product Packed
                $packed_time = date('Y-m-d H:i:s');
                $this->db->query("update orders set delivery_status = 4, packed_time = '$packed_time' where order_id = $order_id");    
                // $status_message = 'Order packed successfully';
                }
                
                }
                // return $status = array('status'=>1,'message'=>'Data Status Updated');
                if($delivery_status==2  && $payment_method ==1){
                  //send Order Confirmatio mail to Customer 
            $ord_dt = $this->db->query("select * from orders where order_id =$order_id ")->result();
            $user_id = $ord_dt[0]->user_id;
            $customer_dtl = $this->db->query("select invoice.inv_no,user.user_id,ord.delivery_status_flg,ord.address1,ord.address2,ord.landmark,ord.city city_town,ord.pincode,ord.state,ord.district,ord.area,user.email,user.fullname,ord.UTN_number ordid,ord.payment_method ,ord.delivery_person_id,ord.total_amount,ord.booking_time,s.store_name,ord.delivery_status from user_profile user inner join orders ord on user.user_id = ord.user_id  INNER JOIN stores s on ord.store_id  = s.store_id inner join invoice on invoice.ord_id = ord.order_id where ord.user_id =$user_id and ord.order_id =$order_id")->result();
            $ordid = $customer_dtl[0]->ordid;
            if($customer_dtl){
            if($customer_dtl[0] ->payment_method==2){
                    $delivery_type = 'Home Delivery';
                }
                else{
                    $delivery_type ='Store Pickup';
                }
// 0- Awaiting Store Confirmation
// 1- Order Accepted
// 2- Delivered
// 3- Order Returned
// 4 - Order Packed
// 5 - Order Picked
$delivery_status_flg = $customer_dtl[0]->delivery_status_flg;
                if($customer_dtl[0]->delivery_status==0){
                    $delivery_status = 'Awaiting Store Confirmation';
                }
                else if($customer_dtl[0]->delivery_status==1){
                    $delivery_status ='Order Accepted';
                }
                else if($customer_dtl[0]->delivery_status==2){
                    $delivery_status ='Delivered';
                }else if($customer_dtl[0]->delivery_status==3){
                    $delivery_status ='Order Returned';
                }
                else if(($customer_dtl[0]->delivery_status==4 || $customer_dtl[0]->delivery_status==5) && $delivery_status_flg ==1 ){
                $status = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                }
                else if($customer_dtl[0]->delivery_status==4){
                    $delivery_status ='Order Packed';
                }
                else if($customer_dtl[0]->delivery_status==5 && $delivery_status_flg ==0){
                    $delivery_status ='Order Picked';
                }
                else if($customer_dtl[0]->delivery_status==6){
                    $delivery_status ='Order Cancelled';
                }
                $delivery_person_name ='';$delivery_person_contact='';
                $delivery_person_id = $customer_dtl[0]->delivery_person_id;
                if($delivery_person_id!=0 && $delivery_person_id!=''){
                    $del_boy_dtl = $this->db->query("select * from delivery_persondtl where deli_boy_id =$delivery_person_id ")->result();
                    if($del_boy_dtl){
                        $delivery_person_name =$del_boy_dtl[0]->deli_name;
                        $delivery_person_contact =$del_boy_dtl[0]->deli_phone;
                    }
                }
                $ordid = $customer_dtl[0]->ordid;
                $store_name =$customer_dtl[0]->store_name;
                $booking_time = $customer_dtl[0]->booking_time;
                $total_amount = $customer_dtl[0]->total_amount;
                if($customer_dtl[0] ->payment_method==2){
                $address = $customer_dtl[0]->address1.', '.$customer_dtl[0]->address2.', '.$customer_dtl[0]->area.', '.$customer_dtl[0]->city.', '.$customer_dtl[0]->landmark.', '.$customer_dtl[0]->state.' - '.$customer_dtl[0]->pincode;
                }else{
                $address ='-';    
                }
                $inv_no = $customer_dtl[0]->inv_no;
                $user_id = $customer_dtl[0]->user_id;
                
             $email = $customer_dtl[0]->email;
            if($email){
            $cust_name = $customer_dtl[0]->fullname;
            $to_receiver_email = $email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellwomart123';
            $from_username = 'Yellow Mart - Mail';
            $subject="Yellow Mart - Your $ordid Delivered.";
            $message = 
"Dear $cust_name,        

Below ORDER DELIVERED Successfully to $cust_name.

ORDER ID : ORDER#$INV_number   $store_name 

 Store Name : $store_name
 Order Date : $booking_time
 Status : Order Delivered
 Bill Amount : $total_amount

 Delivery Type : $delivery_type

Customer Address :
$address

Thank You,
YellowMart Team";
       $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
       }
            }  
                }
                
                $del_status = $postdata['delivery_status'];
                if($del_status==4 || $del_status==2){
            //send push notification to customer & delivery 
$customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name,delivery_person_id from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where usr.user_id = $user_id AND ord.UTN_number = '$ordertutn_id'")->result();
             if($customer){
                    //for home delivery send notification to customer once delivery person assinged
                    $delivery_person_id = $customer[0]->delivery_person_id;
                    $delboy_tokenkey = ''; $message='';
                    $token_key = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name;
                    $notified_person = "customer"; 
                    if($del_status == 4 && $payment_method ==1){//packed //store pickup //notification to customer app
                        $title = "Order packed & ready to pickup";
                        $message = "ORDER#$ordertutn_id   $store_name - Order packed & ready to pickup.";
                    }else if($del_status == 4 && $payment_method ==2){//packed //home delivery //notification to customer app
                        $title = "Order packed & ready for dispatch.";
                        $message = "ORDER#$ordertutn_id   $store_name -  Order packed & ready for dispatch.";
                    }
                    else if($del_status == 2 && $payment_method ==1){//deliverd //store pickup //notification to customer app
                        $title = "Order delivered successfully";
                        $message = "ORDER#$ordertutn_id   $store_name - Order delivered successfully.";
                    }
                    //send notification to deivery app
                    if($del_status == 4 && $payment_method ==2){//packed //home delivery //notification to delivery app
                        $deltitle = "Order packed & ready to pickup";
                        $delmessage = "ORDER#$ordertutn_id   $store_name - Order packed & ready to pickup.";
                        $delnotified_person = "deliveryboy";
                        $delboy_tokenkey = ''; //delivery boy token key
                        $get_delboy_tokenkey = $this->db->query("SELECT token_key FROM delivery_persondtl where deli_boy_id = $delivery_person_id ")->result();
                        if($get_delboy_tokenkey){
                            $delboy_tokenkey = $get_delboy_tokenkey[0]->token_key;
                        }
                    }
                    
                    $notify_type = "order_status";
                    $user_id = $user_id;
                    $seller_id = $customer[0]->seller_id;
                    $delivery_boyid = $delivery_person_id;
                    if($token_key!='' && $message!=''){
                    $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
                    }
                    if($delboy_tokenkey!=''){
                        $this->send_pushnotification($delboy_tokenkey,$delmessage,$deltitle,$notify_type,$user_id,$seller_id,$delivery_boyid,$delnotified_person);    
                    }
                }
                }
                

 return $status = array('status'=>1,'message'=>$status_message);
     }
     public function view_products($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $product_qry = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id and products.status = 1 and products.availability = 1")->result();
        if($product_qry){
        $final_array =array();
        foreach($product_qry as $prd){
            $type = $prd->type;
            if(strtoupper($type)=='LOOSE'){
                $varients = explode('|',$prd->sale_unit);
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                // $total_available_stock = explode('|',$prd->total_available_stock);
                // $moq = explode('|',$prd->moq);
                $total_available_stock = $prd->total_available_stock;
                $moq = $prd->moq;
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                    if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){
                        $price = $mop_price[$i] .' - ₹ '.$mrp_price[$i];
                    }
                    else{
                        $price = 0;
                    }
                    //Stock 
                    if($display_stock[0]=='Yes'){
                        $stock = str_replace("|", "","$total_available_stock");
                        $sl_unit = $sale_unit[$i];
                        $stock_unit = explode("|",$prd->stock_unit);
                        $stock_unit = $stock_unit[0];
                        $pack_cnt = $pack_content[$i];
                        if($sl_unit!=$stock_unit){
                            if($sl_unit == 1){ //ml to ltr  ex. 5ltr total stck 500ml packet connte
                                $converted = $pack_cnt / 1000;   // 500ml /1000 = 0.5ltr
                                $stock = $stock / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                            }
                            else if($sl_unit == 2){ //ltr to ltr
                                $stock = $stock/$pack_cnt;
                            }
                            else if($sl_unit == 3){ //gram to kg
                                $converted = $pack_cnt / 1000; 
                                $stock = $stock / $converted ;
                            }
                            else if($sl_unit == 5){//kg to kg
                                $stock = $stock / $pack_cnt;
                            }
                            else{ //other than kg,ltr,gram,ml
                                $stock = $stock;
                            }
                        }
                    else{
                             if(($sl_unit == 1) || ($sl_unit == 2) || ($sl_unit == 3) || ($sl_unit == 5) ){
                                $stock = $stock /$pack_cnt;
                            }
                            else {
                                $stock = $stock;
                            }
                         }
                    }
                    else{
                        $stock = str_replace("|", "","$moq");
                    }
                    $stock = (int)$stock;
                    //varient for loose
                    $s_unit =$sale_unit[$i];
                    $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                    if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                    }
                    $pck = $pack_content[$i];
                $varient_name =$pck.' '.$sale_unittext;
                
                 //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price,
                    'display_price'=>$price_to_display[$i]
                    );
                }
            }
            else{
                
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                $total_available_stock = explode('|',$prd->total_available_stock);
                $moq = explode('|',$prd->moq);
                //Varient1
                if($prd->varient1!='' && $prd->varient1!='|'){
                $varient1 = explode('|',$prd->varient1);
                }
                else{
                   $varient1 =''; 
                }
                //attribute1
                if($prd->attribute1!='' && $prd->attribute1!='|'){
                $attribute1 = explode('|',$prd->attribute1);
                }
                else{
                   $attribute1 =''; 
                }


               //Varient2
                if($prd->varient2!='' && $prd->varient2!='|'){
                $varient2 = explode('|',$prd->varient2);
                }
                else{
                   $varient2 =''; 
                }
                //attribute2
                if($prd->attribute2!='' && $prd->attribute2!='|'){
                $attribute2 = explode('|',$prd->attribute2);
                }
                else{
                   $attribute2 =''; 
                }
                
                //Varient3
                if($prd->varient3!='' && $prd->varient3!='|'){
                $varient3 = explode('|',$prd->varient3);
                }
                else{
                   $varient3 =''; 
                }
                //attribute3
                if($prd->attribute3!='' && $prd->attribute3!='|'){
                $attribute3 = explode('|',$prd->attribute3);
                }
                else{
                   $attribute3 =''; 
                }
               
                $varients = explode('|',$prd->sale_unit);
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                    if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){
                        $price = $mop_price[$i] .' - '.$mrp_price[$i];
                    }
                    else{
                        $price = 0;
                    }
                    //Stock 
                    if($display_stock[$i]=='Yes'){
                        $stock = $total_available_stock[$i];
                    }
                    else{
                        $stock = $moq[$i];
                    }
                    //varient for packet
                    if($prd->add_varient=='Yes'){
                        $attribute=''; $attribute_varient1='';$attribute_varient2='';$attribute_varient3='';
                        $varient_n1 =''; $varient_n2 =''; $varient_n3 ='';
                        if($attribute1){
                             $attr1 = $attribute1[$i];
                            if($attr1!=''){
                            $att = $this->db->query("select * from attributes where id =$attribute1[$i] ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                            // if($attribute1[$i]==1){
                            //     $attribute = 'Color';
                            // }else if($attribute1[$i]==2){
                            //     $attribute = 'Size';
                            // }else if($attribute1[$i]==3){
                            //     $attribute = 'Weight';
                            // }
                         $attribute_varient1 = $attribute.' : '.$varient1[$i];
                         $varient_n1 = $varient1[$i];
                        }}
                        if($attribute2){
                            $attr2 = $attribute2[$i];
                            if($attr2!=''){
                            $att = $this->db->query("select * from attributes where id =$attribute2[$i] ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient2 = $attribute.' : '.$varient2[$i];
                         $varient_n2 = $varient2[$i];
                            }
                        }
                        if($attribute3){
                            $attr3 = $attribute3[$i];
                            if($attr3!=''){
                           $att = $this->db->query("select * from attributes where id =$attribute3[$i] ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient3 = $attribute.' : '.$varient3[$i];
                         $varient_n3 = $varient3[$i];
                        }}
                        // $varient_name = $attribute_varient1.' '.$attribute_varient2.' '.$attribute_varient3;
                        $varient_name = $varient_n1.';'.$varient_n2.';'.$varient_n3;
                        $varient_name = rtrim($varient_name, ";");
                    }else{
                       $varient_name = ''; 
                    }
                    
                     //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price,
                    'display_price'=>$price_to_display[$i]
                    );
                }
            }
    
        }
        if ($final_array > 0) {
                        return $status = array('status'=>1,'message'=>'Product List', 'data'=>$final_array); 
        }
        }
        else{
             return $result = array('status'=>0,'message'=>'Data Not Found');
        }
    }
         public function product_search($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $keyword ='';
        if(isset($postdata['keyword'])){
        $keyword = $postdata['keyword'];
        }
        if($keyword!=''){
        $product_qry = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id AND (products.product_name LIKE '%$keyword%' || display_name  LIKE '%$keyword%') and products.status = 1 and products.availability = 1")->result();
        }else{
        $product_qry = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id and products.status = 1 and products.availability = 1")->result();    
        }
        if($product_qry){
        $final_array =array();
        foreach($product_qry as $prd){
            $type = $prd->type;
            if(strtoupper($type)=='LOOSE'){
                $varients = explode('|',$prd->sale_unit);
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                // $total_available_stock = explode('|',$prd->total_available_stock);
                // $moq = explode('|',$prd->moq);
                $total_available_stock = $prd->total_available_stock;
                $moq = $prd->moq;
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                     if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){
                        $price = $mop_price[$i] .' - '.$mrp_price[$i];
                    }
                    else{
                        $price = 0;
                    }
                    //Stock 
                    if(strtoupper($display_stock[0])=='YES'){//loose
                        $stock = str_replace("|", "","$total_available_stock");
                        $sl_unit = $sale_unit[$i];
                        $stock_unit = explode("|",$prd->stock_unit);
                        $stock_unit = $stock_unit[0];
                        $pack_cnt = $pack_content[$i];
                        if($sl_unit!=$stock_unit){
                            if($sl_unit == 1){ //ml to ltr  ex. 5ltr total stck 500ml packet connte
                                $converted = $pack_cnt / 1000;   // 500ml /1000 = 0.5ltr
                                $stock = $stock / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                            }
                            else if($sl_unit == 2){ //ltr to ltr
                                $stock = $stock/$pack_cnt;
                            }
                            else if($sl_unit == 3){ //gram to kg
                                $converted = $pack_cnt / 1000; 
                                $stock = $stock / $converted ;
                            }
                            else if($sl_unit == 5){//kg to kg
                                $stock = $stock / $pack_cnt;
                            }
                            else{ //other than kg,ltr,gram,ml
                                $stock = $stock;
                            }
                        }
                    else{
                             if(($sl_unit == 1) || ($sl_unit == 2) || ($sl_unit == 3) || ($sl_unit == 5) ){
                                $stock = $stock /$pack_cnt;
                            }
                            else {
                                $stock = $stock;
                            }
                         }
                        
                    }
                    else{
                        $stock = str_replace("|", "","$moq");
                    }
                    // print_r($i);
                        //varient for loose
                        $s_unit =$sale_unit[$i];
                        $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                        if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                        }
                        
                        $pck = $pack_content[$i];
                        $varient_name =$pck.' '.$sale_unittext;
                  //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                $stock = (int)$stock;
                if ((stripos($display_name_final,$keyword) !== false) || (stripos($prd->product_name,$keyword) !== false) || $keyword=="" ) {
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price,
                    'display_price'=>$price_to_display[$i]
                    );
                }
                }
            }
            else{
                
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                $total_available_stock = explode('|',$prd->total_available_stock);
                $moq = explode('|',$prd->moq);
                //Varient1
                if($prd->varient1!='' && $prd->varient1!='|'){
                $varient1 = explode('|',$prd->varient1);
                }
                else{
                   $varient1 =''; 
                }
                //attribute1
                if($prd->attribute1!='' && $prd->attribute1!='|'){
                $attribute1 = explode('|',$prd->attribute1);
                }
                else{
                   $attribute1 =''; 
                }


               //Varient2
                if($prd->varient2!='' && $prd->varient2!='|'){
                $varient2 = explode('|',$prd->varient2);
                }
                else{
                   $varient2 =''; 
                }
                //attribute2
                if($prd->attribute2!='' && $prd->attribute2!='|'){
                $attribute2 = explode('|',$prd->attribute2);
                }
                else{
                   $attribute2 =''; 
                }
                
                //Varient3
                if($prd->varient3!='' && $prd->varient3!='|'){
                $varient3 = explode('|',$prd->varient3);
                }
                else{
                   $varient3 =''; 
                }
                //attribute3
                if($prd->attribute3!='' && $prd->attribute3!='|'){
                $attribute3 = explode('|',$prd->attribute3);
                }
                else{
                   $attribute3 =''; 
                }
               
                $varients = explode('|',$prd->sale_unit);
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                    if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){
                        $price = $mop_price[$i] .' - '.$mrp_price[$i];
                    }
                    else{
                        $price = 0;
                    }
                    //Stock 
                    if($display_stock[$i]=='Yes'){
                        $stock = $total_available_stock[$i];
                    }
                    else{
                        $stock = $moq[$i];
                    }
                    //varient for packet
                    if(strtoupper($prd->add_varient)=='YES'){
                        $attribute=''; $attribute_varient1='';$attribute_varient2='';$attribute_varient3='';
                        $varient_n1 =''; $varient_n2 =''; $varient_n3 ='';
                        if($attribute1){
                            $att1 = $attribute1[$i];
                            if($att1!=''){
                            $att = $this->db->query("select * from attributes where id =$att1 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient1 = $attribute.' : '.$varient1[$i];
                         $varient_n1 = $varient1[$i];
                        }}
                        if($attribute2){
                            $att2 = $attribute2[$i];
                            if($att2!=''){
                            $att = $this->db->query("select * from attributes where id =$att2 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient2 = $attribute.' : '.$varient2[$i];
                         $varient_n2 = $varient2[$i];
                        }}
                        if($attribute3){
                             $att3 = $attribute3[$i];
                             if($att3!=''){
                            $att = $this->db->query("select * from attributes where id =$att3 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient3 = $attribute.' : '.$varient3[$i];
                         $varient_n3 = $varient3[$i];
                        }}
                        // $varient_name = $attribute_varient1.' '.$attribute_varient2.' '.$attribute_varient3;
                        $varient_name = $varient_n1.';'.$varient_n2.';'.$varient_n3;
                        $varient_name = rtrim($varient_name, ";");
                    }else{
                       //varient for loose
                        $s_unit =$sale_unit[$i];
                        $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                        if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                        }
                        
                        $pck = $pack_content[$i];
                        $varient_name =$pck.' '.$sale_unittext;
                    }
                //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                if ((stripos($display_name_final,$keyword) !== false) || (stripos($prd->product_name,$keyword) !== false) || $keyword=="" ) {
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price,
                    'display_price'=>$price_to_display[$i]
                    );
                }
                }
            }

        }
        if ($final_array > 0) {
                return $status = array('status'=>1,'message'=>'Product Search List', 'data'=>$final_array); 
        }
        }
        else{
             return $result = array('status'=>0,'message'=>'Data Not Found');
        }
    }
         public function add_image($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        // $product_images_list = $this->db->query("SELECT products.product_id,products.product_name FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id AND trim(product_image) =''")->result();
        $product_images_list = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id = seller.store_id WHERE seller.id = $id AND (trim(product_image) ='' or trim(product_image_1='') or trim(product_image_2='') or trim(product_image_3='') or trim(product_image_4='')) ORDER BY `products`.`product_name` ASC")->result();
        if($product_images_list){
            $final_array = array();
        foreach($product_images_list as $img){
        $img_cnt = 0;$product_image =''; $product_image_1 ='';$product_image_2='';$product_image_3='';$product_image_4='';
        
        if(trim($img->product_image)!=''){ //Main Image
            $img_cnt += 1;
            $product_image =$img->product_image;
        }
        
        if(trim($img->product_image_1)!=''){
            $img_cnt += 1;
            $product_image_1 = $img->product_image_1;
        }
        
        if(trim($img->product_image_2)!=''){
            $img_cnt += 1;
            $product_image_2 = $img->product_image_2;
        }
        
        if(trim($img->product_image_3)!=''){
            $img_cnt += 1;
            $product_image_3 = $img->product_image_3;
        }
        
        if(trim($img->product_image_4)!=''){
            $img_cnt += 1;
            $product_image_4 = $img->product_image_4;
        }

        
            $final_array[]  = array (
                'product_id'=>$img->product_id,
                'product_name' =>$img->product_name,
                'product_nameold' =>$img->display_name,
                'product_image_cnt' => $img_cnt,
                'product_image' =>$product_image,
                'product_image1' =>$product_image_1,
                'product_image2' =>$product_image_2,
                'product_image3' =>$product_image_3,
                'product_image4' =>$product_image_4,
                );
               
        }
       
        
       
                        return $status = array('status'=>1,'message'=>'Product Images', 'data'=>$final_array); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Product images updated');
        }
    }
     public function update_images($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['product_id']) || empty($postdata['product_id'])){
            return false;
        }
        // print_r($postdata);die;
        $product_id =  $postdata['product_id'];
            // $update_data['product_image'] = $postdata['product_main_image'];
            if(isset($postdata['product_main_image'])){
            $update_data['product_image'] = $postdata['product_main_image'];    
            }
            if(isset($postdata['product_sub_image1'])){
            $update_data['product_image_1'] = $postdata['product_sub_image1'];    
            }
            if(isset($postdata['product_sub_image2'])){
            $update_data['product_image_2'] = $postdata['product_sub_image2'];    
            }
            if(isset($postdata['product_sub_image3'])){
            $update_data['product_image_3'] = $postdata['product_sub_image3'];    
            }
            if(isset($postdata['product_sub_image4'])){
            $update_data['product_image_4'] = $postdata['product_sub_image4'];    
            }
            if(isset($update_data)){
            $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
            }
            else{
                // return $result = array('status'=>1,'message'=>'No Changes');
                return $result = array('status'=>1,'message'=>'Add product images');
            }
        if(isset($status)){
                        return $status = array('status'=>1,'message'=>'Product images updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Images');
        }
        
     }
     public function add_description($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $product_description_list = $this->db->query("SELECT products.product_id,display_name as product_name, products.product_name as product_nameold FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id AND trim(description) =''")->result();
       if($product_description_list){
                        return $status = array('status'=>1,'message'=>'Product description', 'data'=>$product_description_list); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Product description updated');
        }
    }
    public function update_description($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['product_id']) || empty($postdata['product_id']) || !isset($postdata['description']) || empty($postdata['description'])){
            return false;
        }
            $product_id =  $postdata['product_id'];
            $update_data['description'] =  $postdata['description'];
            $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
        if($status){
                        return $status = array('status'=>1,'message'=>'Product description updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Description');
        }
        
     }
     public function add_stock($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];

        $data_stock = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id)    order by product_id")->result();
        $final_array = array();
        foreach($data_stock as $stock){
            $varient_name = '';$varient_dtl ='';
            $type = $stock->type;
            $display_stock = explode("|",$stock->display_stock);
            $total_available_stock = explode("|",$stock->total_available_stock);
            $moq = explode("|",$stock->moq);
            $i=0;
            if($type=='Loose'){
            foreach($display_stock as $data){ // for loose
                if($type=='Loose'){
                $sale_unit = explode('|',$stock->sale_unit);
                $pack_content = explode('|',$stock->pack_content);
                    if($data=='Yes'){
                        $total_available = $stock->total_available_stock;
                        $stk = str_replace("|","","$total_available");
                        if($stk=='' || $stk==0){
                       //varient for loose
                        $s_unit =$sale_unit[$i];
                        $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                        if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                        }
                        
                        $pck = $pack_content[$i];
                        $varient_name =$pck.' '.$sale_unittext;
                        }
                    }
                    else if($data=='No'){
                        $moq_stk = $stock->moq;
                        $stk =  str_replace("|","","$moq_stk");
                        if($stk=='' || $stk==0){
                        //varient for loose
                        $s_unit =$sale_unit[$i];
                        $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                        if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                        }
                        
                        $pck = $pack_content[$i];
                        $varient_name =$pck.' '.$sale_unittext;
                        }
                    }
                    $varient_dtl = $varient_name.','.$varient_name;
                }
            $i++;
            }
            if($stk=='' || $stk==0){
            $final_array[] = array(
                        'product_id' => $stock->product_id,
                        'product_name' => $stock->product_name,
                        'product_nameold' => $stock->display_name,
                        'varient_id' => 0,
                         'varient_name' => $varient_dtl,
                         'type' => $stock->type
                        );
            }
            }
            $i=0;
            if($type!='Loose'){
        foreach($display_stock as $data){ // for other than Loose
        $varient_dtl ='';
                if($type!='Loose'){
                $sale_unit = explode('|',$stock->sale_unit);
                $pack_content = explode('|',$stock->pack_content);
                $total_available_stock = explode("|",$stock->total_available_stock);
                $moq = explode("|",$stock->moq);
                //Varient1
                if($stock->varient1!='' && $stock->varient1!='|'){
                $varient1 = explode('|',$stock->varient1);
                }
                else{
                   $varient1 =''; 
                }
                //attribute1
                if($stock->attribute1!='' && $stock->attribute1!='|'){
                $attribute1 = explode('|',$stock->attribute1);
                }
                else{
                   $attribute1 =''; 
                }
               //Varient2
                if($stock->varient2!='' && $stock->varient2!='|'){
                $varient2 = explode('|',$stock->varient2);
                }
                else{
                   $varient2 =''; 
                }
                //attribute2
                if($stock->attribute2!='' && $stock->attribute2!='|'){
                $attribute2 = explode('|',$stock->attribute2);
                }
                else{
                   $attribute2 =''; 
                }
                //Varient3
                if($stock->varient3!='' && str_replace("|","","$stock->varient3")!=''){
                $varient3 = explode('|',$stock->varient3);
                }
                else{
                   $varient3 =''; 
                }
                //attribute3
                // if($stock->attribute3!='' && $stock->attribute3!='|'){
                if($stock->attribute3!='' && str_replace("|","","$stock->attribute3")!=''){
                $attribute3 = explode('|',$stock->attribute3);
                }
                else{
                   $attribute3 =''; 
                }
                $varient_name ='';
                    if($data=='Yes'){
                        if($total_available_stock[$i]=='' || $total_available_stock[$i]==0){
                            //varient for packet
                            if($stock->add_varient=='Yes'){
                                $attribute=''; $attribute_varient1='';$attribute_varient2='';$attribute_varient3='';
                                if($attribute1){
                                         $att1 = $attribute1[$i];
                                     $att = $this->db->query("select * from attributes where id =$att1 ")->result();
                                    if($att){
                                        $attribute = $att[0]->attribute_name;  
                                    }
                                     $attribute_varient1 = $attribute.' : '.$varient1[$i];
                                }
                                if($attribute2){
                                     $att2 = $attribute2[$i];
                                 $att = $this->db->query("select * from attributes where id =$att2 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                                 $attribute_varient2 = $attribute.' : '.$varient2[$i];
                                }
                                if($attribute3){
                                    $att3 = $attribute3[$i];
                                 $att = $this->db->query("select * from attributes where id =$att3 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                                 $attribute_varient3 = $attribute.' : '.$varient3[$i];
                                }
                                // print_r($attribute_varient1);
                                // print_r($attribute_varient2);
                                // print_r($attribute_varient3);
                                // die;
                                $varient_name = $attribute_varient1.' '.$attribute_varient2.' '.$attribute_varient3;
                            }else{
                               $varient_name = ''; 
                            }
        
                            }
                    }
                    else if($data=='No'){
                        
                        if($moq[$i]=='' || $moq[$i]==0){
                    //varient for packet
                    if($stock->add_varient=='Yes'){
                        $attribute=''; $attribute_varient1='';$attribute_varient2='';$attribute_varient3='';
                        if($attribute1){
                             $att1 = $attribute1[$i];
                            $att = $this->db->query("select * from attributes where id =$att1 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient1 = $attribute.' : '.$varient1[$i];
                        }
                        if($attribute2){
                            $att2 = $attribute2[$i];
                            $att = $this->db->query("select * from attributes where id =$att2 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient2 = $attribute.' : '.$varient2[$i];
                        }
                        if($attribute3){
                             $att3 = $attribute3[$i];
                            $att = $this->db->query("select * from attributes where id =$att3 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient3 = $attribute.' : '.$varient3[$i];
                        }
                        $varient_name = $attribute_varient1.' '.$attribute_varient2.' '.$attribute_varient3;
                    }else{
                       $varient_name = ''; 
                    }

                    }
                        }
                        
                        if($varient_dtl!=''){
                    $varient_dtl = $varient_dtl.','.$varient_name;
                        }
                        else{
                            $varient_dtl = $varient_name;
                        }
                        
                    if($varient_name!=''){//if stock is exists varient wil be empty, so don't add thi product in list
                    $final_array[] = array(
                        'product_id' => $stock->product_id,
                        'product_name' => $stock->product_name,
                        'product_nameold' => $stock->display_name,
                        // 'varient_id' =>  $i + 1 ,
                        'varient_id' =>  $i ,
                         'varient_name' => $varient_dtl,
                         'type' => $stock->type
                        );
                    }
                }
                $i++;
            
        }
            } 
        }
      
       if($final_array){
                        return $status = array('status'=>1,'message'=>'Product Stock List', 'data'=>$final_array); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Product stocks updated');
        }
    }
    public function update_stock($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['product_id']) || empty($postdata['product_id']) || !isset($postdata['varient_id']) || !isset($postdata['stock']) ){
            return false;
        }
            $product_id =  $postdata['product_id'];
            $varient_id =  $postdata['varient_id'];
            $stock =  $postdata['stock'];
            $data = $this->db->query("select * from products where product_id =$product_id ")->result();
            // echo '<pre>';
            // print_r($postdata);
            // die;
            if($data){
                $data = $data[0];
                if($data->type!='Loose'){ //varient wise stock update
                $display_stock = explode('|',$data->display_stock);
                $j=0; $total_available_stock_final= 0; $moq_final = 0;
                foreach($display_stock as $dt){
                if($dt =='Yes'){
                $total_available_stock = explode('|',$data->total_available_stock);
                // if($j == $varient_id -1){
                if($j == $varient_id ){
                    if($total_available_stock_final==0 && $j==0){
                        $total_available_stock_final = $stock;
                    }else{
                $total_available_stock_final = $total_available_stock_final.'|'.$stock;
                    }
                }
                else{
                     if($total_available_stock_final==0){
                        $total_available_stock_final = $total_available_stock[$j];
                    }else{
                 $total_available_stock_final = $total_available_stock_final.'|'.$total_available_stock[$j];   
                }
                }
                $moq_final = $moq_final.'|'; 
                }
                
                 if($dt =='No'){
                    $moq = explode('|',$data->moq);
                    // print_r($moq);
                    // die;
                    if($j == $varient_id ){
                    if($moq_final==0 && $j==0){
                        $moq_final = $stock;
                    }else{
                $moq_final = $moq_final.'|'.$stock;
                    }
                }
                else{
                     if($moq_final==0){
                        $moq_final = $moq[$j];
                    }else{
                 $moq_final = $moq_final.'|'.$moq[$j];   
                }
                }
                $total_available_stock_final = $total_available_stock_final.'|';  
                }
                $j++;
                }
                if($total_available_stock_final!=0){
                $update_data['total_available_stock'] = $total_available_stock_final;
                }
                if($moq_final!=0){
                $update_data['moq'] = $moq_final;
                }
                }  
                
                 else if($data->type=='Loose'){ //only one stock, not varient wise 
                 $display_stock = explode('|',$data->display_stock);
                $m= 0;
                foreach($display_stock as $dt){
                if($m == $varient_id ){
                if($dt =='Yes'){
                $update_data['total_available_stock'] = $stock;
                }
                else if($dt =='No'){
                    $update_data['moq'] = $stock;
                }
                    }
                    $m++;
                }
                } 
                // print_r($update_data);
                // die;
            $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
            return $status = array('status'=>1,'message'=>'Product stocks updated'); 
            }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Stock');
        }
            
        
     }

public function add_varient($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];

        $data_varient = $this->db->query("SELECT * FROM products WHERE store_id in (SELECT store_id FROM shopper WHERE id = $id) and type!='Loose' and add_varient='Yes' and REPLACE(attribute1,'|','')='' and REPLACE(attribute2,'|','')='' and REPLACE(attribute3,'|','')=''    order by product_id")->result();
        //Store wise Attributes will changes
        $var = array();
        $get_attids = $this->db->query("SELECT attribute_ids FROM stores where store_id in (SELECT store_id FROM shopper WHERE id = $id)") ->result();
        if($get_attids){
            $attids = $get_attids[0]->attribute_ids;
            if($attids!=''){
               $var = $this->db->query("select * from attributes where id in ($attids) ")->result();
            }
        }
        
        $final_array = array();
        foreach($data_varient as $v){
            $var_cnt = count(explode('|',$v->pack_content));
            
            $final_array[] = array(
                        'product_id' => $v->product_id,
                        'product_name' => $v->product_name,
                        'product_nameold' => $v->display_name,
                        'varient_cnt' => $var_cnt
                        
                        );
            }

       if($final_array){
                        return $status = array('status'=>1,'message'=>'Product Varient List', 'data'=>$final_array,'attributes'=>$var); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Product variants updated');
        }
    }
    public function update_varient($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['product_id']) || empty($postdata['product_id']) || !isset($postdata['display_stock']) || empty($postdata['display_stock']) || !isset($postdata['primary_varient']) || empty($postdata['primary_varient'])){
            return false;
        }
            $product_id =  $postdata['product_id'];
            
            if(isset($postdata['attribute1']) && $postdata['attribute1']){
                $att_1 = $postdata['attribute1'];
                $get_attribute = explode(':',$att_1);
                $att1_id = $get_attribute[0];
                $attributes1 = $get_attribute[1];
                $attribute_var_1 = explode('|',$attributes1);
                $attribute1 ='';
                foreach($attribute_var_1 as $varient){
                    if($attribute1==''){
                    $attribute1 = $att1_id;
                    $varient1 = $varient;
                    }else{
                    $attribute1 = $attribute1.'|'.$att1_id; 
                    $varient1 = $varient1.'|'.$varient;
                    }
                    $update_data['attribute1'] =  $attribute1;
                    $update_data['varient1'] =  $varient1;
                }
            }
            // print_r($update_data); die;
            if(isset($postdata['attribute2']) && $postdata['attribute2']!='' ){
                $att_2 = $postdata['attribute2'];
                $get_attribute = explode(':',$att_2);
                $att2_id = $get_attribute[0];
                $attributes2 = $get_attribute[1];
                $attribute_var_2 = explode('|',$attributes2);
                $attribute2 ='';
                foreach($attribute_var_2 as $varient){
                    if($attribute2==''){
                    $attribute2 = $att2_id;
                    $varient2 = $varient;
                    }else{
                    $attribute2 = $attribute2.'|'.$att2_id; 
                    $varient2 = $varient2.'|'.$varient;
                    }
                    $update_data['attribute2'] =  $attribute2;
                    $update_data['varient2'] =  $varient2;
                }
            }
             if(isset($postdata['attribute3']) && $postdata['attribute3']){
                $att_3 = $postdata['attribute3'];
                $get_attribute = explode(':',$att_3);
                $att3_id = $get_attribute[0];
                $attributes3 = $get_attribute[1];
                $attribute_var_3 = explode('|',$attributes3);
                $attribute3 ='';
                foreach($attribute_var_3 as $varient){
                    if($attribute3==''){
                    $attribute3 = $att3_id;
                    $varient3 = $varient;
                    }else{
                    $attribute3 = $attribute3.'|'.$att3_id; 
                    $varient3 = $varient3.'|'.$varient;
                    }
                    $update_data['attribute3'] =  $attribute3;
                    $update_data['varient3'] =  $varient3;
                }
            }
            
            if(isset($postdata['mrp'])){
                $update_data['mrp_price'] = $postdata['mrp'];
            }
            if(isset($postdata['mop'])){
                $update_data['mop_price'] = $postdata['mop'];
            }
            if(isset($postdata['offer_price'])){
                $update_data['offer_price'] = $postdata['offer_price'];
            }
            if(isset($postdata['display_stock'])){
                $display_stock = explode('|',$postdata['display_stock']);
                // $stock = '';
                if(isset($postdata['stock'])){
                $stock =  explode('|',$postdata['stock']);
                }
                $i=0; $total_available_stock = 0;$moq =0;
                if($stock){
                foreach($display_stock as $dt){
                    if($dt =='Yes' || $dt =='YES'){
                        if($total_available_stock=='0'){
                            $total_available_stock = $stock[$i];
                        }
                        else{
                            $total_available_stock = $total_available_stock.'|'.$stock[$i];
                        }
                        if($moq!='0') { $moq = $moq.'|'.''; }  else { $moq =''; }
                    }
                    else if($dt =='No' || $dt=='NO'){
                        
                         if($moq=='0'){
                            $moq = $stock[$i];
                        }
                        else{
                            $moq = $moq.'|'.$stock[$i];
                        }
                        if($total_available_stock!='0') { $total_available_stock  = $total_available_stock.'|'.''; }  else { $total_available_stock =''; }
                    }
                    $i++;
                }
                $update_data['total_available_stock'] = $total_available_stock;
                $update_data['moq'] = $moq;
                }
                $update_data['display_stock'] = $postdata['display_stock'];
            }
            $update_data['primary_varient'] = $postdata['primary_varient'];
            $update_data['status'] = 1;
            
            // print_r($update_data);
            // die;
              $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
        if($status){
                        return $status = array('status'=>1,'message'=>'Product variants updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Varient Details');
        }
        
    }
public function completed_order($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $ord_array = array();
         $ord_qry = $this->db->query("SELECT ord.delivery_person_id,ord.delivery_status,ord.delivery_status_flg,ord.payment_status,ord.UTN_number orderid,cust.fullname,cust.email,cust.phone_no,'' as address,ord.city location,delivery_status,IFNULL('',deli_name)deli_name,ord.booking_time,ord.address1,ord.address2,ord.area,ord.landmark,ord.city,ord.district,ord.state,ord.pincode,ord.gps_coordinates FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN shopper seller on seller.store_id = str.store_id AND ord.store_id = seller.store_id  INNER JOIN user_profile cust on cust.user_id = ord.user_id LEFT join  delivery_persondtl del on del.deli_boy_id = ord.delivery_person_id WHERE seller.id = $id and delivery_status in (2,3,6) order by ord.order_id desc")->result();
        foreach($ord_qry as $ord){
            $dt_frmt=date_create($ord->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            $delivery_status = $ord->delivery_status;
            $delivery_status_flg = $ord->delivery_status_flg;
            // 0- Awaiting Store Confirmation
            // 1- Order Accepted
            // 2- Delivered
            // 3- Order Returned
            // 4 - Order Packed
            // 5 - Order Picked
            if($delivery_status==0){
                 $status = 'Awaiting Store Confirmation';
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $status = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $status = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $status = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $status = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //green
            }
            else if($delivery_status==4){
                $status = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            // else if($delivery_status==5){
            //     $status = 'Order Picked';
            //     $delivery_sts_clr = '#800080'; //purle
            // }
            else if($delivery_status==5 && $delivery_status_flg ==0){
                $status = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }
            else if($delivery_status==6){
                $status = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }
            else{
                $status = 'Order Placed';
                $delivery_sts_clr = '#000000'; //black
            }
            
            $delivery_person_name='';
            if($ord->delivery_person_id!='' && $ord->delivery_person_id!=0){
                $deli_boy_id = $ord->delivery_person_id;
                $del_data = $this->db->query("select * from delivery_persondtl where seller_id = $id and deli_boy_id = $deli_boy_id")->result();
                if($del_data){
                    $delivery_person_name = $del_data[0]->deli_name;
                }
            }
            
            $address = $ord->address1.', '.$ord->address2.', '.$ord->landmark.', '.$ord->area.', '.$ord->city.', '.$ord->district.', '.$ord->state.' - '.$ord->pincode;
            if($ord->address1==''){
            $address = '';
            }
            $ord_array[] = array(
            'payment_status'=>$ord->payment_status,
            'orderid' =>$ord->orderid,
            'fullname' =>$ord->fullname,
            'email' =>$ord->email,
            'phone_no' =>$ord->phone_no,
            'address' =>$address,
            'gps_coordinates'=>$ord->gps_coordinates,
            'location' =>$address,
            'delivery_status' =>$ord->delivery_status,
            'deli_name' =>$ord->deli_name,
            'order_status' =>$status,
            'delivery_sts_clr' =>$delivery_sts_clr,
            'order_time' => $booking_time,
            'delivery_person' =>$delivery_person_name
            );
            
        }
        
        if($ord_qry){
        return $status = array('status'=>1,'message'=>'Completed Order List', 'data'=>$ord_array); 
        }
        else{
            return false;
        }
        }
public function my_profile($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        // $profile_qry = $this->db->query("SELECT store_maplocation,id,seller.shopper_name seller_name,seller.email seller_email,seller.phone_no,seller.shopper_image seller_image,str.store_id,str.store_name,str.store_image,str.store_address1 as str_address1,str.store_address2 as  str_address2,str.city_town as str_citytown,str.pincode str_pincode,str.store_gst str_gstnumber,str.store_phone str_phone_no,store_banner1,store_banner2,store_banner3,str.offer_images,str.store_opening_status,str.order_prep_time,str.delivery_time,str.gps_coordinates FROM shopper as seller INNER JOIN stores as str on seller.store_id = str.store_id WHERE id =  $id ")->result();
        $profile_qry = $this->db->query("SELECT del_time,prep_time,store_maplocation,seller.id,seller.shopper_name seller_name,seller.email seller_email,seller.phone_no,seller.shopper_image seller_image,str.store_id,str.store_name,str.store_image,str.store_address1 as str_address1,str.store_address2 as  str_address2,area.area_locality,city.city_name,str.city_town as str_citytown,district.district,state.state,str.pincode str_pincode,str.store_gst str_gstnumber,str.store_phone str_phone_no,store_banner1,store_banner2,store_banner3,str.offer_images,str.store_opening_status,str.order_prep_time,str.delivery_time,str.gps_coordinates FROM shopper as seller INNER JOIN stores as str on seller.store_id = str.store_id INNER JOIN area ON area.id = str.area_id INNER JOIN city ON city.id = str.city_id INNER JOIN district on district.district_id = str.district_id INNER JOIN state ON  state.state_id = str.state_id WHERE seller.id = $id ")->result();
        if($profile_qry){
            $data = $profile_qry[0];
            //default 30 minutes
            $deltime_type  = 1; $deltime =30 ;
            $preptime_type  = 1; $preptime =30 ;
            if($data->del_time!=''){ //1 Minutes 2 Hours 3 Days
                $ex_del_time = explode("|",$data->del_time);  // 2|9 2 represent Hours so 9hours
                $deltime_type = $ex_del_time[0];
                $deltime = $ex_del_time[1];
            }
            if($data->prep_time!=''){ //1 Minutes 2 Hours 3 Days
                $ex_prep_time = explode("|",$data->prep_time);  // 2|9 2 represent Hours so 9hours
                $preptime_type = $ex_prep_time[0];
                $preptime = $ex_prep_time[1];
            }
            // if($data->order_prep_time=="00:59:59"){
            //   $order_prep_time  = "60";
            // }else{
            //       $prep=date_create($data->order_prep_time); //take minutes         
            //       $order_prep_time = ltrim( date_format($prep,"i"),"0");
            // }
            // if($data->delivery_time=="00:59:59"){
            //   $delivery_time  = "60";
            // }else{
            //       $del=date_create($data->delivery_time); //take minutes         
            //       $delivery_time = ltrim( date_format($del,"i"),"0");
            // }
            $profile_array[] = array (
                'id' =>$data->id,
                'seller_name' =>$data->seller_name,
                'seller_email' =>$data->seller_email,
                'phone_no' =>$data->phone_no,
                'seller_image' =>$data->seller_image,
                'store_id' =>$data->store_id,
                'store_name' =>$data->store_name,
                'store_image' =>$data->store_image,
                'str_address1' =>$data->str_address1,
                'str_address2' =>$data->str_address2,
                'area' =>$data->area_locality,
                'city' =>$data->city_name,
                'district' =>$data->district,
                'state' =>$data->state,
                'str_pincode' =>$data->str_pincode,
                'str_gstnumber' =>$data->str_gstnumber,
                'str_phone_no' =>$data->str_phone_no,
                'store_banner1' =>$data->store_banner1,
                'store_banner2' =>$data->store_banner2,
                'store_banner3' =>$data->store_banner3,
                'store_opening_status' =>$data->store_opening_status,
                'preptime_type'=>$preptime_type,
                'order_prep_time' =>$preptime,
                'deltime_type'=>$deltime_type,
                'delivery_time' =>$deltime,
                'gps_coordinates' => $data->gps_coordinates,
                'store_maplocation' =>$data->store_maplocation
                );
        return $status = array('status'=>1,'message'=>'Seller Profile Detail', 'data'=>$profile_array); 
        }
        else{
            return false;
        }
        }
public function offer_images($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $profile_qry = $this->db->query("SELECT id,seller.shopper_name seller_name,str.store_id, str.offer_images FROM shopper as seller INNER JOIN stores as str on seller.store_id = str.store_id WHERE id =  $id ")->result();
        if($profile_qry){
            $data = $profile_qry[0];
            $offer_images = $data->offer_images;
            $offer_image1 ='';$offer_image2 ='';$offer_image3='';
            if(!empty($offer_images)){
                $adds = explode("|",$offer_images);
                $cnt = count($adds);
                for($i=0;$i<$cnt;$i++){
                    switch($i){
                        case 0:
                            $offer_image1 = $adds[$i];
                            break;
                        case 1:
                            $offer_image2 = $adds[$i];
                            break;
                        case 2:
                            $offer_image3 = $adds[$i];
                            break;
                        default:
                            
                    }
                }
            }
            $offer_array = array (
                'seller_id' =>$data->id,
                'seller_name' =>$data->seller_name,
                'store_id'=>$data->store_id,
                'offer_image1' =>$offer_image1,
                'offer_image2' =>$offer_image2,
                'offer_image3' =>$offer_image3
                );
        return $status = array('status'=>1,'message'=>'Seller Offer Page', 'data'=>$offer_array); 
        }
        else{
            return false;
        }
        }
        public function update_profile($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
            $seller_id =  $postdata['seller_id'];
            $qry = $this->db->query("SELECT u.id seller_id,u.phone_no,email,shopper_name from shopper u where u.id='$seller_id'")->result();
            $store_id =  $postdata['store_id'];
            if(isset($postdata['store_bannerflg1']) && $postdata['store_bannerflg1']==1){ //remove 1st image
                $update_data['store_banner1'] = '';
            }else {
            if(isset($postdata['store_banner1'])){
            $update_data['store_banner1'] = $postdata['store_banner1'];    
            }
            }
            if(isset($postdata['store_bannerflg2']) && $postdata['store_bannerflg2']==1){ //remove 2nd image
                $update_data['store_banner2'] = '';
            }else {
            if(isset($postdata['store_banner2'])){
            $update_data['store_banner2'] = $postdata['store_banner2'];    
            }
            }
             if(isset($postdata['store_bannerflg3']) && $postdata['store_bannerflg3']==1){ //remove 3rd image
                $update_data['store_banner3'] = '';
            }else {
            if(isset($postdata['store_banner3'])){
            $update_data['store_banner3'] = $postdata['store_banner3'];    
            }
            }
            // if(isset($postdata['deltime_type']) && isset($postdata['delivery_time'])){
            //     $update_data['del_time'] = $postdata['deltime_type'].'|'.$postdata['delivery_time'];
            // }
            // if(isset($postdata['preptime_type']) && isset($postdata['order_prep_time'])){
            //     $update_data['prep_time'] = $postdata['preptime_type'].'|'.$postdata['order_prep_time'];
            // }
            
            if(isset($postdata['gps_coordinates'])){
                $update_data['gps_coordinates'] = $postdata['gps_coordinates'];    
            }
            if(isset($postdata['store_maplocation'])){
                $update_data['store_maplocation'] = $postdata['store_maplocation'];    
            }
            if(isset($update_data)){
            $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
            }
            else{
                return $status = array('status'=>1,'message'=>'No changes'); 
            }
        if($status){
            $email = $qry[0]->email;
            if($email){
            $seller_name = $qry[0]->shopper_name;
            $to_receiver_email = $email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellwomart123';
            $from_username = 'Yellow Mart - Mail';
            $subject="Profile Updated";
            $message = 
"Dear $seller_name,

Greetings! Your YellowMart Profile has been successfully updated.

Please reach out to us at hello@yellowmart.co.in, if this was not done by you.

Regards,
YellowMart Team";
             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
             if($response['status']==0){
                 return $result = array('status'=>1,'message'=>'Failed to send mail ', 'data'=>$val); 
             }                
            
            
            
            }
                        // return $status = array('status'=>1,'message'=>'Seller profile updated'); 
                        return $status = array('status'=>1,'message'=>'Profile updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Profile');
        }
        
     }
     public function update_offerimg($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $store_id =  $postdata['store_id'];
        $data = $this->db->query("select * from stores where store_id = $store_id ")->result();
        $imgs = $data[0]->offer_images;
        $images = explode('|',$imgs);
            
            if(isset($postdata['offer_image1'])){
            $offer_images = $postdata['offer_image1'];    
            }
            else{
                $offer_images = $images[0];
            }
            if(isset($postdata['offer_image2'])){
            $offer_images = $offer_images .'|'. $postdata['offer_image2'];    
            }
            else{
                $offer_images = $offer_images .'|'.  $images[1];
            }
            if(isset($postdata['offer_image3'])){
            $offer_images = $offer_images .'|'. $postdata['offer_image3'];      
            }
            $update_data['offer_images'] = $offer_images;
            if(isset($update_data)){
            $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
            }
            else{
                $offer_images = $offer_images .'|'.  $images[2];
            }
        if($status){
                        return $status = array('status'=>1,'message'=>'Store ads updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Offer Images');
        }
        
     }
     public function paymentupi($postdata='') {
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])  || !isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $seller_id = $postdata['seller_id'];
        $store_id = $postdata['store_id'];
        $query = $this->db->query("select store_id,upi_id,upi_mobile,upi_qrcode from stores where store_id = $store_id")->result();
        if($query){
            return $result = array('status'=>1,'message'=>'UPI Payment Details','data' =>$query);
        }
         else {
            return false;
        }
    }
    
    public function submit_paymentupi($postdata='') {
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])  || !isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $store_id = $postdata['store_id'];
        if(isset($postdata['upi_qrcode'])){
            $update_data['upi_qrcode'] = $postdata['upi_qrcode'];
        }
        $update_data['upi_id']  = $postdata['upi_id'];
        $update_data['upi_mobile']  = $postdata['upi_mobile'];
        $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
        if($status){
            // return $result = array('status'=>1,'message'=>'UPI payment details updated');
            return $result = array('status'=>1,'message'=>'Payment details updated');
        }
         else {
            return false;
        }
    }
    public function update_storestatus($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
            $store_id =  $postdata['store_id'];
            $update_data['store_opening_status'] = $postdata['store_opening_status'];    
            $status = $this->db->update('stores',$update_data,array('store_id'=>$store_id));
        if($status){
                        return $status = array('status'=>1,'message'=>'Store Opening Status Updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Store Status');
        }
        
     }
       public function submitcancel_order($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['store_id']) || empty($postdata['store_id'])  || !isset($postdata['order_id']) || empty($postdata['order_id'])){
            return false;
        }
            $store_id =  $postdata['store_id'];
            $seller_id =  $postdata['store_id'];
            $UTN_number = $postdata['order_id'];
            $update_data1['status'] = 4;   //order cancelled
            $update_data1['delivery_status'] = 6;   //order cancelled
           $update_data1['delivery_charge'] = 0;   //order cancelled so charge 0
            $update_data1['packing_charge'] = 0;   //order cancelled
            // $status = $this->db->update('orders',$update_data1,array('UTN_number'=>$UTN_number));
            
            //For cancelled order update(add) stock back to products table
            
            $ord_data = $this->db->query("select * from orders where UTN_number = '$UTN_number'")->result();
            if($ord_data){
                $total_amount = $ord_data[0]->tot_order_base_amt;
                $update_data1['total_amount'] = $total_amount;
                $status = $this->db->update('orders',$update_data1,array('UTN_number'=>$UTN_number));
                
                $order_id = $ord_data[0]->order_id;
                $user_id = $ord_data[0]->user_id;
            $result = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN products ON products.product_id = cart.product_id where user.user_id = $user_id and order_id = $order_id")->result();
                $count = count($result);
                $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data){
        $product_id  = $data->product_id;
        $pro_data = $this->db->query("select * from products where product_id = $product_id")->result();
        $type = $pro_data[0]->type;
        $total = $total + $data->price;
        $total_mrp = $total_mrp + $data->mrp_price;
        $items_in_cart = $items_in_cart + $data->quantity;
        $varient_id = $data->varient_id;
        $total_available_stock_final = 0; $moq_final = 0;
        
        if(strtoupper($type)=='LOOSE'){
            $total_available_stock_final= ''; $moq_final = '';
            $sale_unit = explode('|',$pro_data[0]->sale_unit);
            $sale_unit = $sale_unit[$varient_id];
            $pack_content = explode('|',$pro_data[0]->pack_content);
            $pack_content = $pack_content[$varient_id];
            $stock_unit = explode('|',$pro_data[0]->stock_unit);
            $stock_unit = $stock_unit[0];
            $stock_add = 0;
            $display_stock = explode('|',$pro_data[0]->display_stock);
            if(strtoupper($display_stock[0])=='YES'){
                $total_available_stock = str_replace('|','',$pro_data[0]->total_available_stock);
                //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock
                if($sale_unit!=$stock_unit){
                     if($sale_unit == 1){ //ml to ltr
                    $stock_add = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 2){ //ltr to ltr
                    $stock_add = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 3){ //gram to kg
                    $stock_add = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 5){//kg to kg
                    $stock_add = ($pack_content * $data->quantity);
                }
                
                else if($sale_unit == 4){//box
                    $stock_add = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 6){ //pcs
                    $stock_add = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 7){ //nos
                    $stock_add = ($pack_content * $data->quantity);
                }
                $total_available_stock_final = $total_available_stock + $stock_add;
                }
                else{ //if sale unit and stock unit same unit, so directly minus quantity
                    $total_available_stock = str_replace('|','',$pro_data[0]->total_available_stock);
                    $total_available_stock_final = $total_available_stock + ($pack_content * $data->quantity);
                 }
                
            }
        }

        if(strtoupper($type)!='LOOSE'){
            $display_stock =  explode('|',$pro_data[0]->display_stock);
            $j=0; $total_available_stock_final= ''; $moq_final = '';
                foreach($display_stock as $dt){
                if(strtoupper($dt) =='YES'){
                $total_available_stock = explode('|',$pro_data[0]->total_available_stock);
                if($j == $varient_id ){
                    if($total_available_stock_final==''){
                        $total_available_stock_final = $total_available_stock[$j]+$data->quantity;
                    }else{
                $total_available_stock_final = $total_available_stock_final.'|'.($total_available_stock[$j]+$data->quantity);
                    }
                }
                else{
                     if($total_available_stock_final==''){
                        $total_available_stock_final = $total_available_stock[$j];
                    }else{
                 $total_available_stock_final = $total_available_stock_final.'|'.$total_available_stock[$j];   
                }
                }
                // $moq_final = $moq_final.'|';  
                }
                else if($dt =='No'){
                    
                    //For MOQ no need minus stock
                //     $stock = explode('|',$pro_data[0]->moq);
                //     if($j == $varient_id ){
                //     if($moq_final==''){
                //         $moq_final = $stock[$j]-$data->quantity;
                //     }else{
                // $moq_final = $moq_final.'|'.$stock[$j]-$data->quantity;
                //     }
                // }
                // else{
                //      if($moq_final==''){
                //         $moq_final = $moq[$j];
                //     }else{
                //  $moq_final = $moq_final.'|'.$moq[$j];   
                // }
                // }
                
                $total_available_stock_final = $total_available_stock_final.'|';  
                }
                $j++;
                }
                
            
        }
    
        $update_data['total_available_stock'] ='';
              if($total_available_stock_final!='' || $total_available_stock_final ==0){
                $update_data['total_available_stock'] = $total_available_stock_final;
                }
    //             //No need to minus MOQ that is minimum order quantity
    //             // if($moq_final!=''){
    //             // $update_data['moq'] = $moq_final;
    //             // }
                
       
    //         // print_r($update_data);
    //         // die;
            if(isset($update_data)){
                if($update_data['total_available_stock']!='' || $update_data['total_available_stock']==0){
          $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
                }
            }
    } 
            }
     //send push notification to customer
             $customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where usr.user_id = $user_id AND ord.UTN_number = '$UTN_number'")->result();
             if($customer){
                    $token_key = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name; 
                    $message ="ORDER#$UTN_number   $store_name - Order cancelled. Please contact support for any queries.";
                    $title = "Order cancelled";
                    $notify_type = "order_cancelled";
                    $user_id = $user_id;
                    $seller_id = $customer[0]->seller_id;
                    $delivery_boyid = 0;
                    $notified_person = "customer";
                    if($token_key!=''){
                    $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
                    }
                }    
        if($status){
            return $status = array('status'=>1,'message'=>'Order status updated'); 
        }
        else{
             return $result = array('status'=>0,'message'=>'Failed to Update Order Status');
        }
        
     
        
    }
    public function selleradd_productslist($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $product_qry = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id and products.status = 1 and products.availability = 1 ")->result();    
        if($product_qry){
        $final_array =array();
        foreach($product_qry as $prd){
            $type = $prd->type;
            $UTN_number = $postdata['order_id'];
            $product_id = $prd->product_id;
            $orddata = $this->db->query("select product_id,varient_id,SUM(quantity)quantity from orders ord inner join cart on ord.order_id = cart.order_id where ord.UTN_number = '$UTN_number' and product_id = $product_id and product_status not in (0) GROUP BY product_id,varient_id")->result();
            if(strtoupper($type)=='LOOSE'){
                $varients = explode('|',$prd->sale_unit);
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                // $total_available_stock = explode('|',$prd->total_available_stock);
                // $moq = explode('|',$prd->moq);
                $total_available_stock = $prd->total_available_stock;
                $moq = $prd->moq;
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                    if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){//range price
                        // $price = round(($mop_price[$i] + $mrp_price[$i])/2,2); //avg of mop & mrp
                        $price = $mrp_price[$i]; //take maximum so MRP
                    }
                    else{ // request of price //don't list this product
                        $price = $mrp_price[$i];
                    }
                    //Stock 
                    if($display_stock[0]=='Yes'){
                        $stock = str_replace("|", "","$total_available_stock");
                        $sl_unit = $sale_unit[$i];
                        $stock_unit = explode("|",$prd->stock_unit);
                        $stock_unit = $stock_unit[0];
                        $pack_cnt = $pack_content[$i];
                        if($sl_unit!=$stock_unit){
                            if($sl_unit == 1){ //ml to ltr  ex. 5ltr total stck 500ml packet connte
                                $converted = $pack_cnt / 1000;   // 500ml /1000 = 0.5ltr
                                $stock = $stock / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                            }
                            else if($sl_unit == 2){ //ltr to ltr
                                $stock = $stock/$pack_cnt;
                            }
                            else if($sl_unit == 3){ //gram to kg
                                $converted = $pack_cnt / 1000; 
                                $stock = $stock / $converted ;
                            }
                            else if($sl_unit == 5){//kg to kg
                                $stock = $stock / $pack_cnt;
                            }
                            else{ //other than kg,ltr,gram,ml
                                $stock = $stock;
                            }
                        }
                    else{
                             if(($sl_unit == 1) || ($sl_unit == 2) || ($sl_unit == 3) || ($sl_unit == 5) ){
                                $stock = $stock /$pack_cnt;
                            }
                            else {
                                $stock = $stock;
                            }
                         }
                        }
                    else{
                        $stock = str_replace("|", "","$moq"); //10
                    }
                    if($stock>10){
                            $stock = 10;
                    }
                    //minus useradded stock from curret moq stock
                            if($orddata){
                                foreach($orddata as $od){
                                    if($od->varient_id==$i){ 
                                        $useraddedqty = $od->quantity;//2
                                        $chk_qty = $useraddedqty + $stock;
                                        $chk_qty = 10 - $useraddedqty;
                                        if($chk_qty<=$stock){
                                            $stock = 10 - $useraddedqty;
                                        }else{
                                            $stock = $stock;
                                        }
                                    }
                                }
                            }
                    //varient for loose
                    $s_unit =$sale_unit[$i];
                    $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                    if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                    }
                    
                    $pck = $pack_content[$i];
                    $varient_name =$pck.' '.$sale_unittext;
                
                //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                $stock = (int)$stock; //1.75 to 1
                // $stock = round($stock, 0, PHP_ROUND_HALF_DOWN); //2.5 into 2kg// only for loose product 
                   $display_type = $price_to_display[$i];
                    if($stock>0 && $display_type!=5){//don't list request of price product
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient_id' =>$i,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price
                    );
                }
                
                }
            }
            else{
                
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                $total_available_stock = explode('|',$prd->total_available_stock);
                $moq = explode('|',$prd->moq);
                $add_variant = $prd->add_varient;
                if(strtoupper($add_variant)=='YES'){
                //Varient1
                if($prd->varient1!='' && $prd->varient1!='|'){
                $varient1 = explode('|',$prd->varient1);
                }
                else{
                   $varient1 =''; 
                }
                //attribute1
                if($prd->attribute1!='' && $prd->attribute1!='|'){
                $attribute1 = explode('|',$prd->attribute1);
                }
                else{
                   $attribute1 =''; 
                }


               //Varient2
                if($prd->varient2!='' && $prd->varient2!='|'){
                $varient2 = explode('|',$prd->varient2);
                }
                else{
                   $varient2 =''; 
                }
                //attribute2
                if($prd->attribute2!='' && $prd->attribute2!='|'){
                $attribute2 = explode('|',$prd->attribute2);
                }
                else{
                   $attribute2 =''; 
                }
                
                //Varient3
                if($prd->varient3!='' && $prd->varient3!='|'){
                $varient3 = explode('|',$prd->varient3);
                }
                else{
                   $varient3 =''; 
                }
                //attribute3
                if($prd->attribute3!='' && $prd->attribute3!='|'){
                $attribute3 = explode('|',$prd->attribute3);
                }
                else{
                   $attribute3 =''; 
                }
                }
                
                $varients = explode('|',$prd->sale_unit);
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                    if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){//range price
                        // $price = round(($mop_price[$i] + $mrp_price[$i])/2,2); //avg of mop & mrp
                        $price = $mrp_price[$i]; //take maximum so MRP
                    }
                    else{ // request of price //don't list this product
                        $price = $mrp_price[$i];
                    }
                    //Stock 
                    if($display_stock[$i]=='Yes'){
                        $stock = $total_available_stock[$i];
                    }
                    else{
                        $stock = $moq[$i];//10
                    }
                    if($stock>10){
                            $stock = 10;
                    }
                    //minus useradded stock from curret moq stock
                            if($orddata){
                                foreach($orddata as $od){
                                    if($od->varient_id==$i){ 
                                        $useraddedqty = $od->quantity;//2
                                        $chk_qty = $useraddedqty + $stock;
                                        $chk_qty = 10 - $useraddedqty;
                                        if($chk_qty<=$stock){
                                            $stock = 10 - $useraddedqty;
                                        }else{
                                            $stock = $stock;
                                        }
                                    }
                                }
                            }
                    //varient for packet
                    if(strtoupper($prd->add_varient)=='YES'){
                        $attribute=''; $attribute_varient1='';$attribute_varient2='';$attribute_varient3='';
                        $varient_n1 =''; $varient_n2 =''; $varient_n3 ='';
                        if($attribute1){
                            $att1 = $attribute1[$i];
                            if($att1!=''){
                            $att = $this->db->query("select * from attributes where id =$att1 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient1 = $attribute.' : '.$varient1[$i];
                         $varient_n1 = $varient1[$i];
                        }}
                        if($attribute2){
                            $att2 = $attribute2[$i];
                            if($att2!=''){
                            $att = $this->db->query("select * from attributes where id =$att2 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient2 = $attribute.' : '.$varient2[$i];
                         $varient_n2 = $varient2[$i];
                        }}
                        if($attribute3){
                             $att3 = $attribute3[$i];
                             if($att3!=''){
                            $att = $this->db->query("select * from attributes where id =$att3 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient3 = $attribute.' : '.$varient3[$i];
                         $varient_n3 = $varient3[$i];
                        }}
                        // $varient_name = $attribute_varient1.' '.$attribute_varient2.' '.$attribute_varient3; //Flavour : Plain
                             $varient_name = $varient_n1.';'.$varient_n2.';'.$varient_n3;
                             $varient_name = rtrim($varient_name, ";");
                    }else{
                        //varient for loose
                        $s_unit =$sale_unit[$i];
                        $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                        if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                        }
                        
                        $pck = $pack_content[$i];
                        $varient_name =$pck.' '.$sale_unittext; 
                    }
                    //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                     $display_type = $price_to_display[$i];
                    if($stock>0 && $display_type!=5){//don't list request of price product
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient_id' =>$i,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price
                    );
                }
                
                }
            }

        }
        if ($final_array > 0) {
                return $status = array('status'=>1,'message'=>'Seller Add Product List', 'data'=>$final_array); 
        }
        }
        else{
             return $result = array('status'=>0,'message'=>'Products Not Found');
        }
    }
    
public function selleraddproduct_search($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $keyword ='';
        if(isset($postdata['keyword'])){
        $keyword = $postdata['keyword'];
        }
        if($keyword!=''){
        $product_qry = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id AND (products.product_name LIKE '%$keyword%' || display_name LIKE '%$keyword%'  ) and products.status = 1 and products.availability = 1 ")->result();
        }else{
        $product_qry = $this->db->query("SELECT products.* FROM products INNER JOIN shopper seller ON products.store_id =  seller.store_id  WHERE seller.id =  $id and products.status = 1 and products.availability = 1")->result();    
        }
        if($product_qry){
        $final_array =array();
        foreach($product_qry as $prd){
            $type = $prd->type;
            $UTN_number = $postdata['order_id'];
            $product_id = $prd->product_id;
            $orddata = $this->db->query("select product_id,varient_id,SUM(quantity)quantity from orders ord inner join cart on ord.order_id = cart.order_id where ord.UTN_number = '$UTN_number' and product_id = $product_id and product_status not in (0) GROUP BY product_id,varient_id")->result();
            if(strtoupper($type)=='LOOSE'){
                $varients = explode('|',$prd->sale_unit);
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                // $total_available_stock = explode('|',$prd->total_available_stock);
                // $moq = explode('|',$prd->moq);
                $total_available_stock = $prd->total_available_stock;
                $moq = $prd->moq;
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                    if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){//range price
                        // $price = round(($mop_price[$i] + $mrp_price[$i])/2,2); //avg of mop & mrp
                        $price = $mrp_price[$i]; //take maximum so MRP
                    }
                    else{ // request of price //don't list this product
                        $price = $mrp_price[$i];
                    }
                    //Stock 
                    if(strtoupper($display_stock[0])=='YES'){
                        $stock = str_replace("|", "","$total_available_stock");
                        $sl_unit = $sale_unit[$i];
                        $stock_unit = explode("|",$prd->stock_unit);
                        $stock_unit = $stock_unit[0];
                        $pack_cnt = $pack_content[$i];
                        if($sl_unit!=$stock_unit){
                            if($sl_unit == 1){ //ml to ltr  ex. 5ltr total stck 500ml packet connte
                                $converted = $pack_cnt / 1000;   // 500ml /1000 = 0.5ltr
                                $stock = $stock / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                            }
                            else if($sl_unit == 2){ //ltr to ltr
                                $stock = $stock/$pack_cnt;
                            }
                            else if($sl_unit == 3){ //gram to kg
                                $converted = $pack_cnt / 1000; 
                                $stock = $stock / $converted ;
                            }
                            else if($sl_unit == 5){//kg to kg
                                $stock = $stock / $pack_cnt;
                            }
                            else{ //other than kg,ltr,gram,ml
                                $stock = $stock;
                            }
                        }
                    else{
                             if(($sl_unit == 1) || ($sl_unit == 2) || ($sl_unit == 3) || ($sl_unit == 5) ){
                                $stock = $stock /$pack_cnt;
                            }
                            else {
                                $stock = $stock;
                            }
                         }
                        }
                    else{
                        $stock = str_replace("|", "","$moq"); //10
                    }
                    if($stock>10){  
                            $stock = 10;
                    }
                    
                    //minus useradded stock from curret moq stock
                            if($orddata){
                                foreach($orddata as $od){
                                    if($od->varient_id==$i){ 
                                        $useraddedqty = $od->quantity;//2
                                        $chk_qty = $useraddedqty + $stock;
                                        $chk_qty = 10 - $useraddedqty;
                                        if($chk_qty<=$stock){
                                            $stock = 10 - $useraddedqty;
                                        }else{
                                            $stock = $stock;
                                        }
                                    }
                                }
                            }
                    //varient for loose
                    $s_unit =$sale_unit[$i];
                    $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                    if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                    }
                    
                    $pck = $pack_content[$i];
                    $varient_name =$pck.' '.$sale_unittext;
                
                //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                $stock = (int)$stock; //1.75 to 1
                // $stock = round($stock, 0, PHP_ROUND_HALF_DOWN); //2.5 into 2kg// only for loose product 
                if ((stripos($display_name_final,$keyword) !== false) || (stripos($prd->product_name,$keyword) !== false) || $keyword=="" ) {
                     $display_type = $price_to_display[$i];
                    if($stock>0 && $display_type!=5){//don't list request of price product
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient_id' =>$i,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price
                    );
                }
                }
                }
            }
            else{
                
                $sale_unit = explode('|',$prd->sale_unit);
                $pack_content = explode('|',$prd->pack_content);
                $price_to_display = explode('|',$prd->price_to_display);
                $display_stock = explode('|',$prd->display_stock);
                $mrp_price = explode('|',$prd->mrp_price);
                $mop_price = explode('|',$prd->mop_price);
                $offer_price = explode('|',$prd->offer_price);
                $total_available_stock = explode('|',$prd->total_available_stock);
                $moq = explode('|',$prd->moq);
                $add_variant = $prd->add_varient;
                if(strtoupper($add_variant)=='YES'){
                //Varient1
                if($prd->varient1!='' && $prd->varient1!='|'){
                $varient1 = explode('|',$prd->varient1);
                }
                else{
                   $varient1 =''; 
                }
                //attribute1
                if($prd->attribute1!='' && $prd->attribute1!='|'){
                $attribute1 = explode('|',$prd->attribute1);
                }
                else{
                   $attribute1 =''; 
                }


               //Varient2
                if($prd->varient2!='' && $prd->varient2!='|'){
                $varient2 = explode('|',$prd->varient2);
                }
                else{
                   $varient2 =''; 
                }
                //attribute2
                if($prd->attribute2!='' && $prd->attribute2!='|'){
                $attribute2 = explode('|',$prd->attribute2);
                }
                else{
                   $attribute2 =''; 
                }
                
                //Varient3
                if($prd->varient3!='' && $prd->varient3!='|'){
                $varient3 = explode('|',$prd->varient3);
                }
                else{
                   $varient3 =''; 
                }
                //attribute3
                if($prd->attribute3!='' && $prd->attribute3!='|'){
                $attribute3 = explode('|',$prd->attribute3);
                }
                else{
                   $attribute3 =''; 
                }
                }
                
                $varients = explode('|',$prd->sale_unit);
                $cnt = count($varients);
                for($i=0;$i<$cnt;$i++){
                    //Price section
                   if($price_to_display[$i]==1){
                        $price = $mrp_price[$i];
                    }else if($price_to_display[$i]==2){
                        $price = $mop_price[$i];
                    }
                    else if($price_to_display[$i]==3){
                        $price = $offer_price[$i];
                    }
                    else if($price_to_display[$i]==4){//range price
                        // $price = round(($mop_price[$i] + $mrp_price[$i])/2,2); //avg of mop & mrp
                        $price = $mrp_price[$i]; //take maximum so MRP
                    }
                    else{ // request of price //don't list this product
                        $price = $mrp_price[$i];
                    }
                    //Stock 
                    if($display_stock[$i]=='Yes'){
                        $stock = $total_available_stock[$i];
                    }
                    else{
                        $stock = $moq[$i];//10
                    }
                    if($stock>10){
                            $stock = 10;
                    }
                    //minus useradded stock from curret moq stock
                            if($orddata){
                                foreach($orddata as $od){
                                    if($od->varient_id==$i){ 
                                        $useraddedqty = $od->quantity;//2
                                        $chk_qty = $useraddedqty + $stock;
                                        $chk_qty = 10 - $useraddedqty;
                                        if($chk_qty<=$stock){
                                            $stock = 10 - $useraddedqty;
                                        }else{
                                            $stock = $stock;
                                        }
                                    }
                                }
                            }
                    //varient for packet
                    if(strtoupper($prd->add_varient)=='YES'){
                        $attribute=''; $attribute_varient1='';$attribute_varient2='';$attribute_varient3='';
                        $varient_n1 =''; $varient_n2 =''; $varient_n3 ='';
                        if($attribute1){
                            $att1 = $attribute1[$i];
                            if($att1!=''){
                            $att = $this->db->query("select * from attributes where id =$att1 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient1 = $attribute.' : '.$varient1[$i];
                         $varient_n1 = $varient1[$i];
                        }}
                        if($attribute2){
                            $att2 = $attribute2[$i];
                            if($att2!=''){
                            $att = $this->db->query("select * from attributes where id =$att2 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient2 = $attribute.' : '.$varient2[$i];
                         $varient_n2 = $varient2[$i];
                        }}
                        if($attribute3){
                             $att3 = $attribute3[$i];
                             if($att3!=''){
                            $att = $this->db->query("select * from attributes where id =$att3 ")->result();
                                if($att){
                                    $attribute = $att[0]->attribute_name;  
                                }
                         $attribute_varient3 = $attribute.' : '.$varient3[$i];
                         $varient_n3 = $varient3[$i];
                        }}
                        // $varient_name = $attribute_varient1.' '.$attribute_varient2.' '.$attribute_varient3; //Flavour : Plain
                             $varient_name = $varient_n1.';'.$varient_n2.';'.$varient_n3;
                             $varient_name = rtrim($varient_name, ";");
                    }else{
                        //varient for loose
                        $s_unit =$sale_unit[$i];
                        $unit_dt = $this->db->query("select * from product_units where id = $s_unit")->result();
                        if($unit_dt){
                        $sale_unittext =$unit_dt[0]->unit;
                        }
                        
                        $pck = $pack_content[$i];
                        $varient_name =$pck.' '.$sale_unittext; 
                    }
                    //display name will change varient wise
                $dn_id = $i;
                $varwise_display_name = explode("|",$prd->display_name);
                if(isset($varwise_display_name[$dn_id])){
                $display_name_final = $varwise_display_name[$dn_id];
                }else{
                    $display_name_final = $prd->product_name;
                }
                if ((stripos($display_name_final,$keyword) !== false) || (stripos($prd->product_name,$keyword) !== false) || $keyword=="" ) {
                     $display_type = $price_to_display[$i];
                    if($stock>0 && $display_type!=5){//don't list request of price product
                $final_array[] = array (
                    'product_id'=>$prd->product_id,
                    'product_name' =>$display_name_final,
                    'product_nameold' =>$prd->product_name,
                    'varient_id' =>$i,
                    'varient' =>$varient_name,
                    'stock' =>$stock,
                    'price' =>$price
                    );
                }
                }
                }
            }

        }
        if ($final_array > 0) {
                return $status = array('status'=>1,'message'=>'Seller Add Product Search List', 'data'=>$final_array); 
        }
        }
        else{
             return $result = array('status'=>0,'message'=>'Products Not Found');
        }
    }
    public function seller_addproduct($postdata=array()){
     if(isset($postdata['varient_name'])){
           $varient_name = $postdata['varient_name']; 
        }else{
            $varient_name = '';
        }
    $orderutn_id = $postdata['order_id'];    
    $user_id = $postdata['user_id'];
    $product_id = $postdata['product_id'];
    $store_id = $postdata['store_id'];
    $varient_id = $postdata['varient_id'];
    $quantity = $postdata['quantity'];
    //update unselected item product status as '0' (applicable for customer added product)
    $selected_item_id = $postdata['selected_item_id'];
        if($selected_item_id){
        $item_ids =explode("|",$selected_item_id);
        }
        if($item_ids){
        $data = $this->db->query("select * from orders where UTN_number ='$orderutn_id' ")->result(); 
        if($data){
            $order_id= $data[0]->order_id;
        }
        //update all cart products as not selected 
            $this->db->where('product_addby_seller','0');//(applicable for customer added product)
            $this->db->where("order_id = '$order_id'");
            $this->db->set('product_status','0');
            $status1 = $this->db->update('cart'); 
        foreach($item_ids as $cart_id){ //updated selected item = 1 active
            $this->db->where('product_addby_seller','0'); //(applicable for customer added product)
            $this->db->where("cart_id = '$cart_id'");
            $this->db->set('product_status','1');
            $status2 = $this->db->update('cart');
        }
        }
        
    $pro = $this->db->query("select * from products where product_id = $product_id")->result();
    if(empty($pro)){
        return false; 
    }
    $product_desc  = $pro[0]->description;
    $product_image  = $pro[0]->product_image;
    $type = $pro[0]->type;
    $rate = str_replace( ',', '', $postdata['rate'] );
    $price = $quantity * $rate;
    
        $pro_data = $this->db->query("select * from products where product_id = $product_id")->result();
        $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0;
        $mrp_final = 0; $mop_final =0; $offer_final=0;
        $billing_rate =0; $billing_price=0;
        $mrp_rate = 0; $mrp_price = 0;
        if($pro_data){
            $price_to_display = explode('|',$pro_data[0]->price_to_display);
            $mrp_prc = $pro_data[0]->mrp_price; $exmrp_prc = explode("|",$mrp_prc); 
            $mrp_final = $exmrp_prc[$varient_id];
            $mop_prc = $pro_data[0]->mop_price; $exmop_prc = explode("|",$mop_prc); 
            if($price_to_display[$varient_id]==1){ //MRP
                        $display_rate = $exmrp_prc[$varient_id]; //
                        $billing_rate = $exmop_prc[$varient_id];
                   }else if($price_to_display[$varient_id]==2){ //Mop
                        $display_rate =  $exmop_prc[$varient_id];
                        $billing_rate = $display_rate;
                   }else if($price_to_display[$varient_id]==3){ //Offer price
                        $offer_prc = $pro_data[0]->offer_price; $exoffer_prc = explode("|",$offer_prc);
                        $display_rate =  $exoffer_prc[$varient_id];
                        $billing_rate = $display_rate;
                   }else if($price_to_display[$varient_id]==4){ //range price
                        // $rangeprice = ($exmop_prc[$varient_id] + $exmrp_prc[$varient_id])/2; // take verage of mop & mrp for price range
                        $rangeprice = $exmrp_prc[$varient_id]; // take maximum price so mrp 
                        $display_rate = $rangeprice;
                        $billing_rate = $rangeprice;
                    }else{
                        $display_rate = $exmrp_prc[$varient_id]; //
                        $billing_rate = $exmrp_prc[$varient_id];
                    }
        
        
                ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_final);
        $mrp_price = str_replace(',','',$mrp_final) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display[$varient_id];
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_final;
            $billing_price = str_replace(',','',$mrp_final) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->HSN_code;
        $CGSTperc = $pro_data[0]->CGST;
        $SGST_IGSTperc = $pro_data[0]->SGST_IGST;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        
        }
        $ord_data = $this->db->query("select * from orders where utn_number ='$orderutn_id'")->result();
        $ord_id = $ord_data[0]->order_id;
        
// $status= $this->db->insert('cart', array('user_id'=>$user_id,'product_id'=>$product_id,'store_id'=>$store_id,'varient_id'=>$varient_id,'quantity'=>$quantity,'product_desc'=>$product_desc,'product_image'=>$product_image,'rate'=>$billing_rate,'price'=>$billing_price,'mrp_rate'=>$mrp_rate,'billing_type'=>$billing_type,'mrp_price'=>$mrp_price,'type'=>$type,'varient_name'=>$varient_name,'product_status'=>3,'order_id'=>$ord_id));
$status= $this->db->insert('cart', array('user_id'=>$user_id,'product_id'=>$product_id,'store_id'=>$store_id,'varient_id'=>$varient_id,'quantity'=>$quantity,'product_desc'=>$product_desc,'product_image'=>$product_image,'rate'=>$billing_rate,'price'=>$billing_price,'mrp_rate'=>$mrp_rate,'billing_type'=>$billing_type,'mrp_price'=>$mrp_price,'type'=>$type,'varient_name'=>$varient_name,'product_status'=>3,'order_id'=>$ord_id,'base_amt' =>$base_amt,'HSN_code'=>$HSN_code,'CGST'=>$CGST,'SGST_IGST'=>$SGST_IGST));
//update stock for only newly added item
if($status){
    //  $result = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN products ON products.product_id = cart.product_id where user.user_id = $user_id and cart.product_status in (0,1,3) and order_id =$ord_id ")->result();
    $result = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN products ON products.product_id = cart.product_id where user.user_id = $user_id and cart.product_status in (3) and order_id =$ord_id and stockupdate_status=0 ")->result();
    $count = count($result);
    // print_r($result);
    // die;
     $final_array =array();
     $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data){ 
        $product_id  = $data->product_id;
        $pro_data = $this->db->query("select * from products where product_id = $product_id")->result();
        $type = $pro_data[0]->type;
        // $total = $total + $data->price;
        // $items_in_cart = $items_in_cart + $data->quantity;
        $varient_id = $data->varient_id;
        $total_available_stock_final = 0; $moq_final = 0;
        
        if($type=='Loose'){
            $total_available_stock_final= ''; $moq_final = '';
            $sale_unit = explode('|',$pro_data[0]->sale_unit);
            $sale_unit = $sale_unit[$varient_id];
            $pack_content = explode('|',$pro_data[0]->pack_content);
            $pack_content = $pack_content[$varient_id];
            $stock_unit = explode('|',$pro_data[0]->stock_unit);
            $stock_unit = $stock_unit[0];
            $stock_minus = 0;
            $display_stock = explode('|',$pro_data[0]->display_stock);
            if($display_stock[0]=='Yes'){
                $total_available_stock = str_replace('|','',$pro_data[0]->total_available_stock);
                //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock
                if($sale_unit!=$stock_unit){
                     if($sale_unit == 1){ //ml to ltr
                    $stock_minus = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 2){ //ltr to ltr
                    $stock_minus = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 3){ //gram to kg
                    $stock_minus = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 5){//kg to kg
                    $stock_minus = ($pack_content * $data->quantity);
                }
                
                else if($sale_unit == 4){//box
                    $stock_minus = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 6){ //pcs
                    $stock_minus = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 7){ //nos
                    $stock_minus = ($pack_content * $data->quantity);
                }
                $total_available_stock_final = $total_available_stock - $stock_minus;
                }
                else{ //if sale unit and stock unit same unit, so directly minus quantity
                    $total_available_stock = str_replace('|','',$pro_data[0]->total_available_stock);
                    $total_available_stock_final = $total_available_stock - ($pack_content * $data->quantity);
                 }
                
            }
            else{

                $moq = str_replace('|','',$pro_data[0]->moq);
                //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock
                if($sale_unit!=$stock_unit){
                     if($sale_unit == 1){ //ml to ltr
                    $stock_minus = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 2){ //ltr to ltr
                    $stock_minus = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 3){ //gram to kg
                    $stock_minus = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 5){//kg to kg
                    $stock_minus = ($pack_content * $data->quantity);
                }
                
                else if($sale_unit == 4){//box
                    $stock_minus = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 6){ //pcs
                    $stock_minus = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 7){ //nos
                    $stock_minus = ($pack_content * $data->quantity);
                }
                $moq_final = $moq - $stock_minus;
                }
                else{ //if sale unit and stock unit same unit, so directly minus quantity
                    $moq = str_replace('|','',$pro_data[0]->moq);
                    $moq_final = $moq - ($pack_content * $data->quantity);
                 }
                
            
            }
        }

        if($type!='Loose'){
            $display_stock =  explode('|',$pro_data[0]->display_stock);
            $j=0; $total_available_stock_final= ''; $moq_final = '';
                foreach($display_stock as $dt){
                if($dt =='Yes'){
                $total_available_stock = explode('|',$pro_data[0]->total_available_stock);
                if($j == $varient_id ){
                    if($total_available_stock_final==''){
                        $total_available_stock_final = $total_available_stock[$j]-$data->quantity;
                    }else{
                $total_available_stock_final = $total_available_stock_final.'|'.($total_available_stock[$j]-$data->quantity);
                    }
                }
                else{
                     if($total_available_stock_final==''){
                        $total_available_stock_final = $total_available_stock[$j];
                    }else{
                 $total_available_stock_final = $total_available_stock_final.'|'.$total_available_stock[$j];   
                }
                }
                $moq_final = $moq_final.'|';  
                }
                else if($dt =='No'){
                    
                    //For MOQ no need minus stock
                //     $stock = explode('|',$pro_data[0]->moq);
                //     if($j == $varient_id ){
                //     if($moq_final==''){
                //         $moq_final = $stock[$j]-$data->quantity;
                //     }else{
                // $moq_final = $moq_final.'|'.$stock[$j]-$data->quantity;
                //     }
                // }
                // else{
                //      if($moq_final==''){
                //         $moq_final = $moq[$j];
                //     }else{
                //  $moq_final = $moq_final.'|'.$moq[$j];   
                // }
                // }
                
                $total_available_stock_final = $total_available_stock_final.'|';  
                }
                $j++;
                }
                
            
        }
$update_data['total_available_stock'] ='';
               if($total_available_stock_final!='' || $total_available_stock_final==0){
                $update_data['total_available_stock'] = $total_available_stock_final;
                }
                //No need to minus MOQ that is minimum order quantity
                // if($moq_final!=''){
                // $update_data['moq'] = $moq_final;
                // }

            if(isset($update_data)){
                if($update_data['total_available_stock']!='' || $update_data['total_available_stock']==0){
           $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
                }
            }

    if($result){
    $cart_id = $data->cart_id;
    $this->db->query("update cart set product_addby_seller = 1,stockupdate_status =1 where cart_id = $cart_id and product_status = 3 and user_id =$user_id");   // 0 - default added by customer 1- add by seller 
    }
    else{
        return false;
    }
    
    }
$ttl_discount = 0;
// $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status = 2 and order_id = $ord_id AND user_id = $user_id")->result();
    $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status in (1,2,3) and order_id = $ord_id AND user_id = $user_id")->result();
            if($total_discount){
                $ttl_discount =  $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
                $this->db->query("update orders set discount_amount = $ttl_discount where user_id = $user_id and order_id = $ord_id");
            }

$cancelled_item_total = 0;$cancelled_item_discount =0; $discount_amount =0; $cmrp =0; $mrp =0;
$result_excart = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN products ON products.product_id = cart.product_id where user.user_id = $user_id and cart.product_status in (0,1,2,3) and order_id =$ord_id ")->result();
foreach($result_excart as $ct){
    $items_in_cart = $items_in_cart + $ct->quantity;
    if($ct->product_status==0){
        $cancelled_item_total = $cancelled_item_total + $ct->price ;
        $cmrp = $cmrp + $ct->mrp_price;
    }else{
       $total = $total + $ct->price;  
       $mrp = $mrp + $ct->mrp_price;
    }
    
    $total_mrp =  $total_mrp + $ct->mrp_price;
}
$cancelled_item_discount = $cmrp -  $cancelled_item_total;
$discount_amount = $mrp - $total;
    
$total_amount =  $total;
$payment_method =  $ord_data[0]->payment_method;
$payment_type =  $ord_data[0]->payment_type;
$payment_status =  $ord_data[0]->payment_status;
    if($result){
         $update_data  = array(
            'user_id'=>$user_id,
            'store_id'=>$data->store_id,
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total_amount,
            'discount_amount' =>$discount_amount,
            'items_in_cart' => $items_in_cart,
            'payment_method'=>$payment_method,
            'payment_type'=>$payment_type,
            'payment_status'=>0,
            'booking_time'=>date('Y-m-d H:i:s'),
            'cancel_product_amt' => $cancelled_item_total,
            'cancel_discount_amt' => $cancelled_item_discount,
            'status'=>0
        
        );
    $status = $this->db->update('orders',$update_data,array('order_id'=>$ord_id));
    
         //update packing charge & delivery Charge
    $store_id = $data->store_id;
    
    $str = $this->db->query("select cancel_product_amt,tot_order_base_amt,orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method,delivery_km from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and order_id =$ord_id ")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        if($delivery_type==1)//store pickup
        {
            $est_delivery_charge = 0;
        }
        else { //home delivery
            // $est_delivery_charge = $str[0]->min_dc;
             $min_dc = $str[0]->min_dc;
            $delivery_km = $str[0]->delivery_km;
            $dc_freekm = $str[0]->dc_freekm;
            $dc_perkm = $str[0]->dc_perkm;
            if($delivery_km > $dc_freekm){
                $del_charge = $min_dc + (($delivery_km - $dc_freekm ) * $dc_perkm);
                $est_delivery_charge = $del_charge;
            }else {
            $est_delivery_charge = $min_dc;
            }
        }
        $packing_charges = $str[0]->packing_charges;
        $delivery_charges = $str[0]->delivery_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $billing_price = $str[0]->tot_order_base_amt;
            $items = $str[0]->items_in_cart;
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            $active_itemcnt = 0;
                $cnt = $this->db->query("Select sum(quantity)quantity from cart where order_id = $ord_id and product_status!=0" )->result();
                if($cnt) {
                    $active_itemcnt = $cnt[0]->quantity;
                }
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
            }else{ //unitwise
            $est_packing_charge =  round(($active_itemcnt * $pc_unit_value),2);
            }   
        }
        // $total_amount = $str[0]->tot_order_base_amt + $str[0]->cancel_product_amt +  $est_packing_charge + $est_delivery_charge;
        $total_amount = $str[0]->tot_order_base_amt +  $est_packing_charge + $est_delivery_charge;
        //update packing charge & delivery Charge
      $this->db->query("update orders set packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and order_id = $ord_id");  
    }
    $order = $this->db->query("select * from orders where order_id = $ord_id")->result();
    $order_amount = $order[0]->total_amount;
    $update_invdata  = array(
            'total_final_bill_amt'=>$order_amount
        );
    // $status = $this->db->update('invoice',$update_invdata,array('ord_id'=>$ord_id));
    $this->updatesellerremovedproduct_stock($orderutn_id,$user_id);
    

    }
    else{
        return false;
    }
    
// return $result = array('status'=>1,'message'=>'Product added Sucessfully');
return $result = array('status'=>1,'message'=>'Product updated');

}
else {
    return false;
}
}
public function order_confirmation($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['user_id']) || empty($postdata['user_id'])|| !isset($postdata['order_id']) || empty($postdata['order_id'])){
            return false;
        }
        $seller_id  = $postdata['seller_id'];
        $order_utnnumber  = $postdata['order_id'];
        $user_id = $postdata['user_id'];
        $selected_item_id = $postdata['selected_item_id'];
        if($selected_item_id){
        $item_ids =explode("|",$selected_item_id);
        }
        if($item_ids){
        $data = $this->db->query("select * from orders where UTN_number ='$order_utnnumber' ")->result();
        if($data){
            $order_id= $data[0]->order_id;
        }
        //update all cart products as not selected 
        $this->db->where("order_id = '$order_id'");
            $this->db->set('product_status','0');
            $status1 = $this->db->update('cart'); 
        foreach($item_ids as $cart_id){ //updated selected item = 1 active
            $this->db->where("cart_id = '$cart_id'");
            $this->db->set('product_status','1');
            $status2 = $this->db->update('cart');
        }
        }
        
        $ord_id = $order_id;
        $total =0;
$cancelled_item_total = 0;$cancelled_item_discount =0; $discount_amount =0; $cmrp =0; $mrp =0;$items_in_cart =0; $total_mrp =0;
$result_excart = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN products ON products.product_id = cart.product_id where user.user_id = $user_id and cart.product_status in (0,1,2,3) and order_id =$ord_id ")->result();
foreach($result_excart as $ct){
    $items_in_cart = $items_in_cart + $ct->quantity;
    if($ct->product_status==0){
        $cancelled_item_total = $cancelled_item_total + $ct->price ;
        $cmrp = $cmrp + $ct->mrp_price;
    }else{
       $total = $total + $ct->price;  
       $mrp = $mrp + $ct->mrp_price;
    }
    
    $total_mrp =  $total_mrp + $ct->mrp_price;
}
$cancelled_item_discount = $cmrp -  $cancelled_item_total;
$discount_amount = $mrp - $total;
    
$total_amount =  $total;
         $update_data  = array(
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total_amount,
            'discount_amount' =>$discount_amount,
            'cancel_product_amt' => $cancelled_item_total,
            'cancel_discount_amt' => $cancelled_item_discount,
        );
    $status = $this->db->update('orders',$update_data,array('order_id'=>$ord_id));
    
    //update packing charge & delivery Charge
    $str_dt = $this->db->query("select * from shopper where id = $seller_id")->result();
    $store_id = $str_dt[0]->store_id;
    
    $str = $this->db->query("select cancel_product_amt,tot_order_base_amt,orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method,orders.delivery_km from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and order_id =$ord_id ")->result();
    if($str){
        $delivery_type = $str[0]->payment_method;
        if($delivery_type==1)//store pickup
        {
            $est_delivery_charge = 0;
        }
        else { //home delivery
            $min_dc = $str[0]->min_dc;
            $delivery_km = $str[0]->delivery_km;
            $dc_freekm = $str[0]->dc_freekm;
            $dc_perkm = $str[0]->dc_perkm;
            if($delivery_km > $dc_freekm){
                $del_charge = $min_dc + (($delivery_km - $dc_freekm ) * $dc_perkm);
                $est_delivery_charge = $del_charge;
            }else {
            $est_delivery_charge = $min_dc;
            }
        }
        $packing_charges = $str[0]->packing_charges;
        $delivery_charges = $str[0]->delivery_charges;
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $billing_price = $str[0]->tot_order_base_amt;
            $items = $str[0]->items_in_cart;
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            $active_itemcnt = 0;
                $cnt = $this->db->query("Select sum(quantity)quantity from cart where order_id = $order_id and product_status!=0" )->result();
                if($cnt) {
                    $active_itemcnt = $cnt[0]->quantity;
                }
            if($pc_type==0){ //percwise
            $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
            }else{ //unitwise
            $est_packing_charge =  round(($active_itemcnt * $pc_unit_value),2);
            }   
        }
        // $total_amount = $str[0]->tot_order_base_amt + $str[0]->cancel_product_amt +  $est_packing_charge + $est_delivery_charge;
        $total_amount = $str[0]->tot_order_base_amt +  $est_packing_charge + $est_delivery_charge;
        //update packing charge & delivery Charge
      $this->db->query("update orders set packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and order_id = $ord_id");  
    }
    $order = $this->db->query("select * from orders where order_id = $ord_id")->result();
    $order_amount = $order[0]->total_amount;
    $update_invdata  = array(
            'total_final_bill_amt'=>$order_amount
        );
    // $status = $this->db->update('invoice',$update_invdata,array('ord_id'=>$ord_id));
    
    //final total update 
            $this->db->where("order_id = '$ord_id'");
            $ord_final_total_update = $this->db->query("select * from orders where order_id =$ord_id ")->result();
            $tot_order_base_amt = $ord_final_total_update[0]->tot_order_base_amt;
            $cancel_product_amt = $ord_final_total_update[0]->cancel_product_amt;
            $packing_charge = $ord_final_total_update[0]->packing_charge;
            $delivery_charge = $ord_final_total_update[0]->delivery_charge;
            // $total_amount = $tot_order_base_amt - $cancel_product_amt +  $packing_charge + $delivery_charge;
            $total_amount = $tot_order_base_amt +  $packing_charge + $delivery_charge;
            $this->db->set('total_amount',$total_amount);
            $status2 = $this->db->update('orders'); 
            
    ////////////////////////////////////
    //send order confirmation notification to customer
        $get_maildt =$this->db->query("SELECT str.store_name,usr.fullname custname,ord.UTN_number,usr.email custmail FROM orders ord INNER JOIN user_profile usr on ord.user_id = usr.user_id INNER JOIN stores str on str.store_id = ord.store_id WHERE ord.UTN_number ='$order_utnnumber'")->result();
        if($get_maildt){
            $custmail = $get_maildt[0]->custmail;
            if($custmail!=''){
            $to_receiver_email = $custmail;
            $cust_name = $get_maildt[0]->custname;
            $str_name = $get_maildt[0]->store_name;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellwomart123';
            $from_username = 'Yellow Mart - Mail';
            $subject="Welcome to YellowMart";
            $message = 
"Dear $cust_name,

Greetings from $str_name! Your ordered products are updated and need your Confirmation. Please check YellowMart app to confirm the order.

ORDER ID :  ORDER#$order_utnnumber   $str_name 


Please provide feedback on your experience with YellowMart on the link below,

URL : https://yellowmart.co.in/

Regards,
Store Name
Powered by YellowMart";
             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
             if($response['status']==0){
                 return $result = array('status'=>1,'message'=>'Failed to send mail ', 'data'=>$val); 
             }   
            }
        }
        //push notification
        $qry = $this->db->query("SELECT * from orders where UTN_number='$order_utnnumber'");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $this->db->where("user_id = $user_id");
            $this->db->where("UTN_number = '$order_utnnumber'");
            $this->db->set('order_confirmation',1); // 1 - need approval from customer 2 - approved from customer
            $status = $this->db->update('orders');
            if ($status) {
             $customer  = $this->db->query("select seller.id seller_id,usr.user_id,usr.token_key,str.store_name from user_profile usr INNER JOIN orders ord ON usr.user_id = ord.user_id INNER JOIN stores str ON str.store_id = ord.store_id INNER JOIN shopper seller ON seller.store_id = str.store_id where usr.user_id = $user_id AND ord.UTN_number = '$order_utnnumber'")->result();
             if($customer){
                    $token_key = $customer[0]->token_key;
                    $store_name = $customer[0]->store_name; 
                    $message ="ORDER#$order_utnnumber   $store_name - Products updated. Please confirm the order.";
                    $title = "Please confirm the order";
                    $notify_type = "order_request_confirmation";
                    $user_id = $user_id;
                    $seller_id = $customer[0]->seller_id;
                    $delivery_boyid = 0;
                    $notified_person = "customer";
                    if($token_key!=''){
                    $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
                    }
                    }
                // return $status = array('status'=>1,'message'=>'Order confirmation request sent to customer successfully'); 
                return $status = array('status'=>1,'message'=>'Order confirmation request send to the customer successfully'); 
                
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
        
    }
    public function notifications($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $noti_qry = $this->db->query("SELECT seller.shopper_name seller_name,user.fullname user_name,noti.notify_type,noti.title,noti.content,notify_date notify_date1,DATE_FORMAT(noti.notify_date,'%d-%m-%Y %h:%i %p')notify_date FROM  pushnotifications noti INNER JOIN shopper seller on noti.seller_id = seller.id INNER JOIN user_profile user on user.user_id = noti.user_id WHERE noti.notified_person ='seller' and noti.seller_id = $id order by notify_date1 desc ")->result();
// $cnt = $this->db->query("select * from pushnotifications where seller_id = $id and notified_person ='seller' and read_status = 0")->result();
// $unread_noti = count($cnt);
        $final_array = array();
        foreach($noti_qry as $n){
        $final_array[] = array(
            'seller_name'=>$n->seller_name,
            'user_name' =>$n->user_name,
            'notify_type' =>$n->notify_type,
            'title' =>$n->title,
            'content' =>$n->content,
            'notify_date' =>$n->notify_date
            );
        }
        //update notification as read
        $this->db->query("update pushnotifications set read_status = 1 where seller_id = $id and notified_person ='seller' and read_status = 0 ");
        if(!empty($final_array)){
            // return $status = array('status'=>1,'message'=>'Notification Details','count'=>$unread_noti,'data'=>$final_array); 
            return $status = array('status'=>1,'message'=>'Notification Details','data'=>$final_array); 
        }
        else{
            return false;
        }
        
    }
    public function notifications_count($postdata=array()){
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id'])){
            return false;
        }
        $id = $postdata['seller_id'];
        $cnt = $this->db->query("select * from pushnotifications where seller_id = $id and notified_person ='seller' and read_status = 0")->result();
        $unread_noti = count($cnt);
        if($unread_noti!=0){
            return $status = array('status'=>1,'message'=>'Notification Count','count'=>$unread_noti); 
        }
        else{
            return false;
        }
        
    }
    public function getdelivery_charge($postdata=array()){ // accept order api
        if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['order_id']) || empty($postdata['order_id'])){
            return false;
        }
        if($postdata['selected_item_id']==''){
            return false;
        }
        $selected_item_id = $postdata['selected_item_id'];
        $id = $postdata['seller_id'];
        $ordertutn_id = $postdata['order_id'];
        $deliverykm = $postdata['deliverykm'];
        
        $selected_item_id = $postdata['selected_item_id'];
        $item_ids = '';
        if($selected_item_id){
        $item_ids =explode("|",$selected_item_id);
        }
        $tot_line_item_selected =count($item_ids);
        $tot = 0; $active_itemcnt =0 ;
        // print_r($item_ids);die;
        foreach($item_ids as $cart_id){ 
          $cart =  $this->db->query("Select * from cart where cart_id =$cart_id ")->result();
          if($cart){
          $price = $cart[0]->price;
          $tot = $tot + $price;
          $active_itemcnt = $active_itemcnt + $cart[0]->quantity;
          }
          
         
        }

        $ord_data = $this->db->query("SELECT ord.order_id,ord.UTN_number,ord.tot_order_base_amt,ord.packing_charge,ord.delivery_km,ord.total_amount,str.packing_charges,str.pc_type,str.pc_perc,str.pc_unit_value,str.delivery_charges,str.min_dc,str.dc_freekm,str.dc_perkm,payment_method FROM orders ord INNER JOIN stores str on ord.store_id =  str.store_id WHERE ord.UTN_number  = '$ordertutn_id'")->result();
        // print_r($ord_data);die;
        if($ord_data){
            
            if($ord_data[0]->delivery_charges==0){
                $delivery_charge = 0;
            }else{
                $min_delivery_charge = $ord_data[0]->min_dc;
                $freekm = $ord_data[0]->dc_freekm;
                $perkm_charge = $ord_data[0]->dc_perkm;
                if($deliverykm > $freekm){
                    $extra_km = $deliverykm - $freekm;
                    $delivery_charge = round($min_delivery_charge + ($extra_km *$perkm_charge ),0);
                }else{
                    $delivery_charge = round($min_delivery_charge,0);
                }
            }
            if($ord_data[0]->payment_method==1){ //for storepickup  delivery charge 0 
                $delivery_charge = 0;
            }
        
        if($ord_data[0]->packing_charges==0){
            $packing_charge = 0;
        }else{
            $pc_type = $ord_data[0]->pc_type;
            $pc_perc = $ord_data[0]->pc_perc;
            $pc_unit_value = $ord_data[0]->pc_unit_value;
            if($pc_type == 0){ //percwise packing charge
            $packing_charge = round($tot * ($pc_perc/100),0);
                
            }else { //unitwise packing charge
                // $packing_charge = round($tot_line_item_selected * $pc_unit_value,0);
                $packing_charge = round($active_itemcnt * $pc_unit_value,0);
                
            }
        }
        $tot_amt = $tot + $delivery_charge + $packing_charge;
        $final_data  = array(
            'delivery_km' =>"$deliverykm",
            'delivery_charge' => "$delivery_charge",
            'packing_charge' => "$packing_charge",
            'tot_amt' => "$tot_amt",
            'selected_item_id' =>"$selected_item_id"
            );
            $update_order['delivery_km'] =$deliverykm; //only update delivery km on click order confirmation delivery charge and total will calculate
            $update_order['delivery_charge'] =$delivery_charge;
            $update_order['total_amount'] =$tot_amt;
            $status = $this->db->update('orders',$update_order,array('UTN_number'=>$ordertutn_id));
           return $status = array('status'=>1,'message'=>'Delivery data updated','data'=>$final_data);    
        }else{
            return false;
        }
     }
     function updatesellerremovedproduct_stock($UTN_number,$user_id){
         
            $ord_data = $this->db->query("select * from orders where UTN_number = '$UTN_number'")->result();
            if($ord_data){
                $order_id = $ord_data[0]->order_id;
                $user_id = $ord_data[0]->user_id;
                //seller app -> order delivery update(add) unselected item stock // product_status = 0
            $result = $this->db->query("select cart.* from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN products ON products.product_id = cart.product_id where user.user_id = $user_id and order_id = $order_id and product_status = 0 and stockupdate_status = 0")->result();
                $count = count($result);
                $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data){
        $product_id  = $data->product_id;
        $cart_id = $data->cart_id;
        $pro_data = $this->db->query("select * from products where product_id = $product_id")->result();
        $type = $pro_data[0]->type;
        $total = $total + $data->price;
        $total_mrp = $total_mrp + $data->mrp_price;
        $items_in_cart = $items_in_cart + $data->quantity;
        $varient_id = $data->varient_id;
        $total_available_stock_final = 0; $moq_final = 0;
        
        if(strtoupper($type)=='LOOSE'){
            $total_available_stock_final= ''; $moq_final = '';
            $sale_unit = explode('|',$pro_data[0]->sale_unit);
            $sale_unit = $sale_unit[$varient_id];
            $pack_content = explode('|',$pro_data[0]->pack_content);
            $pack_content = $pack_content[$varient_id];
            $stock_unit = explode('|',$pro_data[0]->stock_unit);
            $stock_unit = $stock_unit[0];
            $stock_add = 0;
            $display_stock = explode('|',$pro_data[0]->display_stock);
            if(strtoupper($display_stock[0])=='YES'){
                $total_available_stock = str_replace('|','',$pro_data[0]->total_available_stock);
                //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock
                if($sale_unit!=$stock_unit){
                     if($sale_unit == 1){ //ml to ltr
                    $stock_add = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 2){ //ltr to ltr
                    $stock_add = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 3){ //gram to kg
                    $stock_add = 0.001 * ($pack_content * $data->quantity);
                }
                else if($sale_unit == 5){//kg to kg
                    $stock_add = ($pack_content * $data->quantity);
                }
                
                else if($sale_unit == 4){//box
                    $stock_add = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 6){ //pcs
                    $stock_add = ($pack_content * $data->quantity);
                }
                else if($sale_unit == 7){ //nos
                    $stock_add = ($pack_content * $data->quantity);
                }
                $total_available_stock_final = $total_available_stock + $stock_add;
                }
                else{ //if sale unit and stock unit same unit, so directly minus quantity
                    $total_available_stock = str_replace('|','',$pro_data[0]->total_available_stock);
                    $total_available_stock_final = $total_available_stock + ($pack_content * $data->quantity);
                 }
                
            }
        }

        if(strtoupper($type)!='LOOSE'){
            $display_stock =  explode('|',$pro_data[0]->display_stock);
            $j=0; $total_available_stock_final= ''; $moq_final = '';
                foreach($display_stock as $dt){
                if(strtoupper($dt) =='YES'){
                $total_available_stock = explode('|',$pro_data[0]->total_available_stock);
                if($j == $varient_id ){
                    if($total_available_stock_final==''){
                        $total_available_stock_final = $total_available_stock[$j]+$data->quantity;
                    }else{
                $total_available_stock_final = $total_available_stock_final.'|'.($total_available_stock[$j]+$data->quantity);
                    }
                }
                else{
                     if($total_available_stock_final==''){
                        $total_available_stock_final = $total_available_stock[$j];
                    }else{
                 $total_available_stock_final = $total_available_stock_final.'|'.$total_available_stock[$j];   
                }
                }
                // $moq_final = $moq_final.'|';  
                }
                else if($dt =='No'){
                $total_available_stock_final = $total_available_stock_final.'|';  
                }
                $j++;
                }
                
            
        }
    
        $update_data['total_available_stock'] ='';
              if($total_available_stock_final!='' || $total_available_stock_final ==0){
                $update_data['total_available_stock'] = $total_available_stock_final;
                }
            if(isset($update_data)){
                if($update_data['total_available_stock']!='' || $update_data['total_available_stock']==0){
          $status = $this->db->update('products',$update_data,array('product_id'=>$product_id));
                }
            }
            $update_data2['stockupdate_status'] = 1;
            $status2 = $this->db->update('cart',$update_data2,array('cart_id'=>$cart_id));
    } 
            }
     }
     function sendmail_notification($from_email='',$from_emailpassword='',$from_username='',$to_receiver_email='',$subject,$message=''){
            $config['protocol'] = 'ssmtp';
            $config['smtp_host'] = 'ssl://ssmtp.gmail.com';
            $config['smtp_port'] = 465;
            $config['smtp_user'] = $from_email;
            $config['smtp_pass'] = $from_emailpassword;
            // $config['charset']  = 'iso-8859-1';
            // $config['priority']= 1;
           // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            $this->email->clear(); 
            // $this->email->initialize($config);
            $this->email->set_newline("\r\n");
            // Sender email address
            $this->email->from($from_email, $from_username);
            // Receiver email address
            $this->email->to($to_receiver_email);
            // Subject of email
            $this->email->subject($subject);
            // Message in email
            $this->email->message($message);
            if ($this->email->send()) {
                return $result = array('status'=>1,'message'=>'Mail sent'); 
            } else {
                return $result = array('status'=>0,'message'=>'Failed to send Mail'); 
            }
}
function send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person){
    if($token_key!=''){
                    $data = array(
                    "action"=>1,    
                    "message"=> "$message",
                    "title"=>"$title"
                        );
                        if($notified_person=='seller'){
                    $sendNotification = seller_send_push_notification($token_key,$data);
                        }else if($notified_person=='customer'){
                    $sendNotification = send_push_notification($token_key,$data);
                        }else if($notified_person=='deliveryboy'){
                    $sendNotification = delivery_send_push_notification($token_key,$data);
                        }
                    $insert_data  = array(
                        'notify_type'=>"$notify_type",
                        "title"=>"$title",
                        'content'=>"$message",
                        'user_id'=>$user_id,
                        'seller_id'=>$seller_id,
                        'delivery_boyid' =>$delivery_boyid,
                        'notified_person' =>"$notified_person", 
                        'notify_date' => date('Y-m-d H:i:s'),
                        'read_status' => 0
                    );
                $this->db->insert('pushnotifications',$insert_data);
                }
}
public function updateproduct_price($postdata=array()){
     if(!isset($postdata['seller_id']) || empty($postdata['seller_id']) || !isset($postdata['order_id']) || empty($postdata['order_id'])){
            return false;
        }
    $orderutn_id = $postdata['order_id'];    
    $cart_id = $postdata['cart_id'];
    $quantity = $postdata['quantity'];
    $rate = $postdata['per_unit_price'];
    $price = $quantity * $rate;
             //update cart
            $this->db->where("cart_id = '$cart_id'");
            $this->db->set('quantity',$quantity);
            $this->db->set('rate',$rate);
            $this->db->set('price',$price);
            $this->db->set('updatedprice',1); //once seller updated the price change updatedprice to 1
            $status2 = $this->db->update('cart');
            
            //update order table
            $get_dt = $this->db->query("SELECT cart.cart_id,cart.quantity,cart.rate,cart.price,cart.mrp_rate,ord.packing_charge,ord.delivery_charge,ord.store_id FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number ='$orderutn_id'")->result();
            $total_mrp =0;$total=0;$discount_amount=0;$items_in_cart=0;$tot_order_base_amt=0;
            if($get_dt){
                foreach($get_dt as $data){
                    $store_id = $data->store_id;
                    // $packing_charge = $data->packing_charge;
                    $delivery_charge = $data->delivery_charge;
                    $total_mrp = $total_mrp + ( $data->quantity * $data->mrp_rate); //mrp_price
                    $total = $total + $data->price;//billing price
                    $items_in_cart = $items_in_cart + $data->quantity;
                }
                //update packing charge
                $packing_charge = 0;
                $strdata = $this->db->query("select str.packing_charges,str.pc_type,str.pc_perc,str.pc_unit_value from stores str where store_id = $store_id")->result();
                if($strdata){
                        $packing_charges = $strdata[0]->packing_charges;
                        $pc_type = $strdata[0]->pc_type;
                         if($pc_type==0){ //percentage wise charge
                             $pc_perc_charge = $total * ($strdata[0]->pc_perc /100);
                             $pc = round($pc_perc_charge,0);
                        }else{ //unitwise charge
                            $pc_unit_value = $strdata[0]->pc_unit_value;
                            $ord_d = $this->db->query("select * from orders where UTN_number ='$orderutn_id' ")->result();
                            $items_in_cart = $ord_d[0]->items_in_cart;
                            $order_id = $ord_d[0]->order_id;
                            $active_itemcnt = 0;
                            $cnt = $this->db->query("Select sum(quantity)quantity from cart where order_id = $order_id and product_status!=0" )->result();
                            if($cnt) {
                                $active_itemcnt = $cnt[0]->quantity;
                            }
                            $pc = round(($active_itemcnt  * $pc_unit_value),0);
                        }
                        $packing_charge = $pc;
                    }
            $discount_amount = $total_mrp - $total; //discount
            $total_amount = $total +  $packing_charge + $delivery_charge;
           $update_data  = array(
            'original_amt' =>$total_mrp,
            'tot_order_base_amt'=>$total,
            'total_amount'=>$total_amount,
            'discount_amount' =>$discount_amount,
            'items_in_cart' => $items_in_cart,
            'packing_charge' =>$packing_charge
        );
    // print_r($update_data);die;
    $status = $this->db->update('orders',$update_data,array('UTN_number'=>"$orderutn_id"));
    if($status){
    return $result = array('status'=>"1",'message'=>'Product price updated');
    }else{
        return false;
    }
}
            else{
                return $result = array('status'=>"0",'message'=>'Failed to update price');//failed to update order table
            }
}

}
?>