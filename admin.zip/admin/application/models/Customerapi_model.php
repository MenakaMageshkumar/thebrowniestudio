<?php
class Customerapi_model extends CI_Model {
    function __construct() {
        parent::__construct();
         $this->load->model('Sms_model','sms_model');
    }
   
  // Login API
  public function login($request='') { 
        if(!isset($request['phone_no']) || empty($request['phone_no'])  || !isset($request['password']) || empty($request['password'])){
            return false;
        }
        $phone_no = $request['country_code'].$request['phone_no'];
        $this->db->where("phone_no = '".$phone_no."'");
        $this->db->where('password', md5($request['password']));
        $this->db->where('status !=', 0);
        $query = $this->db->get('user_profile');
        if ($query->num_rows() > 0) {
            $unique_id = $this->generateUnique();
            $rs = $query->row();
            $this->EncryptPatientKey($unique_id, $rs->user_id);
            if($rs->status==1){
            return $result = array('status'=>1,'message'=>'Login Success', 'data'=>array('auth_id'=>$unique_id,'user_id'=>$rs->user_id,'fullname'=>$rs->fullname,'email'=>$rs->email,'phone_no'=>$rs->phone_no,'image'=>str_replace("null","",$rs->image),'district'=>"" ));    
            }else if($rs->status==2){
                $password = $request['password'];
              return $result = array('status'=>3,'message'=>'Login Success Registration Pending', 'data'=>array('auth_id'=>$unique_id,'user_id'=>$rs->user_id,'fullname'=>"",'email'=>"",'phone_no'=>"",'image'=>"",'district'=>"",'password'=>$password ));      
            }
        } else {
            return false;
        }
    }
    public function generateUnique() {
        $unqe = md5(uniqid(time().mt_rand(), true));
        return $unqe;  
    }
    public function EncryptPatientKey($unique_id, $user_id) {
        $this->db->insert('auth_table', array('user_id'=>$user_id,'unique_id'=>$unique_id,'status'=>1));
        
    }
    public function update_token($request=array()){ //MS
        if(!isset($request['phone_no']) || empty($request['phone_no']) || !isset($request['token_key']) || empty($request['token_key'])){
            return false;
        }
        // $phone_no = $request['phone_no'];
        $phone_no = $request['country_code'].$request['phone_no'];
        $token_key = $request['token_key'];
        $qry = $this->db->query("SELECT * from user_profile u where u.phone_no='$phone_no'");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $this->db->where("phone_no = '$phone_no'");
            $this->db->set('token_key',$token_key);
            $status = $this->db->update('user_profile');
            if ($status) {
            
                return $status = array('status'=>1,'message'=>'Token Updated'); 
            }
        }
        
    }
    public function phoneno_select($request=array()){ //MS
        if(!isset($request) || empty($request)){
            return false;
        }
        $phone_number = $request['country_code'].$request['phone_no'];
        $this->db->select('phone_no');
        $this->db->where('phone_no', $phone_number);
        $this->db->where('status', 1);
        $phone_no= $this->db->get('user_profile');
        $re= $phone_no->row_array();
        //print_r($this->db->last_query());exit;
        return $re;
    }
    //Customer Registration Step 1 - gather Mobile Number 
    public function user_signup($postdata=array()){ //MS
        
        if(!isset($postdata['phone_no']) || empty($postdata['phone_no']) || !isset($postdata['country_code']) || empty($postdata['country_code'])){
            return false;
        }
        if(isset($postdata['appid'])){
        $appid = $postdata['appid'];
        }else{
            $appid ='YM';
        }
        $phone_numebr = $postdata['country_code'].$postdata['phone_no'];
        $phone_num_exists = $this->db->query("select * from user_profile where phone_no ='$phone_numebr' and (status=0 || status=2)")->result(); //incomplete registration //agn trying to register
        if($phone_num_exists){
        $user_id = $phone_num_exists[0]->user_id;
        $otp = $postdata['otp'];
        $this->db->where('user_id',$user_id);
        $this->db->set('otp',$otp);
        $status = $this->db->update('user_profile');
            if($appid!='YM'){ //update in shared database also
                    // $status_db2 = $this->DB2->update('user_profile');
            }
        }
        else{
        $status= $this->db->insert('user_profile', array('phone_no'=>$phone_numebr,'otp' =>$postdata['otp'],'appid'=>'YM')); //default app
             if($appid!='YM'){ //insert in exclusive shared database also
                    $appid = $postdata['appid'];
                    // $status= $this->DB2->insert('user_profile', array('phone_no'=>$phone_numebr,'otp' =>$postdata['otp'],'appid'=>$appid));
            }
        $this->db->where("phone_no = '".$phone_numebr."'");
        $query = $this->db->get('user_profile');
        $rs = $query->row();
        $user_id = $rs->user_id;
        }
        
        $unique_id = $this->generateUnique();
        //print_r($rs);exit;
        $this->EncryptPatientKey($unique_id, $user_id); 
        //print_r($rs->user_id);exit;
        // $qry = $this->db->query("SELECT a.unique_id as auth_token,u.user_id,u.phone_no from auth_table a join user_profile u 
        $qry = $this->db->query("SELECT a.unique_id as auth_token,u.user_id,u.phone_no,u.otp from auth_table a join user_profile u 
        where a.user_id=$user_id and u.user_id=$user_id");
        
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $message = 'your OTP is :';
            $message_otp = $postdata['otp'];
            $message_final = $message.$message_otp;
            // return $result = array('status'=>'success', 'data'=>$val); 
            $result1 = $this->sms_model->send_sms(
                                        $postdata['country_code'],
                                        $postdata['phone_no'],
                                        $message_otp
                                    );
            //echo '<pre>';print_r($result);die;
            return $result = array('status'=>1,'message'=>'OTP send to your phone number', 'data'=>$val); 
        }
    }
    //Customer Registration Step 2 - OTP verification
    public function user_otp($postdata=array()){ //MS
        if(!isset($postdata['user_id']) || empty($postdata['user_id']) || !isset($postdata['otp']) || empty($postdata['otp'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $otp = $postdata['otp'];
        $qry = $this->db->query("SELECT u.user_id,u.phone_no from user_profile u 
        where u.user_id=$user_id and u.otp=$otp");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $this->db->where("user_id = '".$postdata['user_id']."'");
            $this->db->where("otp = '".$postdata['otp']."'");
            $this->db->set('otp','');
            $this->db->set('direct_circle','YEL001');//Direct yellowmart customer
            $status = $this->db->update('user_profile');
            if ($status) {
                return $status = array('status'=>1,'message'=>'OTP verified', 'data'=>$val); 
            }
        }
        
    }
    public function user_address($postdata=array()){ // step 3 load district,state,city and area details
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $state =array();$district =array();$city = array();$area = array(); $area_pincode ='';
        $state_list = $this->db->query("select * from state order by state")->result();
        if($state_list){
            foreach($state_list as $s){
            $state[] = array (
            'state_id' => $s->state_id,
            'state' => $s->state
            );  
            }
        }
        
        if(isset($postdata['state_id']) && $postdata['state_id']!=''){
            $state_id = $postdata['state_id'];
            $district_list = $this->db->query("select * from district where state_id = $state_id order by district")->result();
        }
        // else{
        //     $district_list = $this->db->query("select * from district order by district")->result();
        // }
        if(isset($district_list)){
            foreach($district_list as $d){
            $district[] = array (
            'district_id' => $d->district_id,
            'district' => $d->district
            );  
            }
        }
        
       if(isset($postdata['district_id']) && $postdata['district_id']!=''){
            $district_id = $postdata['district_id'];
            $city_list = $this->db->query("select * from city where district_id = $district_id order by city_name")->result();
        }
        // else{
        //     $city_list = $this->db->query("select * from city order by city_name")->result();
        // }
        if(isset($city_list)){
            foreach($city_list as $c){
            $city[] = array (
            'city_id' => $c->id,
            'city_name' => $c->city_name
            );  
            }
        }
        if(isset($postdata['city_id']) && $postdata['city_id']!=''){
            $city_id = $postdata['city_id'];
            $area_list = $this->db->query("select * from area where city_id = $city_id order by area_locality")->result();
        }
        // else{
        //     $area_list = $this->db->query("select * from area order by area_locality")->result();
        // }
        if(isset($area_list)){
            foreach($area_list as $a){
            $area[] = array (
            'area_id' => $a->id,
            'area_locality' => $a->area_locality,
            'area_pincode' => $a->pincode
            );  
            }
        }
       
       if(isset($postdata['area_id']) && $postdata['area_id']!=''){
            $area_id = $postdata['area_id'];
            $getarea_pincode = $this->db->query("select * from area where id = $area_id order by area_locality")->result();
        }
        // else{
        //     $getarea_pincode = $this->db->query("select * from area order by area_locality")->result();
        // }
        if(isset($getarea_pincode)){
            $area_pincode =$getarea_pincode[0]->pincode; 
        }
                return $status = array('status'=>1,'message'=>'Address Detail', 'state'=>$state,'district'=>$district,'city'=>$city,'area'=>$area,'area_pincode'=>$area_pincode); 

    }
    //Customer Registration Step 3 - Basic information
    public function user_register_oldwithaddress($postdata=array()){ //MS
        if(!isset($postdata['fullname']) || empty($postdata['fullname'])
        || !isset($postdata['password']) || empty($postdata['password'])
        || !isset($postdata['token_key']) || empty($postdata['token_key'])
        || !isset($postdata['address1']) || empty($postdata['address1'])
        || !isset($postdata['address2']) || empty($postdata['address2'])
        || !isset($postdata['landmark']) || empty($postdata['landmark'])
        || !isset($postdata['state_id']) || empty($postdata['state_id'])
        || !isset($postdata['district_id']) || empty($postdata['district_id'])
        || !isset($postdata['city_id']) || empty($postdata['city_id'])
        ){
            return false;
        }
        $user_id = $postdata['user_id'];
        if(isset($postdata['email'])){
            if($postdata['email']!=''){
        $cust_email = $postdata['email'];
        $chk_email_address = $this->db->query("Select * from user_profile where user_id!=$user_id  and email ='$cust_email'")->result();
        if(count($chk_email_address) > 0 ){
             $result = array('status'=>0,'message'=>'Email Address already exist');
             print_r(json_encode($result));exit;
        }
            }
        }
        $insert_address['user_id']= $user_id;
        $insert_address['address1']= $postdata['address1'];
        $insert_address['address2']= $postdata['address2'];
        $insert_address['landmark']= $postdata['landmark'];
        $insert_address['state_id']= $postdata['state_id'];
        $insert_address['district_id']= $postdata['district_id'];
        $insert_address['city_id']= $postdata['city_id'];
        $insert_address['area_id']= $postdata['area_id'];
        $curr_areaid = $insert_address['area_id'];
        $getpincode = $this->db->query("select * from area where id = $curr_areaid")->result();
        if($getpincode){
            $insert_address['pincode'] = $getpincode[0]->pincode;
        }else{
            $insert_address['pincode'] ='';
        }
        if(isset($postdata['gps_coordinates'])){
        if($postdata['gps_coordinates']!=''){//not mandatory
        $url = 'https://www.google.com/maps/search/?api=1&query=';
        $insert_address['gps_coordinates']= $url.$postdata['gps_coordinates'];
        }
        }
        $insert_address['address_name']= $postdata['address_name'];
        $insert_address['address_type']= 1; // 1 - on signup take address as current address
        $this->db->insert('address',$insert_address); // insert to address table
        
        //update user profile table
            $this->db->where("user_id = '".$postdata['user_id']."'");
            $this->db->set('fullname',$postdata['fullname']);
            if(isset($postdata['email'])){
            $this->db->set('email',$postdata['email']);
            }
            $this->db->set('password',md5($postdata['password']));
            // $this->db->set('address_ids',$address_ids);
            $this->db->set('date_registered',date('Y-m-d H:i:s'));
            $this->db->set('token_key',$postdata['token_key']);
            $this->db->set('status',1);
            $status = $this->db->update('user_profile');
            
            $qry = $this->db->query("SELECT a.unique_id as auth_token,u.user_id,u.phone_no,u.fullname from auth_table a join user_profile u 
          where a.user_id=$user_id and u.user_id=$user_id");
            $val = $qry->row();
            //send welcome mail to Customer
            if(isset($postdata['email']) || !empty($postdata['email'])){
            $to_receiver_email = $postdata['email'];
            $cust_name = $postdata['fullname'];
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Welcome to The Brownie Studio!";
              $dt['heading'] = "Welcome to The Brownie Studio!";
             $dt['message'] = 
                "Dear $cust_name, <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  Welcome to <strong> The Brownie Studio! </strong>  <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; We wish to enrich your shopping experience with wide range of stores and products.<br>
                 
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Enjoy your shopping days! <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; For any support reach us at <strong>thebrowniestudio@gmail.com </strong><br><br>

             Regards,<br>
             <strong>  The Brownie Studio </strong>  ";
             $message_html = $this->load->view('template/email_template', $dt, TRUE);
            // $message = $this->load->view('template/email_template');
            
             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
            //  if($response['status']==0){
            //      return $result = array('status'=>1,'message'=>'Failed to send mail ', 'data'=>$val); 
            //  }
            }
            
            
        if($status){
            return $result = array('status'=>1,'message'=>'Signup Success', 'data'=>$val); 
        }else{
            return 0;
        }
    }
     //Customer Registration Step 3 - Basic information
    public function user_register($postdata=array()){ //MS
        if(!isset($postdata['fullname']) || empty($postdata['fullname'])
        || !isset($postdata['password']) || empty($postdata['password'])
        || !isset($postdata['token_key']) || empty($postdata['token_key'])
        || !isset($postdata['current_cityid']) || empty($postdata['current_cityid'])
        ){
            return false;
        }
        $user_id = $postdata['user_id'];
        if(isset($postdata['email'])){
            if($postdata['email']!=''){
        $cust_email = $postdata['email'];
        $chk_email_address = $this->db->query("Select * from user_profile where user_id!=$user_id  and email ='$cust_email'")->result();
        if(count($chk_email_address) > 0 ){
             $result = array('status'=>0,'message'=>'Email Address already exist');
             print_r(json_encode($result));exit;
        }
            }
        }
        //update user profile table
            $this->db->where("user_id = '".$postdata['user_id']."'");
            $this->db->set('fullname',$postdata['fullname']);
            if(isset($postdata['email'])){
            $this->db->set('email',$postdata['email']);
            }
            $this->db->set('password',md5($postdata['password']));
            // $this->db->set('address_ids',$address_ids);
            $this->db->set('date_registered',date('Y-m-d H:i:s'));
            $this->db->set('token_key',$postdata['token_key']);
            $this->db->set('current_cityid',$postdata['current_cityid']);
            $this->db->set('status',1);
            $status = $this->db->update('user_profile');
            
            $qry = $this->db->query("SELECT a.unique_id as auth_token,u.user_id,u.phone_no,u.fullname from auth_table a join user_profile u 
          where a.user_id=$user_id and u.user_id=$user_id");
            $val = $qry->row();
            //send welcome mail to Customer
            if(isset($postdata['email']) || !empty($postdata['email'])){
            $to_receiver_email = $postdata['email'];
            $cust_name = $postdata['fullname'];
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Welcome to The Brownie Studio!";
                $dt['heading'] = "Welcome to The Brownie Studio!";
             $dt['message'] = 
                "Dear $cust_name, <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  Welcome to <strong> The Brownie Studio! </strong>  <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; We wish to enrich your shopping experience with wide range of stores and products.<br>
                 
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Enjoy your shopping days! <br>
                
                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; For any support reach us at <strong>thebrowniestudio@gmail.com </strong><br><br>

Regards,<br>
<strong>  The Brownie Studio </strong>  ";
$message_html = $this->load->view('template/email_template', $dt, TRUE);
             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
            //  if($response['status']==0){
            //      return $result = array('status'=>1,'message'=>'Failed to send mail ', 'data'=>$val); 
            //  }
            }
            
            
        if($status){
            return $result = array('status'=>1,'message'=>'Signup Success', 'data'=>$val); 
        }else{
            return 0;
        }
    }
    function sendmail_notification($from_email='',$from_emailpassword='',$from_username='',$to_receiver_email='',$subject,$message=''){
            $config['protocol'] = 'ssmtp';
            $config['smtp_host'] = 'ssl://ssmtp.gmail.com';
            $config['smtp_port'] = 465;
            $config['smtp_user'] = $from_email;
            $config['smtp_pass'] = $from_emailpassword;
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            
           // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            $this->email->clear(); 
            // $this->email->initialize($config);
            $this->email->set_newline("\r\n");
            $this->email->set_mailtype("html");
            // Sender email address
            $this->email->from($from_email, $from_username);
            // Receiver email address
            $this->email->to($to_receiver_email);
            // Subject of email
            $this->email->subject($subject);
            // Message in email
            $this->email->message($message);
            if ($this->email->send()) {
                return $result = array('status'=>1,'message'=>'Mail sent'); 
            } else {
                // print_r($this->email->print_debugger());
                // die;
                return $result = array('status'=>0,'message'=>'Failed to send Mail'); 
            }
}
//user Forgot Password 
public function user_forgot($request=array()){ //MS
        if(!isset($request) || empty($request)){
            return false;
        }
        $phone_number = $request['country_code'].$request['phone_no'];
        
        $qry = $this->db->query("SELECT u.user_id,u.phone_no,u.otp from user_profile u 
        where u.phone_no=$phone_number");
        if ($qry->num_rows() > 0) {
            $otp = rand(1111, 9999);
            $this->db->where('phone_no',$phone_number);
            $this->db->set('otp',$otp);
            $status = $this->db->update('user_profile');
            $qry = $this->db->query("SELECT u.user_id,u.phone_no,u.otp from user_profile u 
        where u.phone_no=$phone_number");
            $val = $qry->row();
            $message = 'your OTP is :';
            $message_otp = $otp;
            $message_final = $message.$message_otp;
            // return $result = array('status'=>'success', 'data'=>$val); 
            $result1 = $this->sms_model->send_sms(
                                        $request['country_code'],
                                        $request['phone_no'],
                                        $message_otp
                                    );
            return $result = array('status'=>1,'message'=>'OTP send to your phone number', 'data'=>$val); 
        }
        /*$this->db->where("phone_no = '".$request['phone_no']."'");
        //$this->db->set('password',md5($request['password']));
        $status = $this->db->update('user_profile');
        if ($status){
            return 1;
        }
        return 0;*/
    }
    //User forgot password update 
    public function user_forgot_password_final($postdata=array()){ //MS
        if(!isset($postdata['user_id']) || empty($postdata['user_id']) || !isset($postdata['password']) || empty($postdata['password'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $qry = $this->db->query("SELECT a.unique_id as auth_token,u.user_id,u.phone_no,u.fullname,u.email from auth_table a join user_profile u 
        where a.user_id=$user_id and u.user_id=$user_id");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $this->db->where("user_id = '".$postdata['user_id']."'");
            $this->db->set('password',md5($postdata['password']));
            $status = $this->db->update('user_profile');
             $email = $val->email;
            if($email){
            $cust_name = $val->fullname;
            $sender_email = 'yellowmart17@gmail.com';
            $user_password = 'yellowmart123';
            $receiver_email = $email;
            $username = 'The Brownie Studio';
            $subject="Password Updated";
            $dt['heading'] = "Password Updated";
            $dt['message'] = 
           "Dear $cust_name, <br>

                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Alert! Your <strong>  The Brownie Studio </strong> account password has been updated. <br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Please reach out to us at <strong>  thebrowniestudio@gmail.com </strong>, if this was not done by you. <br><br>
                
                Regards,<br>
                <strong>  The Brownie Studio </strong>  
            ";
           $message_html = $this->load->view('template/email_template2', $dt, TRUE);     
            // Configure email library
            $config['protocol'] = 'ssmtp';
            $config['smtp_host'] = 'ssl://ssmtp.gmail.com';
            $config['smtp_port'] = 465;
            $config['smtp_user'] = $sender_email;
            $config['smtp_pass'] = $user_password;
            
            // 
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            // 

            // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            // 
            $this->email->clear(); 
            // 
            $this->email->set_newline("\r\n");
            
            // 
             $this->email->set_mailtype("html");
            // 
            // Sender email address
            $this->email->from('yellowmart17@gmail.com', $username);
            // Receiver email address
            $this->email->to($receiver_email);
            // Subject of email
            $this->email->subject($subject);
            // Message in email
            $this->email->message($message_html);
            $this->email->send();
            }
            return $result = array('status'=>1,'message'=>'Password changed successfully', 'data'=>$val); 
        }
    }
    public function my_profile($postdata=array()){ //MS
    $user_id = $postdata['user_id'];
    //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
            exit;
        }
    $lang_menu = array();
        $my_profile =''; $first_name =''; $full_name=''; $email_address='';$phone='';$submit='';$delivery_address='';$address1='';$address2='';$landmark='';$city_town='';$pincode='';$state='';
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and page_name ='Profile Page'")->result();
        foreach($menu_list as $menu){
            if($menu->menu_variable=='my_profile'){
                $my_profile = $menu->menu;
            }
            if($menu->menu_variable=='first_name'){
                $first_name = $menu->menu;
            }
            if($menu->menu_variable=='full_name'){
                $full_name = $menu->menu;
            }
            if($menu->menu_variable=='email_address'){
                $email_address = $menu->menu;
            }
            if($menu->menu_variable=='phone'){
                $phone = $menu->menu;
            }
            if($menu->menu_variable=='submit'){
                $submit = $menu->menu;
            }

           if($menu->menu_variable=='delivery_address'){
                $delivery_address = $menu->menu;
            }
            if($menu->menu_variable=='address1'){
                $address1 = $menu->menu;
            }
            if($menu->menu_variable=='address2'){
                $address2 = $menu->menu;
            }
            if($menu->menu_variable=='landmark'){
                $landmark = $menu->menu;
            }
            if($menu->menu_variable=='city_town'){
                $city_town = $menu->menu;
            }
            if($menu->menu_variable=='pincode'){
                $pincode = $menu->menu;
            }
            if($menu->menu_variable=='state'){
                $state = $menu->menu;
            }

        }
            $lang_menu = array( 
                "my_profile" =>$my_profile,
                "first_name"=>$first_name,
                "full_name"=>$full_name,
                "email_address"=>$email_address,
                "phone"=>$phone,
                "submit"=>$submit,
                "delivery_address"=>$delivery_address,
                "address1"=>$address1,
                "address2"=>$address2,
                "landmark"=>$landmark,
                "city_town"=>$city_town,
                "pincode"=>$pincode,
                "state"=>$state
                );
        
    $qry = $this->db->query("SELECT user_id,fullname,email,phone_no from user_profile user WHERE user.user_id = $user_id")->result();
    $data = array();
    if($qry){
        $phone_no = substr($qry[0]->phone_no,2); //remove country code 91
    $data = array (
        'user_id' => $qry[0]->user_id,
        'fullname' => $qry[0]->fullname,
        'email' => $qry[0]->email,
        'phone_no' => $phone_no
        );
    }
    if ($qry){
            return $result = array('status'=>1,'message'=>'My Profile','data'=>$data,'menu'=>$lang_menu); 
        }
    else{
        return false;
    }
}
public function update_profile($postdata=array()){ //MS
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id  = $postdata['user_id'];
    $update_data['fullname']  = $postdata['fullname'];
    $update_data['phone_no'] = '91'.$postdata['phone_no'];
    if(isset($postdata['email'])){
    $update_data['email'] = $postdata['email'];
    }
    $status = $this->db->update('user_profile',$update_data,array('user_id'=>$user_id));
    if($status){
        $val = $this->db->query("select email,fullname from user_profile where user_id=$user_id")->result();
        $email = $val[0]->email;
// 			mail start
 //send welcome mail to Customer
                 if(isset($email) || !empty($email)){
            
                $to_receiver_email = $email ;
                $cust_name = $val[0]->fullname;;
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Profile Updated ";
                $dt['heading'] = "Profile Updated";
             $dt['message'] = 
             "Dear $cust_name,<br>

               &nbsp; &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  Greetings! Your <strong>The Brownie Studio</strong> Profile has been successfully updated.<br>
                    
                &nbsp; &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp; Please reach out to us at thebrowniestudio@gmail.com, if this was not done by you.<br><br>

Regards,<br>
<strong>  The Brownie Studio </strong>  
  ";
$message_html = $this->load->view('template/profile_update', $dt, TRUE);
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                //  if($response['status']==0)
                //  {
                //      echo json_encode(array('status'=>0,'message'=>'Failed to send mail ')); exit;
                //  }
            }

      
// mail end
 
        return $result = array('status'=>1,'message'=>'Profile updated'); 
    }
    else{
        return false;
    }

}
public function change_password($postdata=array()){ //MS
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id  = $postdata['user_id'];
    $password  = md5($postdata['new_password']);
    $status=$this->db->query("update user_profile set password  ='$password' where user_id= $user_id");
    if($status){
        $val = $this->db->query("select email,fullname from user_profile where user_id=$user_id")->result();
       $email = $val[0]->email;
       
       ///////////////////////////////////////////////////////////////////////////////////
         //send welcome mail to Customer
            if($email!=''){
                $to_receiver_email = $email;
                $cust_name = $val[0]->fullname;
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Password Updated";
            // $message = $this->load->view('template/email_template2');
            $dt['heading'] = "Password Updated";
            $dt['message']  = 
"Dear $cust_name, <br>

                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Alert! Your <strong>  The Brownie Studio </strong> account password has been updated. <br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Please reach out to us at <strong>  thebrowniestudio@gmail.com </strong>, if this was not done by you. <br><br>
                
                Regards,<br>
                <strong>  The Brownie Studio </strong>  
            ";
    $message = $this->load->view('template/email_template2',$dt,TRUE);
             $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
             if($response['status']==0){
                 return $result = array('status'=>1,'message'=>'Failed to send mail ', 'data'=>$val); 
             }
            }
            
       
       
       ///////////////////////////////////////////////////////////////////////////////////
       
       
            //send Password Changed notification mail to Customer 
    //             if($email!=''){
    //             $to_receiver_email = $email;
    //             $cust_name = $val[0]->fullname;
    //             $from_email = 'yellowmart17@gmail.com';
    //             $from_emailpassword = 'yellowmart123';
    //             $from_username = 'BrownieStudio - Mail';
    //             $subject="Password Changed";
    //             $message = 
    // "Dear $cust_name,
    
    // Alert! Your BrownieStudio account password has been updated.
    
    // Please reach out to us at thebrowniestudio@gmail.com, if this was not done by you.
    
    // Regards,
    // Team BrownieStudio";
    //                  $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
    //                 //  if($response['status']==0){
    //                 //      return $result = array('status'=>1,'message'=>'Failed to send mail '); 
    //                 //  }
    //             }
    
        return $result = array('status'=>1,'message'=>'Password updated'); 
    }
    else{
        return false;
    }

}
public function old_password_validation($postdata=array()){ //MS
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id  = $postdata['user_id'];
    $password  = md5($postdata['old_password']);
    $status=$this->db->query("select * from user_profile where password  ='$password' and user_id= $user_id")->result();
    if($status){
        return $result_old = array('status'=>1,'message'=>'Correct Password'); 
    }
    else{
        return $result_old = array('status'=>0,'message'=>'Invalid old password, Try again!'); 
    }

}
//view store
public function get_storedtl($postdata=array()){ //MS
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $store_id =$postdata['store_id'];
        if (filter_var($store_id, FILTER_VALIDATE_URL)) { //Qrcode contains URL : https://yellowmart.biz/1/Registration // take storeid form url
            $get_storeid = explode('/',$store_id); //Array([0] => https:[1] => [2] => yellowmart.biz [3] => 16 [4] => Registration)
            $store_id = $get_storeid[3];
        }
        $user_id =$postdata['user_id'];
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
        
        $lang_menu = array();
        $store_category =''; $store_timing=''; $add_mart='';
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and trim(page_name) ='View Store Page'")->result();
        foreach($menu_list as $menu){
            if($menu->menu_variable=='store_category'){
                $store_category = $menu->menu;
            }
            if($menu->menu_variable=='store_timing'){
                $store_timing = $menu->menu;
            }
            if($menu->menu_variable=='add_mart'){
                $add_mart = $menu->menu;
            }
            
        }
            $lang_menu = array( 
                "store_category"=>$store_category,
                "store_timing"=>$store_timing,
                "add_mart"=>$add_mart
                );
        
        
        //If this store already added for this user , My Stores list means send status 0,1
        $chk_mystores_list = $this->db->query("select * from my_stores where user_id =$user_id and store_id = $store_id")->result();
        if(count($chk_mystores_list)>0){
        $qry = $this->db->query("SELECT stores.store_id ,stores.store_name,stores.store_image,cat.category_name,TIME_FORMAT(stores.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end, '%h:%i %p')starting_end,'1' as Store_status,city_town as store_location FROM stores INNER JOIN store_category cat on stores.cat_id = cat.id WHERE stores.store_id =$store_id");    
        }
        else{
        $qry = $this->db->query("SELECT stores.store_id ,stores.store_name,stores.store_image,cat.category_name,TIME_FORMAT(stores.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end, '%h:%i %p')starting_end,'0' as Store_status,city_town as store_location FROM stores INNER JOIN store_category cat on stores.cat_id = cat.id WHERE stores.store_id =$store_id");        
        }
        if ($qry->num_rows() > 0) {
            $val = $qry->row(); 
            return $result = array('status'=>1,'message'=>'Store Details', 'data'=>$val,'menu'=>$lang_menu); 
        }
    }
//add store    
public function add_to_my_stores($postdata=array()){
        $date_added = date("Y-m-d H:i:s");
        $store_id = $postdata['store_id'];
        $user_id  = $postdata['user_id'];
        $status= $this->db->insert('my_stores', array('user_id'=>$postdata['user_id'],'store_id'=>$postdata['store_id'],'date_added'=>$date_added));
        if($status==1){
            $dt = $this->db->query("select first_circle from user_profile where user_id = $user_id")->result();
            if($dt){
                $first_circle = $dt[0]->first_circle;
            // Add this store to first circle
                $update['otp_verify_status'] = 1;
                $where['user_id'] = $user_id;
                if($first_circle==''){
                $update['first_circle'] = $store_id;    
                }else{
                    $first_array = explode(",",$first_circle);
                    if (in_array($store_id, $first_array)){
                        
                    }else{
                        $update['first_circle'] = $first_circle.','.$store_id;
                    }
                }
                if(isset($update)){
                $this->db->update('user_profile',$update,$where);
                }
            }
             return $result = array('status'=>1,'message'=>'App added successfully'); 
        }
        else
        {
            return $result = array('status'=>0,'message'=>'Unable to add app!'); 
        }
    }
    //my stores 
    public function my_stores($postdata=array()){
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $city_id ='';
        if(isset($postdata['city_id'])){
            if(trim($postdata['city_id'])!=''){
            $city_id =  trim($postdata['city_id']);
            }
        }
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
            exit;
        }
        $final_array= array();$cat_array =array(); $lang_menu = array();$allcat_array =array();
        $home =''; $profile =''; $my_order=''; $change_password='';$contact_us='';$logout='';$search='';$my_store='';$terms_conditions='';$store_not_available='';$language='';$nearby_store='';$manage_address='';
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and page_name ='Home Page'")->result();
        foreach($menu_list as $menu){
            if($menu->menu_variable=='home'){
                $home = $menu->menu;
            }
            if($menu->menu_variable=='profile'){
                $profile = $menu->menu;
            }
            if($menu->menu_variable=='my_order'){
                $my_order = $menu->menu;
            }
            if($menu->menu_variable=='nearby_store'){
                $nearby_store = $menu->menu;
            }
            if($menu->menu_variable=='change_password'){
                $change_password = $menu->menu;
            }
            if($menu->menu_variable=='contact_us'){
                $contact_us = $menu->menu;
            }
            if($menu->menu_variable=='logout'){
                $logout = $menu->menu;
            }
            if($menu->menu_variable=='search'){
                $search = $menu->menu;
            }
             if($menu->menu_variable=='my_store'){
                $my_store = $menu->menu;
            }
            if($menu->menu_variable=='terms_conditions'){
                $terms_conditions = $menu->menu;
            }
            if($menu->menu_variable=='store_not_available'){
                $store_not_available = $menu->menu;
            }if($menu->menu_variable=='manage_address'){
                $manage_address = $menu->menu;
            }
            if($menu->menu_variable=='language'){
                $language = $menu->menu;
            }
            
        }
            $lang_menu = array( 
                "home" =>$home,
                "profile"=>$profile,
                "my_order"=>$my_order,
                "change_password"=>$change_password,
                "contact_us"=>$contact_us,
                "logout"=>$logout,
                "search"=>$search,
                "my_store"=>$my_store,
                "nearby_store"=>$nearby_store,
                "terms_conditions"=>$terms_conditions,
                "store_not_available"=>$store_not_available,
                "manage_address"=>$manage_address,
                "language"=>$language
                );
        
        $qry_cat =$this->db->query("SELECT DISTINCT s_cat.category_name,s.cat_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id inner join store_category s_cat on s_cat.id = s.cat_id where ms.user_id =$user_id")->result();
        if($qry_cat){
            foreach($qry_cat as $cat){
                $str_array= array();$allstr_array= array();
                $cat_id = $cat->cat_id;
            $qry = $this->db->query("SELECT s.store_opening_status,user.fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id and s.cat_id = $cat_id and s.status = 1 ")->result();
              foreach($qry as $str){
            $str_array[] = array(
                'fullname'=>$str->fullname,
                'store_name'=>$str->store_name,
                'store_image'=>$str->store_image,
                'starting_time'=>$str->starting_time,
                'starting_end'=>$str->starting_end,
                'store_id'=>$str->store_id,
                'store_opening_status' => $str->store_opening_status
                );
            }
            $cat_array[] = array(
                'cat_id' =>$cat->cat_id,
                'category_name' =>$cat->category_name,
                'store' =>$str_array
                );
            }
           $qry_allstores = $this->db->query("SELECT '' fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id,s.store_opening_status FROM stores s where s.store_id not in (SELECT s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id)and s.status = 1 ")->result();       
           if($city_id==''){ //default home page load user curret city nearby stores   // address_type=1 current address address_type= 0  saved address
            //   $current_city = $this->db->query("select * from address where user_id = $user_id and address_type=1")->result(); 
            //   if($current_city){
            //       $city_id = $current_city[0]->city_id;
            //   }
              $current_city = $this->db->query("select current_cityid from user_profile where user_id = $user_id")->result(); 
              if($current_city){
                  $city_id = $current_city[0]->current_cityid;
              }
               if($city_id!=''){
                        $qry_allstores = $this->db->query("SELECT '' fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id,s.store_opening_status FROM stores s where s.store_id not in (SELECT s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id )and s.status = 1 and city_id = $city_id")->result();    
               }
            }else{ //load near by stores  from search city filter  wise
            $qry_allstores = $this->db->query("SELECT '' fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id,s.store_opening_status FROM stores s where s.store_id not in (SELECT s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id )and s.status = 1 and city_id = $city_id")->result();    
            }
               foreach($qry_allstores as $str){
            $allstr_array[] = array(
                'store_name'=>$str->store_name,
                'store_image'=>$str->store_image,
                'starting_time'=>$str->starting_time,
                'starting_end'=>$str->starting_end,
                'store_id'=>$str->store_id,
                'store_opening_status' => $str->store_opening_status
                );
            }
            
            $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
            $cart_count = count($cart_data);
            
             $ticker_array = array();
            $ticker = $this->db->query("select * from ticker where status =1")->result();
            $ttl_discount = 0;
            $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status = 2 AND user_id = $user_id")->result();
            if($total_discount){
                $ttl_discount =  $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
            }
            if($ticker){
                foreach($ticker as $t){
                    $ticker_array[] = array(
                    'ticker_id' => $t->id,
                    'ticker_text' => $t->ticker_text
                    );
                }
            }
            if($ttl_discount > 0){
            // $ticker_array[] = array(
            //         'ticker_id' => -1,
            //         'ticker_text' => 'You have saved Rs. '.$ttl_discount.' on Yellowmart. Enjoy shopping!'
            //         );
            }
                    $city_name ='';
                    $getcity_name = $this->db->query("SELECT * from city WHERE id =$city_id ")->result();
                    if($getcity_name){
                        $city_name = $getcity_name[0]->city_name;
                    }
            $currentaddress_available = 0;
            $getcurrent_address = $this->db->query("select * from address where user_id = $user_id and address_type=1")->result(); 
            if($getcurrent_address){
                $currentaddress_available = 1;
            }
            $final_array = array(
             'status' =>1,
             'message' =>'Stores List',
             'mystores' => $cat_array,
             'allstores'=>$allstr_array,
             'cart_count' =>$cart_count,
             'city' =>$city_name,
             'currentaddress_available'=>$currentaddress_available,
             'menu'=>$lang_menu,
             'ticker'=>$ticker_array
             );
             return $final_array;
        }
        else{
            $cat_array = array();$ticker_array= array();$allstr_array= array();
            $qry_allstores = $this->db->query("SELECT '' fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id,s.store_opening_status FROM stores s where s.store_id not in (SELECT s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id)and s.status = 1 ")->result();       
           if($city_id==''){ //default home page load user curret city nearby stores   // address_type=1 current address address_type= 0  saved address
                //   $current_city = $this->db->query("select * from address where user_id = $user_id and address_type=1")->result(); 
                //   if($current_city){
                //       $city_id = $current_city[0]->city_id;
                //   }
                      $current_city = $this->db->query("select current_cityid from user_profile where user_id = $user_id")->result(); 
                      if($current_city){
                          $city_id = $current_city[0]->current_cityid;
                      }
                   if($city_id!=''){
                            $qry_allstores = $this->db->query("SELECT '' fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id,s.store_opening_status FROM stores s where s.store_id not in (SELECT s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id )and s.status = 1 and city_id = $city_id")->result();    
                   }
            }else{ //load near by stores  from search city filter  wise
                  $qry_allstores = $this->db->query("SELECT '' fullname,s.store_name,s.store_image,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,s.store_id,s.store_opening_status FROM stores s where s.store_id not in (SELECT s.store_id FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id where ms.user_id =$user_id )and s.status = 1 and city_id = $city_id")->result();    
            }
                   $city_name ='';
                    $getcity_name = $this->db->query("SELECT * from city WHERE id =$city_id ")->result();
                    if($getcity_name){
                        $city_name = $getcity_name[0]->city_name;
                    }
            // if($qry_allstores){
               foreach($qry_allstores as $str){
            $allstr_array[] = array(
                'store_name'=>$str->store_name,
                'store_image'=>$str->store_image,
                'starting_time'=>$str->starting_time,
                'starting_end'=>$str->starting_end,
                'store_id'=>$str->store_id,
                'store_opening_status' => $str->store_opening_status
                );
            }
            $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
            $cart_count = count($cart_data);
            $ticker_array = array();
            $ticker = $this->db->query("select * from ticker where status =1")->result();
            $ttl_discount = 0;
            $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status = 2 AND user_id = $user_id")->result();
            if($total_discount){
                $ttl_discount =  $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
            }
            if($ticker){
                foreach($ticker as $t){
                    $ticker_array[] = array(
                    'ticker_id' => $t->id,
                    'ticker_text' => $t->ticker_text
                    );
                }
            }
            if($ttl_discount > 0){
            // $ticker_array[] = array(
            //         'ticker_id' => -1,
            //         'ticker_text' => 'You have saved Rs. '.$ttl_discount.' on Yellowmart. Enjoy shopping!'
            //         );
            }
            $currentaddress_available = 0;
            $getcurrent_address = $this->db->query("select * from address where user_id = $user_id and address_type=1")->result(); 
            if($getcurrent_address){
                $currentaddress_available = 1;
            }
            $final_array = array(
             'status' =>1,
             'message' =>'Stores List',
             'mystores' => $cat_array,
             'allstores'=>$allstr_array,
             'cart_count' =>$cart_count,
             'city' =>$city_name,
             'currentaddress_available'=>$currentaddress_available,
             'menu'=>$lang_menu,
             'ticker'=>$ticker_array
             
             );
             return $final_array;
        // }
        // else{
        //     return false;
        // }
    }
    }
//search store
public function search_store($postdata=array()){
        $keyword = $postdata['keyword'];
        if(isset($postdata['user_id'])){
           $user_id = $postdata['user_id']; 
        }else{
            $user_id = '';
        }
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
        //  $qry = $this->db->query("SELECT user.fullname,s.store_name,s.store_image,s.store_id,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,c.category_id,c.category_name ,ct.location FROM my_stores ms INNER JOIN stores s on s.store_id = ms.store_id INNER JOIN user_profile user on user.user_id = ms.user_id INNER JOIN categories c on c.category_id = s.cat_id INNER join cities1 ct on ct.city_id = s.city_id where s.store_name LIKE '%$keyword%' ");
         if($keyword == "All"){
              $qry = $this->db->query("SELECT '' as fullname,s.store_name,s.store_image,s.store_id,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,c.id category_id,c.category_name ,'' location,store_opening_status FROM stores s INNER JOIN store_category c on c.id = s.cat_id  where s.status =1")->result();
         }else{
              $qry = $this->db->query("SELECT '' as fullname,s.store_name,s.store_image,s.store_id,TIME_FORMAT(s.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(s.starting_end, '%h:%i %p')starting_end,c.id category_id,c.category_name ,'' location,store_opening_status FROM stores s INNER JOIN store_category c on c.id = s.cat_id  where s.store_name LIKE '%$keyword%' and s.status =1")->result();
         }
        
         $data_array = array();
         foreach($qry as $data){
             $store_id = $data->store_id;
             if($user_id){
                $chk = $this->db->query("select * from my_stores where user_id  =$user_id and store_id = $store_id")->result(); 
             }else{
                 $chk = $this->db->query("select * from my_stores where store_id = $store_id")->result();
             }
             
             if(count($chk)>0){
             $mystore_status = 1;
             }
             else {
                 $mystore_status = 0;
             }
             $data_array[] = array (
             'store_name' => $data->store_name,
             'store_image' => $data->store_image,
             'store_id' => $data->store_id,
             'starting_time' => $data->starting_time,
             'starting_end' => $data->starting_end,
             'category_id' => $data->category_id,
             'category_name' => $data->category_name,
             'location' => $data->location,
             'mystore_status' => $mystore_status,
             'store_opening_status' => $data->store_opening_status
             
             );
         }
         if($qry){
             return $result = array('status'=>1,'message'=>'Search List', 'data'=>$data_array); 
         }
         else{
             return false;
         }
    }
     public function product_details($postdata=array()){
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])|| !isset($postdata['user_id'])){
            return false;
        }
        $store_id =$postdata['store_id'];
        $user_id =$postdata['user_id'];
        $product_id =$postdata['product_id'];
        $item_id =$postdata['item_id'];
        $chkcolor_value ='';$chksize_value =''; $chktype_value ='';$chkweight_value="";$chkshape_value="";
        if(isset($postdata['color_value'])){
            $chkcolor_value = $postdata['color_value'];
        }
        if(isset($postdata['size_value'])){
            $chksize_value = $postdata['size_value'];
        }
        if(isset($postdata['type_value'])){
            $chktype_value = $postdata['type_value'];
        }
        if(isset($postdata['weight_value'])){
            $chkweight_value = $postdata['weight_value'];
        }
        if(isset($postdata['shape_value'])){
            $chkshape_value = $postdata['shape_value'];
        }
        $change_key =""; ////type or shape or weight
        if(isset($postdata['change_key'])){
            $change_key = $postdata['change_key'];
        }
        $temp_itemid = 0;
        // if($chkcolor_value!="" || $chksize_value!="" ){
        //     $res = $this->finditem_id($store_id,$product_id,$chkcolor_value,$chksize_value);
        //     if($res){
        //     if($res['status']==1){
        //       $item_id =$res['item_id'];  
        //     }else{
        //         if($chkcolor_value!=""){ //color change from red to pink , so size not yet choose it that case input size value empty
        //             $chksize_value ="";
        //             $gettemp_id = $this->db->query("select * from product_itemdtl where prod_id = $product_id and pri_attcolor ='$chkcolor_value'")->result();
        //             if($gettemp_id){
        //                 $temp_itemid = $gettemp_id[0]->prod_itemid;// if size not selected choose 0th item as item_id
        //                 $item_id = $temp_itemid;
        //             }
        //         }
        //     }
        // }
        // }
     if($chktype_value!="" || $chkweight_value!="" || $chkshape_value!="" ){
         $whr ="";
        if(strtoupper($change_key)=='WEIGHT'){
            $whr = " and var1 = '$chkweight_value'";
        }else if(strtoupper($change_key)=='TYPE'){
            $whr = " and var2 = '$chktype_value'";
        }else if(strtoupper($change_key)=='SHAPE'){
            $whr = " and var3 = '$chkshape_value'";
        }
        $where = "WHERE pro.prod_id = $product_id";
        if($chkweight_value!=""){
            $where = $where." and var1 = '$chkweight_value'";
        }
        if($chktype_value!=""){
            $where = $where." and var2 = '$chktype_value'";
        }
        if($chkshape_value!=""){
            $where = $where." and var3 = '$chkshape_value'";
        }
        $get_data = $this->db->query("SELECT * FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id $where")->result();
        if($get_data){
            $item_id = $get_data[0]->prod_itemid;
        }else{
            $get_firstitem = $this->db->query("SELECT * FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id WHERE pro.prod_id = $product_id $whr ")->result();    
            if($get_firstitem){
                $item_id = $get_firstitem[0]->prod_itemid;
            }
        }
     }
        if($user_id!=0){
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
            exit;
        }}
        $lang_menu = array();
        $price =''; $product_details =''; $product_type=''; $stock='';$brand='';$quantity='';$add_to_basket='';$view_basket='';
        if($user_id==0){
            $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu,menu.lang_id FROM language_menu  as menu WHERE menu.lang_id =1 and trim(page_name) ='Product Detail Page'")->result();//default english language
        }else {
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and trim(page_name) ='Product Detail Page'")->result();
        }
        foreach($menu_list as $menu){
            if($menu->menu_variable=='price'){
                $price = $menu->menu;
            }
            if($menu->menu_variable=='product_details'){
                $product_details = $menu->menu;
            }
            if($menu->menu_variable=='product_type'){
                $product_type = $menu->menu;
            }
            if($menu->menu_variable=='stock'){
                $stock = $menu->menu;
            }
            if($menu->menu_variable=='brand'){
                $brand = $menu->menu;
            }
            if($menu->menu_variable=='quantity'){
                $quantity = $menu->menu;
            }
            if($menu->menu_variable=='add_to_basket'){
                $add_to_basket = $menu->menu;
            }
             if($menu->menu_variable=='view_basket'){
                $view_basket = $menu->menu;
            }

        }
            $lang_menu = array( 
                "price" =>$price,
                "product_details"=>$product_details,
                "product_type"=>$product_type,
                "stock"=>$stock,
                "brand"=>$brand,    
                "quantity"=>$quantity,
                "add_to_basket"=>$add_to_basket,
                "view_basket"=>$view_basket
                );
                
    $proddtl = $this->db->query("SELECT pro.subcat_id,pri_att,pro.prod_name,pro.store_id,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,prod_img2,prod_img3,prod_img4,prod_img5,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.store_id,str.store_name,TIME_FORMAT(str.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(str.starting_end, '%h:%i %p')starting_end,cat.category_id as cat_id,cat.category_name,brand.brand_name,prodtl.item_images,prodtl.pri_attcolor,pro.description from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND pro.prod_id = $product_id AND prodtl.prod_itemid = $item_id AND pro.prod_status = 1 and prodtl.item_availability = 1 order by pro.prod_id")->result();
    if($proddtl){
         $qry_image =array(); $price =''; $stock_qty = 0; $review_array=array();$color_array =array();$varient_array= array();
        
        foreach($proddtl as $dt){
                $type = $dt->type;
                $add_variant = $dt->add_variant;
                 $sale_unit = $dt->sale_unit;
                 $stock_unit = $dt->stock_unit;
                 $pack_content = $dt->pack_content;
            //images section start here
            if($dt->item_images!=""){
                $itemwise_images = explode('|',$dt->item_images);
                $prod_img1 ='';$prod_img2 ='';$prod_img3 ='';$prod_img4 ='';
                if(isset($itemwise_images[0])){
                    $prod_img1 =$itemwise_images[0];
                }
                if(isset($itemwise_images[1])){
                    $prod_img2 =$itemwise_images[1];
                }
                if(isset($itemwise_images[2])){
                    $prod_img3 =$itemwise_images[2];
                }
                if(isset($itemwise_images[3])){
                    $prod_img3 =$itemwise_images[3];
                }
                $qry_image = array (
                'product_image' =>$prod_img1,
                'product_image_1' =>$prod_img2,
                'product_image_2' =>$prod_img3,
                'product_image_3' =>$prod_img4,
                'product_image_4' =>""
                );
            }else{ //default static images
                $qry_image = array (
                'product_image' =>$dt->prod_img1,
                'product_image_1' =>$dt->prod_img2,
                'product_image_2' =>$dt->prod_img3,
                'product_image_3' =>$dt->prod_img4,
                'product_image_4' =>$dt->prod_img5,
                );
            }
            //image section end here
             //Price start here
                $price_to_display = $dt->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $dt->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $dt->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $dt->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $dt->mop_price .' - ₹ '.$dt->mrp_price; //
                   }
                 } //Price end here
                 $display_type = $dt->price_to_display;
                 $final_mrpprice = $dt->mrp_price; 
                 $stock_qty = 0; 
                 //get stock start here
                 if(trim(strtoupper($dt->display_stock))=="NO"){ //follow MOQ
                     $stock_qty = $dt->item_moq;
                 }else {
                     if(strtoupper($type)=="LOOSE"){ //loose product
                         $stock_qty = $dt->item_totstock; 
                      //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock //Only applicable for loose product
                            if($sale_unit!=$stock_unit){
                                if($sale_unit == 1 || $sale_unit == 3){ //1-ml to ltr  ex. 5ltr total stck 500ml packet content //3-gram to kg
                                    $converted = $pack_content / 1000;   // 500ml /1000 = 0.5ltr
                                    $stock_qty = $stock_qty / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                                }
                                else if($sale_unit == 2 || $sale_unit == 5){ //2- ltr to ltr //5-kg to kg
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else if($sale_unit == 4 || $sale_unit == 6 || $sale_unit == 7 || $sale_unit == 8 || $sale_unit == 9){//4-box//6-pcs//7-nos //8-packet//9-plate
                                    $stock_qty = $stock_qty;
                                }
                            }
                            else{
                                 if(($sale_unit == 1) || ($sale_unit == 2) || ($sale_unit == 3) || ($sale_unit == 5) ){
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else {
                                    $stock_qty = $stock_qty;
                                }
                            }
                            $stock_qty = (int)$stock_qty;
                     } else { //Other than loose product
                         $stock_qty = $dt->item_totstock; 
                     }
                 }
                 $fi_stock_qty = round($stock_qty);
                 // stock calculation end here
                  //Stock status    
                if($dt->item_stocksts==1){
                     $stock_status_final='Available';
                }
                
                if($fi_stock_qty <=0 ){
                    $stock_status_final = 'Out of Stock';
                }
                if($dt->item_availability ==0 ){//check availability
                    $stock_status_final = 'Sold Out';
                }
                $weight_var =array(); $type_var =array(); $shape_var =array(); $weight_text=""; $type_text=""; $shape_text="";
                //variant array
                 //get variant name
                 $get_itemdtl = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id=prodtl.prod_id where pro.prod_id=$product_id and pro.store_id=$store_id and item_stocksts=1 and item_availability=1")->result();
                 if($get_itemdtl){
                     foreach($get_itemdtl as $item){
                    if($item->att1!="" && $item->var1!="" ){
                         $selected =0;
                         if($dt->var1 == $item->var1){
                             $selected =1;
                             $weight_text = $item->var1;
                         }
                         if(empty($weight_var)){
                             $weight_var[] = array('value'=>$item->var1,'selected'=>$selected);
                         }else{
                             if(!in_array($item->var1, array_column($weight_var, 'value'))){
                             $weight_var[] = array('value'=>$item->var1,'selected'=>$selected);
                            }
                        $k=0;                                 
                         foreach($weight_var as $we){
                             if($we['value']!=$item->var1){
                                //  $weight_var[] = array('value'=>$vars->var1,'selected'=>$selected);
                                //  break; //avoid duplicate variant adding
                             }else if($selected==1){
                                 $weight_var[$k]['selected'] = 1;
                             }
                             $k++;
                         }}
                         //print_r($weight_var);
                     }
                     if($item->att2!="" && $item->var2!="" ){
                         $selected =0;
                         if($dt->var2 == $item->var2){
                             $selected =1;
                             $type_text = $item->var2;
                         }
                         if(empty($type_var)){
                             $type_var[] = array('value'=>$item->var2,'selected'=>$selected);
                         }
                         if(!in_array($item->var2, array_column($type_var, 'value'))){
                             $type_var[] = array('value'=>$item->var2,'selected'=>$selected);
                             
                         }
                            $l=0;                         
                          foreach($type_var as $ty){
                             if($ty['value']!=$item->var2){
                                //  $type_var[] = array('value'=>$item->var2,'selected'=>$selected);
                                //  break;
                             }else if($selected==1){
                                 $type_var[$l]['selected'] = 1;
                             }
                             $l++;
                         }
                     }
                     if($item->att3!="" && $item->var3!="" ){
                          $selected =0;
                        //   print_r($dt->var3); echo '<pre>';
                        //   print_r($item->var3);  echo '<pre>';
                        //   print_r($selected);
                        //   echo '<pre>';
                         if($dt->var3 == $item->var3){
                             $selected =1;
                             $shape_text = $item->var3;
                         }
                         if(empty($shape_var)){
                             $shape_var[] = array('value'=>$item->var3,'selected'=>$selected);
                         }else{
                         if(!in_array($item->var3, array_column($shape_var, 'value'))){
                             $shape_var[] = array('value'=>$item->var3,'selected'=>$selected);
                         }}
                        //  print_r($shape_var);
                            $m=0;                         
                         foreach($shape_var as $sh){
                             if($sh['value']!=$item->var3){
                                //  $shape_var[] = array('value'=>$vars->var3,'selected'=>$selected);
                                //  break;
                             }else if($selected==1){
                                 $shape_var[$m]['selected'] = 1;
                             }
                             $m++;
                         }
                     }
                    //  die;
                          //color array
                    if($dt->pri_attcolor!=""){
                        $selected =0;
                        //  if($item->prod_itemid==$item_id){
                        //      $selected =1;
                        //  }
                         if($chkcolor_value==$item->pri_attcolor){
                             $selected =1;
                         }
                        $flg_c=1;
                        // $color_strike_out=0;
                         if($color_array){
                                 foreach($color_array as $val){
                                    if($item->pri_attcolor==$val['color_value']){ //if any one match don't repeate
                                        $flg_c=0;
                                    }
                                 }
                                     if($flg_c==1){
                                         $color_array[]  = array(
                                             'product_id'=>$item->prod_id,
                                             'color_value' => $item->pri_attcolor,
                                             'selected' => $selected
                                            //  'strike_out'=>$color_strike_out
                                              );
                                     }
                         }else{
                             $color_array[]  = array(
                                  'product_id'=>$item->prod_id,
                                  'color_value' => $item->pri_attcolor,
                                  'selected' => $selected
                                //   'strike_out'=>$color_strike_out
                              );
                         }
                        
                    }
                ////////
                
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant=="NO")){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $item->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     //Attribute1 //variant2
                        $primary_attibuteid = $item->pri_att;
                         $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                         
                         //Attribute1 //variant2
                         $att1_id = $item->att1;
                         $variant1 = $item->var1;
                         $att2_id = $item->att2;
                         $variant2 = $item->var2;
                         $att3_id = $item->att3;
                         $variant3 = $item->var3;
                         
                         $variant_name = $variant1.';'.$variant2.';'.$variant3;
                         $variant_name = rtrim($variant_name, ";");
                         $color_value = $item->pri_attcolor;
                         $size_value = trim($variant_name);
                         if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                              $color_n = $variant2.';'.$variant3; 
                              $color_n = rtrim($color_n, ";");
                              $size_value = trim($color_n);
                         }
                 }
                 $selected =0;
                     if($chksize_value==""){
                         if($item->prod_itemid==$temp_itemid){
                             $selected =1;  
                             $chksize_value = $size_value;
                         }
                     }else{
                        if($chksize_value==$size_value){
                                 $selected =1;
                             }
                     }
                         //////find item not available show strike
                         $var_strike_out =0;
                        if($chkcolor_value!="" && $item->pri_attcolor!=""){
                        if($chkcolor_value!=$item->pri_attcolor){
                             $var_strike_out =1;
                         }}
                         ///////
                 $flg=1;
                 if($size_value!=""){
                 if($varient_array){
                     $i=0;
                 foreach($varient_array as $val){
                    if($size_value==$val['size_value']){ //if any one match don't repeat
                        $flg=0;
                            if($chkcolor_value!="" && $item->pri_attcolor!=""){
                            if($chkcolor_value==$item->pri_attcolor){
                                 $varient_array[$i]['strike_out'] = 0;
                             }}
                    }
                    $i++;
                 }
                     if($flg==1){
                         $varient_array[]  = array(
                             'product_id'=>$product_id,
                              'var_name'=>$variant_name,
                              'size_value'=>$size_value,
                              'selected' => $selected,
                              'display_name' =>$item->display_name,
                              'strike_out'  =>$var_strike_out
                              );
                     }
                 }else{
                     $varient_array[]  = array(
                     'product_id'=>$product_id,
                      'var_name'=>$variant_name,
                      'size_value'=>$size_value,
                      'selected' => $selected,
                      'display_name' =>$item->display_name,
                      'strike_out'=>$var_strike_out
                      );
                 }
                 }
                 //////find item not available show strike
                        // if($color_array){
                        //              $j=0;
                        //          foreach($color_array as $val){
                        //              if($item->pri_attcolor==$val['color_value']){ 
                        //                     if($chksize_value!=""){
                        //                     if($chksize_value==$size_value){
                        //                          $color_array[$j]['strike_out'] = 0;
                        //                      }}
                                    
                        //             }$j++;
                        //          }}
                 }}
                 ///////
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        $enable_write_review = 0;
        $chk_prodt_orderedbefore = $this->db->query("select * from orders ord inner JOIN cart ON ord.order_id = cart.order_id where product_id = $product_id and ord.user_id =$user_id and delivery_status =2")->result();
        if(!empty($chk_prodt_orderedbefore)){
        $enable_write_review = 1;    
        }
        $get_reviews = $this->db->query("select * from user_reviews where store_id =$store_id and product_id = $product_id and view_status =1 order by id desc")->result();
        if($get_reviews){
            foreach($get_reviews as $re){
             $review_array[] = array(
                 'review_id' => $re->id,
                 'star_count' =>$re->star_count,
                 'review_type' =>$re->review_type,
                 'comment' =>$re->comment,
                 'date_reviewed'=>$re->date_reviewed
                 );
             
            }
        }
        $wishlist_sts = 0;
        $chk_wishlist = $this->db->query("select * from wishlist where user_id =$user_id and store_id =$store_id and product_id = $product_id and item_id = $item_id")->result();
        if($chk_wishlist){
            $wishlist_sts = 1;
        }
            $final_mrpprice =round($final_mrpprice,0);    
            $price_final =round($price_final,0);   
            if($dt->pri_attcolor!=""){
            }
            if($fi_stock_qty > 10){
            $fi_stock_qty = 10;
        }
        $store_id = $dt->store_id;
        //align size into another array .// m,xl,s,xs,xxl into xs,s,m,l,xxl
        $new_varient_array = array();
        $variants = $this->db->query("select * from varients where store_id = $store_id order by filter_orderby")->result();
        foreach($variants as $orderby_var){
            $orderwise_variant_name = $orderby_var->varient_name;
            foreach($varient_array as $cur_var){
                if(trim($cur_var['size_value']) ==trim($orderwise_variant_name)){
                    $new_varient_array[]  = array(
                     'product_id'=>$cur_var['product_id'],
                      'var_name'=>$cur_var['var_name'],
                      'size_value'=>$cur_var['size_value'],
                      'selected' => $cur_var['selected'],
                      'display_name' =>$cur_var['display_name']
                      );
                }
            }
        }
        $color_name =$dt->var1;
        if($chkcolor_value!=""){
        $getcolor_name = $this->db->query("select * from product_itemdtl where prod_id = $product_id and pri_attcolor ='$chkcolor_value'")->result();
        if($getcolor_name){
            $color_name = $getcolor_name[0]->var1;
        }
        }
        // $delivery_slot = $this->db->query("select time_slot from delivery_slot where enable =1")->result();
        $delivery_slotary = $this->get_deliveryslot();
        $delivery_slot = json_decode(json_encode($delivery_slotary['data']), FALSE);
        $pre_deldate = "";$pre_deltime = "";$preferred_del_show_time="";
        $get_datetime = $this->db->query("select preferred_del_date,preferred_del_time,time_slot_view from cart inner join delivery_slot slot ON slot.time_slot = cart.preferred_del_time where order_id = 0 and user_id = $user_id")->result();
        if($get_datetime){
            if($get_datetime[0]->preferred_del_date!='0000-00-00'){
                $pre_deldate = $get_datetime[0]->preferred_del_date;
            }
            if($get_datetime[0]->preferred_del_time!=''){
                $pre_deltime = $get_datetime[0]->preferred_del_time;
            }
            $preferred_del_show_time = $get_datetime[0]->time_slot_view;
        }
        
              $final_array = array(
            'subcat_id'=>$dt->subcat_id,
            'type'=> $dt->type,
            'store_id'=> $dt->store_id,
            'color_name'=> $color_name,
            // 'color_value'=>$dt->pri_attcolor,
            'color_value'=>$chkcolor_value,
            // 'size_value'=>$dt->var2,
            'size_value'=>$chksize_value,
            'store_name' => $dt->store_name,
            'starting_time'=> $dt->starting_time,
            'starting_end'=> $dt->starting_end,
            'product_id'=> $dt->prod_id,
            'item_id'=>$item_id,
            'product_name'=> $dt->display_name,
            'product_nameold'=> $dt->prod_name,
            'product_description'=>$dt->description,
            'category_id'=> $dt->cat_id,
            'category_name'=> $dt->category_name,
            'brand'=> $dt->brand_name,
            'images'=>$qry_image,
            'price'=>"$price_final",
            'display_type'=>$display_type,
            'mrp_price'=>"$final_mrpprice",
            'display_price'=>"$price_final",
            'stock'=>"$fi_stock_qty",
            'stock_status'=>$stock_status_final,
            'color' =>$color_array,
            'varients'=>$varient_array,
            'wishlist_sts'=>$wishlist_sts,
            'theme_color'=>$theme_color,
            'font_color'=>$font_color,
            'enable_write_review' => "$enable_write_review",
            'review_array'=>$review_array,
            'weight_var'=>$weight_var,
            'type_var'=>$type_var,
            'shape_var'=>$shape_var,
            'weight_text'=>$weight_text,
            'type_text'=>$type_text,
            'shape_text'=>$shape_text,
            'delivery_slot'=>$delivery_slot,
            'pre_deldate'=>$pre_deldate,
            'pre_deltime'=>$pre_deltime,
            'preferred_del_show_time' =>$preferred_del_show_time
            );
            return $result = array('status'=>1,'message'=>'Product Details','data' => $final_array ,'menu'=>$lang_menu);
        }
    }
     }
     
//delete store
 public function delete_store($postdata=array()){
    $store_id = $postdata['store_id'];
    $user_id = $postdata['user_id'];
    $result = $this->db->query("delete from my_stores where store_id = $store_id and user_id = $user_id");
    if($result){
    return $result = array('status'=>1,'message'=>'Store Deleted Successfully');    
    }}
      // user delete address API 
     public function delete_address($postdata=array()){ 
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])|| !isset($postdata['address_id']) || empty($postdata['address_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $address_id = $postdata['address_id'];
        $result = $this->db->query("delete from address where id = $address_id and user_id = $user_id and address_type!=1"); //dont't allow to delete current address
        if($result){
        return $status = array('status'=>1,'message'=>'User address Removed'); 
        }else{
            return 0;
        }

    }
    public function update_ordersummary_currentaddress($postdata=array()){
        if(!isset($postdata['user_id']) || empty($postdata['user_id']) || !isset($postdata['address_id']) || empty($postdata['address_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $address_id = $postdata['address_id'];
        $this->db->query("update address set address_type = 0 where user_id =$user_id ");    //update other address as saved address then current address will update as 1
        $status = $this->db->query("update address set address_type = 1 where user_id =$user_id and id = $address_id ");    //update current address will update as 1
        
        $get_currentcity_id = $this->db->query("select city_id from address where address_type = 1 and user_id =$user_id and id = $address_id")->result();
        if($get_currentcity_id){
            $current_cityid = $get_currentcity_id[0]->city_id;
            $this->db->query("update user_profile set current_cityid = $current_cityid where user_id =$user_id ");    //update current city in user_profile
        }
        
        if($status ){
            return $status = array('status'=>1,'message'=>'Delivery Address Updated'); 
        }
        else{
            return false;
        }
        }
    public function offer_products($postdata=array()){
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $user_id =$postdata['user_id'];
        if($user_id!=0){
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
            exit;
        }}
        $store_id =$postdata['store_id'];
        //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        
        $final_array =array();
         $prod_qry = $this->db->query("SELECT pri_att,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.cat_id,pro.subcat_id from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id and pro.prod_status = 1 order by pro.prod_id")->result();
         $data =array();
            foreach($prod_qry as $dt){
                $subcat_name = $dt->subcategory_name;
                $prod_itemid = $dt->prod_itemid;
                //Price start here
                $price_to_display = $dt->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $dt->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $dt->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $dt->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $dt->mop_price .' - ₹ '.$dt->mrp_price; //
                   }
                 } //Price end here
                 $display_type = $dt->price_to_display;
                 $final_mrpprice = $dt->mrp_price; 
                 $type = $dt->type;
                 $add_variant = $dt->add_variant;
                 $sale_unit = $dt->sale_unit;
                 $stock_unit = $dt->stock_unit;
                 $pack_content = $dt->pack_content;
                //get variant name 
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $dt->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $dt->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $dt->att1;
                     $variant1 = $dt->var1;
                     $att2_id = $dt->att2;
                     $variant2 = $dt->var2;
                     $att3_id = $dt->att3;
                     $variant3 = $dt->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $dt->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $size_n = $variant2.';'.$variant3; 
                          $size_n = rtrim($size_n, ";");
                          $size_value = trim($size_n);
                     }
                     
                     $getcnt = explode(";",$variant_name); //masala;egg;corainder
                     $variant_cnt = count($getcnt);//3
                 }
                 //
                 
                 $stock_qty = 0; 
                 //get stock start here
                 if(trim(strtoupper($dt->display_stock))=="NO"){ //follow MOQ
                     $stock_qty = $dt->item_moq;
                 }else {
                     if(strtoupper($type)=="LOOSE"){ //loose product
                         $stock_qty = $dt->item_totstock; 
                      //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock //Only applicable for loose product
                            if($sale_unit!=$stock_unit){
                                if($sale_unit == 1 || $sale_unit == 3){ //1-ml to ltr  ex. 5ltr total stck 500ml packet content //3-gram to kg
                                    $converted = $pack_content / 1000;   // 500ml /1000 = 0.5ltr
                                    $stock_qty = $stock_qty / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                                }
                                else if($sale_unit == 2 || $sale_unit == 5){ //2- ltr to ltr //5-kg to kg
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else if($sale_unit == 4 || $sale_unit == 6 || $sale_unit == 7 || $sale_unit == 8 || $sale_unit == 9){//4-box//6-pcs//7-nos //8-packet//9-plate
                                    $stock_qty = $stock_qty;
                                }
                            }
                            else{
                                 if(($sale_unit == 1) || ($sale_unit == 2) || ($sale_unit == 3) || ($sale_unit == 5) ){
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else {
                                    $stock_qty = $stock_qty;
                                }
                            }
                            $stock_qty = (int)$stock_qty;
                     } else { //Other than loose product
                         $stock_qty = $dt->item_totstock; 
                     }
                 }
                 $fi_stock_qty = round($stock_qty);
                 // stock calculation end here

                //Stock status    
                if($dt->item_stocksts==1){
                     $stock_status_final='Available';
                }
                
                if($fi_stock_qty <=0 ){
                    $stock_status_final = 'Out of Stock';
                }
                if($dt->item_availability ==0 ){//check availability
                    $stock_status_final = 'Sold Out';
                }
                 $final_mrpprice =round($final_mrpprice,0);    
                 $price_final =round($price_final,0);
                 if($price_to_display==3){
                 $data[] = array(
                    'product_id'=>$dt->prod_id,
                    'category_id'=>$dt->cat_id,
                    'subcat_id'=>$dt->subcat_id,
                    'product_name'=>$dt->display_name,
                    'type'=>$dt->type,
                    'color_value'=>$color_value,
                    'size_value'=>$size_value,
                    'product_image'=>$dt->prod_img1,
                    'status'=>$dt->prod_status,
                    'item_id'=>$prod_itemid,
                    'varient_id'=>$prod_itemid,
                    'display_type'=>$display_type,
                    'mrp_price'=>"$final_mrpprice",
                    'display_price'=>"$price_final",
                    'min_price'=>"$price_final",
                    'varient_name'=>$variant_name,
                    'varient'=>$variant_name,
                    'varient_cnt'=>"$variant_cnt",
                    'quantity'=>"$fi_stock_qty",
                    'stock_status'=>$stock_status_final,
                    'theme_color'=>$theme_color,
                    'font_color'=>$font_color
                    );
                 }
            }
      return $result = array('status'=>1,'message'=>'Offer Products List', 'data'=>$data, 'theme_color'=>$theme_color,'font_color'=>$font_color); 
    }
    
public function product_list2($postdata=array()){ // filter testing purpose
         
    }
    public function store_detail($postdata=array()){
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        
        $store_id =$postdata['store_id'];
        $user_id =$postdata['user_id'];
        if($user_id!=0){
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
            exit;
        }}
        $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
        $cart_count = count($cart_data);

        $chk_mystore = $this->db->query("SELECT * FROM my_stores ms INNER JOIN user_profile usr ON ms.user_id = usr.user_id WHERE usr.user_id = $user_id AND ms.store_id = $store_id")->result();
        // if(empty($chk_mystore)){
        //     if(isset($postdata['exclusive_app_enabled'])){ //for exclusive app login add to my store
        //     $date_added = date("Y-m-d H:i:s");
        //     $status= $this->db->insert('my_stores', array('user_id'=>$user_id,'store_id'=>$store_id,'date_added'=>$date_added));
        //         if($status==1){
        //         $dt = $this->db->query("select first_circle from user_profile where user_id = $user_id")->result();
        //             if($dt){
        //                 $first_circle = $dt[0]->first_circle;
        //                 // Add this store to first circle
        //                     if($first_circle==''){
        //                     $update['first_circle'] = $store_id;    
        //                     }else{
        //                         $first_array = explode(",",$first_circle);
        //                         if (in_array($store_id, $first_array)){
        //                         }else{
        //                             $update['first_circle'] = $first_circle.','.$store_id;
        //                         }
        //                     }
        //                     if(isset($update)){
        //                     $this->db->update('user_profile',$update,array('user_id'=>$user_id));
        //                     }
        //             }
        //         }
        //     }else {
        //     $sts = array('status'=>3,'message'=>'Please Install Store');
        //     return $sts;
        //     }
        // }
        $lang_menu = array();
        $store_name =''; $store_type =''; $store_timing=''; $store_location='';$home_delivery_status='';
        if($user_id==0){
            $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu,menu.lang_id FROM language_menu  as menu WHERE menu.lang_id =1 and page_name ='Store Detail Page'")->result();//default english language
        }else{
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu,menu.lang_id FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and trim(page_name) ='Store Detail Page'")->result();
        }
        foreach($menu_list as $menu){
            if($menu->menu_variable=='store_name'){
                $store_name = $menu->menu;
            }
            if($menu->menu_variable=='store_type'){
                $store_type = $menu->menu;
            }
            if($menu->menu_variable=='store_timing'){
                $store_timing = $menu->menu;
            }
            if($menu->menu_variable=='store_location'){
                $store_location = $menu->menu;
            }
            if($menu->menu_variable=='home_delivery_status'){
                $home_delivery_status = $menu->menu;
            }
        }
        if($menu_list){
        $lang_id = $menu_list[0]->lang_id;
        $str = $this->db->query("SELECT * from stores WHERE store_id =$store_id")->result();
        if($str){
        if($str[0]->store_delivery_type==1 && $lang_id ==2){
            $home_delivery_status = "இந்த கடை ஸ்டோர் எடுப்பதை ஆதரிக்கிறது";
        }
        else if($str[0]->store_delivery_type==2 && $lang_id ==2){
            $home_delivery_status = "இந்த ஸ்டோர் ஸ்டோர் பிக்கப் மற்றும் ஹோம் டெலிவரி இரண்டையும் ஆதரிக்கிறது";
        }
        else if($str[0]->store_delivery_type==1){
            $home_delivery_status = "This store supports only store pick up";
        }
        else{
            $home_delivery_status = "This store supports both store pickup and home delivery";
        }
        }
        }
            $lang_menu = array( 
                "store_name" =>$store_name,
                "store_type"=>$store_type,
                "store_timing"=>$store_timing,
                "store_location"=>$store_location,
                "home_delivery_status"=>$home_delivery_status
                );
        
        $str = $this->db->query("SELECT * from shopper WHERE store_id =$store_id")->result();
        if($str){
        // $str_delivery_type = $str[0]->str_delivery_type;
        // $qry = $this->db->query("SELECT stores.store_id,stores.store_name,stores.store_image,stores.description,TIME_FORMAT(stores.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end, '%h:%i %p')starting_end,stores.status ,c.location,sc.category_name as store_type,store_delivery_type as str_delivery_type,'' as cat FROM stores INNER JOIN cities1 c on c.city_id = stores.city_id INNER JOIN store_category sc on sc.id = stores.cat_id WHERE stores.store_id =$store_id");
        $qry = $this->db->query("SELECT stores.whatsapp_no,stores.theme_color,stores.font_color,store_maplocation,stores.store_additional_data,stores.store_id,stores.store_name,stores.store_image,stores.description,TIME_FORMAT(stores.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end, '%h:%i %p')starting_end,stores.status ,stores.city_town location,sc.category_name as store_type,store_delivery_type as str_delivery_type,'' as cat,store_banner1,store_banner2,store_banner3,offer_images FROM stores INNER JOIN store_category sc on sc.id = stores.cat_id WHERE stores.store_id =$store_id")->result();
        $offer_image1 ='';$offer_image2 ='';$offer_image3='';
        if($qry){
            $dt = $qry[0];
            $theme_color = $dt->theme_color;
            $font_color = $dt->font_color;
        if($dt->offer_images!=''){
            $offer_images = $dt->offer_images;
            if(!empty($offer_images)){
                $adds = explode("|",$offer_images);
                $cnt = count($adds);
                for($i=0;$i<$cnt;$i++){
                    switch($i){
                        case 0:
                            $offer_image1 = $adds[$i];
                            break;
                        case 1:
                            $offer_image2 = $adds[$i];
                            break;
                        case 2:
                            $offer_image3 = $adds[$i];
                            break;
                        default:
                            
                    }
                }
            }   
        }
        // print_r(base_url('../StoreDetail'));die;
              $str_name = str_replace(' ', '-', $dt->store_name); 
              $fnl_name=  preg_replace('/[^A-Za-z0-9\-]/', '-', $str_name);
              $share_link = 'https://yellowmart.biz/StoreDetail/'.$fnl_name.'/'.$dt->store_id;
              $str_delivery_type_text ='something went wrong contact admin!!';
              if($dt->str_delivery_type==1){ 
                  $str_delivery_type_text = "We support store pick up only";
              }else if($dt->str_delivery_type==2){
                  $str_delivery_type_text = "We support home delivery only";
              }else if($dt->str_delivery_type==3){
                  $str_delivery_type_text = "We support both store pick up and home delivery";
                  
              }
              $str_delivery_status ='';
              if($dt->str_delivery_type==2 || $dt->str_delivery_type==3){//applicable for delivery support store
              $str_delivery_status = "Sorry, unable to deliver your selected delivery location. Please choose a different delivery location.";
              $getuser_address = $this->db->query("select pincode from address user_add where user_id=$user_id and address_type=1")->result(); //get current address pincode
              if($getuser_address){
                 $user_pincode = trim($getuser_address[0]->pincode);
                 $store_id = $dt->store_id;
                 $chkstr_delivery = $this->db->query("select * from store_address where store_id =$store_id and pincode =$user_pincode")->result(); //check store will support user current address pinocde
                 if(($chkstr_delivery)){
                    $str_delivery_status = "";
                 }
             }else{//new user -> check delivery availability for current city
                 $getuser_cityid = $this->db->query("select current_cityid from user_profile where user_id =$user_id ")->result();
                 if($getuser_cityid){
                     $user_city_id = $getuser_cityid[0]->current_cityid;
                     if($user_city_id!=''){
                     $chkstr_delivery = $this->db->query("select * from store_address where store_id =$store_id and city_id =$user_city_id")->result(); //check store will support user current address city
                     if($chkstr_delivery){
                        $str_delivery_status = "";//if user city comes under store delivery area then don't show alert message
                     }}
                 }
             }
              }
             $whatsapp_link ='';
             if($dt->whatsapp_no!=''){
             $whatsapp_link = 'https://wa.me/+91'.$dt->whatsapp_no;
             }
             $offer = $this->db->query("SELECT 'BrownieStudio' as clientname,store_id,id offer_id,title,offer_code,terms_conds,validity_from,validity_to,offer_image,offer_usage FROM `yms_offercoupon` where store_id =$store_id ")->result();
    $offer_array =array();
        if($offer){
            foreach($offer as $o){
                if($user_id==""){// for guest entry
                    $user_id =0;
                }
                $current_dt = date("Y-m-d H:i");
                    $cpnvalidity_from = $o->validity_from;
                    $cpnvalidity_to = $o->validity_to;
                    $coupon_id = $o->offer_id;
    if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to){
        $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
                        $usedcnt = count($chk_coupon_usage);
                        $coupon_cnt = $o->offer_usage;
        if($usedcnt<$coupon_cnt){
            $offer_array[] = array(
                'store_id'=>$o->store_id,
                'store_name'=>$o->clientname,
                'offer_id'=>$o->offer_id,
                'title'=>$o->title,
                'offer_code'=>$o->offer_code,
                'terms_conds'=>trim($o->terms_conds),
                'validity_from'=>$o->validity_from,
                'validity_to'=>$o->validity_to,
                'offer_image'=>$o->offer_image
                );
        }}
            }
        }
        
        $val_array[] = array(
            'store_id' =>$dt->store_id,
            'store_name' =>$dt->store_name,
            'store_image' =>$dt->store_image,
            'description' =>$dt->description,
            'starting_time' =>$dt->starting_time,
            'starting_end' =>$dt->starting_end,
            'share_link' => $share_link,
            'status' =>$dt->status,
            'location' =>$dt->location,
            'store_type' =>$dt->store_type,
            'str_delivery_type' =>$dt->str_delivery_type,
            'cart_count'=>$cart_count,
            'str_delivery_type_text' =>$str_delivery_type_text,
            'cat' =>$dt->cat,
            'store_banner1' =>$dt->store_banner1,
            'store_banner2' =>$dt->store_banner2,
            'store_banner3' =>$dt->store_banner3,
            'offer_image1' =>$offer_image1,
            'offer_image2' =>$offer_image2,
            'offer_image3' =>$offer_image3,
            'store_additional_data'=>$dt->store_additional_data,
            'store_maplocation'=>$dt->store_maplocation,
            'theme_color'=>$theme_color,
            'font_color'=>$font_color,
            'str_delivery_status'=>$str_delivery_status,
            'whatsapp_link'=>$whatsapp_link,
            'offers'=>$offer_array
            );
        }
        $qry_cat = $this->db->query("SELECT DISTINCT cat.category_id,cat.category_name FROM  product pro INNER JOIN categories maincat  ON pro.maincat_id = maincat.category_id INNER JOIN category cat ON pro.cat_id = cat.category_id INNER JOIN sub_category subcat ON pro.subcat_id = subcat.subcat_id WHERE pro.store_id = $store_id and pro.prod_status =1")->result(); //only show category which product are active p.status =1
        $cat_array = array(); 
        foreach($qry_cat as $cat){
         $category_id = $cat->category_id;
         $qry_subcat = $this->db->query("SELECT * FROM category cat INNER JOIN sub_category subcat ON cat.category_id = subcat.category_id WHERE cat.category_id = $category_id AND store_id = $store_id and subcat_id!=1 ORDER BY subcat.subcategory_name")->result();
         $subcat_array= array();
              foreach($qry_subcat as $subcat){
                  $subcat_id = $subcat->subcat_id;
                  $pro_dta = $this->db->query("select * from product pro where subcat_id = $subcat_id ")->result(); //if product not availble don't show that product category
                  if($pro_dta){
            $subcat_array[] = array(
                'subcat_id'=>$subcat->subcat_id,
                'subcategory_name'=>$subcat->subcategory_name,
                'image'=>$subcat->image
                );
                  }
            }
            
            //for Brownie studio (category - Theme Cakes) products not available just show category name
            $qry_themecake = $this->db->query("SELECT * FROM category cat INNER JOIN sub_category subcat ON cat.category_id = subcat.category_id WHERE cat.category_id = $category_id AND store_id = $store_id and subcat_id=1 ")->result();
               foreach($qry_themecake as $subcat){
                  $subcat_id = $subcat->subcat_id;
            $subcat_array[] = array(
                'subcat_id'=>$subcat->subcat_id,
                'subcategory_name'=>$subcat->subcategory_name,
                'image'=>$subcat->image
                );
            }
                      
                      
            $cat_array[] = array(
                'cat_id' =>$cat->category_id,
                'category_name' =>$cat->category_name,
                 'theme_color'=>$theme_color,
                 'font_color'=>$font_color,
                'subcat' =>$subcat_array
                );
        }
        $currentaddress_available = 0;//if user current address is not there it will redirect to add new address page 
            $getcurrent_address = $this->db->query("select * from address where user_id = $user_id and address_type=1")->result(); 
            if($getcurrent_address){
                $currentaddress_available = 1;
            }
        if (!empty($val_array)) {
            $val_array = json_decode(json_encode($val_array), FALSE);
           $result = array('status'=>1,'message'=>'Store Details', 'data'=>$val_array,'currentaddress_available'=>$currentaddress_available,'menu'=>$lang_menu); 
           $result['data'][0]->cat  =$cat_array;
           return $result;
        }
        }else{
            $result = array('status'=>0,'message'=>'Try again!', 'data'=>'','menu'=>$lang_menu); 
            return false;
        }
    }
    public function search_product($postdata=array()){
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $keyword = $postdata['keyword'];
        $store_id = $postdata['store_id'];
        if(isset($postdata['user_id'])){
           $user_id = $postdata['user_id']; 
        }else{
            $user_id = '';
        }
        if($user_id!=0){
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }}
        if($keyword!=''){
            $prod_qry = $this->db->query("SELECT pri_att,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND (pro.prod_name LIKE '%$keyword%' || prodtl.display_name  LIKE '%$keyword%') AND pro.prod_status = 1 and prodtl.item_availability = 1 order by pro.prod_id")->result();
        }else{
            $prod_qry = $this->db->query("SELECT pri_att,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND (pro.prod_name LIKE '%$keyword%' || prodtl.display_name  LIKE '%$keyword%') AND pro.prod_status = 1 and prodtl.item_availability = 1 order by pro.prod_id")->result();
        }
        if($prod_qry){
        $final_array =array();
            foreach($prod_qry as $dt){
                $subcat_name = $dt->subcategory_name;
                $prod_itemid = $dt->prod_itemid;
                //Price start here
                $price_to_display = $dt->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $dt->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $dt->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $dt->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $dt->mop_price .' - ₹ '.$dt->mrp_price; //
                   }
                 } //Price end here
                 $display_type = $dt->price_to_display;
                 $final_mrpprice = $dt->mrp_price; 
                 $type = $dt->type;
                 $add_variant = $dt->add_variant;
                 $sale_unit = $dt->sale_unit;
                 $stock_unit = $dt->stock_unit;
                 $pack_content = $dt->pack_content;
                 //get variant name 
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant=="NO")){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $dt->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $dt->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $dt->att1;
                     $variant1 = $dt->var1;
                     $att2_id = $dt->att2;
                     $variant2 = $dt->var2;
                     $att3_id = $dt->att3;
                     $variant3 = $dt->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $dt->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $color_n = $variant2.';'.$variant3; 
                          $color_n = rtrim($color_n, ";");
                          $size_value = trim($color_n);
                     }
                 }
                 //
                 
                 $stock_qty = 0; 
                 //get stock start here
                 if(trim(strtoupper($dt->display_stock))=="NO"){ //follow MOQ
                     $stock_qty = $dt->item_moq;
                 }else {
                     if(strtoupper($type)=="LOOSE"){ //loose product
                         $stock_qty = $dt->item_totstock; 
                      //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock //Only applicable for loose product
                            if($sale_unit!=$stock_unit){
                                if($sale_unit == 1 || $sale_unit == 3){ //1-ml to ltr  ex. 5ltr total stck 500ml packet content //3-gram to kg
                                    $converted = $pack_content / 1000;   // 500ml /1000 = 0.5ltr
                                    $stock_qty = $stock_qty / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                                }
                                else if($sale_unit == 2 || $sale_unit == 5){ //2- ltr to ltr //5-kg to kg
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else if($sale_unit == 4 || $sale_unit == 6 || $sale_unit == 7 || $sale_unit == 8 || $sale_unit == 9){//4-box//6-pcs//7-nos //8-packet//9-plate
                                    $stock_qty = $stock_qty;
                                }
                            }
                            else{
                                 if(($sale_unit == 1) || ($sale_unit == 2) || ($sale_unit == 3) || ($sale_unit == 5) ){
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else {
                                    $stock_qty = $stock_qty;
                                }
                            }
                            $stock_qty = (int)$stock_qty;
                     } else { //Other than loose product
                         $stock_qty = $dt->item_totstock; 
                     }
                 }
                 $fi_stock_qty = round($stock_qty);
                 // stock calculation end here

                //Stock status    
                if($dt->item_stocksts==1){
                     $stock_status_final='Available';
                }
                
                if($fi_stock_qty <=0 ){
                    $stock_status_final = 'Out of Stock';
                }
                if($dt->item_availability ==0 ){//check availability
                    $stock_status_final = 'Sold Out';
                }
                 $final_mrpprice =round($final_mrpprice,0);    
                 $price_final =round($price_final,0);
                 $final_array[] = array(
                    'product_id'=>$dt->prod_id,
                    'product_name'=>$dt->display_name,
                    'item_id'=>$prod_itemid,
                    'color_value'=>$color_value,
                    'size_value'=>$size_value,
                    'varient_id'=>$prod_itemid,
                    'varient'=>$variant_name,
                    'stock'=>"$fi_stock_qty",
                    'price'=>"$price_final"
                    );
            }
            if (!empty($final_array)) {
                return $status = array('status'=>1,'message'=>'Product Search List', 'data'=>$final_array); 
            }
        }
        else{
             return $result = array('status'=>0,'message'=>'Products Not Available');
        }
    }
    public function get_themedata($postdata=array()){
    
    if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
        return false;
    }
    $store_id = $postdata['store_id'];
   $get_data =  $this->db->query("select stores.appid,stores.theme_color,stores.font_color,stores.store_logo,app_terms_conditions,shopper.email,shopper.phone_no,stores.store_name from stores  INNER JOIN shopper ON stores.store_id = shopper.store_id where stores.store_id = $store_id ")->result();
   if($get_data){
           $remove_htmltags = strip_tags($get_data[0]->app_terms_conditions);
           $rmv_spacetag = str_replace("&nbsp;", ' ', $remove_htmltags);
           $final_app_terms_conditions = str_replace(array("\n\r", "\n", "\r"), '', $rmv_spacetag);
       $data= array(
           'theme_color'=>$get_data[0]->theme_color,
           'font_color'=>$get_data[0]->font_color,
           'store_logo'=>$get_data[0]->store_logo,
           'app_terms_conditions'=>$final_app_terms_conditions,
           'contactus_email'=>$get_data[0]->email,
           'contactus_phoneno'=>'+91 '.$get_data[0]->phone_no,
           'store_name'=>$get_data[0]->store_name,
           'appid'=>$get_data[0]->appid
           );
       
       $result = array('status'=>1,'message'=>'Theme data','data'=>$data);
        return $result;
   }else{
       return false;
   }
}
public function useremail_validation($postdata=array()){
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id = $postdata['user_id'];
   if(isset($postdata['email'])){
            if($postdata['email']!=''){
                $cust_email = $postdata['email'];
                $chk_email_address = $this->db->query("Select * from user_profile where user_id!=$user_id  and email ='$cust_email'")->result();
                if(count($chk_email_address) > 0 ){
                    //  $result = array('status'=>0,'message'=>'MailID already exists');
                    $result = array('status'=>0,'message'=>'Email Address already exist');
                }else{
                    $result = array('status'=>1,'message'=>'Allow Mail address');
                }
                print_r(json_encode($result));exit;
            }
            else{
                return false;
            }
        }
}
public function get_cities($postdata=array()){ //MS
         if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
        $user_id = $postdata['user_id'];
        $keyword ='';
        if(isset($postdata['keyword'])){
          $keyword = $postdata['keyword'];
        }
        
        if($keyword!=''){
        $qry = $this->db->query("SELECT id,city_name from city where city_name LIKE '%$keyword%' order by city_name")->result();
        }else{
        $qry = $this->db->query("SELECT id,city_name from city order by city_name")->result();   
        }
        if($qry){
            $data_result = array();
        foreach($qry as $data){
            $data_result[] = array(
                'id'=>$data->id,
                'city_name'=>$data->city_name
                );
            
        }
          return $status = array('status'=>1,'message'=>'City list','data'=>$data_result);   
        }
        else
        {
            return false;
        }

    }
    //Home page serach city list API
    public function city_list($postdata=array()){ 
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $keyword ='';
        if(isset($postdata['keyword'])){
            $keyword = trim($postdata['keyword']);
        }
        if($keyword==''){
           $result = $this->db->query("select DISTINCT id as city_id,city_name from city order by city_name")->result();
        }else{
           $result = $this->db->query("select DISTINCT id as city_id,city_name from city where city_name LIKE '%$keyword%' order by city_name")->result();    
        }
        if($result){
        return $status = array('status'=>1,'message'=>'City list', 'data'=>$result); 
        }else{
            return 0;
        }

    } 
    //get user address
    public function manage_address($postdata=array()){
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $keyword = "";$search_keyword ="";
        if(isset($postdata['keyword'])){
            $keyword = $postdata['keyword'];
        }
        $current_address =array(); $saved_address =array();
        if($keyword!=""){
            $search_keyword = "and ad.delto_contact LIKE '%$keyword%'";
        }
        $address_detail = $this->db->query("SELECT delto_contact,delto_name,ad.id address_id, ad.user_id,ad.address1,ad.address2,ad.landmark,ad.area_id,area.area_locality,ad.city_id,city.city_name,ad.district_id,dis.district,ad.state_id,state.state,ad.pincode,ad.gps_coordinates,ad.address_name,ad.address_type FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id $search_keyword")->result();
        $user_type = $this->db->query("select user_type from user_profile where user_id=$user_id ")->result();
        $usertype = $user_type[0]->user_type;
        if($address_detail){
            foreach($address_detail as $add){
                if($add->address_type==1){ //current address
                $current_address[] = array(
                    'delto_name' => $add->delto_name,
                    'delto_contact' => $add->delto_contact,
                    'address_id' => $add->address_id,
                    'user_id' => $add->user_id,
                    'address1' => $add->address1,
                    'address2' => $add->address2,
                    'landmark' => $add->landmark,
                    'area_id' => $add->area_id,
                    'area_locality' => $add->area_locality,
                    'city_id' => $add->city_id,
                    'city_name' => $add->city_name,
                    'district_id' => $add->district_id,
                    'district' => $add->district,
                    'state_id' => $add->state_id,
                    'state' => $add->state,
                    'pincode' => $add->pincode,
                    'gps_coordinates' => $add->gps_coordinates,
                    'address_name' => $add->address_name
                );
            }
            elseif($add->address_type==0){ //saved address
                $saved_address[] = array(
                    'delto_name' => $add->delto_name,
                    'delto_contact' => $add->delto_contact,
                    'address_id' => $add->address_id,
                    'user_id' => $add->user_id,
                    'address1' => $add->address1,
                    'address2' => $add->address2,
                    'landmark' => $add->landmark,
                    'area_id' => $add->area_id,
                    'area_locality' => $add->area_locality,
                    'city_id' => $add->city_id,
                    'city_name' => $add->city_name,
                    'district_id' => $add->district_id,
                    'district' => $add->district,
                    'state_id' => $add->state_id,
                    'state' => $add->state,
                    'pincode' => $add->pincode,
                    'gps_coordinates' => $add->gps_coordinates,
                    'address_name' => $add->address_name
                );
            }
            }
        return $status = array('status'=>1,'message'=>'Manage Address','usertype'=>$usertype, 'current_address'=>$current_address ,'saved_address'=>$saved_address); 
        }else{
            return $status = array('status'=>3,'message'=>'Address not found', 'current_address'=>$current_address ,'saved_address'=>$saved_address); 
        }
    }
    public function ordersummary_changeaddress($postdata=array()){
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];  $store_id = 0;
        $keyword = "";$search_keyword ="";
        if(isset($postdata['keyword'])){
            $keyword = $postdata['keyword'];
        }
        if($keyword!=""){
            $search_keyword = "and ad.delto_contact LIKE '%$keyword%'";
        }
        $storedelivery_pincode_array =array();
        $get_storeid = $this->db->query("select store_id from cart where user_id = $user_id and order_id = 0")->result();
        if($get_storeid){
        $store_id = $get_storeid[0]->store_id;
        }

        $get_storedelivery_pincode = $this->db->query("select DISTINCT pincode from store_address where store_id = $store_id")->result();
        if($get_storedelivery_pincode){
                foreach($get_storedelivery_pincode as $dt){
                    $storedelivery_pincode_array[] = $dt->pincode;
                }
        }
        // print_r($storedelivery_pincode_array);die;
        $undelivered_address =array(); $saved_address =array();
        // $address_detail = $this->db->query("SELECT ad.id address_id, ad.user_id,ad.address1,ad.address2,ad.landmark,ad.area_id,area.area_locality,ad.city_id,city.city_name,ad.district_id,dis.district,ad.state_id,state.state,ad.pincode,ad.gps_coordinates,ad.address_name,ad.address_type FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type=0")->result();
        $address_detail = $this->db->query("SELECT delto_contact,delto_name,ad.id address_id, ad.user_id,ad.address1,ad.address2,ad.landmark,ad.area_id,area.area_locality,ad.city_id,city.city_name,ad.district_id,dis.district,ad.state_id,state.state,ad.pincode,ad.gps_coordinates,ad.address_name,ad.address_type FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id $search_keyword")->result();
        $user_type = $this->db->query("select user_type from user_profile where user_id=$user_id ")->result();
        $usertype = $user_type[0]->user_type;
        if($address_detail){
            foreach($address_detail as $add){
                $userpincode = $add->pincode;
                // for BrownieStudio all location will allow to deliver
                // if( in_array( $userpincode ,$storedelivery_pincode_array ) )
                    // {
                      $saved_address[] = array(
                          'delto_name' => $add->delto_name,
                    'delto_contact' => $add->delto_contact,
                    'address_id' => $add->address_id,
                    'user_id' => $add->user_id,
                    'address1' => $add->address1,
                    'address2' => $add->address2,
                    'landmark' => $add->landmark,
                    'area_id' => $add->area_id,
                    'area_locality' => $add->area_locality,
                    'city_id' => $add->city_id,
                    'city_name' => $add->city_name,
                    'district_id' => $add->district_id,
                    'district' => $add->district,
                    'state_id' => $add->state_id,
                    'state' => $add->state,
                    'pincode' => $add->pincode,
                    'gps_coordinates' => $add->gps_coordinates,
                    'address_name' => $add->address_name
                );
                //     }
                //     else{
                //         $undelivered_address[] = array(
                //     'address_id' => $add->address_id,
                //     'user_id' => $add->user_id,
                //     'address1' => $add->address1,
                //     'address2' => $add->address2,
                //     'landmark' => $add->landmark,
                //     'area_id' => $add->area_id,
                //     'area_locality' => $add->area_locality,
                //     'city_id' => $add->city_id,
                //     'city_name' => $add->city_name,
                //     'district_id' => $add->district_id,
                //     'district' => $add->district,
                //     'state_id' => $add->state_id,
                //     'state' => $add->state,
                //     'pincode' => $add->pincode,
                //     'gps_coordinates' => $add->gps_coordinates,
                //     'address_name' => $add->address_name
                // );
                //     }
                    }
            return $status = array('status'=>1,'message'=>'Manage Address','user_type'=>$usertype,'saved_address'=>$saved_address,'undelivered_address'=>$undelivered_address ); 
    }else{
            return $status = array('status'=>3,'message'=>'Address not found', 'saved_address'=>$saved_address ,'undelivered_address'=>$undelivered_address); 
        }
        
    }
    public function addupdate_address($postdata=array()){
        if( !isset($postdata['user_id']) || empty($postdata['user_id']) 
        || !isset($postdata['address1']) || empty($postdata['address1'])
        || !isset($postdata['address2']) || empty($postdata['address2'])
        || !isset($postdata['landmark']) || empty($postdata['landmark'])
        || !isset($postdata['state_id']) || empty($postdata['state_id'])
        || !isset($postdata['district_id']) || empty($postdata['district_id'])
        || !isset($postdata['city_id']) || empty($postdata['city_id'])
        || !isset($postdata['area_id']) || empty($postdata['area_id'])
        || !isset($postdata['address_name']) || empty($postdata['address_name'])
        || !isset($postdata['address_type'])
        ){
            return false;
        }
        $user_id = $postdata['user_id'];
        $address_type = $postdata['address_type'];
        $current_cityid = $postdata['city_id'];
        if($address_type==1){ //current address
        $this->db->query("update address set address_type = 0 where user_id =$user_id ");    //update other address as saved address then current address will update as 1
        $this->db->query("update user_profile set current_cityid = $current_cityid where user_id =$user_id ");    //update current city in user_profile
        }
        $data['user_id']= $postdata['user_id'];
        $data['address1']= $postdata['address1'];
        $data['address2']= $postdata['address2'];
        $data['landmark']= $postdata['landmark'];
        $data['state_id']= $postdata['state_id'];
        $data['district_id']= $postdata['district_id'];
        $data['city_id']= $postdata['city_id'];
        $data['area_id']= $postdata['area_id'];
        $curr_areaid = $data['area_id'];
        //

        $getpincode = $this->db->query("select * from area where id = $curr_areaid")->result();
        if($getpincode){
            $data['pincode'] = $getpincode[0]->pincode;
        }else{
            $data['pincode'] ='';
        }
        if(isset($postdata['gps_coordinates'])){
        if($postdata['gps_coordinates']!=''){//not mandatory
        $url = 'https://www.google.com/maps/search/?api=1&query=';
        $data['gps_coordinates']= $url.$postdata['gps_coordinates'];
        }
        }
        $data['address_name']= $postdata['address_name'];
        $data['address_type'] = $address_type; 
        if($address_type==1){//make it as current address
        $update_user['current_cityid'] =  $postdata['city_id'];
            $this->db->update('user_profile',$update_user,array('user_id'=>$user_id));
        }
        if(isset($postdata['address_id']) && $postdata['address_id']!=''){ //update address 
           $address_id = $postdata['address_id'];
           $status = $this->db->update('address',$data,array('id'=>$address_id));    
        }else{  // add new address to this user
           $status =  $this->db->insert('address',$data); // insert to address table    
        }
        
        if($status ){
            return $status = array('status'=>1,'message'=>'User Address Updated'); 
        }
        else{
            return false;
        }
    }
    public function add_cart($postdata=array()){
    //  if(isset($postdata['varient_name'])){
    //       $varient_name = $postdata['varient_name']; 
    //     }else{
    //         $varient_name = '';
    //     }
        
    $user_id = $postdata['user_id'];
    if($user_id==0){
        return $result = array('status'=>5,'message'=>'User not loggedin');
    }
    $product_id = $postdata['product_id'];
    $store_id = $postdata['store_id'];
    // $varient_id = $postdata['varient_id'];
    $item_id = $postdata['item_id'];
    $quantity = $postdata['quantity'];
    if(isset($postdata['appid'])){
        $appid = $postdata['appid'];
    }else{
        $appid ='YM';
    }
    $message_on_cake =""; $preferred_del_date=""; $preferred_del_time="";$notes_on_chef="";
    if(isset($postdata['message_on_cake'])){
        $message_on_cake = $postdata['message_on_cake'];
    }
    if(isset($postdata['preferred_del_date'])){
        $preferred_del_date = $postdata['preferred_del_date'];
        $today = date('Y-m-d');
        if($preferred_del_date < $today ){
            return $result = array('status'=>0,'message'=>'Please select correct preferred date');
        }
    }
    if(isset($postdata['preferred_del_time'])){
        $preferred_del_time = $postdata['preferred_del_time'];
    }
    if(isset($postdata['notes_on_chef'])){
        $notes_on_chef = $postdata['notes_on_chef'];
    }

    $pro = $this->db->query("select * from product where prod_id = $product_id")->result();
    if(empty($pro)){
        return false; 
    }
    $variant_name ='';
    $get_var = $this->db->query("SELECT image_type,item_images,pri_att,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id = $store_id AND prodtl.prod_itemid=$item_id AND pro.prod_status = 1 and prodtl.item_availability = 1 order by pro.prod_id")->result();
    if($get_var){
    //get variant name 
                $type = $get_var[0]->type;
                $add_variant = $get_var[0]->add_variant;
                $sale_unit = $get_var[0]->sale_unit;
                $pack_content = $get_var[0]->pack_content;
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;

                 }else{
                     $primary_attibuteid = $get_var[0]->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     //Attribute1 //variant2
                     $att1_id = $get_var[0]->att1;
                     $variant1 = $get_var[0]->var1;
                     $att2_id = $get_var[0]->att2;
                     $variant2 = $get_var[0]->var2;
                     $att3_id = $get_var[0]->att3;
                     $variant3 = $get_var[0]->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                 }
                 //
    }
    $product_desc  = $pro[0]->description;
    //$product_image  = $pro[0]->prod_img1;
     if($get_var[0]->image_type==2){ // 1 - generic 2 - variant
        $item_images  = $get_var[0]->item_images;
        $ex_images = explode("|", $item_images); 
        $product_image =  $ex_images[0];
        if($product_image==""){
        $product_image = $pro[0]->prod_img1;
        }
    }else{
        $product_image  = $pro[0]->prod_img1;
    }
    //for existing item update quantity and price
        $check_cart = $this->db->query("select * from cart where user_id = $user_id and product_id = $product_id and store_id =$store_id and item_id = $item_id and order_id = 0  and product_status =0")->result();
        if($check_cart) {
            $cart_id  = $check_cart[0]->cart_id;
            $quantity =  $check_cart[0]->quantity + $quantity;
        }
    $pro_data = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id = prodtl.prod_id  inner join packettype_master packtype ON packtype.id = pro.packtype_id where pro.prod_id = $product_id and prodtl.prod_itemid=$item_id")->result();
        $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0;
        $billing_rate =0; $billing_price=0;
        $display_rate =0; $display_price=0;
        $mrp_rate = 0; $mrp_price = 0;
        $range_pricing = 0;
        if($pro_data){
            $type = $pro_data[0]->type_name;
                //Price 
               $price_to_display = $pro_data[0]->price_to_display;
               $mrp_prc = $pro_data[0]->mrp_price; 
               $mop_prc = $pro_data[0]->mop_price; 
               $offer_prc = $pro_data[0]->offer_price; 
               if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==2){ //Mop
                        $display_rate =  $mop_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==3){ //Offer price
                        $display_rate =  $offer_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==4){ //range price
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                        $range_pricing =  (str_replace(',','',$mop_prc) * $quantity) .' - ₹ '.(str_replace(',','',$mrp_prc) * $quantity);
                    }else{
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                    }
               }
                ///.....///
        
        
                 ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_prc);
        $mrp_price = str_replace(',','',$mrp_prc) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display;
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_prc;
            $billing_price = str_replace(',','',$mrp_prc) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->hsn_code;
        $CGSTperc = $pro_data[0]->cgst;
        $SGST_IGSTperc = $pro_data[0]->sgst;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        }
        $display_name = $pro_data[0]->display_name;
    $check_cart = $this->db->query("select * from cart where user_id = $user_id and product_id = $product_id and store_id =$store_id and item_id = $item_id and order_id = 0  and product_status =0")->result();
    if($check_cart) { //update
            $status  = $this->db->query("update cart set product_name = '$display_name',quantity = $quantity,rate ='$billing_rate', price ='$billing_price',mrp_rate='$mrp_rate',mrp_price='$mrp_price',billing_type= '$billing_type',base_amt ='$base_amt',HSN_code='$HSN_code',CGST='$CGST',SGST_IGST='$SGST_IGST',display_rate='$display_rate',display_price='$display_price',display_type= '$display_type',range_pricing='$range_pricing',message_on_cake='$message_on_cake',preferred_del_date='$preferred_del_date',preferred_del_time='$preferred_del_time',notes_on_chef='$notes_on_chef' where cart_id = $cart_id");            
    }
    else{ //insert
       $status= $this->db->insert('cart', array('user_id'=>$user_id,'product_name'=>$display_name,'product_id'=>$product_id,'store_id'=>$store_id,'item_id'=>$item_id,'quantity'=>$quantity,'product_desc'=>$product_desc,'product_image'=>$product_image,'rate'=>$billing_rate,'price'=>$billing_price,'mrp_rate'=>$mrp_rate,'billing_type'=>$billing_type,'mrp_price'=>$mrp_price,'type'=>$type,'varient_name'=>$variant_name,'product_status'=>0,'base_amt'=>$base_amt,'HSN_code'=>$HSN_code,'CGST'=>$CGST,'SGST_IGST'=>$SGST_IGST,'display_rate'=>$display_rate,'display_price'=>$display_price,'display_type'=> $display_type,'range_pricing'=> $range_pricing,'message_on_cake'=>$message_on_cake,'preferred_del_date'=>$preferred_del_date,'preferred_del_time'=>$preferred_del_time,'notes_on_chef'=>$notes_on_chef));    
    }
    //for same order with mulitple cart  preferred_del_date, preferred_del_time is same
    $this->db->query("update cart set preferred_del_date='$preferred_del_date',preferred_del_time='$preferred_del_time' where user_id = $user_id and order_id = 0"); 
if($status){
        $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
        $cart_count = count($cart_data);
        return $result = array('status'=>1,'message'=>'Added to basket successfully','count' => $cart_count);
}
else {
    return false;
}
}
public function add_cartquantity($postdata=array()){
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id']) || !isset($postdata['quantity']) || empty($postdata['quantity'])){
        return false;
    }
    $user_id = $postdata['user_id'];
    if($user_id==0){
        return $result = array('status'=>5,'message'=>'User not loggedin');
    }
    $cart_id = $postdata['cart_id'];
    $store_id = $postdata['store_id'];
    $quantity = $postdata['quantity'];
    $product_id = $postdata['product_id'];
    $pro_data = $this->db->query("select * from product where prod_id = $product_id")->result();
    if(empty($pro_data)){
        return false; 
    }
    $check_cart = $this->db->query("select * from cart where cart_id = $cart_id")->result();
     if(empty($check_cart)){
        return false; 
    }
    foreach($check_cart as $cc){
            $rate  = $cc->rate;
            $price =  $quantity * $rate;
            // $varient_id = $cc->varient_id;
            $item_id = $cc->item_id;
        $pro_data = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id = prodtl.prod_id  inner join packettype_master packtype ON packtype.id = pro.packtype_id where pro.prod_id = $product_id  and prodtl.prod_itemid=$item_id")->result();
        $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0;
        $billing_rate =0; $billing_price=0;
        $display_rate =0; $display_price=0;
        $mrp_rate = 0; $mrp_price = 0;
        $range_pricing = 0;
        if($pro_data){
            $type = $pro_data[0]->type_name;
                //Price 
               $price_to_display = $pro_data[0]->price_to_display;
               $mrp_prc = $pro_data[0]->mrp_price; 
               $mop_prc = $pro_data[0]->mop_price; 
               $offer_prc = $pro_data[0]->offer_price; 
               if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==2){ //Mop
                        $display_rate =  $mop_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==3){ //Offer price
                        $display_rate =  $offer_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==4){ //range price
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                        $range_pricing =  (str_replace(',','',$mop_prc) * $quantity) .' - ₹ '.(str_replace(',','',$mrp_prc) * $quantity);
                    }else{
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                    }
               }
                ///.....///
        
        
                 ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_prc);
        $mrp_price = str_replace(',','',$mrp_prc) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display;
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_prc;
            $billing_price = str_replace(',','',$mrp_prc) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->hsn_code;
        $CGSTperc = $pro_data[0]->cgst;
        $SGST_IGSTperc = $pro_data[0]->sgst;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        }
        $status  = $this->db->query("update cart set quantity = $quantity,rate ='$billing_rate', price ='$billing_price',mrp_rate='$mrp_rate',mrp_price='$mrp_price',billing_type= '$billing_type',base_amt ='$base_amt',HSN_code='$HSN_code',CGST='$CGST',SGST_IGST='$SGST_IGST',display_rate='$display_rate',display_price='$display_price',display_type= '$display_type',range_pricing='$range_pricing' where cart_id = $cart_id");            
        }
        $cart_total = 0;$array = array();
        $cart_tot = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    if(empty($cart_tot)){
        return false; 
    }
        foreach($cart_tot as $ct){
        $cart_total = $cart_total +  $ct->display_price;  
        $pro_id = $ct->product_id;
        $varient_id = $ct->varient_id;
        $pro_data = $this->db->query("select pack_content,display_stock,item_totstock,item_moq from product pro inner join product_itemdtl prodtl on pro.prod_id= prodtl.prod_id where pro.prod_id = $pro_id")->result();
        if($pro_data){
        $data = $pro_data[0];
        if(strtoupper($data->display_stock)=="YES"){
            $tot_stk = $data->item_totstock;
        }else{
            $tot_stk = $data->item_moq;
        }
        $curr_stk = $tot_stk - ($quantity * $data->pack_content);
        if($curr_stk<0){
                $tot_stk = 0;
             }
        $stock = (int)$tot_stk;
        if($stock > 10){
            $stock = 10;
        }}
        $array = array(
            "cart_id" =>$ct->cart_id,
            "stock" => "$stock"
            );
        }
        if(!empty($array)){
        $cart_total = round($cart_total);
        return $result = array('status'=>1,'message'=>'Quantity Updated','stock' =>$array, 'cart_total'=>$cart_total); 
        }else{
            return false;
        }
    }
public function requestof_price($postdata=array()){ //MS
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id  = $postdata['user_id'];
    $store_id  = $postdata['store_id'];
    $product_id  = $postdata['product_id'];
    // $variant_id  = $postdata['variant_id'];
    $item_id  = $postdata['item_id'];
    $selleremail = '';
    $get_strdata = $this->db->query("select id,email,shopper_name from shopper where store_id =$store_id ")->result();
    if(empty($get_strdata)){
        return false;
    }else{
        $selleremail = $get_strdata[0]->email;
        $seller_id = $get_strdata[0]->id;
        $seller_name = $get_strdata[0]->shopper_name;
    }
    
    $insert_data['user_id']  = $user_id;
    $insert_data['seller_id'] = $seller_id;
    $insert_data['store_id'] = $store_id;
    $insert_data['product_id'] = $product_id;
    // $insert_data['variant_id'] = $variant_id;
    $insert_data['item_id'] = $item_id;
    $insert_data['request_status'] = 0;
    $insert_data['request_time'] = date('Y-m-d H:i:s');
    $status = $this->db->insert('requestprice_dtl',$insert_data);
    if($status){
        $get_productdata = $this->db->query("select * from product where prod_id = $product_id")->result();
        $get_userdata =  $this->db->query("SELECT * FROM  user_profile where user_id = $user_id")->result();
        $custname = $get_userdata[0]->fullname;
             //send Request notification mail to Seller 
            if($selleremail!='' && !empty($get_productdata)){
            $product_name = $get_productdata[0]->product_name;
            $to_receiver_email = $selleremail;
            $name = $seller_name;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Request of Price";
            $message = 
"Dear $name,

 You got price request from  $custname.
 Requesting for Product Name - $product_name

Regards,
Team BrownieStudio";
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
                //  if($response['status']==0){
                //      return $result = array('status'=>1,'message'=>'Failed to send mail '); 
                //  }
                 return $result = array('status'=>1,'message'=>'Request sent'); 
            }
        else{
            return $result = array('status'=>0,'message'=>'Requestmail not sent'); 
        }
    }
    else{
        return false;
    }

}
public function cart_list($postdata=array()){
    $user_id = $postdata['user_id'];
    if($user_id==0){
        return $result = array('status'=>5,'message'=>'User not loggedin');
    }
    //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
     $lang_menu = array();
        $shopping_basket =''; $total =''; $great_choice=''; $goto_checkout='';$continue_shopping='';$msg1='';$empty_basket='';$basket_is_empty='';$start_shopping='';
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and page_name ='Cart List Page'")->result();
        foreach($menu_list as $menu){
            if($menu->menu_variable=='shopping_basket'){
                $shopping_basket = $menu->menu;
            }
            if($menu->menu_variable=='total'){
                $total = $menu->menu;
            }
            if($menu->menu_variable=='great_choice'){
                $great_choice = $menu->menu;
            }
            if($menu->menu_variable=='goto_checkout'){
                $goto_checkout = $menu->menu;
            }
            if($menu->menu_variable=='continue_shopping'){
                $continue_shopping = $menu->menu;
            }
             if($menu->menu_variable=='msg1'){
                $msg1 = $menu->menu;
            }
             if($menu->menu_variable=='empty_basket'){
                $empty_basket = $menu->menu;
            }
             if($menu->menu_variable=='basket_is_empty'){
                $basket_is_empty = $menu->menu;
            }
             if($menu->menu_variable=='start_shopping'){
                $start_shopping = $menu->menu;
            }
        }
            $lang_menu = array( 
                "shopping_basket" =>$shopping_basket,
                "total"=>$total,
                "great_choice"=>$great_choice,
                "goto_checkout"=>$goto_checkout,
                "continue_shopping"=>$continue_shopping,
                "msg1"=>$msg1,
                "empty_basket"=>$empty_basket,
                "basket_is_empty"=>$basket_is_empty,
                "start_shopping"=>$start_shopping
                );
        
    
    //check products status = 1
    if(isset($postdata['appid'])){
        $appid = $postdata['appid'];
    }else{
        $appid ='YM';
    }
    $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    $count = count($cart_data);
   
    $cart_total = 0;$curr_stk = '';$preloose_product_id='';
    $result = $this->db->query("select product.subcat_id,message_on_cake,preferred_del_date,preferred_del_time,notes_on_chef,cart.product_image,sale_unit,pri_attcolor,pri_att,att1,var1,att2,var2,att3,var3,add_variant,ptype.type_name type,product.cat_id,prodtl.pack_content,cart.item_id,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,prodtl.display_name,cart.cart_id ,cart.varient_id,cart.varient_name,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,cart.quantity,product.prod_name,product.description product_description,product.prod_img1,product.prod_id,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status,prodtl.item_availability from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product ON product.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON product.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid INNER JOIN packettype_master ptype ON product.packtype_id = ptype.id where user.user_id =$user_id and cart.order_id = 0 and cart.product_status in (0) order by cart.product_id,cart_id")->result();
    $store_id ='';
    $final_array = array();
    foreach($result as $data){
        $store_id = $data->store_id;
        //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        $product_id = $data->prod_id;
        $varient_id = 0;
        $item_id = $data->item_id;
        $type = $data->type;
        $add_variant = $data->add_variant;
        $pack_content = $data->pack_content;
         if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product
                    $sale_unit = $data->sale_unit;
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $data->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $data->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $data->att1;
                     $variant1 = $data->var1;
                     $att2_id = $data->att2;
                     $variant2 = $data->var2;
                     $att3_id = $data->att3;
                     $variant3 = $data->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $data->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $color_n = $variant2.';'.$variant3; 
                          $color_n = rtrim($color_n, ";");
                          $size_value = trim($color_n);
                     }
                 }
        if(strtoupper($data->display_stock)=="YES"){
            $tot_stk = $data->item_totstock;
        }else{
            $tot_stk = $data->item_moq;
        }
        $curr_stk = $tot_stk - ($data->quantity * $data->pack_content);
        if($curr_stk<0){
                $tot_stk = 0;
             }
        $stock = (int)$tot_stk;
        
        //if cart quantity less than stock quantity means update cart quantity as stock quantity //also update stock price
        $cart_id = $data->cart_id;
        $quantity = $data->quantity;
        $stock = round($stock,0);
        if($stock > 10){
            $stock = 10;
        }
        
        if($quantity > $stock){
            $current_stock = $stock;
            $this->cart_price_calculation($cart_id,$current_stock,$item_id);
        }
        
        $updated_stock = $this->db->query("select * from cart where cart_id =$cart_id")->result();
        if($updated_stock){
            $cart_total = $cart_total + $updated_stock[0]->display_price;
            $stock_availability ='';
            if($updated_stock[0]->quantity == 0 || $data->item_availability==0 ){
              $stock_availability = 'Out of stock';
              $stock_status = 'Sold Out';  
            }
        else if($updated_stock[0]->quantity > $stock){
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
        }else if($updated_stock[0]->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }
        $quantity = $updated_stock[0]->quantity;
        }else{ //rare case
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
            $quantity = 0;
        }
        
        // $chk_product_availability = $this->db->query("select availability from products where product_id =$product_id and availability=0 ")->result();
        // if($chk_product_availability){
        //     $stock_availability = 'Out of stock';
        //     $stock_status = 'Sold Out';
        //     $stock = $updated_stock[0]->quantity;//for unavailabilty product stock should not allow to increase + -
        // }
        $stock = round($stock,0);
        if($stock > 10){
            $stock = 10;
        }
        if(trim($updated_stock[0]->display_type)=='4'){ // range price
            $display_price = $updated_stock[0]->range_pricing;
            $lang_menu['total']= 'Estimated Total';
        }else{
            $display_price = $updated_stock[0]->display_price;
        }
        $varient_cnt = 0;
        $getcnt = explode(";",$data->varient_name); //masala;egg;corainder
        $varient_cnt = count($getcnt);//3
        if($data->preferred_del_date=='0000-00-00'){
            $preferred_del_date = "";
        }else{
            $dt_frmt=date_create($data->preferred_del_date);
            $preferred_del_date =  date_format($dt_frmt,"d/m/Y");
        }
        $final_array[] = array(
            'product_id' => $product_id,
            'cart_id' => $data->cart_id,
            'category_id' =>$data->cat_id,
            'varient_id' => $data->varient_id,
            'item_id' => $data->item_id,
            'color_value'=>$color_value,
            'size_value'=>$size_value,
            'varient_name' => $variant_name,
            'varient_cnt' => $varient_cnt,
            'quantity' => $quantity,
            'product_name' => $data->display_name,
            'product_nameold' => $data->prod_name,
            'product_description' => $data->product_description,
            'product_image' => $data->product_image,
            'store_id' => $data->store_id,
            'store_name' => $data->store_name,
            'store_image' => $data->store_image,
            'store_description' => $data->store_description,
            'user_name' => $data->user_name,
            'rate' => $updated_stock[0]->rate,
            'price' => $updated_stock[0]->price,
            'display_type' => $data->display_type,
            'display_rate' => $updated_stock[0]->display_rate,
            'display_price' => $display_price,
            'mrp_rate' => $updated_stock[0]->mrp_rate,
            'mrp_price' => $updated_stock[0]->mrp_price,
            'stock' => "$stock",
            'stock_status' => $stock_status,
            'stock_availability' => $stock_availability,
            'theme_color'=>$theme_color,
            'font_color' =>$font_color,
            'message_on_cake'=>$data->message_on_cake,
            'preferred_del_date'=>$preferred_del_date,
            'preferred_del_time'=>$data->preferred_del_time,
            'notes_on_chef'=>$data->notes_on_chef,
            'subcat_id'=>$data->subcat_id
            );
    }
   
    if($result){
        $cart_total = round($cart_total);
    return $result = array('status'=>1,'message'=>'Cart List','store_id'=>$store_id,'store_name'=>$data->store_name,'data' =>$final_array,'cart_count'=>$count,'cart_total'=>"$cart_total",'theme_color' =>"$theme_color",'font_color' => "$font_color",'menu'=>$lang_menu);
    }
    else{
        return $result = array('status'=>3,'message'=>'Cart is Empty', 'menu'=>$lang_menu);
    }
}
function cart_price_calculation($cart_id,$current_stock,$item_id){
        $update_cart = $this->db->query("select * from cart where cart_id =$cart_id ")->result();
        foreach($update_cart as $cc){
            $ex_quantity = $cc->quantity;
            $product_id = $cc->product_id;
            if($ex_quantity > $current_stock){
            $quantity = $current_stock;
            $rate  = $cc->rate;
            $price =  $quantity * $rate;
            // $varient_id = $cc->varient_id;
            
            //Price Caluculation
        $pro_data = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id = prodtl.prod_id  inner join packettype_master packtype ON packtype.id = pro.packtype_id where pro.prod_id = $product_id and prodtl.prod_itemid=$item_id")->result();
        $mrp_prc = 0; $mop_prc = 0;  $offer_prc = 0;
        $billing_rate =0; $billing_price=0;
        $display_rate =0; $display_price=0;
        $mrp_rate = 0; $mrp_price = 0;
        $range_pricing = 0;
        if($pro_data){
            $type = $pro_data[0]->type_name;
                //Price 
               $price_to_display = $pro_data[0]->price_to_display;
               $mrp_prc = $pro_data[0]->mrp_price; 
               $mop_prc = $pro_data[0]->mop_price; 
               $offer_prc = $pro_data[0]->offer_price; 
               if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $display_rate = $mrp_prc; //
                        $billing_rate = $mop_prc;
                   }else if($price_to_display==2){ //Mop
                        $display_rate =  $mop_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==3){ //Offer price
                        $display_rate =  $offer_prc;
                        $billing_rate = $display_rate;
                   }else if($price_to_display==4){ //range price
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                        $range_pricing =  (str_replace(',','',$mop_prc) * $quantity) .' - ₹ '.(str_replace(',','',$mrp_prc) * $quantity);
                    }else{
                        $display_rate = $mrp_prc;
                        $billing_rate = $mrp_prc;
                    }
               }
                ///.....///
        
        
                 ////MRP Price
        $mrp_rate = str_replace(',','',$mrp_prc);
        $mrp_price = str_replace(',','',$mrp_prc) * $quantity; //1,450.00 to 1450.00
            ////
        $display_price = str_replace(',','',$display_rate) * $quantity;
        $display_type = $price_to_display;
        $get_pricetype = $this->db->query("select * from product_pricing where id = $display_type")->result();
        if($get_pricetype){
            $billing_price = str_replace(',','',$billing_rate) * $quantity; //1,450.00 to 1450.00
            $billing_type = $get_pricetype[0]->price_type;
        }
        //
        if($billing_price==0){ //Case 4 if dislay price = 'MOP or Offer price' but in that column value is zero means take MRP Price
            $billing_rate = $mrp_prc;
            $billing_price = str_replace(',','',$mrp_prc) * $quantity; 
            $billing_type ='MRP';
            }
        //GST calculation
        $base_amt = 0;$cgst_amt = 0;$sgst_igst_amt=0;
        $HSN_code = $pro_data[0]->hsn_code;
        $CGSTperc = $pro_data[0]->cgst;
        $SGST_IGSTperc = $pro_data[0]->sgst;
        if($CGSTperc > 0 && $CGSTperc!=''){
        $cgst_amt = $billing_price * ($CGSTperc/100);
        }
        if($SGST_IGSTperc > 0 && $SGST_IGSTperc!=''){
        $sgst_igst_amt = $billing_price * ($SGST_IGSTperc/100);    
        }
        $CGST = $CGSTperc .':'.$cgst_amt; // cgst % : cgst amount
        $SGST_IGST = $SGST_IGSTperc .':'.$sgst_igst_amt; // cgst % : cgst amount
        $base_amt = $billing_price - $cgst_amt - $sgst_igst_amt;
        }
        $status  = $this->db->query("update cart set quantity = $quantity,rate ='$billing_rate', price ='$billing_price',mrp_rate='$mrp_rate',mrp_price='$mrp_price',billing_type= '$billing_type',base_amt ='$base_amt',HSN_code='$HSN_code',CGST='$CGST',SGST_IGST='$SGST_IGST',display_rate='$display_rate',display_price='$display_price',display_type= '$display_type',range_pricing= '$range_pricing' where cart_id = $cart_id");
                
            }
        
            
        }
    }
    public function cart_count($postdata=array()){
    $user_id = $postdata['user_id'];
    if($user_id!=0){
    $result = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0) AND pro.prod_status = 1")->result();
    $count = count($result);
    }
    else{
        $count = 0;
    }
    return $result = array('status'=>1,'message'=>'Cart count','count' => $count);
}
public function remove_cart($postdata=array()){
    $cart_id = $postdata['cart_id'];
    $user_id = $postdata['user_id'];
    $result = $this->db->query("delete from cart where cart_id = $cart_id and user_id = $user_id");
    if($result){
    return $result = array('status'=>1,'message'=>'Product Deleted from cart Successfully');    
    }
}
public function submit_review($postdata=array()){
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $insert_data['user_id'] = $postdata['user_id'];
    $insert_data['store_id'] = $postdata['store_id'];
    $insert_data['product_id'] = $postdata['product_id'];
    // $insert_data['variant_id'] = $postdata['variant_id'];
    $insert_data['item_id'] = $postdata['item_id'];
    $insert_data['star_count'] = $postdata['star_count'];
    $insert_data['review_type'] = $postdata['review_type'];
    if(isset($postdata['comment'])){
    $insert_data['comment'] = $postdata['comment'];
    }
    $insert_data['date_reviewed'] = date('Y-m-d H:i:s');
    $status = $this->db->insert('user_reviews',$insert_data);
    if($status){
    return $result = array('status'=>1,'message'=>'Product review updated'); 
    }else{
        return false;
    }
    
 
}
public function payment_type($postdata=array()){
        if(!isset($postdata['user_id']) || empty($postdata['user_id']) || !isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        $store_id = $postdata['store_id'];
        $coupon_discount = $postdata['coupon_discount'];
    //     ///////Check stock before go to Order Payment Page
       $chk_ctk = $this->check_stock($user_id);
       if($chk_ctk['status']==3){ //3 means stock not available //1 Stock available - allow to further process
          return $chk_ctk; 
       }
    $get_data = $this->db->query("SELECT email,phone_no FROM user_profile WHERE user_id = $user_id")->result();
    $user_email = (isset($get_data[0]->email)?$get_data[0]->email:'');
    $user_phoneno = (isset($get_data[0]->phone_no)?$get_data[0]->phone_no:'');
    $amt = 0;$items =0;$display_price=0;
    $cart_data = $this->db->query("select cart.price,cart.quantity from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0,1) AND pro.prod_status = 1")->result();
    foreach($cart_data as $cart){
        $amt = $amt+ $cart->price;
        $display_price = $display_price + $cart->price;
        $items = $items + $cart->quantity;
    }
    $district_id = 0; $state_id = 0;
    $address_detail = $this->db->query("SELECT ad.id address_id, ad.user_id,ad.address1,ad.address2,ad.landmark,ad.area_id,area.area_locality,ad.city_id,city.city_name,ad.district_id,dis.district,ad.state_id,state.state,ad.pincode,ad.gps_coordinates,ad.address_name,ad.address_type FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type = 1")->result();
    if($address_detail){
        $district_id =$address_detail[0]->district_id;
        $state_id =$address_detail[0]->state_id;
    }
    $est_packing_charge = 0; $est_delivery_charge = 0;
    $str = $this->db->query("select stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,store_delivery_type from stores where store_id = $store_id ")->result();
    if($str){
        $packing_charges = $str[0]->packing_charges;
        $delivery_charges = $str[0]->delivery_charges;
        $store_delivery_type = $str[0]->store_delivery_type; // 1-storepickup 2 -home delivery 3- both
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            if($pc_type==0){ //percwise
            // $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
            $est_packing_charge = round(($display_price * ($pc_perc/100)),0);
            }else{ //unitwise
            $est_packing_charge =  round(($items * $pc_unit_value),0);
            }   
        }
        
        if($delivery_charges ==0 || $store_delivery_type==1){ //disable // delivery charge = 0
            $est_delivery_charge = 0;
            $delivery_charges = 0; //$store_delivery_type ==1 means store pickup so don't show delivery_charge
        }else{
            $est_delivery_charge = $str[0]->min_dc;
           if(strtoupper($district_id)=="1" && $state_id==1 ){ ////manual address change can't calculate accurate distance $district_id = 1 chennai  $state_id=1 tamilnadu
                $est_delivery_charge = round($str[0]->min_dc,0);
            }else if($state_id==1){ //Inside Tamilnadu outside chennai
                $est_delivery_charge = 75;
            }else{
                $est_delivery_charge = 130;
            }
        }
    }
    $tot = $amt - $coupon_discount + $est_packing_charge + $est_delivery_charge;
            if($tot<0){
                $tot = 0;
            }
    $email = (isset($get_data[0]->email)?$get_data[0]->email:'');
     //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        $qry = $this->db->query("SELECT * from stores where store_id = $store_id");
        if ($qry->num_rows() > 0) {
            $val = $qry->row();
            $store_payment_type = $val->store_payment_type;
            $strpay_type = explode('|',$store_payment_type);// 1 or 1|3 or 1|2|3
            $payment_type = array();
            foreach($strpay_type as $types){
             if($types==1){
                 $payment_type[] = array(
                                        'id'=> 1,
                                        'value'=>'Cash on Delivery'
                                        );
             }else if($types==2 && $tot!=0){
                 $payment_type[] = array(
                                'id'=> 2,
                                'value'=>'UPI Based (Google Pay, PhonePe, Paytm)'
                                );

             }else if($types==3 && $tot!=0){
                 $payment_type[] = array(
                                'id'=> 3,
                                'value'=>'Online Payment'
                                );

             }   
            }

                return $status = array('status'=>1,'message'=>'Payment Type', 'data'=>$payment_type,'user_email'=>$user_email,'user_phoneno'=>$user_phoneno,'amt'=>$tot,'theme_color'=>"$theme_color",'font_color' =>"$font_color"); 
        }
        
    }
    public function store_payment($postdata=array()){
    $user_id = $postdata['user_id'];
    $store_id = $postdata['store_id'];
   $data =  $this->db->query("select stores.upi_id,stores.upi_mobile,stores.upi_qrcode from stores where store_id =$store_id ")->result();
   if($data){
       $data_array = array(
           'upi_id'=>$data[0]->upi_id,
           'upi_mobile'=>$data[0]->upi_mobile,
           'upi_qrcode'=>$data[0]->upi_qrcode
           );
    return $result = array('status'=>1,'message'=>'Store UPI Payment', 'data'=>$data_array); 
   }else{
       return false;
   }
    
}
public function user_address_update($postdata=array()){
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id  = $postdata['user_id'];
    $address1  = $postdata['address1'];
    $address2 = $postdata['address2'];
    $landmark = $postdata['landmark'];
    $city_town = $postdata['city_town'];
    $state_id = $postdata['state_id'];
    $pincode = $postdata['pincode'];
    //bug
    // $status=$this->db->query("update user_profile set address1 ='$address1',address2 = '$address2',landmark ='$landmark',city_town='$city_town',state_id='$state_id',pincode='$pincode' where user_id= $user_id");
    if($status){
        return $result = array('status'=>1,'message'=>'User Delivery Address Updated'); 
    }
    else{
        return false;
    }

}
public function delivery_status_update($postdata=array()){
    if((!isset($postdata['order_id']) || empty($postdata['order_id'])) ||(!isset($postdata['user_id']) || empty($postdata['user_id']))||(!isset($postdata['delivery_status_flg']) || empty($postdata['delivery_status_flg']))){
        return false;
    }
    $order_id = $postdata['order_id'];
    $UTN_number = $postdata['order_id'];
    $user_id = $postdata['user_id'];
    $delivery_status_flg = $postdata['delivery_status_flg'];
    $result = $this->db->query("select * from orders where utn_number ='$order_id' and delivery_status in (4,5) ")->result();
    // print_r($result);
    // die;
    //$delivery_status =1 means order accepted by seller
    if($result){
        $delivery_status = $result[0]->delivery_status;
    if($delivery_status==4 || $delivery_status==5){
    // if($delivery_status==5){
            if($delivery_status_flg==2){ //2 -'No'
                $delivery_status = 5; //Not delivered //so it's in pickup stage
            }
            else
            if($delivery_status_flg==1){ //1 - 'Yes'
                $delivery_status = 2; //Deliverd
            }
            // print_r($delivery_status);
            // die;
            $this->db->where("utn_number = '$order_id'");
            $this->db->set('delivery_status',$delivery_status);
            $status = $this->db->update('orders');
    }
            if ($status) {
                
                if($delivery_status_flg==1){
                    // //create invoice 
                $order = $this->db->query("select orders.order_id,orders.total_amount,orders.store_id,stores.store_name from orders inner join stores on orders.store_id = stores.store_id where UTN_number = '$order_id'")->result();
                $order_id = $order[0]->order_id;
                $order_amount = $order[0]->total_amount;
                $store_id = $order[0]->store_id;
                $store_name = $order[0]->store_name;
                 $dt = $this->db->query("SELECT MAX(invid)invid FROM invoice WHERE store_id = $store_id")->result();
                if(isset($dt[0]->invid)!=''){
                    $invid = $dt[0]->invid;
                $inv_dt = $this->db->query("select inv_no from invoice where invid =$invid ")->result();
                $invno = $inv_dt[0]->inv_no; //"YSA240521001"
                $remove = substr($invno, 9); //001
                $id = ltrim($remove, '0');//1
                }else{
                    $id = 0;
                }
                $sequence_num = str_pad($id + 1, 3, 0, STR_PAD_LEFT);
                $store_2letter = strtoupper(substr($store_name, 0, 2)); // SA salt n pepper,
                $d = date("dmy");//Invoice Format "YSA240521001" Y - Yellowmart, SA salt n pepper, 24052 datemonthyear, store wise sequence 001
                $INV_number = "Y".$store_2letter.$d.$sequence_num;
                 $insert_invdata  = array(
                        'inv_no'=>$INV_number,
                        'ord_id'=>$order_id,
                        'store_id'=>$store_id,
                        'total_final_bill_amt'=>$order_amount,
                        'inv_view_status '=>0
                    );
                $this->db->insert('invoice',$insert_invdata);
                //send Order Delivered notification mail      
    $get_data = $this->db->query("SELECT seller.email seller_email,seller.shopper_name seller_name,usr.email, usr.fullname,str.store_name,ord.UTN_number,ord.booking_time,ord.total_amount,ord.payment_method,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.delivery_status FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN user_profile usr ON usr.user_id = ord.user_id INNER JOIN shopper seller on seller.store_id = str.store_id  WHERE ord.UTN_number ='$UTN_number'")->result();
    if($get_data){
        $seller_email = $get_data[0]->seller_email;
        $email = $get_data[0]->email;
        // print_r($email);die;
        $cust_name = $get_data[0]->fullname;
        $seller_name = $get_data[0]->seller_name;
        $store_name = $get_data[0]->store_name;
        $dt_frmt=date_create($get_data[0]->booking_time);
        $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
        $total = $get_data[0]->total_amount;
        $payment_method = $get_data[0]->payment_method; //1 for store pickup and 2 for home delivery
        if($payment_method==1){
            $delivery_type ="Store pickup";
            $delivery_address = "-";
        }else{
            $delivery_type ="Home delivery";
            $delivery_address = $get_data[0]->address1.', '.$get_data[0]->address2.', '.$get_data[0]->landmark.', '.$get_data[0]->area.', '.$get_data[0]->city.', '.$get_data[0]->district.', '.$get_data[0]->state.' - '.$get_data[0]->pincode;
        }
        $delivery_status = $get_data[0]->delivery_status;
           //send Order Delivered notification mail to Customer
            if($email!=''){
            $to_receiver_email = $email;
            $from_email = 'yellowmart17@gmail.com';
            $from_emailpassword = 'yellowmart123';
            $from_username = 'The Brownie Studio';
            $subject="Order Delivered";
            $message = 
"Dear $cust_name

Greetings from $store_name! ORDER DELIVERED! Thanks for shopping with us.

ORDER ID : ORDER#$UTN_number   $store_name 

Store Name : $store_name
Order ID : $UTN_number
Order Date : $booking_time
Status : Delivered
Total : $total

Delivery Type: $delivery_type
Delivery Address: $delivery_address

Please provide feedback on your experience with BrownieStudio on the link
below,

URL : https://yellowmart.biz/browniestudio/

Regards,
$store_name
Powered by YellowMart";
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
                //  if($response['status']==0){
                //      return $result = array('status'=>1,'message'=>'Failed to send mail '); 
                //  }
            }
    }
                }
                return $status = array('status'=>1,'message'=>'Delivery Status Updated'); 
            }
}
else{
    return false;
}

}
public function language_list($postdata=array()){
     if(!isset($postdata['user_id']) ||empty($postdata['user_id'])){
            return false;
        }
        $user_id = $postdata['user_id'];
        if($user_id==0){
        return $result = array('status'=>5,'message'=>'User not loggedin');
    }
        $data = $this->db->query("select * from language where status = 1 order by id")->result();
        
     if($data){
         foreach($data as $dt){
         $final_array[] = array(
             "lang_id" => $dt->id,
             "lang_name" => $dt->lang_name
             );
         
        }
        return $status = array('status'=>1,'data'=>$final_array); 
       }
    else {
        return false;
    }
}
    public function update_language($postdata=array()){
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id  = $postdata['user_id'];
    $update_data['lang_id']  = $postdata['lang_id'];
    $status = $this->db->update('user_profile',$update_data,array('user_id'=>$user_id));
    if($status){
        return $result = array('status'=>1,'message'=>'Language Updated'); 
    }
    else{
        return false;
    }

}
public function notify_me($postdata=array()){
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id = $postdata['user_id'];
    $store_id = $postdata['store_id'];
    $product_id = $postdata['product_id'];
    // $varient_id = $postdata['varient_id'];
    $item_id = $postdata['item_id'];
    $varient_name = $postdata['varient_name'];
          $insert_data  = array(
            'user_id'=>$user_id,
            'store_id'=>$store_id,
            'product_id'=>$product_id,
            'item_id'=>$item_id,
            'varient_name' => $varient_name
        );
    $this->db->insert('notify',$insert_data);
    return $result = array('status'=>1,'message'=>'Product notify request sent'); 
    
 
}
public function wishlist($postdata=array()){
        if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
            return false;
        }
        $user_id =$postdata['user_id'];
        if($user_id!=0){
        //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
            exit;
        }}
        $store_id =$postdata['store_id'];
        //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        
        $final_array =array();
         $prod_qry = $this->db->query("SELECT pro.image_type,prodtl.item_images,pri_attcolor,pri_att,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.cat_id,pro.subcat_id from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id INNER JOIN wishlist ON wishlist.store_id = pro.store_id AND wishlist.product_id = pro.prod_id AND wishlist.item_id = prodtl.prod_itemid WHERE wishlist.user_id = $user_id and pro.prod_status = 1 order by pro.prod_id")->result();
         $data =array();
            foreach($prod_qry as $dt){
                $subcat_name = $dt->subcategory_name;
                $prod_itemid = $dt->prod_itemid;
                //Price start here
                $price_to_display = $dt->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $dt->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $dt->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $dt->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $dt->mop_price .' - ₹ '.$dt->mrp_price; //
                   }
                 } //Price end here
                 $display_type = $dt->price_to_display;
                 $final_mrpprice = $dt->mrp_price; 
                 $type = $dt->type;
                 $add_variant = $dt->add_variant;
                 $sale_unit = $dt->sale_unit;
                 $stock_unit = $dt->stock_unit;
                 $pack_content = $dt->pack_content;
               if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product
                    $sale_unit = $dt->sale_unit;
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $dt->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $dt->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $dt->att1;
                     $variant1 = $dt->var1;
                     $att2_id = $dt->att2;
                     $variant2 = $dt->var2;
                     $att3_id = $dt->att3;
                     $variant3 = $dt->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $getcnt = explode(";",$variant_name); //masala;egg;corainder
                     $variant_cnt = count($getcnt);//3
                     $color_value = $dt->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $color_n = $variant2.';'.$variant3; 
                          $color_n = rtrim($color_n, ";");
                          $size_value = trim($color_n);
                     }
                 }
                 
                 $stock_qty = 0; 
                 //get stock start here
                 if(trim(strtoupper($dt->display_stock))=="NO"){ //follow MOQ
                     $stock_qty = $dt->item_moq;
                 }else {
                     if(strtoupper($type)=="LOOSE"){ //loose product
                         $stock_qty = $dt->item_totstock; 
                      //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock //Only applicable for loose product
                            if($sale_unit!=$stock_unit){
                                if($sale_unit == 1 || $sale_unit == 3){ //1-ml to ltr  ex. 5ltr total stck 500ml packet content //3-gram to kg
                                    $converted = $pack_content / 1000;   // 500ml /1000 = 0.5ltr
                                    $stock_qty = $stock_qty / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                                }
                                else if($sale_unit == 2 || $sale_unit == 5){ //2- ltr to ltr //5-kg to kg
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else if($sale_unit == 4 || $sale_unit == 6 || $sale_unit == 7 || $sale_unit == 8 || $sale_unit == 9){//4-box//6-pcs//7-nos //8-packet//9-plate
                                    $stock_qty = $stock_qty;
                                }
                            }
                            else{
                                 if(($sale_unit == 1) || ($sale_unit == 2) || ($sale_unit == 3) || ($sale_unit == 5) ){
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else {
                                    $stock_qty = $stock_qty;
                                }
                            }
                            $stock_qty = (int)$stock_qty;
                     } else { //Other than loose product
                         $stock_qty = $dt->item_totstock; 
                     }
                 }
                 $fi_stock_qty = round($stock_qty);
                 // stock calculation end here

                //Stock status    
                if($dt->item_stocksts==1){
                     $stock_status_final='Available';
                }
                
                if($fi_stock_qty <=0 ){
                    $stock_status_final = 'Out of Stock';
                }
                if($dt->item_availability ==0 ){//check availability
                    $stock_status_final = 'Sold Out';
                }
                 $final_mrpprice =round($final_mrpprice,0);    
                 $price_final =round($price_final,0);
    if($dt->image_type==2){ // 1 - generic 2 - variant
        $item_images  = $dt->item_images;
        $ex_images = explode("|", $item_images); 
        $product_image =  $ex_images[0];
        if($product_image==""){
        $product_image = $dt->prod_img1;
        }
    }else{
        $product_image  = $dt->prod_img1;
    }

                 $data[] = array(
                     'store_id' =>$store_id,
                    'product_id'=>$dt->prod_id,
                    'category_id'=>$dt->cat_id,
                    'subcat_id'=>$dt->subcat_id,
                    'product_name'=>$dt->display_name,
                    'type'=>$dt->type,
                    'product_image'=>$product_image,
                    'status'=>$dt->prod_status,
                    'item_id'=>$prod_itemid,
                    'color_value'=>$color_value,
                    'size_value'=>$size_value,
                    'varient_id'=>$prod_itemid,
                    'display_type'=>$display_type,
                    'mrp_price'=>"$final_mrpprice",
                    'display_price'=>"$price_final",
                    'min_price'=>"$price_final",
                    'varient_name'=>$variant_name,
                    'varient'=>$variant_name,
                    'varient_cnt'=>"$variant_cnt",
                    'quantity'=>"$fi_stock_qty",
                    'stock_status'=>$stock_status_final,
                    'theme_color'=>$theme_color,
                    'font_color'=>$font_color
                    );
                 
            }
      return $result = array('status'=>1,'message'=>'Wishlist', 'data'=>$data, 'theme_color'=>$theme_color,'font_color'=>$font_color); 
    }
    public function addto_wishlist($postdata=array()){ //add //remove wishlist
    
    if(!isset($postdata['user_id']) || empty($postdata['user_id'])){
        return false;
    }
    $user_id = $postdata['user_id'];
    $store_id = $postdata['store_id'];
    $product_id = $postdata['product_id'];
    $item_id = $postdata['item_id'];
    $wishlist_key = $postdata['wishlist_key'];
    $pro_data = $this->db->query("select * from product where prod_id = $product_id")->result();
    if(empty($pro_data)){
        return false; 
    }
    if($wishlist_key==1){
            $status= $this->db->insert('wishlist', array('user_id'=>$user_id,'product_id'=>$product_id,'store_id'=>$store_id,'item_id'=>$item_id,'wish_addeddate'=>date('Y-m-d H:i:s')));    
            return $result = array('status'=>1,'message'=>'Added to wishlist successfully');
    }else{
            $status = $this->db->query("delete from wishlist where store_id = $store_id and user_id = $user_id and product_id=$product_id and item_id=$item_id");
            return $result = array('status'=>1,'message'=>'Removed from wishlist');
    }
            
     }
       public function offers($postdata=array()){
         if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
        return false;
    }  
        $store_id = $postdata['store_id'];
        $user_id = $postdata['user_id'];
        $offer = $this->db->query("SELECT id offer_id,title,offer_code,terms_conds,validity_from,validity_to,offer_image,offer_usage FROM `yms_offercoupon` WHERE yms_offercoupon.store_id = $store_id ")->result();
        $offer_array =array(); $storewise_offer = array();
        if($offer){
            foreach($offer as $o){
                  $current_dt = date("Y-m-d H:i");
                    $cpnvalidity_from = $o->validity_from;
                    $cpnvalidity_to = $o->validity_to;
                    $coupon_id = $o->offer_id;
    if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to){
        $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
                        $usedcnt = count($chk_coupon_usage);
                        $coupon_cnt = $o->offer_usage;
        if($usedcnt<$coupon_cnt){
            $offer_array[] = array(
                'offer_id'=>$o->offer_id,
                'title'=>$o->title,
                'offer_code'=>$o->offer_code,
                'terms_conds'=>trim($o->terms_conds),
                'validity_from'=>$o->validity_from,
                'validity_to'=>$o->validity_to,
                'offer_image'=>$o->offer_image
                );
                    }}
                  
            }   
        }

        $result = array('status'=>1,'message'=>'offers list','stores'=>$storewise_offer,'client_offer'=>$offer_array);
        return $result;
    }
    public function chk_coupon($postdata=array()){ //MS
        
        if(!isset($postdata['user_id']) && !isset($postdata['coupon_code']) && empty($postdata['coupon_code'])){
            return false;
        }
        $total_array = array();
        $user_id = $postdata['user_id'];
        $coupon_code = trim($postdata['coupon_code']);
        $store_id = $postdata['store_id'];
        $total = 0;$items = 0;$mrp_total=0;$display_price=0;
        $overall_discount_text = "";
        $price = $this->db->query("select * from cart where user_id =$user_id and order_id = 0 and product_status = 0")->result();
        if($price){
            foreach($price as $p){
            $total = $total + $p->display_price;
            $display_price = $display_price + $p->display_price;
            $mrp_total = $mrp_total + $p->mrp_price;
            $items = $items + $p->quantity;
            }
        }
        $str = $this->db->query("select stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,store_delivery_type from stores where store_id = $store_id ")->result();
                                if($str){
                                    $packing_charges = $str[0]->packing_charges;
                                    $delivery_charges = $str[0]->delivery_charges;
                                    $store_delivery_type = $str[0]->store_delivery_type; // 1-storepickup 2 -home delivery 3- both
                                    if($packing_charges ==0){ //disable // packing charge = 0
                                        $est_packing_charge = 0;
                                    } 
                                    else { //packing charges enabled for this store
                                        $pc_type = $str[0]->pc_type;
                                        $pc_perc = $str[0]->pc_perc;
                                        $pc_unit_value = $str[0]->pc_unit_value;
                                        if($pc_type==0){ //percwise
                                        // $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
                                        $est_packing_charge = round(($display_price * ($pc_perc/100)),0);
                                        }else{ //unitwise
                                        $est_packing_charge =  round(($items * $pc_unit_value),0);
                                        }   
                                    }
                                    
                                    if($delivery_charges ==0 || $store_delivery_type==1){ //disable // packing charge = 0
                                        $est_delivery_charge = 0;
                                        $delivery_charges = 0; //$store_delivery_type ==1 means store pickup so don't show delivery_charge
                                    }else{
                                        $est_delivery_charge = round($str[0]->min_dc,0);
                                        $address_detail = $this->db->query("SELECT ad.district_id,ad.state_id FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type = 1")->result();
                                        if($address_detail){
                                        $district_id = $address_detail[0]->district_id;
                                        $state_id = $address_detail[0]->state_id;
                                            if(strtoupper($district_id)=="1" && $state_id==1 ){ ////manual address change can't calculate accurate distance $district_id = 1 chennai  $state_id=1 tamilnadu
                                                $est_delivery_charge = round($str[0]->min_dc,0);
                                            }else if($state_id==1){ //Inside Tamilnadu outside chennai
                                                $est_delivery_charge = 75;
                                            }else{
                                                $est_delivery_charge = 130;
                                            }
                                        }
                                    }
                                }
                       $tot = $total + $est_packing_charge + $est_delivery_charge;
                       $overall_dis = round($mrp_total -  $total,0);
                        if($overall_dis>0){
                            $overall_discount_text = 'You have saved Rs.'.$overall_dis.' on this order.';
                       }
        $total_array = array(
            'coupon_code' =>$coupon_code,
            'coupon_discount' => "0",
            'total' =>"$tot",
            'discount_text'=>$overall_discount_text,
            'delivery_charge'=>$est_delivery_charge,
            'packing_charge'=>$est_packing_charge
            
            );
        $chk_coupon_availability =$this->db->query("select id,offer_code,offer_usage from yms_offercoupon where store_id =$store_id and offer_code = '$coupon_code'")->result();
        if(empty($chk_coupon_availability)){
            $result_1 = array('status'=>2,'message'=>'Please enter valid coupon','data'=>$total_array);
            return $result_1;
        }
        else{
            $coupon_id= $chk_coupon_availability[0]->id;
            $offer_usage = $chk_coupon_availability[0]->offer_usage;
            $ord = $this->db->query("select * from orders where user_id =$user_id and coupon_id = $coupon_id")->result();
            $couponused_cnt = count($ord);
            if($couponused_cnt >= $offer_usage){
                $result_2 = array('status'=>2,'message'=>'Coupon used more than assigned','data'=>$total_array);
                return $result_2;
            }else{
                   //offer || coupon code discount
                if(isset($postdata['coupon_code'])){
                $coupon_code = trim($postdata['coupon_code']);
                $get_cpndtl = $this->db->query("select * from yms_offercoupon where offer_code = '$coupon_code' ")->result();
                if($get_cpndtl){
                    $current_dt = date("Y-m-d H:i");
                    $cpnvalidity_from = $get_cpndtl[0]->validity_from;
                    $cpnvalidity_to = $get_cpndtl[0]->validity_to;
                    $coupon_id = $get_cpndtl[0]->id;
                    if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to){ //coupon validation date & time
                        $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
                        $usedcnt = count($chk_coupon_usage);
                        $coupon_cnt = $get_cpndtl[0]->offer_usage;
                        if($usedcnt<=$coupon_cnt){
                            $rule_type = $get_cpndtl[0]->rule_type; // 1- prec% 2- flat
                            $rule_value = $get_cpndtl[0]->rule_value; // how much percentage or flat price //5% or 50FLAT
                            $condition_chkvalue = $get_cpndtl[0]->condition_chkvalue; //thershold value
                            if($total >= $condition_chkvalue){ // order amount should greater than $condition_chkvalue
                            $coupon_discount =0;
                            if($rule_type==1 ){ //%
                                $coupon_discount = ($rule_value / 100) * $total;
                            }else if($rule_type==2 ){ //Flat
                                $coupon_discount = $rule_value;
                            }
                            // $total_amt = round(($total + $est_packing_charge + $est_delivery_charge - $rule_value),2);
                            $total_amt = $total - $coupon_discount + $est_packing_charge + $est_delivery_charge;
                            if($total_amt<0){
                                $total_amt =0;
                            }
                            $overdis = $mrp_total -  $total + $coupon_discount;
                            $overall_dis = round($overdis,0);
                            $overall_discount_text = 'You have saved Rs.'.$overall_dis.' on this order.';

                            $total_amt = round($total_amt,0);
                            $c_discount = round($coupon_discount,0);
                            $total_array = array(
                                    'coupon_code' =>$coupon_code,
                                    'coupon_discount' => "$c_discount",
                                    'total' =>"$total_amt",
                                    'discount_text'=>$overall_discount_text,
                                    'delivery_charge'=>$est_delivery_charge,
                                    'packing_charge'=>$est_packing_charge
                                    );
                            $result_3 = array('status'=>1,'message'=>'Coupon available','data'=>$total_array);
                            return $result_3;
                            }
                        }else{
                            $result_2 = array('status'=>2,'message'=>'Coupon used more than assigned','data'=>$total_array);
                            return $result_2;
                        }
            
        }
                    else{
                        $result_3 = array('status'=>2,'message'=>'Coupon expired','data'=>$total_array);
                    }
    }
                }
                // $result_3 = array('status'=>1,'message'=>'Coupon available','data'=>$total_array);
                $result_3 = array('status'=>2,'message'=>'Invalid coupon','data'=>$total_array);
                return $result_3;
                
            }
            
        }
    }
    public function checkout($postdata=array()){
    $user_id = $postdata['user_id'];
    $status = 1;
    $cart_data = $this->db->query("select * from cart INNER JOIN product pro ON cart.product_id =  pro.prod_id where user_id = $user_id and order_id = 0 and product_status in (0,1) AND pro.prod_status = 1")->result();
    $cart_count = count($cart_data);
    $result = $this->db->query("select  cart.preferred_del_date,item_stocksts,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.display_name,cart.cart_id ,cart.varient_id,cart.item_id,cart.varient_name,cart.quantity,pro.prod_name product_name,pro.description product_description,pro.prod_img1 product_image,pro.prod_id product_id,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product pro ON pro.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND prodtl.prod_itemid = cart.item_id where user.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0,1) order by product_id,cart_id")->result();
    $final_array = array();
    $data_array = array();
    if($result){
        $today = date('Y-m-d');
        if($result[0]->preferred_del_date < $today ){
            return $result = array('status'=>0,'message'=>'Please select correct preferred date');
        }
    }
     ///////Check stock before go to Order Summary Page
      $chk_ctk = $this->check_stock($user_id);
      if($chk_ctk['status']==3){ //3 means stock not available //1 Stock available - allow to further process
          return $chk_ctk; 
      }
     
    foreach($result as $data){
        if($data->quantity<=0){
            return array('status'=>0,'message'=>'Please remove sold out products from your basket');   
             exit;
        }
        $status = 1;
        $product_id = $data->product_id;
        $varient_id = $data->varient_id;
        $item_id = $data->item_id;
        $display_stock = $data->display_stock;
        if($display_stock=="YES"){
            $stock = $data->item_totstock; 
        }else{
            $stock = $data->item_moq;
        }
        
        $stock_availability ='';
        if($data->quantity > $stock){
            $stock_availability = 'Out of stock';
            $stock_status = 'Sold Out';
        }else if($data->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status = 'Available';
        }
        if($data->item_stocksts==2){
            $stock_status = 'Sold Out';
        }else if($data->item_stocksts==1){
            $stock_status = 'Available';
        }else{
            $stock_status = 'Sold Out';
        }
        if($stock_status!='Available'){
                $status = 3;
            }

        $data_array[] = array(
            'product_id' => $product_id,
            'cart_id' => $data->cart_id,
            'varient_id' => $data->varient_id,
            'item_id' => $data->item_id,
            'varient_name' => $data->varient_name,
            'quantity' => $data->quantity,
            'product_name' => $data->display_name,
            'product_nameold' => $data->product_name,
            'product_description' => $data->product_description,
            'product_image' => $data->product_image,
            'store_id' => $data->store_id,
            'store_name' => $data->store_name,
            'store_image' => $data->store_image,
            'store_description' => $data->store_description,
            'user_name' => $data->user_name,
            'rate' => $data->rate,
            'price' => $data->price,
            'stock' => $stock,
            'stock_status' => $stock_status,
            'stock_availability' => $stock_availability
            );
            
    }    
     $message="Checkout Order";
        if($status==3){
            $message ="Stock not available Please remove Sold Out products";
        }
        $final_array = array (
                'status' =>$status,
                'message' =>$message,   
                'data' => $data_array
                );
    
    //die;
    if($result){
        return $final_array;
    }
    else {
        return false;
    }
    
}
public function order_summary($postdata=array()){
     $user_id = $postdata['user_id'];
     if($user_id==0){
        return $result = array('status'=>5,'message'=>'User not loggedin');
    }
     //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
      $lang_menu = array();
        $order_summary =''; $store_pickup =''; $total_amount=''; $delivery_type='';$save='';$edit='';$please_note_orderno='';$agree_terms_conditions='';$home_delivery='';$delivery_address='';$address1='';
        $address2='';$landmark='';$city_town='';$state='';$pincode='';$confirm_order='';
        $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and page_name ='Order Summary Page'")->result();
        foreach($menu_list as $menu){
switch ($menu->menu_variable) {
  case "order_summary":
    $order_summary = $menu->menu;
    break;
  case "store_pickup":
    $store_pickup = $menu->menu;
    break;
  case "total_amount":
    $total_amount = $menu->menu;
    break;
  case "delivery_type":
    $delivery_type = $menu->menu;
    break;
  case "save":
    $save = $menu->menu;
    break;
  case "edit":
    $edit = $menu->menu;
    break;
  case "please_note_orderno":
    $please_note_orderno = $menu->menu;
    break;
  case "agree_terms_conditions":
    $agree_terms_conditions = $menu->menu;
    break;
 case "home_delivery":
    $home_delivery = $menu->menu;
    break;
  case "delivery_address":
    $delivery_address = $menu->menu;
    break;
  case "address1":
    $address1 = $menu->menu;
    break;
  case "address2":
    $address2 = $menu->menu;
    break;
  case "landmark":
    $landmark = $menu->menu;
    break;
 case "city_town":
    $city_town = $menu->menu;
    break;
  case "state":
    $state = $menu->menu;
    break;
  case "pincode":
    $pincode = $menu->menu;
    break;
  case "confirm_order":
    $confirm_order = $menu->menu;
    break;
    
  default:
    
}
        }
            $lang_menu = array( 
                "order_summary" =>$order_summary,
                "store_pickup"=>$store_pickup,
                "total_amount"=>$total_amount,
                "delivery_type"=>$delivery_type,
                "save"=>$save,
                "edit"=>$edit,
                "please_note_orderno"=>$please_note_orderno,
                "agree_terms_conditions"=>$agree_terms_conditions,
                "home_delivery"=>$home_delivery,
                "delivery_address"=>$delivery_address,
                "address1"=>$address1,
                "address2"=>$address2,
                "landmark"=>$landmark,
                "city_town"=>$city_town,
                "state"=>$state,
                "pincode"=>$pincode,
                "confirm_order"=>$confirm_order
                );

     $status = 1 ; 
     ///////Check stock before go to Order Summary Page
      $chk_ctk = $this->check_stock($user_id);
      if($chk_ctk['status']==3){ //3 means stock not available //1 Stock available - allow to further process
          return $chk_ctk; 
      }
 $summary_array = array(); $order_total = 0; $billing_price = 0; $tot_discount = 0; $est_delivery_charge = 0; $est_packing_charge = 0;$items = 0; $display_price = 0;
$result = $this->db->query("select user.user_type,user.email uptodate_email,user.fullname orderby_name,user.phone_no orderby_contact,pro.subcat_id,pro.packtype_id,message_on_cake,preferred_del_date,preferred_del_time,notes_on_chef,cart.product_image,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,stores.exclusive_app_enabled,range_pricing,prodtl.display_name,cart.mrp_rate,cart.mrp_price,cart.billing_type,cart.cart_id ,cart.varient_id,cart.item_id,cart.varient_name,cart.quantity,pro.prod_name product_name,pro.description product_description,pro.prod_img1,pro.prod_id product_id,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,stores.store_delivery_type,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,display_rate,display_price,display_type from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product pro ON pro.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON pro.prod_id  = prodtl.prod_id  AND prodtl.prod_id = cart.product_id AND prodtl.prod_itemid = cart.item_id where user.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0,1)")->result();
    if($result){
    $final_array = array();
    $data_array = array();
    $common_data = array();
    $store_id = $result[0]->store_id;
    //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        
    $str_delivery_type = $result[0]->store_delivery_type; //1-store pickup 2- home delivery 3- both
    
    $address_detail = $this->db->query("SELECT ad.id address_id, ad.user_id,ad.address1,ad.address2,ad.landmark,ad.area_id,area.area_locality,ad.city_id,city.city_name,ad.district_id,dis.district,ad.state_id,state.state,ad.pincode,ad.gps_coordinates,ad.address_name,ad.address_type FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type = 1")->result();
    $address_array = ''; $address_id = '';$address1='';$address2='';$landmark='';$area_id='';$area_locality='';$city_id='';$city_name='';$district_id='';$district='';$state_id='';$state='';$pincode='';$gps_coordinates='';$address_name='';$address_type='';
    $address_flg =0;$str_delivery_status ='';
    if($address_detail){
        if(($address_detail[0]->address1!='' || $address_detail[0]->address2!='') && $address_detail[0]->landmark!='' && $address_detail[0]->city_name!='' && $address_detail[0]->district!='' && $address_detail[0]->state!='' && $address_detail[0]->pincode!='' ){
         $address_flg =1;   
        }
            //  $getuser_address = $this->db->query("select pincode from address user_add where user_id=$user_id and address_type=1")->result(); //get current address pincode
            //  if($getuser_address){
            //      $user_pincode = trim($getuser_address[0]->pincode);
            //      $chkstr_delivery = $this->db->query("select * from store_address where store_id =$store_id and pincode =$user_pincode")->result(); //check store will support user current address pinocde
            //      if(empty($chkstr_delivery)){
            //          $str_delivery_status = "This item cannot be shipped to your selected delivery location. Please choose a different delivery location.";
                     
            //      }
            //  }
             
    $address_id = $address_detail[0]->address_id;
    $address1=$address_detail[0]->address1;
    $address2=$address_detail[0]->address2;
    $landmark=$address_detail[0]->landmark;
    $area_id=$address_detail[0]->area_id;
    $area_locality=$address_detail[0]->area_locality;
    $city_id=$address_detail[0]->city_id;
    $city_name=$address_detail[0]->city_name;
    $district_id=$address_detail[0]->district_id;
    $district=$address_detail[0]->district;
    $state_id=$address_detail[0]->state_id;
    $state=$address_detail[0]->state;
    $pincode=$address_detail[0]->pincode;
    $gps_coordinates=$address_detail[0]->gps_coordinates;
    $address_name=$address_detail[0]->address_name;
    $address_type=$address_detail[0]->address_type;
    }
    $address_array = array(
        'delivery_type' => $str_delivery_type,
        'address_id' => $address_id,
        'user_id' => $user_id,
        'address1' => $address1,
        'address2' => $address2,
        'landmark' => $landmark,
        'area_id' => $area_id,
        'area_locality' => $area_locality,
        'city_id' => $city_id,
        'city_name' => $city_name,
        'district_id' => $district_id,
        'district' => $district,
        'state_id' => $state_id,
        'state' => $state,
        'pincode' => $pincode,
        'gps_coordinates' => $gps_coordinates,
        'address_name' => $address_name,
        'address_type' => $address_type,
        'address_flg'=>$address_flg,
        'str_delivery_status'=>$str_delivery_status
        );
    $store_address = '';
    $str_address = $this->db->query("SELECT str.store_id,str.store_address1,str.store_address2,str.area_id,area.area_locality,str.city_id,city.city_name,str.district_id,dis.district,str.state_id,state.state,str.pincode,str.store_maplocation FROM stores as str INNER JOIN state ON str.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = str.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = str.city_id INNER JOIN area on area.id = str.area_id AND area.city_id = city.id  WHERE store_id = $store_id")->result();
    if($str_address){
         $store_address = array(
        'store_id' => $str_address[0]->store_id,
        'address1' => $str_address[0]->store_address1,
        'address2' => $str_address[0]->store_address2,
        'area_locality' => $str_address[0]->area_locality,
        'city_name' => $str_address[0]->city_name,
        'district' => $str_address[0]->district,
        'state' => $str_address[0]->state,
        'pincode' => $str_address[0]->pincode,
        'gps_coordinates' => $str_address[0]->store_maplocation
        );
        }
    $allow_other_state =1; $pronames = ""; $erro_message="";
    foreach($result as $data){
        if($data->subcat_id==4 && $data->packtype_id ==4){ //brownie box
                                              
        }else{ ////cart product contains other than "Brownies" so allow only chennai region 
            $allow_other_state =0;
            $pronames = $pronames.' , '.$data->product_name;
        }
        $product_id = $data->product_id;
        $varient_id = $data->varient_id;
        $item_id = $data->item_id;
        $display_name_final = $data->display_name;
            $display_stock = $data->display_stock;
            if(strtoupper($display_stock)=="YES"){
                $stock = $data->item_totstock; 
            }else{
                $stock = $data->item_moq;
            }
            
            $stock_availability ='';
            if($data->quantity > $stock){
                $stock_availability = 'Out of stock';
                $stock_status = 'Sold Out';
            }else if($data->quantity <= $stock){
                $stock_availability = 'Stock Available';
                $stock_status = 'Available';
            }
            if($data->item_stocksts==2){
                $stock_status = 'Sold Out';
            }else if($data->item_stocksts==1){
                $stock_status = 'Available';
            }else{
                $stock_status = 'Sold Out';
            }
            if($stock_status!='Available'){
                $status = 3;
            }
        $currentaddress_available = "0";
            $getcurrent_address = $this->db->query("select * from address where user_id = $user_id and address_type=1")->result(); 
            if($getcurrent_address){
                $currentaddress_available = "1";
            }
            if(trim($data->display_type)=='4'){//price range
                $dis_price =  $data->range_pricing;
                $lang_menu['total_amount']= 'Estimated Total';
            }else{
                $dis_price = $data->display_price;
            }
            $lang_menu['agree_terms_conditions'] = 'I agree to Yellow Mart terms & conditions by placing an order.';
            if($data->exclusive_app_enabled==1){
            $lang_menu['agree_terms_conditions']= 'I agree to '.$data->store_name.' terms & conditions by placing an order.';
            }
        $varient_cnt = 0;
        $getcnt = explode(";",$data->varient_name); //masala;egg;corainder
        $varient_cnt = count($getcnt);//3
        if($data->preferred_del_date=='0000-00-00'){
            $preferred_del_date = "";
        }else{
            $dt_frmt=date_create($data->preferred_del_date);
            $preferred_del_date =  date_format($dt_frmt,"d/m/Y");
        }
        $data_array[] = array(
            'product_id' => $product_id,
            'cart_id' => $data->cart_id,
            'varient_id' => $data->varient_id,
            'item_id' => $data->item_id,
            'varient_name' => $data->varient_name,
            'varient_cnt' =>$varient_cnt,
            'quantity' => $data->quantity,
            'product_name' => $display_name_final,
            'product_nameold' => $data->product_name,
            'product_description' => $data->product_description,
            'product_image' => $data->product_image,
            'store_id' => $data->store_id,
            'store_name' => $data->store_name,
            'store_image' => $data->store_image,
            'store_description' => $data->store_description,
            'user_name' => $data->user_name,
            'display_rate' => $data->display_rate,
            'display_price' => $dis_price,
            'display_type' => $data->display_type,
            'billing_rate' => $data->rate,
            'billing_price' => $data->price,
            'mrp_rate' => $data->mrp_rate,
            'mrp_price' => $data->mrp_price,
            'billing_type' => $data->billing_type,
            'stock' => $stock,
            'stock_status' => $stock_status,
            'stock_availability' => $stock_availability,
            'theme_color'=>$theme_color,
            'font_color' =>$font_color,
            'str_delivery_type'=>$str_delivery_type,
            'currentaddress_available'=>$currentaddress_available,
            'message_on_cake'=>$data->message_on_cake,
            'preferred_del_date'=>$preferred_del_date,
            'preferred_del_time'=>$data->preferred_del_time,
            'notes_on_chef'=>$data->notes_on_chef,
            'subcat_id'=>$data->subcat_id
            );
        $order_total = $order_total + $data->mrp_price;
        $billing_price = $billing_price +  $data->price;
        // $tot_discount = $order_total - $billing_price ;
        $display_price = $display_price +  $data->display_price;
        // $tot_discount = $order_total - $display_price ;
        
        $items = $items + $data->quantity;
    }  
    //allow cake only inside chennai , allow brownie box all over india
    if($allow_other_state==0 && ($state_id!=1 || $district_id!=1)){ // $district_id =1 chennai
        $pronames = str_replace(',','',$pronames);
        $erro_message = $pronames.' item unable to delivery entered pincode, kindly remove item or change the pincode';
    }else if($allow_other_state==0 && ($state_id==1 || $district_id==1)){ // for chennai -> cake delivery for allowed pincode only 
                $chk_pin = $this->db->query("select * from area where pincode = '$pincode' and city_id=1")->result();
                    if(empty($chk_pin)){
                        $pronames = str_replace(',','',$pronames);
                        $erro_message = $pronames.' item unable to delivery entered pincode, kindly remove item or change the pincode';
                    }
    }else{
        $erro_message = "";
    }
    if($result){
        $phone_no = substr($result[0]->orderby_contact,2); //remove country code 91
        $common_data = array(
            'user_type' => $result[0]->user_type,
            'uptodate_email' => $result[0]->uptodate_email,
            'orderby_name' => $result[0]->orderby_name,
            'orderby_contact' => $phone_no,
            'delivery_errormessage' =>$erro_message
            );
    }
    
    $tot_discount = $order_total - $display_price ;
    $str = $this->db->query("select stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,store_delivery_type from stores where store_id = $store_id ")->result();
    if($str){
        $packing_charges = $str[0]->packing_charges;
        $delivery_charges = $str[0]->delivery_charges;
        $store_delivery_type = $str[0]->store_delivery_type; // 1-storepickup 2 -home delivery 3- both
        if($packing_charges ==0){ //disable // packing charge = 0
            $est_packing_charge = 0;
        } 
        else { //packing charges enabled for this store
            $pc_type = $str[0]->pc_type;
            $pc_perc = $str[0]->pc_perc;
            $pc_unit_value = $str[0]->pc_unit_value;
            if($pc_type==0){ //percwise
            // $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
            $est_packing_charge = round(($display_price * ($pc_perc/100)),2);
            }else{ //unitwise
            $est_packing_charge =  round(($items * $pc_unit_value),2);
            }   
        }
        
        if($delivery_charges ==0 || $store_delivery_type==1){ //disable // delivery charge = 0
            $est_delivery_charge = 0;
            $delivery_charges = 0; //$store_delivery_type ==1 means store pickup so don't show delivery_charge
        }else{
            $est_delivery_charge = $str[0]->min_dc;
           if(strtoupper($district_id)=="1" && $state_id==1 ){ ////manual address change can't calculate accurate distance $district_id = 1 chennai  $state_id=1 tamilnadu
                $est_delivery_charge = round($str[0]->min_dc,0);
            }else if($state_id==1){ //Inside Tamilnadu outside chennai
                $est_delivery_charge = 75;
            }else{
                $est_delivery_charge = 130;
            }
        }
        
      $summary_array = array(
          'order_total' => $order_total,
          'tot_discount' => round($tot_discount),
          'packing_charge_enable' =>round($packing_charges,2), //0 - disable 1- enable
          'est_packing_charge' => round($est_packing_charge,0),
          'delivery_charge_enable' =>round($delivery_charges,2), //0 - disable 1- enable
          'est_delivery_charge' => round($est_delivery_charge,0),
          'delivery_note' => $str[0]->delivery_note,
          'Total' => round(($order_total - $tot_discount + $est_packing_charge + $est_delivery_charge),0),
          'Total_storedelivery' => round(($order_total - $tot_discount + $est_packing_charge),0)
        );
    }
    $message="Order summary";
        if($status==3){
            $message ="Stock not available Please remove Sold Out products";
        }
        $final_array = array (
                'status' =>$status,
                'message' =>$message,
                'common_data' => $common_data,
                'data' => $data_array,
                'address' =>$address_array,
                'store_address'=>$store_address,
                'summary_calculation' =>$summary_array,
                'menu' => $lang_menu
                );
    if($result){
        return $final_array;
    }

    }
    else {
        return false;
    }
    
}
public function place_order($postdata=array()){
    $user_id = $postdata['user_id'];
    if($user_id==0)
    {
        return $result = array('status'=>5,'message'=>'User not loggedin');
    }
    $lang_menu = array();
    $confirm_order =''; $order_id =''; $thanku_message=''; $check_order='';
    $menu_list =$this->db->query("SELECT menu.menu_variable,menu.menu FROM language_menu  as menu INNER JOIN language lang on menu.lang_id = lang.id INNER JOIN user_profile user on user.lang_id = lang.id WHERE user.user_id =$user_id and page_name ='Place Order Page'")->result();
    foreach($menu_list as $menu)
    {
        switch ($menu->menu_variable) 
        {
          case "confirm_order":
            $confirm_order = $menu->menu;
            break;
          case "order_id":
            $order_id = $menu->menu;
            break;
          case "thanku_message":
            $thanku_message = $menu->menu;
            break;
          case "check_order":
            $check_order = $menu->menu;
            break;
          default:
        }
    }
    $thanku_message = 'Thank you for shopping with Yellow Mart!';
    $get_store_name = $this->db->query("select stores.store_name from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id where user.user_id = $user_id and cart.product_status in (0,1) and order_id = 0")->result();
    if($get_store_name)
    {
        $store_name = $get_store_name[0]->store_name;
        $thanku_message = 'Thank you for shopping with '.$store_name.'!';
    }
    $lang_menu = array( 
        "confirm_order" =>$confirm_order,
        "order_id"=>$order_id,
        "thanku_message"=>$thanku_message,
        "check_order"=>$check_order
    );
    $get_usercurrent_address = $this->db->query("SELECT ad.id add_id,ad.address1,ad.address2,ad.landmark,area.area_locality,city.city_name,dis.district,state.state,ad.pincode,ad.gps_coordinates,ad.address_name FROM address AS ad INNER JOIN state ON ad.state_id = state.state_id INNER JOIN district as dis ON dis.district_id = ad.district_id AND dis.state_id = state.state_id INNER JOIN city on city.id = ad.city_id AND city.district_id = dis.district_id INNER JOIN area on area.id = ad.area_id AND area.city_id = city.id  WHERE user_id = $user_id and address_type = 1")->result();
    if(empty($get_usercurrent_address))
    {//for store pickup user current address empty
            $get_usercurrent_address = $this->db->query("SELECT 0 as add_id,'' address1,'' address2,'' landmark,'' area_locality,'' city_name,'' district,'' state,'' pincode,'' gps_coordinates,'' address_name  from user_profile WHERE user_id = $user_id")->result();
        //   return $result = array('status'=>0,'message'=>'Unable to place order, Manage your address and try again');
    }

    //     ///////Check stock before go to Place Order Page
    $chk_ctk = $this->check_stock($user_id);
    if($chk_ctk['status']==3)
    { //3 means stock not available //1 Stock available - allow to further process
          return $chk_ctk; 
    }
    $payment_method = $postdata['payment_method'];
    $payment_type = $postdata['payment_type'];
    
    $gift = $postdata['gift_type'];
    if(isset($postdata['uptodate_email'])){
        $uptodate_email = $postdata['uptodate_email'] ;    
    }else{
        $uptodate_email = "" ;
    }
    $orderby_name = $postdata['orderby_name'];
    $orderby_contact = $postdata['orderby_contact'];
    $deliveryto_name = $postdata['deliveryto_name'];
    $deliveryto_contact = $postdata['deliveryto_contact'];
    
    //update del person name , contact
    $add_id = $get_usercurrent_address[0]->add_id;
    $update_deldtl['delto_name'] = $deliveryto_name;
    $update_deldtl['delto_contact'] = $deliveryto_contact;
    $this->db->update('address',$update_deldtl,array('id'=>$add_id));
    
    $status = 1;
    if(isset($postdata['payment_sts']) && $postdata['payment_sts']=="0")
    {// on online payment mode failed or cancelled
        return $data = array ('status'=>2,'message'=>'Order Cancelled/Failed');
        exit;
    }
    
    $dt = $this->db->query("SHOW TABLE STATUS LIKE 'orders'")->result();
    $id = $dt[0]->Auto_increment;
    $sequence_num = str_pad($id, 3, 0, STR_PAD_LEFT);
    $UTN_number = "YEL".$sequence_num;
    $result = $this->db->query("SELECT cart.product_id,cart.price,cart.mrp_price,cart.quantity,cart.varient_id,cart.item_id,prodtl.price_to_display,prodtl.item_totstock,prodtl.pack_content,prodtl.item_moq,cart_id,cart.store_id,prodtl.display_stock FROM cart INNER JOIN product pro ON cart.product_id = pro.prod_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid WHERE cart.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0,1) AND pro.prod_status = 1")->result();
    $count = count($result);

     $final_array =array();
     $total = 0; $items_in_cart =0; $total_mrp = 0;
    foreach ($result as $data)
    {
        $product_id  = $data->product_id;
        $total = $total + $data->price;
        $total_mrp = $total_mrp + $data->mrp_price;
        $items_in_cart = $items_in_cart + $data->quantity;
        $varient_id = $data->varient_id;
        $item_id = $data->item_id;
        $total_available_stock_final = 0; $moq_final = 0;
        $price_to_display = $data->price_to_display;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES')
        {
            $stockavailable =  $data->item_totstock;
            $stock_minus = $data->pack_content * $data->quantity;
        }else
        {
            $stockavailable =  $data->item_moq;
            $stock_minus = $data->pack_content * $data->item_moq;
        }
        $total_available_stock_final = $stockavailable - $stock_minus; 
        //minus stock in product table
        if(strtoupper($display_stock)=='YES')
        {
            if($total_available_stock_final!='' || $total_available_stock_final==0)
            { //allow 0 quantity  also  stock - order = 5-5 = 0
                $update_data5['item_totstock'] = $total_available_stock_final;
                $status = $this->db->update('product_itemdtl',$update_data5,array('prod_id'=>$product_id,'prod_itemid'=>$item_id));
            }
        }
          
        if($result)
        {
            $cart_id = $data->cart_id;
            $this->db->query("update cart set product_status = 2 where cart_id = $cart_id and user_id =$user_id");    
            $this->db->query("update cart set order_id = $id where user_id = $user_id and cart_id = $cart_id and order_id = 0");
        }
        else
        {
            return false;
        }
    
    }
    
    $payment_status = 0;
    if(isset($postdata['payment_sts']) && $postdata['payment_sts']=="1")
    {
        // on online payment mode success
            $payment_status = 1;
         if(isset($postdata['transaction_id'])){
             $transaction_id = $postdata['transaction_id'];
             $this->db->query("update orders set transaction_id = '$transaction_id' where UTN_number = '$UTN_number'");    
         }
          if(isset($postdata['transaction_amt'])){
             $transaction_amt = $postdata['transaction_amt'];
             $this->db->query("update orders set transaction_amt = $transaction_amt where UTN_number = '$UTN_number'");    
         }
    
    }
    if($result)
    {
        $insert_data  = array(
                'UTN_number'=>$UTN_number,
                'user_id'=>$user_id,
                'store_id'=>$data->store_id,
                'original_amt' =>$total_mrp,
                'tot_order_base_amt'=>$total,
                'total_amount'=>$total,
                'items_in_cart' => $items_in_cart,
                'payment_method'=>$payment_method,
                'payment_type'=>$payment_type,
                'payment_status'=>$payment_status,
                'booking_time'=>date('Y-m-d H:i:s'),
                'status'=>0,
                'address1' =>$get_usercurrent_address[0]->address1,
                'address2' =>$get_usercurrent_address[0]->address2,
                'landmark' =>$get_usercurrent_address[0]->landmark,
                'area' =>$get_usercurrent_address[0]->area_locality,
                'city' =>$get_usercurrent_address[0]->city_name,
                'district' =>$get_usercurrent_address[0]->district,
                'state' =>$get_usercurrent_address[0]->state,
                'pincode' =>$get_usercurrent_address[0]->pincode,
                'gps_coordinates' =>$get_usercurrent_address[0]->gps_coordinates,
                'address_name' =>$get_usercurrent_address[0]->address_name,
                'gift' =>$gift,
                'uptodate_email' =>$uptodate_email,
                'orderby_name' =>$orderby_name,
                'orderby_contact' =>$orderby_contact,
                'deliveryto_name' =>$deliveryto_name,
                'deliveryto_contact' =>$deliveryto_contact,
                'order_by'=>'Mobileapp'
            );
        // print_r($insert_data);
        // die;
        $this->db->insert('orders',$insert_data);
        //update discount
        $ttl_discount = 0;
        $total_discount = $this->db->query("SELECT SUM(price)billig_price,SUM(mrp_price)mrp_price FROM `cart` WHERE product_status = 2 and order_id = $id AND user_id = $user_id")->result();
        if($total_discount)
        {
            $ttl_discount = $total_discount[0]->mrp_price - $total_discount[0]->billig_price;
            $this->db->query("update orders set discount_amount = $ttl_discount where user_id = $user_id and order_id = $id");
        }
        
        //update packing charge & delivery Charge
        $store_id = $result[0]->store_id;
        $str = $this->db->query("select orders.district,orders.state,orders.items_in_cart,orders.total_amount,stores.store_id ,stores.packing_charges,stores.pc_type,pc_perc,pc_unit_value,delivery_charges,min_dc,delivery_note,dc_freekm,dc_perkm,orders.payment_method from stores inner join orders on stores.store_id = orders.store_id where stores.store_id = $store_id and UTN_number ='$UTN_number' ")->result();
        if($str)
        {
            $delivery_type = $str[0]->payment_method;
            $delivery_charges = $str[0]->delivery_charges;
            if($delivery_type==1 || $delivery_charges==0)//store pickup 
            {
                $est_delivery_charge = 0;
            }
            else { //home delivery
                $est_delivery_charge = $str[0]->min_dc;
            }
             if(strtoupper($str[0]->district)=="CHENNAI" && strtoupper($str[0]->state)=="TAMILNADU"){
                $est_delivery_charge = $est_delivery_charge; // FOr  inside chennai km depends delivery charge
            }else if(strtoupper($str[0]->district)!="CHENNAI" && strtoupper($str[0]->state)=="TAMILNADU"){ //outside chennai inside tamilnadu courier charge 75 rs.
                $est_delivery_charge = 75; 
            }else{ //outside tamilnadu courier charge 130.rs
                $est_delivery_charge = 130; 
            }
            $packing_charges = $str[0]->packing_charges;
            if($packing_charges ==0)
            { //disable // packing charge = 0
                $est_packing_charge = 0;
            } 
            else 
            { //packing charges enabled for this store
                $billing_price = $str[0]->total_amount;
                $items = $str[0]->items_in_cart;
                $pc_type = $str[0]->pc_type;
                $pc_perc = $str[0]->pc_perc;
                $pc_unit_value = $str[0]->pc_unit_value;
                if($pc_type==0)
                { //percwise
                    $est_packing_charge = round(($billing_price * ($pc_perc/100)),2);
                }else
                { //unitwise
                    $est_packing_charge =  round(($items * $pc_unit_value),2);
                }   
            }
            $total_amount = $str[0]->total_amount +  $est_packing_charge + $est_delivery_charge;
            //update packing charge & delivery Charge
           $this->db->query("update orders set customer_ordered_amt = $total_amount, packing_charge = $est_packing_charge ,delivery_charge = $est_delivery_charge,total_amount=$total_amount where user_id = $user_id and UTN_number = '$UTN_number'");  
        }
            ////
        
        $order = $this->db->query("select order_id,total_amount,store_id from orders where UTN_number = '$UTN_number'")->result();
        $order_id = $order[0]->order_id;
        $order_amount = $order[0]->total_amount;
        if(isset($postdata['coupon_code']) && $postdata['coupon_code']!="" && isset($postdata['coupon_discount']) && $postdata['coupon_discount']!=0 && $postdata['coupon_discount']!="")
        {
            $store_id = $order[0]->store_id;
            $coupon_code = $postdata['coupon_code'];
            $coupon_discount = $postdata['coupon_discount'];
            $get_couponid = $this->db->query("SELECT * FROM `yms_offercoupon` WHERE store_id = $store_id AND offer_code='$coupon_code'")->result();
            if($get_couponid)
            {
                   $coupon_id = $get_couponid[0]->id;
                   $current_dt = date("Y-m-d H:i");
                   $cpnvalidity_from = $get_couponid[0]->validity_from;
                   $cpnvalidity_to = $get_couponid[0]->validity_to;
                   if($current_dt >=$cpnvalidity_from && $current_dt<=$cpnvalidity_to)
                   {
                       $chk_coupon_usage = $this->db->query("select order_id from orders where user_id = $user_id and coupon_id =$coupon_id ")->result();
                       $usedcnt = count($chk_coupon_usage);
                       $coupon_cnt = $get_couponid[0]->offer_usage;
                        if($usedcnt<=$coupon_cnt)
                        {
                            $final = $order_amount-$coupon_discount;
                            if($final<0)
                            {
                                $final = 0;
                            }
                            $this->db->query("update orders set coupon_id = $coupon_id ,coupon_discount =$coupon_discount,total_amount=$final,customer_ordered_amt=$final where user_id = $user_id and UTN_number = '$UTN_number'");  
                        }
                   }
            }
        }
         //for BrownieStudio order accpeted on place_order by default // commented on 25-02-2022 order will accept by Seller app
        // $this->db->query("update orders set delivery_status = 1 where UTN_number = '$UTN_number'");    
    
        //send Order placed notification mail      
        $get_data = $this->db->query("SELECT ord.orderby_name,ord.orderby_contact,ord.uptodate_email,seller.email seller_email,seller.shopper_name seller_name,usr.email, usr.fullname,str.store_name,ord.UTN_number,ord.booking_time,ord.total_amount,ord.payment_method,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode FROM orders ord INNER JOIN stores str on ord.store_id = str.store_id INNER JOIN user_profile usr ON usr.user_id = ord.user_id INNER JOIN shopper seller on seller.store_id = str.store_id  WHERE ord.UTN_number ='$UTN_number'")->result();
         // ///////////////////////////////////////ORDER ACCEPTED/////////////////////////////
        if($get_data)
        {
            $seller_email = $get_data[0]->seller_email;
            $email = $get_data[0]->email;
            $cust_name = $get_data[0]->fullname;
            $seller_name = $get_data[0]->seller_name;
            $store_name = $get_data[0]->store_name;
            $dt_frmt=date_create($get_data[0]->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            $total = $get_data[0]->total_amount;
            $payment_method = $get_data[0]->payment_method; //1 for store pickup and 2 for home delivery
            if($payment_method==1)
            {
                $delivery_type ="Store pickup";
                $delivery_address = "-";
            }
            else
            {
                $delivery_type ="Home Delivery";
                $delivery_address = $get_data[0]->address1.', '.$get_data[0]->address2.', '.$get_data[0]->landmark.', '.$get_data[0]->area.', '.$get_data[0]->city.', '.$get_data[0]->district.', '.$get_data[0]->state.' - '.$get_data[0]->pincode;
            }
              // mail start
          ///////////////////////////////send Order placed notification mail to Customer
            $dt['item_dtl'] = $this->db->query("SELECT cart.preferred_del_date , cart.preferred_del_time , cart.varient_name,cart.product_name,cart.product_image,cart.product_desc,cart.quantity,cart.rate,cart.price,ord.packing_charge,ord.delivery_charge,ord.total_amount,ord.discount_amount,ord.coupon_discount FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$UTN_number'")->result();
            $dt['del_address'] = $this->db->query("SELECT ord.deliveryto_name , ord.deliveryto_contact, ord.address1,ord.address2,ord.landmark,ord.area,city,district,state,pincode,gps_coordinates,address_name FROM cart INNER JOIN orders ord ON cart.order_id = ord.order_id WHERE ord.UTN_number = '$UTN_number'")->result();
           //send Order placed notification mail to Customer
            if(trim($email)!='')
            {
            $sender_email = 'yellowmart17@gmail.com';
            $user_password = 'yellowmart123';
            $receiver_email = $email;
            $username = 'The Brownie Studio';
            $subject="Order Accepted";
            $dt['heading'] = "Order Accepted";
            $dt['message'] = 
            "Dear $cust_name, <br>

                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Greetings from <strong>  The Brownie Studio! ORDER ACCEPTED! </strong>,  Thanks for shopping with us. We are working on it now. Once it is ready to ship, we will send you another email with the tracking details. Questions? Suggestions? Insightful shower thoughts? Shoot us an email. <br><br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong style='font-size:17px;margin-left:130px'>  ORDER ID : ORDER#$UTN_number </strong>   <br><br>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Store Name : </strong> $store_name <br>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Order Date : </strong> $booking_time <br>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Status : </strong>  Order Accepted  <br>
                
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>  Delivery Type :  </strong>   $delivery_type <br>
            ";
            $message_html = $this->load->view('template/email_template3', $dt, TRUE);     
            // Configure email library
            $config['protocol'] = 'ssmtp';
            $config['smtp_host'] = 'ssl://ssmtp.gmail.com';
            $config['smtp_port'] = 465;
            $config['smtp_user'] = $sender_email;
            $config['smtp_pass'] = $user_password;
            // 
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            // 
            // Load email library and passing configured values to email library 
            $this->load->library('email', $config);
            // 
            $this->email->clear(); 
            // 
            $this->email->set_newline("\r\n");
            
            // 
             $this->email->set_mailtype("html");
            // 
            // Sender email address
            $this->email->from('yellowmart17@gmail.com', $username);
            // Receiver email address
            $this->email->to($receiver_email);
            // Subject of email
            $this->email->subject($subject);
            // Message in email
            $this->email->message($message_html);
            $this->email->send();
            }
              
              

            // mail end
            //////////////////////////Send Order Placed notification mail to seller
            // /////////////////////////////////PAYMENT CONFIRMATION///////////////////
             //send payment confirmation mail to customer
            if(trim($email)!='')
            {
                $to_receiver_email = $email;
                $from_email = 'yellowmart17@gmail.com';
                $from_emailpassword = 'yellowmart123';
                $from_username = 'The Brownie Studio';
                $subject="Payment Confirmation";
                $dt['heading'] = "Payment Confirmation";
                $dt['message'] = 
                "Dear $cust_name, <br>
                
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Thanks for the payment for your  <strong> ORDER ID : ORDER#$UTN_number </strong><br>
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Your order will be delivered shortly and you will receive the confirmation on the same.<br>
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  For any queries, you can reachout through <strong>thebrowniestudio@gmail.com</strong><br><br>

                ";
                 $message_html = $this->load->view('template/payment_template', $dt, TRUE);
                 $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message_html);
                 if($response['status']==0)
                 {
                     echo json_encode(array('status'=>0,'message'=>'Failed to send mail1 ')); exit;
                }
            }
                        
                if(trim($seller_email)!='')
                {
                    $to_receiver_email = $seller_email;
                    $from_email = 'yellowmart17@gmail.com';
                    $from_emailpassword = 'yellowmart123';
                    $from_username = 'The Brownie Studio';
                    $subject="Order ID : $UTN_number";
                    $message = 
                        "Dear $seller_name
                        
                        You have received a new order from $cust_name.
                        
                        Store Name : $store_name 
                        Order ID : $UTN_number
                        Order Date : $booking_time
                        Status : Order Placed
                        Total : $total
                        
                        Delivery Type: $delivery_type
                        Customer Address :
                        $delivery_address
                        
                        Thank You,
                        Team BrownieStudio,";
                     $response = $this->sendmail_notification($from_email,$from_emailpassword,$from_username,$to_receiver_email,$subject,$message);
                  
                }
        }
        // ///////////////////////////////////////ORDER ACCEPTED////////////////////////////// 
        //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        
        /////////////////////////send order placed push notification to seller
        $seller = $this->db->query("select id,token_key,str.store_name from shopper seller INNER JOIN stores str ON seller.store_id = str.store_id where str.store_id  =$store_id ")->result();
        if($seller)
        {
            $token_key = $seller[0]->token_key;
            $message ="ORDER#$UTN_number   $store_name - You have received a new order.";
            $title = "Order placed by the customer";
            $notify_type = "order_received";
            $user_id = $user_id;
            $seller_id = $seller[0]->id;
            $delivery_boyid = 0;
            $notified_person = "seller";
            if($token_key!='')
            {
                $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
            }
        }
        
        //////////////////////send order place thanku push notification to customer
        $customer = $this->db->query("SELECT user_id,token_key FROM user_profile WHERE user_id = $user_id ")->result();
        if($customer)
        {
            $token_key = $customer[0]->token_key;
            $store_name = $seller[0]->store_name; 
            $message ="Thank you for placing an order with $store_name! Your ORDER#$UTN_number $store_name";
            $title = "Thank you for placing an order";
            $notify_type = "order_placed";
            $user_id = $user_id;
            $seller_id = $seller[0]->id;
            $delivery_boyid = 0;
            $notified_person = "customer";
            if($token_key!='')
            {
                $this->send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person);
            }
        }
          
        return $data = array ('status'=>1,'message'=>'Order Placed','UTN_number'=>$UTN_number,'order_id'=>$order_id,'order_amount'=>$order_amount,'theme_color'=>"$theme_color",'font_color'=>$font_color,'menu'=>$lang_menu);
    }
    else
    {
        return false;
    }
}
    function chk_userstatus($user_id){
     //Check User Status //If not exists or inactive send status = 2 'which means user not available so logout'
        $chk_user = $this->db->query("select * from user_profile where user_id=$user_id and status=1")->result();
        if(empty($chk_user)){
        $result_res = array('status'=>2,'message'=>'User Not exists Please Try Again');
        return $result_res;
        }
     }
     //get store theme color and font color
    function gettheme($store_id="")   {
      $theme_color ='#64077b';$font_color='#FFFFFF';//default purple and white YM
    if($store_id!=''){
       $str_theme = $this->db->query("select theme_color,font_color from stores where store_id = $store_id")->result();
       if($str_theme){
            $theme_color = $str_theme[0]->theme_color;
            $font_color = $str_theme[0]->font_color;
            }
      }
        return $color = array ('theme_color'=>$theme_color,'font_color'=>$font_color);
  }
    function send_pushnotification($token_key,$message,$title,$notify_type,$user_id,$seller_id,$delivery_boyid,$notified_person){
    if($token_key!=''){
                    $data = array(
                    "action"=>1,    
                    "message"=> "$message",
                    "title"=>"$title"
                        );
                        if($notified_person=='seller'){
                    $sendNotification = seller_send_push_notification($token_key,$data);
                        }else if($notified_person=='customer'){
                    $sendNotification = send_push_notification($token_key,$data);
                        }else if($notified_person=='deliveryboy'){
                    $sendNotification = delivery_send_push_notification($token_key,$data);
                        }
                    $insert_data  = array(
                        'notify_type'=>"$notify_type",
                        "title"=>"$title",
                        'content'=>"$message",
                        'user_id'=>$user_id,
                        'seller_id'=>$seller_id,
                        'delivery_boyid' =>$delivery_boyid,
                        'notified_person' =>"$notified_person", 
                        'notify_date' => date('Y-m-d H:i:s'),
                        'read_status' => 0
                    );
                $this->db->insert('pushnotifications',$insert_data);
                }
}
    public function my_orders($postdata=array()){
    $user_id = $postdata['user_id'];
    //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
    $result = $this->db->query("SELECT coupon_discount,customer_ordered_amt,orders.delivery_charge,orders.packing_charge,orders.payment_method,orders.order_id,orders.UTN_number,orders.total_amount,orders.booking_time,stores.store_name,stores.store_image,stores.description,TIME_FORMAT(stores.starting_time,'%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end,'%h:%i %p')starting_end,pro.prod_id product_id,pro.prod_name product_name,pro.description as product_description,cart.type,cart.product_image,cart.varient_name,cart.quantity,cart.rate,orders.delivery_status,cart.product_status,orders.delivery_status_flg   FROM orders INNER JOIN user_profile user ON user.user_id =  orders.user_id INNER JOIN cart on cart.order_id = orders.order_id AND cart.user_id =user.user_id INNER JOIN stores on stores.store_id = orders.store_id and stores.store_id = cart.store_id INNER JOIN product pro on pro.prod_id = cart.product_id and pro.store_id = stores.store_id WHERE user.user_id = $user_id  GROUP By orders.order_id desc")->result();
    $final_array = array();
    foreach($result as $data){
        $order_id = $data->order_id;
        $customer_ordered_amt = $data->customer_ordered_amt;
        $updated_total = 0; $total = 0; $discount = 0;
        $itemwise_dtl = $this->db->query("select * from cart where order_id =$order_id ")->result();
        $store_id = $itemwise_dtl[0]->store_id;
        foreach($itemwise_dtl as $d){
            // if($d->product_status==1 || $d->product_status==2 ){
            if($d->product_status==1 || $d->product_status==2 ||  $d->product_status==3){
                $updated_total = $updated_total + $d->price;
            }
            $total = $total + $d->price;
        }
        
// 0- Awaiting Store Confirmation
// 1- Order Accepted
// 2- Delivered
// 3- Order Returned
// 4 - Order Packed  // Order Packed & ready to Pickup
// 5 - Order Picked
$delivery_status = $data->delivery_status;
$delivery_status_flg = $data->delivery_status_flg;
$order_method = $data->payment_method; //1 for store pickup and 2 for home delivery
           if($delivery_status==0 &&  $store_id ==1){ // for brownie studio on place order confirm mail send to customer so show status as 'Order Accepted'
                 $delivery_status_text = 'Order Accepted'; 
                 $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==0 &&  $store_id !=1){ 
                 $delivery_status_text = 'Awaiting Store Confirmation'; //Order Placed
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $delivery_status_text = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $delivery_status_text = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $delivery_status_text = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $delivery_status_text = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //purle
            }
            else if($delivery_status==4 && $order_method==2 ){ //home delivery
                $delivery_status_text = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            else if($delivery_status==4 && $order_method==1 ){ //store pickup
                $delivery_status_text = 'Order Packed  & ready to Pickup';
                $delivery_sts_clr = '#a52a2a'; //brown
            }else if($delivery_status==5 && $delivery_status_flg ==0){
                $delivery_status_text = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }else if($delivery_status==6){
                $delivery_status_text = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }else if($delivery_status==7){
                $delivery_status_text = 'Order Shipped';
                $delivery_sts_clr = '#800080'; //purple
            }
            else{
                $delivery_status_text = 'Order Placed';//Order Placed
                $delivery_sts_clr = '#000000'; //black
            }
            //order cancelled will be Red - #ff0000
            
            $dt_frmt=date_create($data->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            $up_total =round($updated_total+ $data->delivery_charge + $data->packing_charge - $data->coupon_discount,0);
            if($up_total<0){
                $up_total=0;
            }
        $final_array[] = array(
        'order_id' =>$data->order_id,
        'UTN_number' =>$data->UTN_number,
        'total_amount' =>round($customer_ordered_amt,0),
        'updated_total' =>$up_total,
        'booking_time' =>$booking_time,
        'store_name' =>$data->store_name,
        'store_image' =>$data->store_image,
        'description' =>$data->description,
        'starting_time' =>$data->starting_time,
        'starting_end' =>$data->starting_end,
        'product_id' =>$data->product_id,
        'product_name' =>$data->product_name,
        'product_description' =>$data->product_description,
        'type' =>$data->type,
        'product_image' =>$data->product_image,
        'varient_name' =>$data->varient_name,
        'quantity' =>$data->quantity,
        'rate' =>$data->rate,
        'delivery_status' =>$data->delivery_status,
        'delivery_status_text' =>$delivery_status_text,
        'delivery_sts_clr' =>$delivery_sts_clr
        );
        
    }
    if($final_array){
        
        return $data = array('status'=>1,'message'=>'My Orders','data'=>$final_array);
    }
    else{
        return false;
    }
}
    public function order_detail($postdata=array()){
    $user_id = $postdata['user_id'];
    //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
    $order_id = $postdata['order_id'];
    $result = $this->db->query("SELECT original_amt,ord.coupon_discount,ord.discount_amount,ord.customer_ordered_amt,ord.delivery_status_flg,ord.payment_method,ord.order_confirmation ,ord.utn_number,ord.booking_time,ord.items_in_cart,ord.payment_method,ord.payment_status,ord.delivery_status,ord.total_amount,ord.delivery_person_id,ord.store_id,ord.delivery_status_flg,delivery_charge,packing_charge,ord.address1,ord.address2,ord.landmark,ord.area,ord.city,ord.district,ord.state,ord.pincode,ord.track_id FROM orders ord WHERE ord.utn_number = '$order_id'")->result();
    $total_selected_items = 0;
    $final_array = array();
    $item_array = array();
    $item_sellerorder_array = array();
    $store_name = '';
    if($result){
        $store_id = $result[0]->store_id;
        $discount_text =''; $coupon_discount = round($result[0]->coupon_discount,0);
            if($result[0]->discount_amount > 0 || $result[0]->coupon_discount>0 ){
                // $final_discount = $result[0]->discount_amount + $result[0]->coupon_discount;
                $overall_dis = round($result[0]->original_amt - $result[0]->total_amount,0);
            $discount_text = 'You have saved Rs.'.$coupon_discount.' on this order.';
            }
        $updated_total = 0;$total = 0;
        $result_item = $this->db->query("SELECT pro.subcat_id,message_on_cake,preferred_del_date,slot.time_slot_view, preferred_del_time,notes_on_chef,cart.item_id,updatedprice,cart.range_pricing,cart.display_type,prodtl.display_name,stores.store_name,pro.prod_name product_name,cart.quantity,cart.product_image,cart.varient_id,cart.varient_name,cart.rate,cart.price,cart.product_status,stores.store_delivery_type FROM orders ord INNER JOIN cart on ord.order_id = cart.order_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product pro on cart.product_id = pro.prod_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid INNER JOIN delivery_slot slot ON slot.time_slot = cart.preferred_del_time WHERE ord.utn_number = '$order_id' and cart.product_addby_seller =0")->result();
        foreach($result_item as $item){
           if($item->preferred_del_date=='0000-00-00'){
                $preferred_del_date = "";
            }else{
                $dt_frmt=date_create($item->preferred_del_date);
                $preferred_del_date =  date_format($dt_frmt,"d/m/Y");
            }
        
            $product_status = $item->product_status; 
            if($product_status!=0){
                $total_selected_items = $total_selected_items + $item->quantity;
                
            }
                $display_name_final =$item->display_name; 
                $delivery_status = $result[0]->delivery_status;
                if(($delivery_status==0) && ($item->display_type==4) && ($item->updatedprice==0)){ //price range  //take $delivery_status = 0  place order  if once order accepted take price column  //updatedprice = 0 show range price 
                    $itemprice = $item->range_pricing;
                }else{
                    $itemprice = $item->price;
                }
        $varient_cnt = 0;
        $getcnt = explode(";",$item->varient_name); //masala;egg;corainder
        $varient_cnt = count($getcnt);//3
        
        $item_array[]=array(
            'product_name' =>$display_name_final,
            'product_nameold' =>$item->product_name,
            'product_image' =>$item->product_image,
            'varient_id' =>$item->varient_id,
            'item_id' =>$item->item_id,
            'varient_name' =>$item->varient_name,
            'varient_cnt'=>$varient_cnt,
            'quantity' =>$item->quantity,
            'rate' =>$item->rate,
            'price' =>$itemprice,
            'product_status'=>$item->product_status,
            'message_on_cake'=>$item->message_on_cake,
            'preferred_del_date'=>$preferred_del_date,
            'preferred_del_time'=>$item->preferred_del_time,
            'time_slot_view' =>$item->time_slot_view,
            'notes_on_chef'=>$item->notes_on_chef,
            'subcat_id'=>$item->subcat_id
            );
            $store_name = $item->store_name;
            // if($item->product_status==1 || $item->product_status==2 ){
            if($item->product_status==1 || $item->product_status==2 || $item->product_status==3 ){
                $updated_total = $updated_total + $item->price;
            }
            $total = $total + $item->price;
            
        }
        $str_delivery_type = 1;$delivery_person_name =''; $delivery_person_number =''; 
        //order added by seller
         $result_item2 = $this->db->query("SELECT pro.subcat_id,message_on_cake,preferred_del_date,slot.time_slot_view,preferred_del_time,notes_on_chef,cart.item_id,updatedprice,cart.range_pricing,cart.display_type,prodtl.display_name,stores.store_name,pro.prod_name product_name,cart.quantity,cart.product_image,cart.varient_id,cart.varient_name,cart.rate,cart.price,cart.product_status,stores.store_delivery_type FROM orders ord INNER JOIN cart on ord.order_id = cart.order_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product pro on cart.product_id = pro.prod_id INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id AND cart.item_id = prodtl.prod_itemid INNER JOIN delivery_slot slot ON slot.time_slot = cart.preferred_del_time WHERE ord.utn_number = '$order_id' and cart.product_addby_seller =1")->result();
         if($result_item2){
        foreach($result_item2 as $item){
            if($item->preferred_del_date=='0000-00-00'){
                $preferred_del_date = "";
            }else{
                $dt_frmt=date_create($item->preferred_del_date);
                $preferred_del_date =  date_format($dt_frmt,"d/m/Y");
            }
            $product_status = $item->product_status; 
            if($product_status!=0){ //selected item 
                $total_selected_items = $total_selected_items + $item->quantity;
            }
            $display_name_final = $item->display_name;
                $delivery_status = $result[0]->delivery_status;
                if(($delivery_status==0) && ($item->display_type==4) && ($item->updatedprice==0)){ //price range  //take $delivery_status = 0  place order  if once order accepted take price column  //updatedprice = 0 show range price 
                    $itemprice = $item->range_pricing;
                }else{
                    $itemprice = $item->price;
                }
        $varient_cnt = 0;
        $getcnt = explode(";",$item->varient_name); //masala;egg;corainder
        $varient_cnt = count($getcnt);//3
        
        $item_sellerorder_array[]=array(
            'product_name' =>$display_name_final,
            'product_image' =>$item->product_image,
            'varient_id' =>$item->varient_id,
            'item_id' =>$item->item_id,
            'varient_name' =>$item->varient_name,
            'varient_cnt'=>$varient_cnt,
            'quantity' =>$item->quantity,
            'rate' =>$item->rate,
            'price' =>$itemprice,
            'product_status'=>$item->product_status,
            'message_on_cake'=>$item->message_on_cake,
            'preferred_del_date'=>$preferred_del_date,
            'preferred_del_time'=>$item->preferred_del_time,
            'time_slot_view'=>$item->time_slot_view,
            'notes_on_chef'=>$item->notes_on_chef,
            'subcat_id'=>$item->subcat_id
            );
            $store_name = $item->store_name;
            if($item->product_status==1 || $item->product_status==2  || $item->product_status==3 ){
                $updated_total = $updated_total + $item->price;
            }
            $total = $total + $item->price;
            
        }
        // print_r($updated_total);die;
        $delivery_person_name =''; $delivery_person_number =''; 
        $str_delivery_type = $result_item2[0]->store_delivery_type;
        if($str_delivery_type==3){
            $str_delivery_type=2;
        }
         }
        if( $result[0]->payment_method==2 && $str_delivery_type==2){
            $p_id = $result[0]->delivery_person_id;
            $del_data = $this->db->query("select * from delivery_persondtl where store_id = $store_id and deli_boy_id = $p_id")->result();
            if($del_data){
                $delivery_person_name = $del_data[0]->deli_name;
                $delivery_person_number = $del_data[0]->deli_phone;
            }
        }
        // 0- Awaiting Store Confirmation
// 1- Order Accepted
// 2- Delivered
// 3- Order Returned
// 4 - Order Packed  // Order Packed & ready to Pickup
// 5 - Order Picked
$delivery_status = $result[0]->delivery_status;
$delivery_status_flg = $result[0]->delivery_status_flg;
$order_method = $result[0]->payment_method; //1 for store pickup and 2 for home delivery
        if($delivery_status==0 &&  $store_id ==1){ // for brownie studio on place order confirm mail send to customer so show status as 'Order Accepted'
                 $delivery_status_text = 'Order Accepted'; 
                 $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==0 &&  $store_id !=1){ 
                 $delivery_status_text = 'Awaiting Store Confirmation'; //Order Placed
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $delivery_status_text = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $delivery_status_text = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $delivery_status_text = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $delivery_status_text = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //green
            }
            else if($delivery_status==4 && $order_method==2 ){ //home delivery
                $delivery_status_text = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            else if($delivery_status==4 && $order_method==1 ){ //store pickup
                $delivery_status_text = 'Order Packed  & ready to Pickup';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            // else if($delivery_status==5 ){
            //     $delivery_status_text = 'Order Picked';
            //     $delivery_sts_clr = '#800080'; //purle
            // }
          else if($delivery_status==5 && $delivery_status_flg ==0){
                $delivery_status_text = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }else if($delivery_status==6){
                $delivery_status_text = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }else if($delivery_status==7){
                $delivery_status_text = 'Order Shipped';
                $delivery_sts_clr = '#800080'; //purple
            }
            else{
                $delivery_status_text = 'Order Placed';//Order Placed
                $delivery_sts_clr = '#000000'; //black
            }
            //order cancelled will be Red - #ff0000

       $delivery_status_flg = $result[0]->delivery_status_flg;
        $delivery_status_update = 1;//hide
        if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg==1 )
        {
         $delivery_status_update =0; //show
         }
$payment_method = $result[0]->payment_method;
$delivery_charge_enable = 0; $delivery_address='';
if($payment_method==2){ //home pickup
    $delivery_charge_enable = 1; //enable delivery charge only for Home delivery
    $delivery_address = $result[0]->address1.', '.$result[0]->address2.', '.$result[0]->landmark.', '.$result[0]->area.', '.$result[0]->city.', '.$result[0]->district.', '.$result[0]->state.' - '.$result[0]->pincode;
}
if($result[0]->delivery_charge==0){
    $delivery_charge_enable = 0;
}
$dt_frmt = date_create($result[0]->booking_time);
$booking_time = date_format($dt_frmt,'d/m/Y  h:i A');
$up_total = round($updated_total + $result[0]->delivery_charge +  $result[0]->packing_charge - $result[0]->coupon_discount,0);
if($up_total<0){
    $up_total=0;
}
if($result[0]->track_id!=""){
    $track_id = $result[0]->track_id;
}else{
    $track_id ="NA";    
}

    $final_array = array(
        'store_name'=>$store_name,
        'order_id' =>$result[0]->utn_number,
        'order_confirmation'=>$result[0]->order_confirmation,
        'order_placedon' =>$booking_time,
        'ordered_items' =>$total_selected_items,
        'payment_method' =>$result[0]->payment_method,
        'payment_status' =>$result[0]->payment_status,
        'delivery_status' =>$result[0]->delivery_status,
        'delivery_status_text' =>$delivery_status_text,
        'delivery_sts_clr' =>$delivery_sts_clr,
        'delivery_person_name' =>$delivery_person_name,
        'delivery_person_number'=>$delivery_person_number,
        'delivery_status_flg' =>$result[0]->delivery_status_flg,
        'total' =>round($result[0]->customer_ordered_amt,0),
        'updated_total'=>$up_total,
        'coupon_discount' => round($coupon_discount,0),
        'discount_text' => $discount_text, 
        'itemswise_details'=>$item_array,
        'item_addbyseller' =>$item_sellerorder_array,
        'delivery_status_update' =>$delivery_status_update,
        'delivery_charge_enable' =>$delivery_charge_enable,
        'delivery_charge' => round($result[0]->delivery_charge,0),
        'packing_charge' => round($result[0]->packing_charge,0),
        'delivery_address' => $delivery_address,
        'track_id' => $track_id
        );
    }

    if($result){
        return $data = array('status'=>1,'message'=>'Order Details','data'=>$final_array);
    }
    else{
        return false;
    }
}
    public function store_orders($postdata=array()){
    $user_id = $postdata['user_id'];
    $store_id = $postdata['store_id'];
    //check User status 
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }
    //$result = $this->db->query("SELECT coupon_discount,customer_ordered_amt,orders.delivery_charge,orders.packing_charge,orders.payment_method,orders.order_id,orders.UTN_number,orders.total_amount,orders.booking_time,stores.store_name,stores.store_image,stores.description,TIME_FORMAT(stores.starting_time,'%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end,'%h:%i %p')starting_end,pro.prod_id product_id,pro.prod_name product_name,pro.description as product_description,cart.type,cart.product_image,cart.varient_name,cart.quantity,cart.rate,orders.delivery_status,cart.product_status,orders.delivery_status_flg   FROM orders INNER JOIN user_profile user ON user.user_id =  orders.user_id INNER JOIN cart on cart.order_id = orders.order_id AND cart.user_id =user.user_id INNER JOIN stores on stores.store_id = orders.store_id and stores.store_id = cart.store_id INNER JOIN product pro on pro.prod_id = cart.product_id and pro.store_id = stores.store_id WHERE user.user_id = $user_id and stores.store_id = $store_id GROUP By orders.order_id desc")->result();
    $result = $this->db->query("SELECT coupon_discount,customer_ordered_amt,orders.delivery_charge,orders.packing_charge,orders.payment_method,orders.order_id,orders.UTN_number,orders.total_amount,orders.booking_time,stores.store_name,stores.store_image,stores.description,TIME_FORMAT(stores.starting_time,'%h:%i %p')starting_time,TIME_FORMAT(stores.starting_end,'%h:%i %p')starting_end,pro.prod_id product_id,pro.prod_name product_name,pro.description as product_description,cart.type,cart.product_image,cart.varient_name,cart.quantity,cart.rate,orders.delivery_status,cart.product_status,orders.delivery_status_flg   FROM orders INNER JOIN user_profile user ON user.user_id =  orders.user_id INNER JOIN cart on cart.order_id = orders.order_id AND cart.user_id =user.user_id INNER JOIN stores on stores.store_id = orders.store_id and stores.store_id = cart.store_id INNER JOIN product pro on pro.prod_id = cart.product_id and pro.store_id = stores.store_id WHERE user.user_id = $user_id and stores.store_id = $store_id Order By orders.order_id desc")->result();
    $final_array = array();
    foreach($result as $data){
        $order_id = $data->order_id;
        $customer_ordered_amt = $data->customer_ordered_amt;
        $updated_total = 0; $total = 0; $discount = 0;
        $itemwise_dtl = $this->db->query("select * from cart where order_id =$order_id ")->result();
        foreach($itemwise_dtl as $d){
            // if($d->product_status==1 || $d->product_status==2 ){
            if($d->product_status==1 || $d->product_status==2 ||  $d->product_status==3){
                $updated_total = $updated_total + $d->price;
            }
            $total = $total + $d->price;
        }
        
// 0- Awaiting Store Confirmation
// 1- Order Accepted
// 2- Delivered
// 3- Order Returned
// 4 - Order Packed  // Order Packed & ready to Pickup
// 5 - Order Picked
$delivery_status = $data->delivery_status;
$delivery_status_flg = $data->delivery_status_flg;
$order_method = $data->payment_method; //1 for store pickup and 2 for home delivery
            if($delivery_status==0 &&  $store_id ==1){ // for brownie studio on place order confirm mail send to customer so show status as 'Order Accepted'
                 $delivery_status_text = 'Order Accepted'; 
                 $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==0 &&  $store_id !=1){ 
                 $delivery_status_text = 'Awaiting Store Confirmation'; //Order Placed
                 $delivery_sts_clr = '#000000'; //black
            }
            else if($delivery_status==1){
                $delivery_status_text = 'Order Accepted';
                $delivery_sts_clr = '#0000ff'; //blue
            }else if($delivery_status==2){
                $delivery_status_text = 'Delivered';
                $delivery_sts_clr = '#008000'; //green
            }else if($delivery_status==3){
                $delivery_status_text = 'Order Returned';
                $delivery_sts_clr = '#ffa500'; //orange
            }
            else if(($delivery_status==4 || $delivery_status==5) && $delivery_status_flg ==1 ){
                $delivery_status_text = 'Delivered'; //delivered by delivery boy or updated by seller admin //customer not updated 
                $delivery_sts_clr = '#008000'; //purle
            }
            else if($delivery_status==4 && $order_method==2 ){ //home delivery
                $delivery_status_text = 'Order Packed';
                $delivery_sts_clr = '#a52a2a'; //brown
            }
            else if($delivery_status==4 && $order_method==1 ){ //store pickup
                $delivery_status_text = 'Order Packed  & ready to Pickup';
                $delivery_sts_clr = '#a52a2a'; //brown
            }else if($delivery_status==5 && $delivery_status_flg ==0){
                $delivery_status_text = 'Order Picked';
                $delivery_sts_clr = '#800080'; //purle
            }else if($delivery_status==6){
                $delivery_status_text = 'Order Cancelled';
                $delivery_sts_clr = '#ff0000'; //red
            }else if($delivery_status==7){
                $delivery_status_text = 'Order Shipped';
                $delivery_sts_clr = '#800080'; //purle
            }
            else{
                
                $delivery_status_text = 'Order Placed';//Order Placed
                $delivery_sts_clr = '#000000'; //black
            }
            //order cancelled will be Red - #ff0000
            
            $dt_frmt=date_create($data->booking_time);
            $booking_time =  date_format($dt_frmt,"d/m/Y  h:i A");
            $up_total =round($updated_total+ $data->delivery_charge + $data->packing_charge - $data->coupon_discount,0);
            if($up_total<0){
                $up_total=0;
            }
        $final_array[] = array(
        'order_id' =>$data->order_id,
        'UTN_number' =>$data->UTN_number,
        'total_amount' => round($customer_ordered_amt,0),
        'updated_total' =>$up_total,
        'booking_time' =>$booking_time,
        'store_name' =>$data->store_name,
        'store_image' =>$data->store_image,
        'description' =>$data->description,
        'starting_time' =>$data->starting_time,
        'starting_end' =>$data->starting_end,
        'product_id' =>$data->product_id,
        'product_name' =>$data->product_name,
        'product_description' =>$data->product_description,
        'type' =>$data->type,
        'product_image' =>$data->product_image,
        'varient_name' =>$data->varient_name,
        'quantity' =>$data->quantity,
        'rate' =>$data->rate,
        'delivery_status' =>$data->delivery_status,
        'delivery_status_text' =>$delivery_status_text,
        'delivery_sts_clr' =>$delivery_sts_clr
        );
        
    }
    if($final_array){
        
        return $data = array('status'=>1,'message'=>'Store Orders','data'=>$final_array);
    }
    else{
        return false;
    }
}
    function finditem_id($store_id,$product_id,$chkcolor_value,$chksize_value)
    {
        // $get_itemdtl = $this->db->query("select * from product pro inner join product_itemdtl prodtl on pro.prod_id=prodtl.prod_id where pro.prod_id=$product_id and pro.store_id=$store_id")->result();
        $proddtl = $this->db->query("SELECT pri_att,pro.prod_name,pro.store_id,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,prod_img2,prod_img3,prod_img4,prod_img5,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.store_id,str.store_name,TIME_FORMAT(str.starting_time, '%h:%i %p')starting_time,TIME_FORMAT(str.starting_end, '%h:%i %p')starting_end,cat.category_id as cat_id,cat.category_name,brand.brand_name,prodtl.item_images,prodtl.pri_attcolor,pro.description from product pro INNER JOIN product_itemdtl prodtl on pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND pro.prod_id = $product_id")->result();
        if($proddtl){
            foreach($proddtl as $dt){
                     $type = $dt->type;
                     $add_variant = $dt->add_variant;
                     $sale_unit = $dt->sale_unit;
                     $stock_unit = $dt->stock_unit;
                     $pack_content = $dt->pack_content;
                     if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                         $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                            if($unit_dt){
                                $slunit_name =$unit_dt[0]->unit;
                            }
                            $variant_name = $pack_content.' '.$slunit_name;
                            $variant_cnt = 1;
                            $color_value = $dt->pri_attcolor;
                            $size_value = trim($variant_name);
                         
                     }else{
                         //Attribute1 //variant2
                            $primary_attibuteid = $dt->pri_att;
                             $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                             
                             //Attribute1 //variant2
                             $att1_id = $dt->att1;
                             $variant1 = $dt->var1;
                             $att2_id = $dt->att2;
                             $variant2 = $dt->var2;
                             $att3_id = $dt->att3;
                             $variant3 = $dt->var3;
                             
                             $variant_name = $variant1.';'.$variant2.';'.$variant3;
                             $variant_name = rtrim($variant_name, ";");
                             $color_value = $dt->pri_attcolor;
                             $size_value = trim($variant_name);
                             if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                                  $color_n = $variant2.';'.$variant3; 
                                  $color_n = rtrim($color_n, ";");
                                  $size_value = trim($color_n);
                             }
                     }
                     if($chkcolor_value==$color_value &&  $chksize_value == $size_value){
                         $item_id = $dt->prod_itemid;
                         return $data = array('status'=>1,'item_id'=>$item_id);
                     }
                     
                         }
            return $data = array('status'=>0);
        }
        return $data = array('status'=>0);
                     
    }

    public function prod_filter($postdata=array()){
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        //input data
         $user_id =$postdata['user_id']; $store_id =$postdata['store_id']; $category_id =$postdata['category_id']; $subcategory_id =$postdata['subcategory_id'];
         $final_array =array(); 
         
        //check User status 
        if($user_id!=0){
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }}
        //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        $att_array =array();
        $pro_filt = $this->db->query("SELECT ptype.type_name,pro.add_variant,slunit.unit,prodtl.pack_content, att1.attribute_name att1 ,att2.attribute_name att2 ,att3.attribute_name att3,var1,var2,var3 FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id INNER JOIN packettype_master ptype ON ptype.id = pro.packtype_id INNER JOIN product_units slunit ON prodtl.sale_unit = slunit.id left join attributes att1 ON prodtl.att1 = att1.id left join attributes att2 ON prodtl.att2 = att2.id left join attributes att3 ON prodtl.att3 = att3.id WHERE pro.store_id = $store_id ORDER BY pro.prod_id")->result();
        // echo '<pre>';
        // print_r($pro_filt);
        // die;
        if($pro_filt){
            foreach($pro_filt as $pro){
                if(strtoupper($pro->type_name)=="LOOSE" || strtoupper($pro->add_variant=="NO")){
                                    if (!in_array('Size',$att_array)){
                                        $att_array[] = 'Size'; //default size
                                    }
                }else{
                    // if($pro->att1=='COLOR' || $pro->att1=="COLOUR"){
  
                    if($pro->att1!=""){
                                if (!in_array($pro->att1,$att_array)){
                                    $att_array[] = $pro->att1; 
                                }
                     }
                    if($pro->att2!=""){
                           if (!in_array($pro->att2,$att_array)){
                                    $att_array[] = $pro->att2; 
                                } 
                    }
                    if($pro->att3!=""){
                       if (!in_array($pro->att3,$att_array)){
                                    $att_array[] = $pro->att3; 
                                }
                    }
                }
            }
        }
        $filter_value1 =array(); $filter_value2 =array(); $filter_value3 =array();
        if(!empty($att_array)){
            $id =1;
            // echo '<pre>';
            // print_r($att_array);
            // die;
            
            foreach($att_array as $att){
                // ${"filter_value" . $id} = array(); //dynamice variable
                $pro_filt2 = $this->db->query("SELECT DISTINCT ptype.type_name,pro.add_variant,slunit.unit,prodtl.pack_content, att1.attribute_name att1 ,att2.attribute_name att2 ,att3.attribute_name att3,var1,var2,var3 FROM product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id INNER JOIN packettype_master ptype ON ptype.id = pro.packtype_id INNER JOIN product_units slunit ON prodtl.sale_unit = slunit.id left join attributes att1 ON prodtl.att1 = att1.id left join attributes att2 ON prodtl.att2 = att2.id left join attributes att3 ON prodtl.att3 = att3.id WHERE pro.store_id = $store_id ORDER BY pro.prod_id")->result();
                if($pro_filt2){
                foreach($pro_filt2 as $pro2){
                    if(strtoupper($pro2->type_name)=="LOOSE" || strtoupper($pro2->add_variant=="NO")){
                        if(strtoupper($att)=="SIZE"){
                            if (!in_array($pro2->pack_content.' '.$pro2->unit,$filter_value1)){
                            $filter_value1[] = $pro2->pack_content.' '.$pro2->unit;    
                            }
                        }
                        
                    }else{
                        // if(strtoupper($pro2->att1)==strtoupper($att))
                        //          if($pro2->var1!=""){
                        //          if (!in_array($pro2->var1,$filter_value1)){
                        //                 $filter_value1[] = $pro2->var1; 
                        //             }
                        // }
                        // if(strtoupper($pro2->att2)==strtoupper($att))
                        //          if($pro2->var2!=""){
                        //          if (!in_array($pro2->var2,$filter_value2)){
                        //                 $filter_value2[] = $pro2->var2; 
                        //             }
                        // }
                        //  if(strtoupper($pro2->att3)==strtoupper($att))
                        //          if($pro2->var3!=""){
                        //          if (!in_array($pro2->var3,$filter_value3)){
                        //                 $filter_value3[] = $pro2->var3; 
                        //             }
                        // }
                          if(strtoupper($pro2->att1)==strtoupper($att))
                                 if($pro2->var1!=""){
                                 if (!in_array($pro2->var1,${"filter_value" . $id})){
                                        ${"filter_value" . $id}[] = $pro2->var1; 
                                    }
                        }
                        if(strtoupper($pro2->att2)==strtoupper($att))
                                 if($pro2->var2!=""){
                                 if (!in_array($pro2->var2,${"filter_value" . $id})){
                                        ${"filter_value" . $id}[] = $pro2->var2; 
                                    }
                        }
                         if(strtoupper($pro2->att3)==strtoupper($att))
                                 if($pro2->var3!=""){
                                 if (!in_array($pro2->var3,${"filter_value" . $id})){
                                        ${"filter_value" . $id}[] = $pro2->var3; 
                                    }
                        }
                    }
                }
                }
                $id++;
        }
        // echo '<pre>';
        // print_r($filter_value1);
        // die;
         //align size into another array .// m,xl,s,xs,xxl into xs,s,m,l,xxl
        $filter1 = array(); $filter2 = array(); $filter3 = array();
        $variants = $this->db->query("select * from varients where store_id = $store_id order by filter_orderby")->result();
        foreach($variants as $orderby_var){
            $orderwise_variant_name = $orderby_var->varient_name;
            foreach($filter_value1 as $cur_var){
                if(strtoupper(trim($cur_var)) ==strtoupper(trim($orderwise_variant_name))){
                    if (!in_array($cur_var,$filter1)){
                    $filter1[]  = $cur_var;
                    }
                }}
                foreach($filter_value2 as $cur_var){
                if(strtoupper(trim($cur_var)) ==strtoupper(trim($orderwise_variant_name))){
                    if (!in_array($cur_var,$filter2)){
                    $filter2[]  = $cur_var;
                    }
                }}
                foreach($filter_value3 as $cur_var){
                if(strtoupper(trim($cur_var)) ==strtoupper(trim($orderwise_variant_name))){
                    if (!in_array($cur_var,$filter3)){
                    $filter3[]  = $cur_var;
                    }
                }}
        }
        ////
          //the below commented code is correct (but for Android dev need response without array i put static code)(which is not crct way)
            // $filter_final[] = array(
            //   $att =>${"filter_value" . $id}
            //   );
        if(count($att_array)==1){ //only 1 attribute
            $filter_final = array(
              $att_array[0] =>$filter1
              );
        }
         if(count($att_array)==2){ //2 attribute
            $filter_final = array(
              $att_array[0] =>$filter1,
              $att_array[1] =>$filter2
              );
        }
         if(count($att_array)==3){ //3 attribute
            $filter_final = array(
              $att_array[0] =>$filter1,
              $att_array[1] =>$filter2,
              $att_array[2] =>$filter3
              );
        }
            
        }

         return $result = array('status'=>1,'message'=>'Product Filter', 'filter'=>$filter_final); 
         
    }
    // Product list API
    public function product_list($postdata=array()){
        if(!isset($postdata['store_id']) || empty($postdata['store_id'])){
            return false;
        }
        //input data
         $user_id =$postdata['user_id']; $store_id =$postdata['store_id']; $category_id =$postdata['category_id']; $subcategory_id =$postdata['subcategory_id'];
         $final_array =array();
        //check User status 
        if($user_id!=0){
        $result_status = $this->chk_userstatus($user_id);
        if(!empty($result_status)){
            return $result_status; 
        }}
        //get store theme and font color
        $get_theme = $this->gettheme($store_id);
        $theme_color = $get_theme['theme_color'];
        $font_color = $get_theme['font_color'];
        
        //Filter section start here 
         //filter data - seperate attributes and variants
         $filter_attributes_name = array(); /// color or size or flavour
         $filter_variants_name =array(); /// blue or red or S or M or Pepper ord chilli
         $att_ids = "";
         $var_names = "";
         $filter_data="";
         //[\"Size:4-5 Years| 6-7 Years| 8-9 Years| XL| M| S\",\"Color:Blue| Red\"] // actual input from app
         //this filter worked for variant product for loose have to work
         if(isset($postdata['filter_data']) && $postdata['filter_data']!="" && $postdata['filter_data']!="0"){    //["Size:4-5 Years| 6-7 Years| 8-9 Years| XL| M| S","Color:Blue| Red"]
         $fildata = $postdata['filter_data'];
         //remove [ ] "   and convert to array
         $fildata_fi = str_replace("[","",$fildata);   //"Size:4-5 Years| 6-7 Years| 8-9 Years| XL| M| S","Color:Blue| Red"]
         $fildata_fi = str_replace("]","",$fildata_fi);  //"Size:4-5 Years| 6-7 Years| 8-9 Years| XL| M| S","Color:Blue| Red"
         $fildata_fi = str_replace('"',"",$fildata_fi); //Size:4-5 Years| 6-7 Years| 8-9 Years| XL| M| S,Color:Blue| Red
         $filter_data = explode(",",$fildata_fi);  // string to array
         //print_r($filter_data);
         //die;

             foreach($filter_data as $fil){
                 $att_var = explode(":",$fil);    //color:Red| Blue
                 //get attribute id in array
                 $att_name = trim($att_var[0]); //color
                 $get_att_ids = $this->db->query("SELECT * FROM attributes WHERE attribute_name = '$att_name'")->result();
                 if($get_att_ids){
                     $filter_attributes_name[] = $get_att_ids[0]->id;
                 }
                 //get variant name in array
                 $tot_variants = $att_var[1]; //Red| Blue
                 $variants_array = explode("|",$tot_variants);
                 foreach($variants_array as $var){
                    $filter_variants_name[] = trim($var);
                 }
                 
                 }
                 $att_ids = implode(",",$filter_attributes_name); // array to string 1,2,6,7
                 $var_names = implode("|",$filter_variants_name);// array to string S|M|Red|Blue
         
         }
          //echo '<pre>';
          //print_r($att_ids);
          //echo '<pre>';
          //print_r($var_names);
          //die;
        //Filter section end here
        
        //Sorting starte here  (YOU CAN SORT AFTER ADD TO ARRAY)
        $order_by = 'order by pro.prod_id,prodtl.prod_itemid ASC'; // default
        if(isset($postdata['sort_type']) && $postdata['sort_type']!="" && $postdata['sort_type']!=0){
            $sort_type = $postdata['sort_type'];
            if($sort_type==1){ //Popular
                $order_by = 'order by pro.prod_id ASC';
            }else if($sort_type==2) { //New
                $order_by = 'order by pro.prod_id DESC';
            }else if($sort_type==3) { //high to low
                $order_by = 'order by price_orderby DESC';
            }else if($sort_type==4){ //low to high
                $order_by = 'order by price_orderby ASC';
            }
        }//sorting condition end here

        //product list page category
         $selected_cat = $this->db->query("select subcategory_name category_name,maincategory_id,category_id ,subcat_id subcategory_id from sub_category where subcat_id in (select DISTINCT subcat_id from product where store_id = $store_id and status = 1 ) and subcat_id =$subcategory_id AND category_id = $category_id order by category_name")->result();
         $remaining_cat = $this->db->query("select subcategory_name category_name,maincategory_id,category_id ,subcat_id subcategory_id from sub_category where subcat_id in (select DISTINCT subcat_id from product where store_id = $store_id and status =1 ) and subcat_id !=$subcategory_id AND category_id = $category_id order by category_name")->result();
         $catwise = array_merge($selected_cat,$remaining_cat);
         if(empty($catwise)){
             return false;
         }
         
         //category wise loop start here
          foreach($catwise as $ct){
            $data =array();
            $cat_id = $ct->category_id;
            $subcat_id = $ct->subcategory_id;
            if($att_ids!="" && $var_names!="" ){
              $prod_qry = $this->db->query("SELECT CASE WHEN prodtl.price_to_display =1 THEN prodtl.mrp_price ELSE CASE WHEN prodtl.price_to_display =2 THEN prodtl.mop_price ELSE CASE WHEN prodtl.price_to_display =3 THEN prodtl.offer_price ELSE CASE WHEN prodtl.price_to_display =4 THEN prodtl.mop_price END END END END as price_orderby,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.pri_att,image_type,item_images  from product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND pro.cat_id = $cat_id AND pro.subcat_id = $subcat_id and pro.prod_status = 1 AND (att1 IN ($att_ids) || att2 IN ($att_ids) || att3 IN ($att_ids))  $order_by")->result();    
            }else {
            $prod_qry = $this->db->query("SELECT CASE WHEN prodtl.price_to_display =1 THEN prodtl.mrp_price ELSE CASE WHEN prodtl.price_to_display =2 THEN prodtl.mop_price ELSE CASE WHEN prodtl.price_to_display =3 THEN prodtl.offer_price ELSE CASE WHEN prodtl.price_to_display =4 THEN prodtl.mop_price END END END END as price_orderby,pri_attcolor,pro.prod_id,prodtl.display_name,packtype.type_name as type,pro.prod_img1,pro.prod_status,prodtl.prod_itemid,prodtl.price_to_display,prodtl.mrp_price,prodtl.mop_price,prodtl.offer_price,pro.add_variant,prodtl.sale_unit,prodtl.pack_content,prodtl.stock_unit,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,prodtl.item_stocksts,prodtl.item_availability,att1,var1,att2,var2,att3,var3,subcat.subcategory_name,pro.pri_att,image_type,item_images  from product pro INNER JOIN product_itemdtl prodtl ON pro.prod_id = prodtl.prod_id INNER JOIN brand ON brand.brand_id = pro.brand_id INNER JOIN categories maincat ON maincat.category_id = pro.maincat_id INNER JOIN category cat ON cat.category_id = pro.cat_id INNER JOIN sub_category subcat ON subcat.subcat_id = pro.subcat_id INNER JOIN packettype_master packtype ON packtype.id = pro.packtype_id INNER JOIN stores str ON str.store_id = pro.store_id WHERE pro.store_id =$store_id AND pro.cat_id = $cat_id AND pro.subcat_id = $subcat_id and pro.prod_status = 1 $order_by")->result();
            }
            //echo '<pre>';
           // print_r($prod_qry);
            //die;
            foreach($prod_qry as $dt){
                $allow =1;
                //[0] => Size:4-5 Years| 6-7 Years| 8-9 Years| XL| M| S
//[1] => Color:Blue| Red
                if($filter_data){
                    $allow=0;
                foreach($filter_data as $fil){
                    $exp_fil = explode(":",$fil);
                    $fil_attname = trim($exp_fil[0]);
                    $fil_varname = $exp_fil[1];
                    //Attribute1
                    if(trim($dt->att1)!=""){
                        $att1_id = $dt->att1;
                        $get_att1 = $this->db->query("SELECT * from attributes WHERE id = $att1_id ")->result();
                        if($get_att1){
                        $att_name1 = $get_att1[0]->attribute_name;
                        if($att_name1 == $fil_attname){
                            $exp_vars = explode("|",$fil_varname);//4-5 Years| 6-7 Years| 8-9 Years| XL| M| S
                            foreach($exp_vars as $var){
                                $tvar = trim($var);
                            if($tvar == $dt->var1){
                                $allow=1;
                            }}
                        }}
                    } //Attribute1 end here
                     //Attribute2
                    if(trim($dt->att2)!=""){
                        $att2_id = $dt->att2;
                        $get_att2 = $this->db->query("SELECT * from attributes WHERE id = $att2_id ")->result();
                        if($get_att2){
                        $att_name2 = $get_att2[0]->attribute_name;
                        if($att_name2 == $fil_attname){
                            $exp_vars = explode("|",$fil_varname);//4-5 Years| 6-7 Years| 8-9 Years| XL| M| S
                            foreach($exp_vars as $var){
                                $tvar = trim($var);
                            if($tvar == $dt->var2){
                                $allow=1;
                            }}
                        }}
                    } //Attribute2 end here
                     //Attribute3
                    if(trim($dt->att3)!=""){
                        $att3_id = $dt->att3;
                        $get_att3 = $this->db->query("SELECT * from attributes WHERE id = $att3_id ")->result();
                        if($get_att3){
                        $att_name3 = $get_att3[0]->attribute_name;
                        if($att_name3 == $fil_attname){
                            $exp_vars = explode("|",$fil_varname);//4-5 Years| 6-7 Years| 8-9 Years| XL| M| S
                            foreach($exp_vars as $var){
                                $tvar = trim($var);
                            if($tvar == $dt->var3){
                                $allow=1;
                            }}
                        }}
                    } //Attribute3 end here
                }
            }
            if($allow==1){ // allow filtered data
                $subcat_name = $dt->subcategory_name;
                $prod_itemid = $dt->prod_itemid;
                //Price start here
                $price_to_display = $dt->price_to_display;
                 if($price_to_display){
                   if($price_to_display==1){ //MRP
                        $price_final = $dt->mrp_price; //
                   }else if($price_to_display==2){ //Mop
                        $price_final = $dt->mop_price; //
                   }else if($price_to_display==3){ //Offer price
                        $price_final = $dt->offer_price;
                   }else if($price_to_display[$m]==4){ //range price
                        $price_final = $dt->mop_price .' - ₹ '.$dt->mrp_price; //
                   }
                 } //Price end here
                 $display_type = $dt->price_to_display;
                 $final_mrpprice = $dt->mrp_price; 
                 $type = $dt->type;
                 $add_variant = $dt->add_variant;
                 $sale_unit = $dt->sale_unit;
                 $stock_unit = $dt->stock_unit;
                 $pack_content = $dt->pack_content;
                 //get variant name 
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //Loose product 
                     $unit_dt = $this->db->query("select * from product_units where id = $sale_unit")->result();
                        if($unit_dt){
                            $slunit_name =$unit_dt[0]->unit;
                        }
                        $variant_name = $pack_content.' '.$slunit_name;
                        $variant_cnt = 1;
                        $color_value = $dt->pri_attcolor;
                        $size_value = trim($variant_name);
                     
                 }else{
                     $primary_attibuteid = $dt->pri_att;
                     $chk_priatt_is_color = $this->db->query("Select * from attributes where id = $primary_attibuteid and attribute_name in ('color','colour')")->result();
                     
                     //Attribute1 //variant2
                     $att1_id = $dt->att1;
                     $variant1 = $dt->var1;
                     $att2_id = $dt->att2;
                     $variant2 = $dt->var2;
                     $att3_id = $dt->att3;
                     $variant3 = $dt->var3;
                     
                     $variant_name = $variant1.';'.$variant2.';'.$variant3;
                     $variant_name = rtrim($variant_name, ";");
                     $color_value = $dt->pri_attcolor;
                     $size_value = trim($variant_name);
                     if($chk_priatt_is_color){ //if primary attibute is color means don't take first attibute (that's color)
                          $size_n = $variant2.';'.$variant3; 
                          $size_n = rtrim($size_n, ";");
                          $size_value = trim($size_n);
                     }
                     
                     $getcnt = explode(";",$variant_name); //masala;egg;corainder
                     $variant_cnt = count($getcnt);//3
                 }
                 //
                 
                 $stock_qty = 0; 
                 //get stock start here
                 if(trim(strtoupper($dt->display_stock))=="NO"){ //follow MOQ
                     $stock_qty = $dt->item_moq;
                 }else {
                     if(strtoupper($type)=="LOOSE"){ //loose product
                         $stock_qty = $dt->item_totstock; 
                      //Convert Stock  sale unit(gram) to stock unit(kg) and minus the stock //Only applicable for loose product
                            if($sale_unit!=$stock_unit){
                                if($sale_unit == 1 || $sale_unit == 3){ //1-ml to ltr  ex. 5ltr total stck 500ml packet content //3-gram to kg
                                    $converted = $pack_content / 1000;   // 500ml /1000 = 0.5ltr
                                    $stock_qty = $stock_qty / $converted ;  // 5/0.5  , total quantity available 10 500ml's
                                }
                                else if($sale_unit == 2 || $sale_unit == 5){ //2- ltr to ltr //5-kg to kg
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else if($sale_unit == 4 || $sale_unit == 6 || $sale_unit == 7 || $sale_unit == 8 || $sale_unit == 9){//4-box//6-pcs//7-nos //8-packet//9-plate
                                    $stock_qty = $stock_qty;
                                }
                            }
                            else{
                                 if(($sale_unit == 1) || ($sale_unit == 2) || ($sale_unit == 3) || ($sale_unit == 5) ){
                                    $stock_qty = $stock_qty / $pack_content;
                                }
                                else {
                                    $stock_qty = $stock_qty;
                                }
                            }
                            $stock_qty = (int)$stock_qty;
                     } else { //Other than loose product
                         $stock_qty = $dt->item_totstock; 
                     }
                 }
                 $fi_stock_qty = round($stock_qty);
                 // stock calculation end here

                //Stock status    
                if($dt->item_stocksts==1){
                     $stock_status_final='Available';
                }
                
                if($fi_stock_qty <=0 ){
                    $stock_status_final = 'Out of Stock';
                }
                if($dt->item_availability ==0 ){//check availability
                    $stock_status_final = 'Sold Out';
                }
                 $final_mrpprice =round($final_mrpprice,0);    
                 $price_final =round($price_final,0);
                 $flg =0;
                 if(strtoupper($type)=="LOOSE" || strtoupper($add_variant)=="NO"){ //primary attibute wise prooductlist
                     $flg =1;
                 }else{
                     if($dt->pri_att == $dt->att1){
                        $flg =1; 
                     }
                 }
                 if($flg =1){
                        $pro_allow = 1;
                    foreach ($data as $key => $value) {
                        if($value['product_id'] == $dt->prod_id){
                            $pro_allow = 0;
                        }
                    }
                    if($dt->image_type==2){//variant wise image
                            $ex_im = explode('|',$dt->item_images);
                            $image = $ex_im[0];
                    }else{ //generic image
                        $image = $dt->prod_img1;
                    }
                    if($pro_allow == 1){ // allow only one item from each product
                 $data[] = array(
                    'product_id'=>$dt->prod_id,
                    'product_name'=>$dt->display_name,
                    'type'=>$dt->type,
                    'color_value'=>$color_value,
                    'size_value'=>$size_value,
                    'product_image'=>$image,
                    'status'=>$dt->prod_status,
                    'item_id'=>$prod_itemid,
                    'varient_id'=>$prod_itemid,
                    'display_type'=>$display_type,
                    'mrp_price'=>"$final_mrpprice",
                    'display_price'=>"$price_final",
                    'min_price'=>"$price_final",
                    'varient_name'=>$variant_name,
                    //'varient'=>$variant_name,
			'varient'=>"",
                    'varient_cnt'=>"$variant_cnt",
                    'quantity'=>"$fi_stock_qty",
                    'stock_status'=>$stock_status_final,
                    'theme_color'=>$theme_color,
                    'font_color'=>$font_color
                    );
             }
                 }
            } }
            if($data){
              $final_array[] = array(
               "category_id"=>$subcat_id,
               "category_name"=>$subcat_name,
               "products"=>$data
               );
            }

          } //category wise loop end here
          
         return $result = array('status'=>1,'message'=>'Product list', 'data'=>$final_array); 
         
    }

    function check_stock($user_id){
        $stock_qty = 0;
        $chk_stock_status = 1;
        $cart_data = $this->db->query("select prodtl.item_stocksts,prodtl.item_availability,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,  prod.prod_status,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,display_name,cart.cart_id,cart.varient_name,cart.quantity,prod.prod_name,prod.description product_description,prod.prod_img1,prod.prod_id,prod_itemid,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product as prod ON prod.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON prodtl.prod_id = prod.prod_id AND prodtl.prod_itemid = cart.item_id  where user.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0) AND cart.type != 'Loose'  ORDER BY product_id,prod_itemid")->result();
        if($cart_data){ //other than loose
    foreach($cart_data as $data){
        $store_id = $data->store_id;
        $product_id = $data->prod_id;
        $prod_itemid = $data->prod_itemid;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES'){
            $stock = $data->item_totstock;
        }else{
            $stock = $data->item_moq;
        }
        $final_availability = $data->item_availability;
        if($data->quantity > $stock){
            $chk_stock_status = 0;
            $stock_availability = 'Out of Stock';
            $stock_status = 'Sold Out';
        }else if($data->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }
        if($final_availability!=1){
            $chk_stock_status = 0;
        }
    }
        }
        $loosecart_data = $this->db->query("select prodtl.sale_unit,prodtl.stock_unit,prodtl.pack_content, prodtl.item_stocksts,prodtl.item_availability,prodtl.display_stock,prodtl.item_totstock,prodtl.item_moq,  prod.prod_status,display_rate,display_price,display_type,mrp_rate,cart.mrp_price,display_name,cart.cart_id,cart.varient_name,cart.quantity,prod.prod_name,prod.description product_description,prod.prod_img1,prod.prod_id,prod_itemid,stores.store_id,stores.store_name,stores.store_image,stores.description store_description,user.fullname user_name,cart.rate,cart.price,0 as stock,'' as stock_status from cart INNER JOIN user_profile user on cart.user_id = user.user_id INNER JOIN stores on stores.store_id = cart.store_id INNER JOIN product as prod ON prod.prod_id = cart.product_id INNER JOIN product_itemdtl prodtl ON prodtl.prod_id = prod.prod_id AND prodtl.prod_itemid = cart.item_id  where user.user_id = $user_id and cart.order_id = 0 and cart.product_status in (0) AND cart.type = 'Loose'  ORDER BY product_id,prod_itemid")->result();
         if($loosecart_data){ //other than loose
     $preloose_product_id=''; $chk_loose_overallqty = 0;
    foreach($loosecart_data as $data){
         $store_id = $data->store_id;
        $product_id = $data->prod_id;
        $prod_itemid = $data->prod_itemid;
        $display_stock = $data->display_stock;
        if(strtoupper($display_stock)=='YES'){
                         $stock = $data->item_totstock;
                        $sale_unit = $data->sale_unit;
                        $stock_unit = $data->stock_unit;
                        $pack_content = $data->pack_content;
                        if($preloose_product_id==''){
                            $preloose_product_id = $prod_itemid;  
                            $chk_loose_overallqty = $data->quantity * $pack_content;//5 * 250g = 1250g
                        }
                        else {
                            if($preloose_product_id == $prod_itemid){
                                    $chk_loose_overallqty = $chk_loose_overallqty +($data->quantity * $pack_content);
                                }else{
                                      $preloose_product_id = $prod_itemid;  
                                      $chk_loose_overallqty = $data->quantity * $pack_content;
                                }
                        }
                        if( $chk_loose_overallqty > $stock_qty){
                                $chk_stock_status = 0;
                                    }
        }else{
            $stock = $data->item_moq;
        }
        $final_availability = $data->item_availability;
        if($data->quantity > $stock){
            $chk_stock_status = 0;
            $stock_availability = 'Out of Stock';
            $stock_status = 'Sold Out';
        }else if($data->quantity <= $stock){
            $stock_availability = 'Stock Available';
            $stock_status ='Available';
        }   
      //chk product availability
        // $chk_product_availability = $this->db->query("select availability from products where product_id =$product_id and availability=0 ")->result();
        // if($chk_product_availability){
        //     $chk_stock_status = 0;
        // }
        if($final_availability!=1){
            $chk_stock_status = 0;
        }
        
    }
        }
        if($chk_stock_status==0){
                // $result = array('status'=>3,'message'=>'Stock Quantity updated Please Check the Cart');
                $result = array('status'=>3,'message'=>'Please check update stock status in your basket','stock'=>$stock_qty);
            }else {
                $result = array('status'=>1,'message'=>'Stock Available','stock'=>$stock_qty);
            }
        return $result;
        
    }
    public function get_deliveryslot($selected_date=""){
    $list = $this->db->query("select * from delivery_slot where enable =1")->result();
    $del_array = array();
    if($list){
        foreach($list as $dt){
            $del_date = explode("to",$dt->time_slot);
            $deldate_from =  date("H", strtotime($del_date[0]));
            $deldate_to =  date("H", strtotime($del_date[1]));
            $cur_time = date("H");
            $allow = 0;
            $today = date('Y-n-j'); //2022-02-05 to 2022-2-5  jere $selected_date = 2022-2-5
            if(($deldate_from >= $cur_time + 1) || $selected_date!=$today){ //1. for today check timing condition 2.for futute delivery date allow all the timing
                $allow = 1;
            }
            if($allow==1){
                $del_array[] = array(
                    'id' => $dt->id,
                    'time_slot'=>$dt->time_slot,
                    'time_slot_view'=>$dt->time_slot_view
                    );
            }
        }
    }
    return $result = array('status'=>1,'data'=>$del_array); 
}
    public function delivery_datechanges($postdata=array()){
    if(!isset($postdata['user_id']) || !isset($postdata['selected_date']) || empty($postdata['selected_date'])){
            return false;
        }
    $user_id = $postdata['user_id'];
    $selected_date = $postdata['selected_date'];
     $delivery_slotary = $this->get_deliveryslot($selected_date);
        $delivery_slot = json_decode(json_encode($delivery_slotary['data']), FALSE);
        $pre_deldate = "";$pre_deltime = "";
        $get_datetime = $this->db->query("select preferred_del_date,preferred_del_time from cart where order_id = 0 and user_id = $user_id")->result();
        if($get_datetime){
            if($get_datetime[0]->preferred_del_date!='0000-00-00'){
                $pre_deldate = $get_datetime[0]->preferred_del_date;
            }
            if($get_datetime[0]->preferred_del_time!=''){
                $pre_deltime = $get_datetime[0]->preferred_del_time;
            }
        }
        $final_array = array(
            'delivery_slot'=>$delivery_slot,
            'pre_deldate'=>$pre_deldate,
            'pre_deltime'=>$pre_deltime
            );
            return $result = array('status'=>1,'message'=>'Delivery Slot','data' => $final_array );
}
}
?>