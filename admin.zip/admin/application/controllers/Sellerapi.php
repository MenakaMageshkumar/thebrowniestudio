<?php
ob_start();
defined('BASEPATH')OR exit('No direct script access allowed');
header('Content-Type: text/html; charset=utf-8');
if (isset($_SERVER['HTTP_ORIGIN'])) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Max-Age: 86400');
}

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
  header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  exit(0);
}
class Sellerapi extends CI_Controller{ 
    var $request_headers = array();
  public function __construct() {
    parent::__construct();
    date_default_timezone_set('asia/kolkata');
    $this->load->model('Sellerapi_model');
    $this->load->library(array('encryption','form_validation'));
    $this->load->helper('string');
    $this->load->helper('url');
    $this->load->helper('pushnotification_helper'); 
    $this->load->model('Common_model','common');
    $this->request_headers = $this->input->request_headers();
  }
  	function get_guid() {
				mt_srand((double) microtime() * 10000); //optional for php 4.2.0 and up.
			$charid = strtoupper(md5(uniqid(rand(), true)));
			$hyphen = chr(45); // "-"
			$uuid = substr($charid, 0, 8) . $hyphen
			. substr($charid, 8, 4) . $hyphen
			. substr($charid, 12, 4) . $hyphen
			. substr($charid, 16, 4) . $hyphen
			. substr($charid, 20, 12);
			return strtolower($uuid);
	}
public function login() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'phone_no', 
						 'label'   => 'phone_no', 
						 'rules'   => 'required'
					  ),
				   array(
						 'field'   => 'password', 
						 'label'   => 'password', 
						 'rules'   => 'required'
					  )	 
					  ,
				   array(
						 'field'   => 'token_key', 
						 'label'   => 'token_key', 
						 'rules'   => 'required'
					  )	 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
			$phone_no= trim($this->input->post('phone_no'));
            $password= $this->input->post('password');
            $request = $this->input->post();
            $chk_exists = $this->db->query("select * from shopper where phone_no ='$phone_no'")->result();
            if(empty($chk_exists)){
              $result = array('status'=>0,'message'=>'Invalid phone number, Try again!');
              print_r(json_encode($result));exit;
            }
            
            $chk_status = $this->db->query("select * from shopper where phone_no ='$phone_no' and status = 0")->result();
            if(($chk_status)){
            //   $result = array('status'=>0,'message'=>'Account Inactive Contact Admin');
              $result = array('status'=>0,'message'=>'Inactive account, Please contact admin!');
              print_r(json_encode($result));exit;
            }
            $result = $this->Sellerapi_model->login($request);
    if (empty($result) || !isset($result['status']) || $result['status'] != '1') {
    $result = array('status'=>0,'message'=>'Invalid credentials, Try again!');
    }
    else{
        $result_token = $this->Sellerapi_model->update_token($request);
    }
    print_r(json_encode($result));exit;
			}
	 }  
	  else{
			$this->common->renderError("Please send required fields");
		}
}
public function forgot_password() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'phone_no', 
						 'label'   => 'phone_no', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
			$phone_no= trim($this->input->post('phone_no'));
			if(strlen($phone_no)<10){
			     $result = array('status'=>0,'message'=>'Please enter Valid Mobile no');
                 print_r(json_encode($result));exit;
			}
            $request = $this->input->post();
            $phone_no=$this->Sellerapi_model->chck_user_exists($request);
            if(empty($phone_no)){
              $result = array('status'=>0,'message'=>'Seller not registered. Please visit www.yellowmart.co.in');
              print_r(json_encode($result));exit;
            }
    
    $result = $this->Sellerapi_model->forgot_password($request);
    if (empty($result) || !isset($result['status']) || $result['status'] != '1') {
    $result = array('status'=>0,'message'=>'Failed to Send OTP');
    }
    print_r(json_encode($result));exit;
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
}

  public function otp_verify(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'phone_no',
					      'label' => 'phone_no',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
					      'field' => 'otp_code',
					      'label' => 'otp_code',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $phone_no= trim($this->input->post('phone_no'));
    $chk = $this->db->query("select * from shopper where phone_no ='$phone_no'")->result();
    if(empty($chk)){
              $result = array('status'=>0,'message'=>'Mobile Number not registered');
              print_r(json_encode($result));exit;
            }
    $result = $this->Sellerapi_model->verify_otp($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Wrong OTP');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  } 
 
 public function update_password(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
					      'field' => 'new_password',
					      'label' => 'new_password',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->update_password($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Password');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
   public function dashboard(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->dashboard($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  
   public function orderdetail(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->orderdetail($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function submit_orderdetail(){
      
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'selected_item_id',
					      'label' => 'selected_item_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'delivery_person_id',
					      'label' => 'delivery_person_id'
					      ),
					      array(
					          'field' => 'packing_charge',
					          'label' => 'packing_charge',
					          ),
					      array(
					          'field' => 'delivery_km',
					          'label' => 'delivery_km',
					          ),
					      array(
					          'field' => 'delivery_charge',
					          'label' => 'delivery_charge',
					          ),
					      array(
					          'field' => 'total_amt',
					          'label' => 'total_amt',
					          'rules' => 'required'
					          )
					          
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->submit_orderdetail($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Submit the Data');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
     public function delivery_orderdetail(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->delivery_orderdetail($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  
  public function submitdelivery_orderdetail(){
      
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'delivery_status',
					      'label' => 'delivery_status',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'track_id',
					      'label' => 'track_id'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->submitdelivery_orderdetail($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Submit the Data');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
     public function view_products(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->view_products($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function product_search(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'keyword',
					      'label' => 'keyword'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->product_search($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function add_image(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->add_image($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Product images updated');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_images(){
// $_POST = json_decode(file_get_contents("php://input"), true);
// print_r($_POST);
// die;
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'product_id',
					      'label' => 'product_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    
    
    if(isset($_FILES['product_main_image']['name'])){
   $config = set_upload_service("../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_main_image']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_main_image')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['product_main_image'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
    if(isset($_FILES['product_sub_image1']['name'])){
   $config = set_upload_service("../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_sub_image1']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_sub_image1')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['product_sub_image1'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
     if(isset($_FILES['product_sub_image2']['name'])){
   $config = set_upload_service("../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_sub_image2']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_sub_image2')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['product_sub_image2'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
    if(isset($_FILES['product_sub_image3']['name'])){
   $config = set_upload_service("../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_sub_image3']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_sub_image3')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['product_sub_image3'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
    if(isset($_FILES['product_sub_image4']['name'])){
   $config = set_upload_service("../assets/uploads/products");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['product_sub_image4']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('product_sub_image4')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['product_sub_image4'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }

    $result = $this->Sellerapi_model->update_images($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Images');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function add_description(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->add_description($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Product description updated');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_description(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'product_id',
					      'label' => 'product_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'description',
					      'label' => 'description',
					      'rules' => 'required'
					      )
		
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->update_description($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Description');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function add_stock(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->add_stock($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Product stocks updated');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_stock(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'product_id',
					      'label' => 'product_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'item_id',
					      'label' => 'item_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'stock',
					      'label' => 'stock',
					      'rules' => 'required'
					      )
			
				);
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->update_stock($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Stock');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function add_varient(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->add_varient($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Product variants updated');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_varient(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'product_id',
					      'label' => 'product_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'color',
					      'label' => 'color'
					      )
					      ,
					      array(
					      'field' => 'size',
					      'label' => 'size'
					      )
					      ,
					      array(
					      'field' => 'weight',
					      'label' => 'weight'
					      )
					       ,
					      array(
					      'field' => 'mrp',
					      'label' => 'mrp'
					      )
					       ,
					      array(
					      'field' => 'mop',
					      'label' => 'mop'
					      )
					      ,
					      array(
					      'field' => 'offer_price',
					      'label' => 'offer_price'
					      )
      				      ,
					      array(
					      'field' => 'display_stock',
					      'label' => 'display_stock',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'stock',
					      'label' => 'stock'
					      ),
					      array(
					      'field' => 'primary_varient',
					      'label' => 'primary_varient',
					      'rules' => 'required'
					      )
			
				);
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->update_varient($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Varient');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
     public function completed_order(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->completed_order($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function my_profile(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->my_profile($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function offer_images(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->offer_images($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_profile(){
// $_POST = json_decode(file_get_contents("php://input"), true);
// print_r($_POST);
// die;
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      ),
					   //   array(
					   //   'field' => 'order_prep_time',
					   //   'label' => 'order_prep_time',
					   //   'rules' => 'required'
					   //   ),
					   //   array(
					   //   'field' => 'delivery_time',
					   //   'label' => 'delivery_time',
					   //   'rules' => 'required'
					   //   )
					   //   ,
					      array(
					      'field' => 'gps_coordinates',
					      'label' => 'gps_coordinates'
					      ),
					      array(
					      'field' => 'store_maplocation',
					      'label' => 'store_maplocation'
					      )
					       ,
					      array(
					      'field' => 'deltime_type',
					      'label' => 'deltime_type',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'preptime_type',
					      'label' => 'preptime_type',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'preptime_type',
					      'label' => 'preptime_type',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_bannerflg1',
					      'label' => 'store_bannerflg1'
					      ),
					      array(
					      'field' => 'store_bannerflg2',
					      'label' => 'store_bannerflg2'
					      ),
					      array(
					      'field' => 'store_bannerflg3',
					      'label' => 'store_bannerflg3'
					      )
					      
					      
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    if(isset($_FILES['store_banner1']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['store_banner1']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('store_banner1')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['store_banner1'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
     if(isset($_FILES['store_banner2']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['store_banner2']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('store_banner2')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['store_banner2'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
      if(isset($_FILES['store_banner3']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['store_banner3']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('store_banner3')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['store_banner3'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
    $result = $this->Sellerapi_model->update_profile($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Profile');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_offerimg(){
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    if(isset($_FILES['offer_image1']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['offer_image1']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('offer_image1')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['offer_image1'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
     if(isset($_FILES['offer_image2']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['offer_image2']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('offer_image2')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['offer_image2'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
      if(isset($_FILES['offer_image3']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['offer_image3']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('offer_image3')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['offer_image3'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
    $result = $this->Sellerapi_model->update_offerimg($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Offer Images');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
     public function paymentupi(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      )
					      
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->paymentupi($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function submit_paymentupi(){
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'upi_id',
					      'label' => 'upi_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'upi_mobile',
					      'label' => 'upi_mobile',
					      'rules' => 'required'
					      )
					      
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    if(isset($_FILES['upi_qrcode']['name'])){
   $config = set_upload_service("../assets/uploads/stores");
            $this->load->library('upload');
            $config['file_name'] = time()."_".$_FILES['upi_qrcode']['name'];
            $this->upload->initialize($config);
            if(!$this->upload->do_upload('upi_qrcode')){
                $err = 1;
                $errMsg = $this->upload->display_errors();
            }
            else{
                $upload_data = $this->upload->data();
                $postdata['upi_qrcode'] = $config['upload_path']."/".$upload_data['file_name'];
            }		
    }
    $result = $this->Sellerapi_model->submit_paymentupi($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Payment Detail');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_storestatus(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_opening_status',
					      'label' => 'store_opening_status',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->update_storestatus($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Store Status');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function submitcancel_order(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->submitcancel_order($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Order Status');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function update_prep_time(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
					      ,
				 array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'order_prep_time',
					      'label' => 'order_prep_time',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'order_acpt_time',
					      'label' => 'order_acpt_time',
					      'rules' => 'required'
					      ) ,
					      array(
					      'field' => 'selected_item_id',
					      'label' => 'selected_item_id',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'delivery_person_id',
					      'label' => 'delivery_person_id'
					      ),
					      array(
					          'field' => 'packing_charge',
					          'label' => 'packing_charge',
					          ),
					      array(
					          'field' => 'delivery_km',
					          'label' => 'delivery_km',
					          ),
					      array(
					          'field' => 'delivery_charge',
					          'label' => 'delivery_charge',
					          ),
					      array(
					          'field' => 'total_amt',
					          'label' => 'total_amt',
					          'rules' => 'required'
					          )      
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->update_prep_time($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Update Preparation Time');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function selleradd_productslist(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					       array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					       array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->selleradd_productslist($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function selleraddproduct_search(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'keyword',
					      'label' => 'keyword'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->selleraddproduct_search($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function seller_addproduct() { //place order
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
    		            'field' => 'seller_id',
    		            'label' => 'seller_id',
    		            'rules'   => 'required'
    		            ),
    		        array(
						 'field'   => 'order_id', 
						 'label'   => 'order_id', 
						 'rules'   => 'required'
					  ),
				 array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					   ,
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ) 
					  ,
					  array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id', 
						 'rules'   => 'required'
					  ) ,
					  array(
						 'field'   => 'varient_name', 
						 'label'   => 'varient_name', 
						 'rules'   => 'required'
					  ) 
					   ,
					  array(
						 'field'   => 'quantity', 
						 'label'   => 'quantity', 
						 'rules'   => 'required'
					  ) 
					 ,
					  array(
						 'field'   => 'rate',
						 'label'   => 'rate', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'selected_item_id',//cart_ids
						 'label'   => 'selected_item_id', 
						 'rules'   => 'required'
					  ) ,
					  array(
						 'field'   => 'preferred_del_date',
						 'label'   => 'preferred_del_date', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'preferred_del_time',
						 'label'   => 'preferred_del_time', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'message_on_cake',
						 'label'   => 'message_on_cake'
					  ),
					  array(
						 'field'   => 'notes_on_chef',
						 'label'   => 'notes_on_chef'
					  )
					  
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $store_id = $postdata['store_id'];
    $utn_number = $postdata['order_id'];
	$user_id  = $postdata['user_id'];
	$check = $this->db->query("select * from cart inner join orders on cart.order_id = orders.order_id where cart.user_id = $user_id  and utn_number = '$utn_number' ")->result();
	if(empty($check)){
	$result = array('status'=>0,'message'=>'Something went wrong please try again');
	}
	else {
    $result = $this->Sellerapi_model->seller_addproduct($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
    
	}
	
	
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function order_confirmation(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      )
					       ,
				 
					  array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'selected_item_id',
					      'label' => 'selected_item_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->order_confirmation($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Failed to Confirm Order');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
     public function notifications(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->notifications($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function notifications_count(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->notifications_count($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Data Not Found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  
  public function getdelivery_charge(){
      
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'deliverykm',
					      'label' => 'deliverykm',
					      'rules' => ''
					      )
					      ,
					      array(
					      'field' => 'selected_item_id',
					      'label' => 'selected_item_id',
					      'rules' => ''
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->getdelivery_charge($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  public function updateproduct_price(){
      
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'cart_id',
					      'label' => 'cart_id',
					      'rules' => 'required'
					      ),
					       array(
					      'field' => 'quantity',
					      'label' => 'quantity',
					      'rules' => 'required'
					      )
					      ,
					      array(
					      'field' => 'per_unit_price',
					      'label' => 'per_unit_price',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->updateproduct_price($postdata);
    if(empty($result)){
    $result = array('status'=>"0",'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //Seller add product ->  on change preferred date according to date load preferred delivery time 
  public function delivery_datechanges(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'seller_id',
					      'label' => 'seller_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'order_id',
					      'label' => 'order_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'selected_date',
					      'label' => 'selected_date',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Sellerapi_model->delivery_datechanges($postdata);
    if(empty($result)){
    $result = array('status'=>"0",'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  
  }
?>