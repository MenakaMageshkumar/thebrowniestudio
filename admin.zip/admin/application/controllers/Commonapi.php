<?php
ob_start();
defined('BASEPATH')OR exit('No direct script access allowed');
header('Content-Type: text/html; charset=utf-8');
if (isset($_SERVER['HTTP_ORIGIN'])) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Max-Age: 86400');
}

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
  header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  exit(0);
}
class Commonapi extends CI_Controller{ 
    var $request_headers = array();
  public function __construct() {
    parent::__construct();
    date_default_timezone_set('asia/kolkata');
    $this->load->model('Commonapi_model');
    $this->load->library(array('encryption','form_validation'));
    $this->load->helper('string');
    $this->load->helper('url');
    $this->request_headers = $this->input->request_headers();
  }
  public function get_baseurl() {
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'userid',  //client userid
						 'label'   => 'client_userid', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'apptype', // 1.deliveryadmin_app 2.selleradmin_app 3.merchant_app 4.deliveryboy_app
						 'label'   => 'apptype', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model','common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
            $request = $this->input->post();
            //check client useris exists or not
            $result = $this->Commonapi_model->chk_active($request);
            if (empty($result) || !isset($result['status']) || $result['status'] != '1') {
                print_r(json_encode($result));exit;
            }else{
            
                print_r(json_encode($result));exit;
			}
	 }}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
}
?>