<?php
ob_start();
defined('BASEPATH')OR exit('No direct script access allowed');
header('Content-Type: text/html; charset=utf-8');
if (isset($_SERVER['HTTP_ORIGIN'])) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Max-Age: 86400');
}

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
  header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  exit(0);
}
class Customerapi extends CI_Controller{ 
    var $request_headers = array();
  public function __construct() {
    parent::__construct();
    date_default_timezone_set('asia/kolkata');
    $this->load->model('Customerapi_model');
    $this->load->library(array('encryption','form_validation'));
    $this->load->helper('string');
    $this->load->helper('url');
    $this->load->helper('pushnotification_helper');
    $this->load->model('Common_model','common');
    $this->request_headers = $this->input->request_headers();
  }
   
    //LOGIN API
    public function do_login() { //MS
  $_POST = json_decode(file_get_contents("php://input"), true);

if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'phone_no', 
						 'label'   => 'phone_no', 
						 'rules'   => 'required'
					  ),
				   array(
						 'field'   => 'password', 
						 'label'   => 'password', 
						 'rules'   => 'required'
					  ),
				   array(
						 'field'   => 'country_code', 
						 'label'   => 'country_code', 
						 'rules'   => 'required'
					  )	
					  ,
				   array(
						 'field'   => 'token_key', 
						 'label'   => 'token_key', 
						 'rules'   => 'required'
					  )
					    ,
				   array(
						 'field'   => 'appid', 
						 'label'   => 'appid'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
			$phone_no= trim($this->input->post('phone_no'));
            $password= $this->input->post('password');
            $request = $this->input->post();
            $result = $this->Customerapi_model->login($request);
    if (empty($result) || !isset($result['status']) || $result['status'] == '0') {
    $result = array('status'=>0,'message'=>'Invalid credentials, Try again!');
    }
    else{
        $result_token = $this->Customerapi_model->update_token($request);
    }
    print_r(json_encode($result));exit;
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //Customer Registration Step 1 - gather Mobile Number 
  public function register(){ 
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'country_code',
					      'label' => 'country_code',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
					      'field' => 'phone_no',
					      'label' => 'phone_no',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
    					  'field' => 'appid',
					      'label' => 'appid'  //default ym(YM) or exclusive shared app(EX1) or seperate app(EXSE1) make mandatory later
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $phone = $postdata['phone_no'];
    //country code validation allow only india
    $country_code = $postdata['country_code'];
    if($country_code!=91){
      $result = array('status'=>0,'message'=>'We support only for India(+91) location.');
      print_r(json_encode($result));exit;    
    }
    
    if(!empty($phone)){
        $cnt = strlen($phone);
        if($cnt!=10){
      $result = array('status'=>0,'message'=>'Please Enter Valid Mobile No');
          print_r(json_encode($result));exit; 
        }
        $chk_case1 = substr($phone, 0, 1);
        if($chk_case1=='0'){
            $result = array('status'=>0,'message'=>'Please Enter Valid Mobile No');
            print_r(json_encode($result));exit;
        }
        $chk_case2 = substr($phone, 2, 8);
        if($chk_case2=='00000000'){
            $result = array('status'=>0,'message'=>'Please Enter Valid Mobile No');
            print_r(json_encode($result));exit;
        }
    }
    $phone_no=$this->Customerapi_model->phoneno_select($postdata);
    if(!empty($phone_no)){
    $result = array('status'=>0,'message'=>'Phone Number already exist');
      print_r(json_encode($result));exit; 
    }
    $phone_n = '91'.$postdata['phone_no'];
    $phone_result = $this->db->query("select phone_no from user_profile where phone_no =$phone_n and status = 2")->result();
    if(!empty($phone_result)){
    $result = array('status'=>0,'message'=>'Phone Number already registered, Please log in!');
      print_r(json_encode($result));exit; 
    }
    
    $postdata['otp'] = $otp = rand(1111, 9999);
    $result = $this->Customerapi_model->user_signup($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  } 
  //Customer Registration Step 2 - OTP verification
  public function otp_verify(){ 
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
					      'field' => 'otp',
					      'label' => 'otp',
					      'rules' => 'required'
					      )
					      ,
					  /*array(
					      'field' => 'password',
					      'label' => 'password',
					      'rules' => 'required'
					      )*/
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
   
    $result = $this->Customerapi_model->user_otp($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Invalid OTP');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  } 
  //Customer Registration Step 3 - Basic information
   public function user_register_oldwithaddress(){ //MS
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
				 array(
						 'field'   => 'fullname', 
						 'label'   => 'fullname', 
						 'rules'   => 'required'
					  ),
				   array(
						 'field'   => 'email', 
						 'label'   => 'email'
					  ),
					  array(
					      'field' => 'password',
					      'label' => 'password',
					      'rules' => 'required'
					      )
					      ,
					  
					  array(
					      'field' => 'token_key',
					      'label' => 'token_key',
					      'rules' => 'required'
					      )
					      ,
					  
					  array(
					      'field' => 'address1',
					      'label' => 'address1',
					      'rules' => 'required'
					      )
					       ,
					  
					  array(
					      'field' => 'address2',
					      'label' => 'address2',
					      'rules' => 'required'
					      )
					      ,
					  
					  array(
					      'field' => 'landmark',
					      'label' => 'landmark',
					      'rules' => 'required'
					      )
					       ,
					  
					  array(
					      'field' => 'state_id',
					      'label' => 'state_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'district_id',
					      'label' => 'district_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'city_id',
					      'label' => 'city_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'area_id',
					      'label' => 'area_id',
					      'rules' => 'required'
					      ),
					  array(
					          'field' => 'address_name',
					          'label' => 'address_name',
					          'rules' => 'required'
					          ),
                     array(
					          'field' => 'gps_coordinates',
					          'label' => 'gps_coordinates'
					          )
					          
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
  
    //Validation part
        $fullname = $postdata['fullname'];
        $cnt = strlen($fullname);
        if($cnt < 3 || $cnt >26){ //Case1 : customer name should be min 3 & maximum 26
          $result = array('status'=>0,'message'=>'Please enter your full name');
          print_r(json_encode($result));exit; 
          }
          
        if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $fullname)) //Don't Allow Special characters
            {
                $result = array('status'=>0,'message'=>'Please enter your full name');
                print_r(json_encode($result));exit;
            }
    
    $passwordErr ='';
    $password = $postdata['password'];
     if (trim($password) == '') {
        $passwordErr = "Please enter Password";
    }
  
    
    if($passwordErr!=''){
        $result = array('status'=>0,'message'=>$passwordErr);
        print_r(json_encode($result));exit;
    }
     //validation end here
    $result = $this->Customerapi_model->user_register_oldwithaddress($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }  
  //Customer Registration Step 3 - Basic information
  public function user_register(){ //MS
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
				 array(
						 'field'   => 'fullname', 
						 'label'   => 'fullname', 
						 'rules'   => 'required'
					  ),
				   array(
						 'field'   => 'email', 
						 'label'   => 'email'
					  ),
					  array(
					      'field' => 'password',
					      'label' => 'password',
					      'rules' => 'required'
					      )
					      ,
					  
					  array(
					      'field' => 'token_key',
					      'label' => 'token_key',
					      'rules' => 'required'
					      ),
					     
					  array(
					      'field' => 'current_cityid',
					      'label' => 'current_cityid',
					      'rules' => 'required'
					      )
					          
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    //Validation part
        $fullname = $postdata['fullname'];
        $cnt = strlen($fullname);
        if($cnt < 3 || $cnt >26){ //Case1 : customer name should be min 3 & maximum 26
          $result = array('status'=>0,'message'=>'Please enter your full name');
          print_r(json_encode($result));exit; 
          }
          
        if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $fullname)) //Don't Allow Special characters
            {
                $result = array('status'=>0,'message'=>'Please enter your full name');
                print_r(json_encode($result));exit;
            }
    
    $passwordErr ='';
    $password = $postdata['password'];
     if (trim($password) == '') {
        $passwordErr = "Please enter Password";
    }
    if($passwordErr!=''){
        $result = array('status'=>0,'message'=>$passwordErr);
        print_r(json_encode($result));exit;
    }
     //validation end here
     
    $result = $this->Customerapi_model->user_register($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }  
  //Forgot password API5
  public function forgot_password(){ //MS
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		     array(
						 'field'   => 'country_code', 
						 'label'   => 'country_code', 
						 'rules'   => 'required'
					  ),
				 array(
						 'field'   => 'phone_no', 
						 'label'   => 'phone_no', 
						 'rules'   => 'required'
					  )  
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
			    $request =$this->input->post();
    $phone_no=$this->Customerapi_model->phoneno_select($request);
    if(empty($phone_no)){
      $result = array('status'=>0,'message'=>"Phone Number doesn't exist");
      print_r(json_encode($result));exit;
    }
    $result = $this->Customerapi_model->user_forgot($request);
    if(empty($result)){ 
      $result = array('status'=>0,'message'=>'Failed to Update Password');
    } 
    print_r(json_encode($result));exit;
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //User forgot password update API6 
   public function forgot_password_final(){ //MS
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
				 
					  array(
					      'field' => 'password',
					      'label' => 'password',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    
    $result = $this->Customerapi_model->user_forgot_password_final($postdata);
    if(empty($result)){
    //   $result = array('status'=>'error','message'=>'Try Again','error'=>'502');
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //Customer My Profile API7
  public function my_profile(){ 
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->my_profile($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //Update customer profile API8
  public function update_profile(){ //MS
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'fullname', 
						 'label'   => 'fullname', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'phone_no', 
						 'label'   => 'phone_no', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'email', 
						 'label'   => 'email'
					  )
					
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	
	$user_id = $postdata['user_id'];
	$phone = '91'.$postdata['phone_no'];
	$chk_exists = $this->db->query("select * from user_profile where phone_no = '$phone' and user_id!=$user_id")->result();
	if(!empty($chk_exists)){
    $result = array('status'=>0,'message'=>'Phone Number already exist');
      print_r(json_encode($result));exit; 
    }
    //Validation part
        $fullname = $postdata['fullname'];
        $cnt = strlen($fullname);
        if($cnt < 3 || $cnt >26){ //Case1 : customer name should be min 3 & maximum 26
          $result = array('status'=>0,'message'=>'Please enter your full name');
          print_r(json_encode($result));exit; 
          }
          
        if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $fullname)) //Don't Allow Special characters
            {
                $result = array('status'=>0,'message'=>'Please enter your full name');
                print_r(json_encode($result));exit;
            }
    if(isset($postdata['email'])){
        $email = $postdata['email'];
        if($email!=''){
	$chk_emailexists = $this->db->query("select * from user_profile where email = '$email' and user_id!=$user_id")->result();
	if(!empty($chk_emailexists)){
    $result = array('status'=>0,'message'=>'Email Address already exist');
      print_r(json_encode($result));exit; 
    }
        }
    }
     //validation end here
    
    $result = $this->Customerapi_model->update_profile($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //Change password API9
  public function change_password(){ //MS
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'new_password', 
						 'label'   => 'new_password', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'old_password', 
						 'label'   => 'old_password', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			else{
	$postdata =$this->input->post();
	$result_old = $this->Customerapi_model->old_password_validation($postdata);
	if($result_old['status']==1){
    $result = $this->Customerapi_model->change_password($postdata);
	}
	else{
	print_r(json_encode($result_old));exit;     
	}
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
    //View store API10
  public function view_store() { //MS
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  )
					  ,
					   array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	$result = $this->Customerapi_model->get_storedtl($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Store not available in YellowMart');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
   //Add Store API11
  public function add_store() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ) 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->add_to_my_stores($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //My Stores API12
  public function my_stores(){
       $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'city_id', 
						 'label'   => 'city_id'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->my_stores($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'My Store is empty');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  //search store API13
  public function search_store(){
       $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'keyword', 
						 'label'   => 'keyword', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id',
						 'rules'   => 'required'
					  ) 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->search_store($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'No apps found');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  // Offer Products API14
  public function offer_products(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      ),
    		        array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->offer_products($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'No offers for now');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Product list  API15
  public function product_list() { 
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'category_id', 
						 'label'   => 'category_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'subcategory_id', 
						 'label'   => 'subcategory_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'filter_data', 
						 'label'   => 'filter_data'
					  ),
					  array(
						 'field'   => 'sort_type', 
						 'label'   => 'sort_type'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->product_list($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products not available');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Store detail API16
  public function store_detail() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'exclusive_app_enabled', 
						 'label'   => 'exclusive_app_enabled'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->store_detail($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Search product API17
  public function search_product(){
       $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'keyword', 
						 'label'   => 'keyword', 
						 'rules'   => ''
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id',
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id',
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->search_product($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products Not Available');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  // User email validation API18
  public function useremail_validation() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				     array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					 ,
					  array(
						 'field'   => 'email',
						 'label'   => 'email'
					  ) 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	$result = $this->Customerapi_model->useremail_validation($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	}
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // get cities API19
  public function get_cities(){ //MS
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      )
					      ,
				 
					  array(
					      'field' => 'keyword',
					      'label' => 'keyword'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
   
    $result = $this->Customerapi_model->get_cities($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'City not found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  } 
  // city list API20
  public function city_list(){
      $_POST = json_decode(file_get_contents("php://input"), true);
      if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user id',
					      'rules' => 'required'
					      ),
					array(
					      'field' => 'keyword',
					      'label' => 'keyword'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->city_list($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'City Not found');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  //Manage address API21
  public function manage_address(){
      $_POST = json_decode(file_get_contents("php://input"), true);
      if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user id',
					      'rules' => 'required'
					      ),
					 array( //user address contact search
					      'field' => 'keyword',
					      'label' => 'keyword'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->manage_address($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  // order summary page -> change address API22
  public function ordersummary_changeaddress(){
      $_POST = json_decode(file_get_contents("php://input"), true);
      if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user id',
					      'rules' => 'required'
					      ),
					 array( //user address contact search
					      'field' => 'keyword',
					      'label' => 'keyword'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->ordersummary_changeaddress($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  // add and update customer address API23
  public function addupdate_address(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
					      'field' => 'address1',
					      'label' => 'address1',
					      'rules' => 'required'
					      )
					       ,
					  
					  array(
					      'field' => 'address2',
					      'label' => 'address2',
					      'rules' => 'required'
					      )
					      ,
					  
					  array(
					      'field' => 'landmark',
					      'label' => 'landmark',
					      'rules' => 'required'
					      )
					       ,
					  
					  array(
					      'field' => 'state_id',
					      'label' => 'state_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'district_id',
					      'label' => 'district_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'city_id',
					      'label' => 'city_id',
					      'rules' => 'required'
					      ),
					  array(
					      'field' => 'area_id',
					      'label' => 'area_id',
					      'rules' => 'required'
					      ),
					  array(
					          'field' => 'address_name',
					          'label' => 'address_name',
					          'rules' => 'required'
					          ),
					  array(
					          'field' => 'address_type',
					          'label' => 'address_type',
					          'rules' => 'required'
					          ),
                     array(
					          'field' => 'gps_coordinates',
					          'label' => 'gps_coordinates'
					          ),
					          array(
					          'field' => 'address_id',  
					          'label' => 'address_id'
					          )

				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->addupdate_address($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //delete customer address API24
  public function delete_address(){
      $_POST = json_decode(file_get_contents("php://input"), true);
      if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user id',
					      'rules' => 'required'
					      ),
					array(
					      'field' => 'address_id',
					      'label' => 'address_id',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->delete_address($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  //update order summary page address API25
  public function update_ordersummary_currentaddress(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ), array(
						 'field'   => 'address_id', 
						 'label'   => 'address_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->update_ordersummary_currentaddress($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //Product details  API26
  public function product_details() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id',   
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ) 
					  ,
					  array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  )
					 ,
					  array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id',
						 'rules'   => 'required'
					  ),
					    array(
						 'field'   => 'color_value', 
						 'label'   => 'color_value'
					  ),
					    array(
						 'field'   => 'size_value', 
						 'label'   => 'size_value'
					  ),
					  array(
						 'field'   => 'type_value', 
						 'label'   => 'type_value'
					  ),
					    array(
						 'field'   => 'weight_value', 
						 'label'   => 'weight_value'
					  )
					  ,
					    array(
						 'field'   => 'shape_value', 
						 'label'   => 'shape_value'
					  )
					  //type or shape or weight
					  ,
					    array(
						 'field'   => 'change_key', 
						 'label'   => 'change_key'
					  )
					  
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->product_details($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //Add to cart API27
  public function add_cart() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					   ,
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  )  ,
					  array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id', 
						 'rules'   => 'required'
					  )
				// 	  ,
				// 	  array(
				// 		 'field'   => 'varient_id', 
				// 		 'label'   => 'varient_id'
				// 	  ) ,
				// 	  array(
				// 		 'field'   => 'varient_name', 
				// 		 'label'   => 'varient_name', 
				// 		 'rules'   => 'required'
				// 	  ) 
					   ,
					  array(
						 'field'   => 'quantity', 
						 'label'   => 'quantity', 
						 'rules'   => 'required'
					  ) 
					 ,
					  array(
						 'field'   => 'rate',
						 'label'   => 'rate', 
						 'rules'   => 'required'
					  ) 
					  ,
					  array(
						 'field'   => 'check_cart',
						 'label'   => 'check_cart', 
					  ),
					  array(
						 'field'   => 'appid',
						 'label'   => 'appid', 
					  )
					  ,
					  array(
						 'field'   => 'message_on_cake',
						 'label'   => 'message_on_cake', 
					  )
					  ,
					  array(
						 'field'   => 'preferred_del_date',
						 'label'   => 'preferred_del_date', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'preferred_del_time',
						 'label'   => 'preferred_del_time', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'notes_on_chef',
						 'label'   => 'notes_on_chef', 
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	
	if(!isset($postdata['check_cart'])) {
	$check_cart = '';
	}
	else {
$check_cart = $postdata['check_cart'];    	     
	}
	
	if($check_cart == 1){ //Trying to add new store products and remove old products from cart
	$user_id  = $postdata['user_id'];
	$check = $this->db->query("delete from cart where user_id = $user_id and product_status = 0 and order_id = 0 ");
	$result = $this->Customerapi_model->add_cart($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	}
	else{// check cart  = 0 means allow store
	$store_id = $postdata['store_id'];
	$get_newstr = $this->db->query("select store_name from stores where store_id = $store_id")->result();
	$new_store_name = $get_newstr[0]->store_name;
	$user_id  = $postdata['user_id'];
	$check = $this->db->query("select * from cart where user_id = $user_id  and product_status = 0 and order_id = 0 ")->result();
	if($check){
	$existing_store_id = trim($check[0]->store_id);
	$get_str = $this->db->query("select store_name from stores where store_id = $existing_store_id")->result();
	if($get_str){
	$existing_store_name = $get_str[0]->store_name;
	}else{//if store not exists delete cart
	    $this->db->query("delete from cart where user_id = $user_id and product_status = 0 and order_id = 0 ");
	}
	}else{
	    $existing_store_id =0;
	    $existing_store_name ='';
	}
	
	if(($existing_store_id != $store_id) && ($existing_store_id !=0)){
	   // $result = array('status'=>2,'message'=>'Trying to add new store products to cart , Do you want to continue ?');
	   //$result = array('status'=>2,'message'=>'Your cart contains items from '.$existing_store_name.'. Do you want to clear the cart and select '.$new_store_name.'?');
	   $result = array('status'=>2,'message'=>'Your basket contain products from '.$existing_store_name.'. Do you want to clear the basket and select '.$new_store_name.'?');
	    print_r(json_encode($result));exit; 
	}
	else {
    $result = $this->Customerapi_model->add_cart($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
    
	}
	}
	
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Request of Price API28
  public function requestof_price(){ //MS
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  )
					  ,array(
						 'field'   => 'variant_id', 
						 'label'   => 'variant_id'
					  ),array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->requestof_price($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  
  //API29 get_price_stock – not using
  
  // Customer cart list page API30
  public function cart_list(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'appid', 
						 'label'   => 'appid'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->cart_list($postdata);
    if(empty($result)){
    $result = array('status'=>2,'message'=>'Cart is Empty');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //delete store API44
   public function delete_store(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->delete_store($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
   //Get store theme API60
  public function get_themedata() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				     array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	$result = $this->Customerapi_model->get_themedata($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	}
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Cart count API31
  public function cart_count() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->cart_count($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Cart is Empty');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //delete or remove cart item API32
  public function remove_cart(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'cart_id', 
						 'label'   => 'cart_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->remove_cart($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // save user review API35
  public function submit_review() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				     array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),					   
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ) ,
					  array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id', 
						 'rules'   => 'required'
					  ) ,
					  array(
						 'field'   => 'star_count', 
						 'label'   => 'star_count', 
						 'rules'   => 'required'
					  ) 
					   ,
					  array(
						 'field'   => 'review_type', 
						 'label'   => 'review_type', 
						 'rules'   => 'required'
					  ) 
					 ,
					  array(
						 'field'   => 'comment',
						 'label'   => 'comment'
					  ) 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	
	$result = $this->Customerapi_model->submit_review($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	}
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //Payment page API38
  public function payment_type(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'coupon_discount', 
						 'label'   => 'coupon_discount', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->payment_type($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //Store paymnet API42
  public function store_payment(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->store_payment($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //api45
  public function user_address_update(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'address1', 
						 'label'   => 'address1', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'address2', 
						 'label'   => 'address2', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'landmark', 
						 'label'   => 'landmark', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'city_town', 
						 'label'   => 'city_town', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'state_id', 
						 'label'   => 'state_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'pincode', 
						 'label'   => 'pincode', 
						 'rules'   => 'required'
					  )
					  
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->user_address_update($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Unable to Update Delivery Address');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //api47
  public function delivery_status_update(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'order_id', 
						 'label'   => 'order_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'delivery_status_flg', 
						 'label'   => 'delivery_status_flg', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->delivery_status_update($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Unable to Update Delivery Status');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  // Language list API48
  public function language_list(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->language_list($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // customer language update API49
  public function update_language(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'lang_id', 
						 'label'   => 'lang_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->update_language($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //For stock demand send notification to seller API50
  public function notify_me() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					   ,
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ) 
					  ,
					  array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id', 
						 'rules'   => 'required'
					  ) ,
					  array(
						 'field'   => 'varient_name', 
						 'label'   => 'varient_name', 
						 'rules'   => 'required'
					  ) 
					   
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->notify_me($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
    
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //add or minus cart quantity from cart list page API33
  public function add_cartquantity(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					   ,
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ) 
					  ,
					  array(
						 'field'   => 'cart_id', 
						 'label'   => 'cart_id', 
						 'rules'   => 'required'
					  ) 
					   ,
					  array(
						 'field'   => 'quantity', 
						 'label'   => 'quantity', 
						 'rules'   => 'required'
					  ) 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
	$result = $this->Customerapi_model->add_cartquantity($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
	
	}
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // User wishlist page API56
  public function wishlist(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'store_id',
					      'label' => 'store_id',
					      'rules' => 'required'
					      )
					      
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->wishlist($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'no wishlist');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function addto_wishlist() {
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'product_id', 
						 'label'   => 'product_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					   ,
					  array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ) 
					  ,
					  array(
						 'field'   => 'item_id', 
						 'label'   => 'item_id', 
						 'rules'   => 'required'
					  )
     			 ,
					  array(
						 'field'   => 'wishlist_key', 
						 'label'   => 'wishlist_key', 
						 'rules'   => 'required'
					  )
				,
					  array(
						 'field'   => 'appid',
						 'label'   => 'appid', 
					  ) 
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
                $postdata =$this->input->post();
               
                $result = $this->Customerapi_model->addto_wishlist($postdata);
                if(empty($result)){
                $result = array('status'=>0,'message'=>'Try again!');
                }
                print_r(json_encode($result));exit; 
	        }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  //offers , coupons API53
  public function offers(){
       $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'city_id', 
						 'label'   => 'city_id'
					  ),
					  array(
						 'field'   => 'appid', 
						 'label'   => 'appid'
					  )
					  
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->offers($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'No offers');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  //Check coupon valid API54
  public function chk_coupon(){
       $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'coupon_code', 
						 'label'   => 'coupon_code', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->chk_coupon($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'No offers');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
      
  }
  // Proceed to checkout API34
  public function checkout(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->checkout($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Order summary API36
  public function order_summary(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->order_summary($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // Place order API37
  public function place_order(){
      
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'payment_method', 
						 'label'   => 'payment_method', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'payment_type', 
						 'label'   => 'payment_type', 
						 'rules'   => 'required'
					  )
					  ,array(
						 'field'   => 'payment_sts', 
						 'label'   => 'payment_sts'
					  ),array(
						 'field'   => 'transaction_id', 
						 'label'   => 'transaction_id'
					  ),array(
						 'field'   => 'transaction_amt', 
						 'label'   => 'transaction_amt'
					  )
					  ,array(
						 'field'   => 'coupon_code', 
						 'label'   => 'coupon_code'
					  ),
					  array(
					     'field'   => 'coupon_discount', 
						 'label'   => 'coupon_discount'
					  ),
					  array(
					      'field' => 'gift_type',
					      'label' => 'gift_type',
					      'rules' => 'required'
					      ),
				          array(
				          'field' => 'uptodate_email',  
				          'label' => 'uptodate_email'
				          ),
    			          array(
    			          'field' => 'orderby_name',  
    			          'label' => 'orderby_name',
    			          'rules' => 'required'
    			          ),
    			          array(
    			          'field' => 'orderby_contact',  
    			          'label' => 'orderby_contact',
    			          'rules' => 'required'
    			          ),
    			          array(
    			          'field' => 'deliveryto_name',  
    			          'label' => 'deliveryto_name',
    			          'rules' => 'required'
    			          ),
    			          array(
    			          'field' => 'deliveryto_contact',  
    			          'label' => 'deliveryto_contact',
    			          'rules' => 'required'
    			          )

				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->place_order($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  // store wise orders API41
  public function store_orders(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->store_orders($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'No orders found');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  // Customer  My orders API39
  public function my_orders(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->my_orders($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'No orders found');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  // Order Detail API46
  public function order_detail(){
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  ),array(
						 'field'   => 'order_id', 
						 'label'   => 'order_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->order_detail($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try Again');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
  //
  public function user_address(){ //get district,state,city and area details
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'state_id',
					      'label' => 'selected_state'
					      ),
					      array(
					      'field' => 'district_id',
					      'label' => 'selected_district'
					      ),
					      array(
					      'field' => 'city_id',
					      'label' => 'selected_state'
					      ),
					      array(
					      'field' => 'area_id',
					      'label' => 'selected_area'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->user_address($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  } 
  // Product list  API58
  public function prod_filter() { 
      // form_data input
    // $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'category_id', 
						 'label'   => 'category_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'subcategory_id', 
						 'label'   => 'subcategory_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->prod_filter($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products not available');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function prod_filter1() { 
    // $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'category_id', 
						 'label'   => 'category_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'subcategory_id', 
						 'label'   => 'subcategory_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->prod_filter1($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products not available');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function product_list2() { 
    $_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
				 array(
						 'field'   => 'store_id', 
						 'label'   => 'store_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'category_id', 
						 'label'   => 'category_id', 
						 'rules'   => 'required'
					  ),
					  array(
						 'field'   => 'subcategory_id', 
						 'label'   => 'subcategory_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'user_id', 
						 'label'   => 'user_id', 
						 'rules'   => 'required'
					  )
					  ,
					  array(
						 'field'   => 'filter_data', 
						 'label'   => 'filter_data'
					  ),
					  array(
						 'field'   => 'sort_type', 
						 'label'   => 'sort_type'
					  )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
	$postdata =$this->input->post();
    $result = $this->Customerapi_model->product_list2($postdata);
    if(empty($result)){
    $result = array('status'=>0,'message'=>'Products not available');
    }
    print_r(json_encode($result));exit; 
			}
	 }
	  else{
			$this->common->renderError("Please send required fields");
		}
  }
  public function delivery_datechanges(){
$_POST = json_decode(file_get_contents("php://input"), true);
if(!empty($_POST)){
    		    $config = array(
    		        array(
					      'field' => 'user_id',
					      'label' => 'user_id',
					      'rules' => 'required'
					      ),
					      array(
					      'field' => 'selected_date',
					      'label' => 'selected_date',
					      'rules' => 'required'
					      )
				);
				
			$this->form_validation->set_rules($config);
			$this->load->model('Common_model',' common');
			if ($this->form_validation->run()==FALSE){ 
				 $error = '';
				 foreach($config as $c)
					$error .= form_error($c['field']);
				 $this->common->renderError($error);			
			}
			
			else{
    $postdata =$this->input->post();
    $result = $this->Customerapi_model->delivery_datechanges($postdata);
    if(empty($result)){
    $result = array('status'=>"0",'message'=>'Try again');
    }
    print_r(json_encode($result));exit; 
	 }
}
	  else{
			$this->common->renderError("Please send required fields");
		}
  
      
  }
}
?>