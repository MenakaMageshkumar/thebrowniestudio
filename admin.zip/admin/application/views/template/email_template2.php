<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
        <link href="https://fonts.googleapis.com/css?family=Lato:400,300,700,400italic" rel="stylesheet" type="text/css" />
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
        <link rel="icon" href="https://yellowmart.co.in/images/favicon.ico" sizes="16x16" type="image/ico">
		 <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/email_template.css">  -->
		 <style type="text/css">
		/* custom code */
		
				/* responsive code for mobile view */
				.ReadMsgBody {
					width: 100%;
				}
				.ExternalClass {
					width: 100%;
				}
				.yshortcuts {
					color: #ffffff;
				}
				.yshortcuts a span {
					color: #ffffff;
					border-bottom: none !important;
					background: none !important;
				}
				/*Hotmail and Yahoo specific code*/
				body {
					-webkit-text-size-adjust: 100%;
					-ms-text-size-adjust: 100%;
					-webkit-font-smoothing: antialiased;
					margin: 0 !important;
					padding: 0 !important;
					width: 100% !important;
				}
				p {
					margin: 0px !important;
					padding: 0px !important;
				}
				th {
					font-weight: normal !important;
				}
				.appleLinks a {
					color: #e3e3f1 !important;
					text-decoration: none !important;
				}
				.button-container {
					margin: 0 auto !important;
					width: 60% !important;
				}
				/* mouse over link title */
				.titletxt {
					color: #616161;
					text-decoration: none;
				}
				.titletxt:hover {
					color: #545454;
					text-decoration: none;
				}
				/* mouse over link cta */
				/*-----Mobile specific code------*/
				@media only screen and (max-width:799px) {
				body {
					width: auto !important;
				}
				table[class="main"] {
					max-width: 480px !important;
					width: 100% !important;
				}
				img[class="img1"] {
					max-width: 150px !important;
					width: 100% !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				img[class="img2"] {
					max-width: 100% !important;
					width: 100% !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				img[class="banner"] {
					max-width: 100% !important;
					width: 100% !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				img[class="spacerimg"] {
					max-width: 0px !important;
					width: 0px !important;
					display: none !important;
				}
				th[class="stack1"] {
					display: block !important;
					width: 100% !important;
					height: auto !important;
					text-align: center !important;
				}
				th[class="stack2"] {
					display: block !important;
					width: 100% !important;
					height: auto !important;
					margin-top: 15px !important;
				}
				th[class="sphide"] {
					display: none !important;
					width: 0px;
				}
				td[class="textcntr"] {
					text-align: center !important;
					padding-left: 10px;
					padding-right: 10px;
				}
				td[class="button"] {
					max-width: 180px !important;
					width: 180px !important;
					display: block;
					margin: 0 auto;
					background-color: #faad47;
					border-radius: 2px;
					-moz-border-radius: 2px;
					-webkit-border-radius: 2px;
				}
				td[class="hspace"] {
					height: 25px !important;
				}
				}
				@media only screen and (max-width: 479px) {
				body {
					width: auto !important;
				}
				table[class="main"] {
					max-width: 320px !important;
					width: 100% !important;
				}

				img[class="img1"] {
					max-width: 150px !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				th[class="sphide22"] {
					display: none !important;
					width: 0px;
				}
				td[class="titlefsize"] {
					font-size: 20px !important;
					text-align: center !important;
				}
				td[class="wspacw"] {
					width: 6px !important;
				}
				th[class="midspacw"] {
					width: 8px !important;
				}
				td[class="textcntr"] {
					text-align: center !important;
				}
				table[class="logo_left"] {
					max-width: 100%;
					width: 100% !important;
					height: auto;
					margin: 0 auto;
					text-align: center !important;
				}
				img[class="logo_center"] {
					display: inherit !important;
				}
				td[class="cta1"] {
					max-width: 100% !important;
					width: 100% !important;
					background-color: #ffffff;
					border-radius: 2px;
					-moz-border-radius: 2px;
					-webkit-border-radius: 2px;
				}
				td[class="cta"] {
					max-width: 100% !important;
					width: 100% !important;
					background-color: #faad47;
					border-radius: 2px;
					-moz-border-radius: 2px;
					-webkit-border-radius: 2px;
				}
				img[class="spacerimg"] {
					max-width: 0px !important;
					width: 0px !important;
					display: none !important;
				}
				/* custom  */
				.logo_img
				{
					width: 150px!important;
					object-fit: contain;
					margin-left: 14px;
				}
				.mobile_app_top_right
				{
					text-decoration: unset;
					float: right;
					font-family: 'Lato';
					font-size: 9.5px;
				}
				.banner_img_email
				{
					width: 100%;
					object-fit: cover;
					height:auto!important;
				}
				}
				.im {
                    color: #535353!important;
                }
				/* mobile view end */
				
		</style>
	    <title>YellowMart Email</title>

</head>
<body  bgcolor="#fff" style="margin:0px;">
<table bgcolor="#fff" cellpadding="0" cellspacing="0" width="100%">
	<tbody>
		<tr>
			<td  align="center">
			<table align="center"  cellpadding="0" cellspacing="0" class="main" width="600">
				<tbody>
					<tr>
						<td valign="top">
						<table  border="0"  width="100%"cellpadding="0" cellspacing="0" >
							<tbody>
                                <!-- header -->
								<tr>
									<td bgcolor="#fff" style="padding-top:25px;padding-bottom: 25px;" >
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
												<td>
                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                        <tbody>
                                                            <tr>
                                                                <td  align="left">
                                                                <table cellpadding="0" cellspacing="0" border="0" class="logo_left">
                                                                    <tbody>   
                                                                        <tr>
                                                                            <td align="center">
                                                                                <a href="" target="_blank">
                                                                                    <img alt="logo" border="0" style="width: 190px;object-fit: contain;margin-left:14px;" class="logo_center logo_img"  src="https://yellowmart.biz/browniestudio/img/logo.png"  />
                                                                                </a>
                                                                            </td>
                                                                        </tr>
                                                                    
                                                                    </tbody>
                                                                </table>
                                                                </td> 
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                
												<td width="12">&nbsp;</td>
											</tr>
										</tbody>
									</table>
									</td>
                                </tr>
                                <!-- header end -->
                                <!-- banner -->
								<!--<tr>-->
								<!--	<td valign="top">-->
        <!--                                <span class="sg-image" >-->
        <!--                                     <a href="" target="_blank">-->
        <!--                                            <img alt="banner" border="0" class="banner banner_img_email" style="object-fit:cover;" height="245" width="100%" src="https://cdn.pixabay.com/photo/2018/03/22/02/37/email-3249062_960_720.png"  />-->
        <!--                                        </a>-->
        <!--                                    </span>-->
        <!--                                </td>-->
        <!--                        </tr>-->
                                <!-- banner end -->
                                <!-- welcome email content -->
								<tr>
									<td  style="background-image: url('https://yellowmart.co.in/images/about_bg.png');background-position: center;background-size: contain;">
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
												<td class="wspacw" width="20">&nbsp;</td>
												<td>
												<table border="0" cellpadding="0" cellspacing="0" width="100%">
													<tbody>
                                                        <!-- welcome title -->
														<tr>
                                                            <td  style="font-family: Lato, Arial, sans-serif, Trebuchet MS;font-size: 26px;line-height: 32px;color: #06555c;text-align: center;font-weight: 700;padding-top: 25px;">
                                                               <?php echo $heading; ?></td>
                                                        </tr>
                                                        <!-- br -->
														<tr>
															<td height="12">&nbsp;</td>
                                                        </tr>
                                                        <!-- welcome content -->
														<tr>
                                                            <td  style="font-family: Lato, Arial, sans-serif, Trebuchet MS;
															font-size: 13px;line-height: 26px;color: #500050!important;text-align: left;">
                                                             <!--We're happy you're here and excited to help you sell online. Your next step is to confirm your email address, so that we know exactly where to send your sales notification nd other important information-->
                                                             <?php echo $message;?>
                                                            </td>
                                                        </tr>
                                                        <!-- br -->
														<tr>
															<td height="5">&nbsp;</td>
                                                        </tr>	
                            							<!-- Sign in button -->
														<tr>
															<td align="center">
															<table cellpadding="0" cellspacing="0" width="180">
																<tbody>
																	<tr>
                                                                        <td align="center" bgcolor="#FFFFFF" style="border-radius: 2px;
																		-moz-border-radius: 2px;-webkit-border-radius: 2px;border-top: 1px solid #500050;border-left: 1px solid #500050;border-bottom: 1px solid #500050;border-right: 1px solid #500050;" class="cta1 " height="40"  width="180">
                                                                            <a href="https://yellowmart.biz/browniestudio/login" target="_blank"  style="font-family: Lato, Arial, sans-serif, Trebuchet MS;font-size: 14px;line-height: 38px;
																			color: #500050;text-align: center;text-decoration: none !important;padding-bottom: 1px;width: 100%;font-weight: bold;display: inline-block;">
                                                                            <span  style="color:#500050;">SIGN IN NOW</span></a></td>
																	</tr>
																</tbody>
															</table>
															</td>
                                                        </tr>
                                                        <!-- br -->
														<tr>
															<td height="5">&nbsp;</td>
														</tr>
													</tbody>
												</table>
												</td>
												<td class="wspacw" width="35">&nbsp;</td>
											</tr>
										</tbody>
									</table>
									</td>
                                </tr>
                                <!-- welcome email content end -->
                               <tr>
	                                <td style="text-align: center;" ><p style="color: #535353">
		                                Thanks for shopping with<a href="" style="color:#06555c;text-decoration: none;font-weight: 600"> The Brownie Studio!</a></p>
                                	</td>
                                </tr>

							</tbody>
						</table>
						</td>
					</tr>
						<!-- footer -->
					<tr>
						<td valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tbody>
								<tr>
									<!-- <td width="28">&nbsp;</td> -->
									<td>
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
												<td class="textcntr" style="font-family: Lato, Arial, sans-serif, 'Trebuchet MS';
												font-size: 15px;line-height: 25px;color: rgb(97, 97, 97);font-weight: 700;text-align: center;padding-top: 30px;padding-bottom: 10px;">
                                                    Follow us for our latest deals, tips and advice&nbsp;
                                                </td>
												<td height="36">&nbsp;</td>
											</tr>
											<tr>
												<td align="center">
												<table align="center" border="0" cellpadding="0" cellspacing="0">
													<tbody>
														<tr>
                                                            <td>
                                                                <span class="sg-image" >
                                                                    <a href="https://www.facebook.com/thebrowniestudio" target="_blank" >
																		<img src="https://yellowmart.biz/browniestudio/img/fb.png" style="width:25px;height:25px;">
                                                                    </a>
                                                                    </span>
                                                                </td>
															<td width="25">&nbsp;</td>
															<td>
                                                                <span class="sg-image" >
                                                                    <a href="https://instagram.com/thebrowniestudio.official?igshid=5nw1rybpm0z5" target="_blank" >
																		<img src="https://yellowmart.biz/browniestudio/img/insta.png" style="width:25px;height:25px;">     
                                                                    </a>
                                                                </span>
                                                            </td>
															
															<td width="25">&nbsp;</td>
															<td>
                                                                <span class="sg-image" >
                                                                    <a href="mailto:thebrowniestudio@gmail.com" target="_blank" >
																		<img src="https://yellowmart.biz/browniestudio/img/mail.png" style="width:25px;height:25px;">     
                                                                    </a>
                                                                </span>
                                                            </td>
														</tr>
													</tbody>
												</table>
												</td>
											</tr>
											<tr>
												<td height="36">&nbsp;</td>
											</tr>
											<tr>
                                                <td style="font-family:Helvetica, Arial, sans-serif, Trebuchet MS; font-size:12px; line-height:18px; color:#616161; text-align: center;"><em>You&rsquo;re receiving this email because you&rsquo;ve registered on <a href="https://yellowmart.biz/browniestudio/" style="text-decoration: none;" target="_blank" ><span style="color:#740606;">thebrowniestudio.com</span></a>.<br /><br/>
                                                    
												</em></td>
                                            </tr>
                                            <tr  bgcolor="#c4ab3f" style="font-family: Helvetica, Arial, sans-serif, Trebuchet MS;font-size: 12px;line-height: 18px;color: #F7F7F7;text-align: center;">
                                                <td style="padding-top: 15px;padding-bottom: 15px;">
                                                    <bold>Address:</bold> 77, Pillayar Koil Street, Shenoy Nagar, Chennai, Tamil Nadu, India - 600030
                                                    <br/>
                                                    <a  style="text-decoration: none;color:#F7F7F7" href="tel:+91 8939621467"><span>Click Here To Call Support +91 8939621467</span></a>
                                                    <p><a style="text-decoration: none;color:#F7F7F7" href="mailto:thebrowniestudio@gmail.com">thebrowniestudio@gmail.com</a></p>
                                                </td>
                                                <!-- <td>
                                                    <br/> +91 75022 01999
                                                </td>
                                                <td>
                                                    
                                                    <br/>hello@yellowmart.co.in
                                                </td> -->
                                            </tr>
											<tr>
												<td height="15">&nbsp;</td>
											</tr>
										</tbody>
									</table>
									</td>
									<!-- <td width="28">&nbsp;</td> -->
								</tr>
							</tbody>
						</table>
						</td>
                    </tr>
                    <!-- footer end -->
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</body>
</html>
	