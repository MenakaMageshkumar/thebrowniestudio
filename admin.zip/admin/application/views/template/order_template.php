<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
        <link href="https://fonts.googleapis.com/css?family=Lato:400,300,700,400italic" rel="stylesheet" type="text/css" />
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
        <link rel="icon" href="https://yellowmart.co.in/images/favicon.ico" sizes="16x16" type="image/ico">
		 <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/email_template.css">  -->
		 <style type="text/css">
		/* custom code */
		
				/* responsive code for mobile view */
				.ReadMsgBody {
					width: 100%;
				}
				.ExternalClass {
					width: 100%;
				}
				.yshortcuts {
					color: #ffffff;
				}
				.yshortcuts a span {
					color: #ffffff;
					border-bottom: none !important;
					background: none !important;
				}
				/*Hotmail and Yahoo specific code*/
				body {
					-webkit-text-size-adjust: 100%;
					-ms-text-size-adjust: 100%;
					-webkit-font-smoothing: antialiased;
					margin: 0 !important;
					padding: 0 !important;
					width: 100% !important;
				}
				p {
					margin: 0px !important;
					padding: 0px !important;
				}
				th {
					font-weight: normal !important;
				}
				.appleLinks a {
					color: #e3e3f1 !important;
					text-decoration: none !important;
				}
				.button-container {
					margin: 0 auto !important;
					width: 60% !important;
				}
				/* mouse over link title */
				.titletxt {
					color: #616161;
					text-decoration: none;
				}
				.titletxt:hover {
					color: #545454;
					text-decoration: none;
				}
				/* mouse over link cta */
				/*-----Mobile specific code------*/
				@media only screen and (max-width:799px) {
				body {
					width: auto !important;
				}
				table[class="main"] {
					max-width: 480px !important;
					width: 100% !important;
				}
				img[class="img1"] {
					max-width: 150px !important;
					width: 100% !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				img[class="img2"] {
					max-width: 100% !important;
					width: 100% !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				img[class="banner"] {
					max-width: 100% !important;
					width: 100% !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				img[class="spacerimg"] {
					max-width: 0px !important;
					width: 0px !important;
					display: none !important;
				}
				th[class="stack1"] {
					display: block !important;
					width: 100% !important;
					height: auto !important;
					text-align: center !important;
				}
				th[class="stack2"] {
					display: block !important;
					width: 100% !important;
					height: auto !important;
					margin-top: 15px !important;
				}
				th[class="sphide"] {
					display: none !important;
					width: 0px;
				}
				td[class="textcntr"] {
					text-align: center !important;
					padding-left: 10px;
					padding-right: 10px;
				}
				td[class="button"] {
					max-width: 180px !important;
					width: 180px !important;
					display: block;
					margin: 0 auto;
					background-color: #faad47;
					border-radius: 2px;
					-moz-border-radius: 2px;
					-webkit-border-radius: 2px;
				}
				td[class="hspace"] {
					height: 25px !important;
				}
				}
				@media only screen and (max-width: 479px) {
				body {
					width: auto !important;
				}
				table[class="main"] {
					max-width: 320px !important;
					width: 100% !important;
				}

				img[class="img1"] {
					max-width: 150px !important;
					height: auto;
					display: block;
					margin: 0 auto;
				}
				th[class="sphide22"] {
					display: none !important;
					width: 0px;
				}
				td[class="titlefsize"] {
					font-size: 20px !important;
					text-align: center !important;
				}
				td[class="wspacw"] {
					width: 6px !important;
				}
				th[class="midspacw"] {
					width: 8px !important;
				}
				td[class="textcntr"] {
					text-align: center !important;
				}
				table[class="logo_left"] {
					max-width: 100%;
					width: 100% !important;
					height: auto;
					margin: 0 auto;
					text-align: center !important;
				}
				img[class="logo_center"] {
					display: inherit !important;
				}
				td[class="cta1"] {
					max-width: 100% !important;
					width: 100% !important;
					background-color: #ffffff;
					border-radius: 2px;
					-moz-border-radius: 2px;
					-webkit-border-radius: 2px;
				}
				td[class="cta"] {
					max-width: 100% !important;
					width: 100% !important;
					background-color: #faad47;
					border-radius: 2px;
					-moz-border-radius: 2px;
					-webkit-border-radius: 2px;
				}
				img[class="spacerimg"] {
					max-width: 0px !important;
					width: 0px !important;
					display: none !important;
				}
				/* custom  */
				.logo_img
				{
					width: 150px!important;
					object-fit: contain;
					margin-left: 14px;
				}
				.mobile_app_top_right
				{
					text-decoration: unset;
					float: right;
					font-family: 'Lato';
					font-size: 9.5px;
				}
				.banner_img_email
				{
					width: 100%;
					object-fit: cover;
					height:auto!important;
				}
				}
				.im {
                    color: #535353!important;
                }
				/* mobile view end */
				
		</style>
	    <title>YellowMart Email</title>

</head>
<body  bgcolor="#fff" style="margin:0px;">
<table bgcolor="#fff" cellpadding="0" cellspacing="0" width="100%">
	<tbody>
		<tr>
			<td  align="center">
			<table align="center"  cellpadding="0" cellspacing="0" class="main" width="600">
				<tbody>
					<tr>
						<td valign="top">
						<table  border="0"  width="100%"cellpadding="0" cellspacing="0" >
							<tbody>
                                <!-- header -->
								<tr>
									<td bgcolor="#fff" style="padding-top:25px;padding-bottom: 25px;" >
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
												<td>
                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                                        <tbody>
                                                            <tr>
                                                                <td  align="left">
                                                                <table cellpadding="0" cellspacing="0" border="0" class="logo_left">
                                                                    <tbody>   
                                                                        <tr>
                                                                            <td align="center">
                                                                                <a href="" target="_blank">
                                                                                    <img alt="logo" border="0" style="width: 190px;object-fit: contain;margin-left:14px;" class="logo_center logo_img"  src="<?php echo base_url();?>img/logo.png"  />
                                                                                </a>
                                                                            </td>
                                                                        </tr>
                                                                    
                                                                    </tbody>
                                                                </table>
                                                                </td> 
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                
												<td width="12">&nbsp;</td>
											</tr>
										</tbody>
									</table>
									</td>
                                </tr>
                                <!-- header end -->
                                <!-- banner -->
								<!--<tr>-->
								<!--	<td valign="top">-->
        <!--                                <span class="sg-image" >-->
        <!--                                     <a href="" target="_blank">-->
        <!--                                            <img alt="banner" border="0" class="banner banner_img_email" style="object-fit:cover;" height="245" width="100%" src="https://cdn.pixabay.com/photo/2018/03/22/02/37/email-3249062_960_720.png"  />-->
        <!--                                        </a>-->
        <!--                                    </span>-->
        <!--                                </td>-->
        <!--                        </tr>-->
                                <!-- banner end -->
                                <!-- welcome email content -->
								<tr>
									<td  style="background-image: url('https://yellowmart.co.in/images/about_bg.png');background-position: center;background-size: contain;">
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
											
												<td>
												<table border="0" cellpadding="0" cellspacing="0" width="100%">
													<tbody>
                                                        <!-- welcome title -->
														<tr>
                                                            <td  style="font-family: Lato, Arial, sans-serif, Trebuchet MS;font-size: 26px;line-height: 32px;color: #06555c;text-align: center;font-weight: 700;padding-top: 25px;">
                                                               <?php echo $heading; ?></td>
                                                        </tr>
                                                        <!-- br -->
														<tr>
															<td height="12">&nbsp;</td>
                                                        </tr>
                                                        <!-- welcome content -->
														<tr>
                                                            <td  style="font-family: Lato, Arial, sans-serif, Trebuchet MS;
															font-size: 13px;line-height: 26px;color: #500050!important;text-align: left;">
                                                             <!--We're happy you're here and excited to help you sell online. Your next step is to confirm your email address, so that we know exactly where to send your sales notification nd other important information-->
                                                             <?php echo $message;?>
                                                            </td>
                                                        </tr>
                                                        <!-- br -->
														<tr>
															<td height="5">&nbsp;</td>
                                                        </tr>
                                                       
                                                       <br>
                                                        	
													
													
                            						<!-- ----------------------------------------Delivery Address-------------------------------------------->
													
														<tr>
															<td height="2">&nbsp;</td>
														</tr>	
<!-- ----------------------------------------Delivery Address END-------------------------------------------->
                                                        <!-- br -->
                                                        <!-- ----------------------------------------Order item-------------------------------------------->
														<tr>
															<td  style="font-family: Lato, Arial, sans-serif, Trebuchet MS;
															font-size: 14px;line-height: 26px;color: #500050;text-align: left;">

															<p style="color: #500050;font-weight: 500; text-decoration: underline;font-weight: 600;">
																Item Details:
															</p>
															</td>
														</tr>
														<tr>
															<td height="1">&nbsp;</td>
                                                        </tr>
														<tr>
															<td>
																<table border="0"  width="100%"cellpadding="0" cellspacing="0" bgcolor="#ffffff" style=" border-collapse:collapse;border-spacing: 0;color: #4a4a4d;border:1px solid #cecfd5;width:100%">
																	<thead style="background: #395870;background: linear-gradient(#451681, #3c1173);color: #fff;font-size: 11px;text-transform: uppercase;">
																	  <tr>
																		<th scope="col"  style="padding: 10px 15px;vertical-align: middle;">
																			S.No
																		</th>
																		<th scope="col"  style="padding: 10px 15px;vertical-align: middle;">
																			Item Image
																		</th>
																		<th scope="col"  style="padding: 10px 15px;vertical-align: middle;">
																			Item Name
																		</th>
																		<th scope="col" style="padding: 10px 15px;vertical-align: middle;">
																			Qty
																		</th>
																		<!--<th scope="col" style="padding: 10px 15px;vertical-align: middle;">-->
																		<!--	Delivery Date-->
																		<!--</th>-->
																		<!--<th scope="col" style="padding: 10px 15px;vertical-align: middle;">-->
																		<!--	Delivery Time-->
																		<!--</th>-->
																		<th scope="col" style="padding: 10px 5px;vertical-align: middle;">
																			Unit Price
																		</th>
																		<th scope="col" style="padding: 10px 5px;vertical-align: middle;">
																			Total Price
																		</th>
																	  </tr>
																	</thead>
																	<tbody>

                                                                             <?php
                                                                        if(!empty($item_dtl)){
                                                                          $i = 0;
                                                                          foreach($item_dtl as $itm) {
                                                                            $var_String = $itm->varient_name;
                                                                            $item_var_cu = explode(';', $var_String);
                                                                              $item_time_1 = $itm->preferred_del_time;
                                                                              if($item_time_1 == "")
                                                                              {
                                                                                    $item_time = "---";
                                                                              }
                                                                              else
                                                                              {
                                                                                  $item_time =  $item_time_1;
                                                                              }
                                                                              $originalDate = $itm->preferred_del_date;
                                                                              $item_date_1 = date("d/m/Y", strtotime($originalDate));
                                                                                if( $item_date_1 == "30-11--0001")
                                                                                {
                                                                                    $item_date = "---";
                                                                                }
                                                                                else
                                                                                {
                                                                                    $item_date =  $item_date_1;
                                                                                }
                                                                           ?>
																	  <tr>
						 <!------------------------- S.NO---------------------------- -->
																		<td style="padding: 10px 15px;vertical-align: middle; border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align: center;">
																			<?php echo ++$i; 
																	
																		?>
																		</td>
						 <!------------------ S.NO End------------------------------------ -->
						 <!-------------------------------------images---------------------->
						 	                                            <td style="padding: 10px 15px;vertical-align: middle; border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align: center;">
																		    <img src="<?php print_r(base_url('../').$itm->product_image);?>" style="width:100px;height:100px">	
																		</td>
						  <!-------------------------------------images End---------------------->
						 <!------------------------- Item Name---------------------------- -->

																	    <td class="item-stock" style="padding: 2px 3px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;overflow-wrap: anywhere;">
																	            <?php print_r($itm->product_name);?> <br>
																	            <!----------blank space----------------->
																	            <h1 style="color: #fff0;font-size: 1px!important;">blank space</h1>
																	             <!----------blank space----------------->
																	             <?php if(strtoupper($item_var_cu[1])=="EGG") { ?>
                                                                                     <span style="background: #dc3545;color: white;border-radius: 4px;font-size: 12px;padding: 0.2em 0.4em;">Egg</span> <br>
                                                                                     <?php } else { ?> 
                                                                                     <span style="background: #28a745;color: white;border-radius: 4px;font-size: 12px;padding: 0.2em 0.4em;">Eggless</span> <br>
                                                                                     <?php } ?>
																	             <!--<span style="color:#4a4a4d">Type:&nbsp;<?= isset($item_var_cu[1])?$item_var_cu[1]:"-";?><br></span> -->
																	             <!----------blank space----------------->
																	            <h1 style="color: #fff0;font-size: 1px!important;">blank space</h1>
																	             <!----------blank space----------------->
                                                                                 <span style="color:#4a4a4d"><?= isset($item_var_cu[0])?$item_var_cu[0]:"-";?></span> <br>
                                                                                 <!----------blank space----------------->
																	            <h1 style="color: #fff0;font-size: 1px!important;">blank space</h1>
																	             <!----------blank space----------------->
                                                                                 <span style="color:#4a4a4d"><strong>Delivery Date:</strong>&nbsp;<?php print_r($item_date);?></span> <br>
                                                                                  <!----------blank space----------------->
																	            <h1 style="color: #fff0;font-size: 1px!important;">blank space</h1>
																	             <!----------blank space----------------->
                                                                                  <span style="color:#4a4a4d"><strong>Delivery Time:</strong>&nbsp;<?php print_r($item_time);?></span> <br>
                                                                                  <!----------blank space----------------->
																	            <h1 style="color: #fff0;font-size: 1px!important;">blank space</h1>
																	             <!----------blank space----------------->
																	            
																	            
																	           <!--<span style="color:#4a4a4d">Weight:&nbsp;<?php print_r($item_var_cu[0]);?> <br></span> -->
																	           <!-- <span style="color:#4a4a4d">Type:&nbsp;<?php print_r($item_var_cu[1]);?> <br></span> -->
																	           <!--   <span style="color:#4a4a4d">Shape:&nbsp;<?php print_r($item_var_cu[2]);?> <br></span> -->
										
                                            						           <!--<span style="color:#4a4a4d">Shape:&nbsp;<?= isset($item_var_cu[2])? $item_var_cu[2]:"-";?> <br></span> -->
                                            						            
                                    						                    <?php
                                                                                if (isset($item_var_cu[2])) {?>
                                                                                   <span style="color:#4a4a4d">Shape:&nbsp;<?php print_r($item_var_cu[2]);?> <br></span>
                                                                               <?php }else{?>
                                                                                   <span style="color:#4a4a4d"></span>
                                                                               <?php } ?>
																		</td>
						 <!------------------------- Item Name End---------------------------- -->
						 <!------------------------- QTy---------------------------- -->

																		<td  style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align: center;">
																		        <?php print_r($itm->quantity);?>
																		</td>
						 <!------------------------- QTy End---------------------------- -->
						  <!------------------------- Delivery ---------------------------- -->

																		<!--<td  style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align: center;">-->
																		<!--        <?php print_r($item_date);?>-->
																		<!--</td>-->
						 <!------------------------- Delivery End---------------------------- -->
						  <!------------------------- Time ---------------------------- -->

																		<!--<td  style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align: center;">-->
																		<!--         <?php print_r($item_time);?>-->
																		<!--</td>-->
						 <!------------------------- Time End---------------------------- -->
						 <!------------------------- Unit Price---------------------------- -->

																		<td  style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align:left;">
																			&#x20b9;   <?php print_r($itm->rate);?>	
																		</td>
						 <!------------------------- Unit Price END---------------------------- -->
						 <!------------------------- Total Price---------------------------- -->

																		<td  style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align:left;">
																			&#x20b9;   <?php print_r($itm->price);?>	
																		</td>
						 <!------------------------- Total Price End---------------------------- -->

																	  </tr>
																	  	<?php }}?>																				  
																	</tbody>
																	
																	<tfoot style="text-align: right">
																	   <?php if(round($itm->coupon_discount)>0){ ?> 
																	  <tr class="text-offset">
						 <!------------------------- Packing Charge---------------------------- -->

																		<td colspan="5" style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;">
																		    Coupon Discount
																		</td>
																		<td style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align:left">
																		   &#x20b9;	<?php print_r(round($itm->coupon_discount));?>
						 <!------------------------- Packing Charge END---------------------------- -->
																		</td>

																	  </tr>
																	  	<?php } ?>
																	  	 	<?php if(round($itm->packing_charge)>0){ ?> 
																	  <tr class="text-offset">
						 <!------------------------- Packing Charge---------------------------- -->

																		<td colspan="5" style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;">
																			Packing Charge
																		</td>
																		<td style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align:left">
																		   &#x20b9;	<?php print_r($itm->packing_charge);?>
						 <!------------------------- Packing Charge END---------------------------- -->
																		</td>

																	  </tr>
																	  <?php } ?>
																	  <tr class="text-offset">
						 <!------------------------- Delivery Charge---------------------------- -->

																		<td colspan="5" style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;">
																			Delivery Charge
																		</td>
																		<td style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align:left">
																		  &#x20b9;<?php
																		  if($itm->changesin_deliverycharge>0){
																		      print_r($itm->changesin_deliverycharge); //old delivery charge
																		  }else{ //changesin_deliverycharge ==0 means no changes in delivery charge so show deliverycharge column
																		      print_r($itm->delivery_charge); 
																		  }
																		  ?>
																		</td>
																	</tr>
																		<tr class="text-offset">
																		<?php if($itm->changesin_deliverycharge>0){ ?>
																		<td colspan="5" style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;">
																			Updated Delivery Charge
																		</td>
																		<td style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align: left;">
																		  &#x20b9;<?php print_r($itm->delivery_charge);?>
																		</td>
																		<?php } ?>
						 <!------------------------- Delivery Charge END---------------------------- -->

																	  </tr>
																	  <tr class="text-offset">
						 <!------------------------- Sub Total---------------------------- -->

																		<td colspan="5" style="padding: 10px 15px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5; color:#401479;font-weight:bold;">
																			SubTotal
																		</td>
																		<td style="padding: 10px 5px;vertical-align: middle;border-bottom: 1px solid #cecfd5;border-right: 1px solid #cecfd5;text-align:left">
																		  &#x20b9; <?php $final_amt = $itm->total_amount;
																		  print_r($final_amt);?>
																		</td>
						 <!-------------------------Sub Total End---------------------------- -->

																	  </tr>
																	  
																	</tfoot>
																  </table>		
															</td>
														</tr>
														<tr>
															<td height="5">&nbsp;</td>
                                                        </tr>														
                                                        <!-- br -->
<!-- ----------------------------------------Order item END-------------------------------------------->
														<tr>
															<td height="5">&nbsp;</td>
														</tr>
													</tbody>
												</table>
												</td>
												<td class="wspacw" width="15">&nbsp;</td>
											</tr>
										</tbody>
									</table>
									</td>
                                </tr>
                                <!-- welcome email content end -->
                                 <tr>
                                   	<table border="0" cellpadding="0" cellspacing="0" width="100%" style="padding-left:10px">
                                   	    <p style="color: #500050;font-weight: 500; text-decoration: underline;font-weight: 600; font-size: 14px;">
									        Customer Information:
										</p>
										<br>
										<tbody>
											<tr>
                                               <td style="text-align: left;" width="30" >
                                                   <p style="color: #500050">
                                                     <strong style="font-size: 15px;">Shipping Address</strong>
                                                      <br>
                                                   	<p style="color: #500050;font-weight: 500;text-transform: capitalize;">
            															   <?php if($del_address)
            															    { ?>
            															     <span><?php print_r($del_address[0]->deliveryto_name);?>,&nbsp;</span><br>
            															    
                                                                            <span><?php print_r($del_address[0]->address1);?>,&nbsp;</span>
                                                                            <?php
                                                                            $add_2 = $del_address[0]->address2;
                                                                            if($add_2 == ""){ }else
                                                                            {?>
                                                                             <span><?php print_r($del_address[0]->address2);?>,&nbsp; </span>
                                                                            <?php }?>
                                                                            <span><?php print_r($del_address[0]->landmark);?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->area); ?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->city); ?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->district);?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->state); ?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->pincode); ?>,&nbsp;</span><br>
                                                                             <span>+91<?php print_r($del_address[0]->deliveryto_contact); ?></span>
                 
                                                                        <?php } ?>
                                                                           
                                        
            															</p>
                                                    </p>
                                               </td>
                                                <td class="wspacw" width="40">&nbsp;</td>
                                               <td style="text-align: left;" width="30">
                                                   <p style="color: #500050">
                                                    <strong style="font-size: 15px;">Billing Address</strong>
                                                      <br>
                                                   	<p style="color: #500050;font-weight: 500;text-transform: capitalize;">
            															   	<?php if($del_address)
            															    { ?>
            															     <span><?php print_r($del_address[0]->deliveryto_name);?>,&nbsp;</span><br>
            															     
                                                                            <span><?php print_r($del_address[0]->address1);?>,&nbsp;</span>
                                                                            <?php
                                                                            $add_2 = $del_address[0]->address2;
                                                                            if($add_2 == ""){ }else
                                                                            {?>
                                                                             <span><?php print_r($del_address[0]->address2);?>,&nbsp; </span>
                                                                            <?php }?>
                                                                            <span><?php print_r($del_address[0]->landmark);?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->area); ?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->city); ?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->district);?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->state); ?>,&nbsp;</span>
                                                                            <span><?php print_r($del_address[0]->pincode); ?>,&nbsp;</span><br>
                                                                            <span>+91<?php print_r($del_address[0]->deliveryto_contact); ?></span><br>
                 
                                                                        <?php } ?>
                                                                           
                                        
            															</p>
                                                    </p>
                                               </td>
                                            </tr>
                                            <br>
                                            <br>
                                            <tr>
                                               <td style="text-align: left;" width="30" >
                                                   <p style="color: #500050">
                                                     <strong style="font-size: 15px;">Shipping Method</strong>
                                                      <br>
                                                   	<p style="color: #500050;font-weight: 500;text-transform: capitalize;">
            											Chennai				  
            															</p>
                                                    </p>
                                               </td>
                                                <td class="wspacw" width="40">&nbsp;</td>
                                               <td style="text-align: left;" width="30">
                                                   <p style="color: #500050">
                                                    <strong style="font-size: 15px;">Payment Method</strong>
                                                      <br>
                                                   	<p style="color: #500050;font-weight: 500;text-transform: capitalize;">
                                                   	    <?php $final_amt = $itm->total_amount; ?>
																		  Online :&nbsp;&#x20b9; <?php print_r($final_amt);?>
            										</p>
                                                    </p>
                                               </td>
                                            </tr>
                                        </tbody>
                                   </table>
                                  
                                </tr> 
                                <br><br>
                               <tr>
                                   <td style="text-align: center;color:#500050" >
                                       <p style="color: #500050">
                                         Please provide feedback on your experience with <strong>The Brownie Studio</strong> on the link below,     <br><br>
                                          URL: <a href="https:// Thebrowniestudio.co.in/">https:// Thebrowniestudio.co.in/</a>
                                         <br><br>
                                          <?php if($del_address) { ?>
									       
                                          ORDER TRACK ID: <a href="<?php echo $del_address[0]->track_id;?>"><?php echo $del_address[0]->track_id;?></a>
                                          
                                         <?php } ?>
										<tr>
											<td height="5">&nbsp;</td>
                                        </tr>	
            							<!-- Sign in button -->
										<tr>
											<td align="center">
											<table cellpadding="0" cellspacing="0" width="180">
												<tbody>
													<tr>
													       <?php if(isset($invoice_data) || !empty($invoice_data)){?>
                                                        <td align="center" bgcolor="#FFFFFF" style="border-radius: 2px;
														-moz-border-radius: 2px;-webkit-border-radius: 2px;border-top: 1px solid #500050;border-left: 1px solid #500050;border-bottom: 1px solid #500050;border-right: 1px solid #500050;" class="cta1 " height="40"  width="100">
                                                            <a href="<?= base_url("../browniestudio/home/invoice/".$invoice_data[0]->store_id)."/".$invoice_data[0]->UTN_number."/".$invoice_data[0]->inv_no ?>" target="_blank"   style="font-family: Lato, Arial, sans-serif, Trebuchet MS;font-size: 15px;line-height: 38px;
															color: #500050;text-align: center;text-decoration: none !important;padding-bottom: 0px;width: 100%;font-weight: 400;display: inline-block;">
                                                            DOWNLOAD INVOICE</a>
                                                        </td>
                                                         <?php }else { ?>
                                                        <td>
                                                            
                                                        </td>
                                                         <?php }?>
													</tr>
												</tbody>
											</table>
											</td>
                                        </tr>
                                        <!-- br --><br><br>
                                        <span style="color: #500050">Regards,</span> <br>
                                        <strong style="color: #500050">  The Brownie Studio </strong>   <br>
                                        <i style="color: #500050">Powered by YellowMart</i> <br>
                                        </p>
                                   </td>
	                               
                                </tr>
                                

							</tbody>
						</table>
						</td>
					</tr>
					<br><br>
						<!-- footer -->
						 <tr>
                                  
	                                <td style="text-align: center;" ><p style="color: #535353">
		                                Thanks for shopping with<a href="" style="color:#06555c;text-decoration: none;font-weight: 600"> The Brownie Studio!</a></p>
                                	</td>
                                </tr>
					<tr>
						<td valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tbody>
								<tr>
									<!-- <td width="28">&nbsp;</td> -->
									<td>
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
												<td class="textcntr" style="font-family: Lato, Arial, sans-serif, 'Trebuchet MS';
												font-size: 15px;line-height: 25px;color: rgb(97, 97, 97);font-weight: 700;text-align: center;padding-top: 30px;padding-bottom: 10px;">
                                                    Follow us for our latest deals, tips and advice&nbsp;
                                                </td>
												<td height="36">&nbsp;</td>
											</tr>
											<tr>
												<td align="center">
												<table align="center" border="0" cellpadding="0" cellspacing="0">
													<tbody>
														<tr>
                                                            <td>
                                                                <span class="sg-image" >
                                                                    <a href="https://www.facebook.com/thebrowniestudio" target="_blank" >
																		<img src="<?php echo base_url();?>img/fb.png" style="width:25px;height:25px;">
                                                                    </a>
                                                                    </span>
                                                                </td>
															<td width="25">&nbsp;</td>
															<td>
                                                                <span class="sg-image" >
                                                                    <a href="https://instagram.com/thebrowniestudio.official?igshid=5nw1rybpm0z5" target="_blank" >
																		<img src="<?php echo base_url();?>img/insta.png" style="width:25px;height:25px;">     
                                                                    </a>
                                                                </span>
                                                            </td>
															
															<td width="25">&nbsp;</td>
															<td>
                                                                <span class="sg-image" >
                                                                    <a href="mailto:thebrowniestudio@gmail.com" target="_blank" >
																		<img src="<?php echo base_url();?>img/mail.png" style="width:25px;height:25px;">     
                                                                    </a>
                                                                </span>
                                                            </td>
														</tr>
													</tbody>
												</table>
												</td>
											</tr>
											<tr>
												<td height="36">&nbsp;</td>
											</tr>
											<tr>
                                                <td style="font-family:Helvetica, Arial, sans-serif, Trebuchet MS; font-size:12px; line-height:18px; color:#616161; text-align: center;"><em>You&rsquo;re receiving this email because you&rsquo;ve registered on <a href="<?php echo base_url();?>" style="text-decoration: none;" target="_blank" ><span style="color:#740606;">thebrowniestudio.com</span></a>.<br /><br/>
                                                    
												</em></td>
                                            </tr>
                                            <tr  bgcolor="#c4ab3f" style="font-family: Helvetica, Arial, sans-serif, Trebuchet MS;font-size: 12px;line-height: 18px;color: #F7F7F7;text-align: center;">
                                                <td style="padding-top: 15px;padding-bottom: 15px;">
                                                    <bold>Address:</bold> 77, Pillayar Koil Street, Shenoy Nagar, Chennai, Tamil Nadu, India - 600030
                                                    <br/>
                                                    <a  style="text-decoration: none;color:#F7F7F7" href="tel:+91 8939621467"><span>Click Here To Call Support +91 8939621467</span></a>
                                                    <p><a style="text-decoration: none;color:#F7F7F7" href="mailto:thebrowniestudio@gmail.com">thebrowniestudio@gmail.com</a></p>
                                                </td>
                                                <!-- <td>
                                                    <br/> +91 75022 01999
                                                </td>
                                                <td>
                                                    
                                                    <br/>hello@yellowmart.co.in
                                                </td> -->
                                            </tr>
											<tr>
												<td height="15">&nbsp;</td>
											</tr>
										</tbody>
									</table>
									</td>
									<!-- <td width="28">&nbsp;</td> -->
								</tr>
							</tbody>
						</table>
						</td>
                    </tr>
                    <!-- footer end -->
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</body>
</html>
	